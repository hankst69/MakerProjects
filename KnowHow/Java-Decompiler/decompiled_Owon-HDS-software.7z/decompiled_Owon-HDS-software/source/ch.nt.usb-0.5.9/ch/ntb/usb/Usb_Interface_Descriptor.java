package ch.ntb.usb;

public class Usb_Interface_Descriptor extends Usb_Descriptor {
   public static final int USB_MAXINTERFACES = 32;
   private byte bInterfaceNumber;
   private byte bAlternateSetting;
   private byte bNumEndpoints;
   private byte bInterfaceClass;
   private byte bInterfaceSubClass;
   private byte bInterfaceProtocol;
   private byte iInterface;
   private Usb_Endpoint_Descriptor[] endpoint;
   private byte[] extra;
   private int extralen;

   @Override
   public String toString() {
      return "Usb_Interface_Descriptor bNumEndpoints: 0x" + Integer.toHexString(this.bNumEndpoints);
   }

   public byte getBAlternateSetting() {
      return this.bAlternateSetting;
   }

   public byte getBInterfaceClass() {
      return this.bInterfaceClass;
   }

   public byte getBInterfaceNumber() {
      return this.bInterfaceNumber;
   }

   public byte getBInterfaceProtocol() {
      return this.bInterfaceProtocol;
   }

   public byte getBInterfaceSubClass() {
      return this.bInterfaceSubClass;
   }

   public byte getBNumEndpoints() {
      return this.bNumEndpoints;
   }

   public Usb_Endpoint_Descriptor[] getEndpoint() {
      return this.endpoint;
   }

   public byte[] getExtra() {
      return this.extra;
   }

   public int getExtralen() {
      return this.extralen;
   }

   public byte getIInterface() {
      return this.iInterface;
   }
}
