package ch.ntb.usb;

public class Usb_Descriptor {
   public static final int USB_DT_DEVICE = 1;
   public static final int USB_DT_CONFIG = 2;
   public static final int USB_DT_STRING = 3;
   public static final int USB_DT_INTERFACE = 4;
   public static final int USB_DT_ENDPOINT = 5;
   public static final int USB_DT_HID = 33;
   public static final int USB_DT_REPORT = 34;
   public static final int USB_DT_PHYSICAL = 35;
   public static final int USB_DT_HUB = 41;
   public static final int USB_DT_DEVICE_SIZE = 18;
   public static final int USB_DT_CONFIG_SIZE = 9;
   public static final int USB_DT_INTERFACE_SIZE = 9;
   public static final int USB_DT_ENDPOINT_SIZE = 7;
   public static final int USB_DT_ENDPOINT_AUDIO_SIZE = 9;
   public static final int USB_DT_HUB_NONVAR_SIZE = 7;
   private byte bLength;
   private byte bDescriptorType;

   public byte getBDescriptorType() {
      return this.bDescriptorType;
   }

   public byte getBLength() {
      return this.bLength;
   }
}
