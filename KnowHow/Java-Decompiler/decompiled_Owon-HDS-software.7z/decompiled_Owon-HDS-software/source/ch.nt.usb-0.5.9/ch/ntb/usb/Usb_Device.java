package ch.ntb.usb;

public class Usb_Device {
   private Usb_Device next;
   private Usb_Device prev;
   private String filename;
   private Usb_Bus bus;
   private Usb_Device_Descriptor descriptor;
   private Usb_Config_Descriptor[] config;
   private byte devnum;
   private byte num_children;
   private Usb_Device children;
   public long devStructAddr;

   public Usb_Bus getBus() {
      return this.bus;
   }

   public Usb_Device getChildren() {
      return this.children;
   }

   public Usb_Config_Descriptor[] getConfig() {
      return this.config;
   }

   public Usb_Device_Descriptor getDescriptor() {
      return this.descriptor;
   }

   public byte getDevnum() {
      return this.devnum;
   }

   public String getFilename() {
      return this.filename;
   }

   public Usb_Device getNext() {
      return this.next;
   }

   public byte getNumChildren() {
      return this.num_children;
   }

   public Usb_Device getPrev() {
      return this.prev;
   }

   @Override
   public String toString() {
      return "Usb_Device " + this.filename;
   }
}
