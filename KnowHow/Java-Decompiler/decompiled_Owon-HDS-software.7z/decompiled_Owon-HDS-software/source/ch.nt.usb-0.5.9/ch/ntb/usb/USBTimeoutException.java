package ch.ntb.usb;

public class USBTimeoutException extends USBException {
   private static final long serialVersionUID = -1065328371159778249L;

   public USBTimeoutException(String string) {
      super(string);
   }
}
