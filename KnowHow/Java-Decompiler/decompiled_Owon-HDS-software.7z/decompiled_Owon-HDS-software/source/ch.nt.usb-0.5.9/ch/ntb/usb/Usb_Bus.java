package ch.ntb.usb;

public class Usb_Bus {
   private Usb_Bus next;
   private Usb_Bus prev;
   private String dirname;
   private Usb_Device devices;
   private long location;
   private Usb_Device root_dev;

   public Usb_Device getDevices() {
      return this.devices;
   }

   public String getDirname() {
      return this.dirname;
   }

   public Usb_Bus getNext() {
      return this.next;
   }

   public Usb_Bus getPrev() {
      return this.prev;
   }

   public Usb_Device getRootDev() {
      return this.root_dev;
   }

   public long getLocation() {
      return this.location;
   }

   @Override
   public String toString() {
      return "Usb_Bus " + this.dirname;
   }
}
