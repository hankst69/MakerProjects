package ch.ntb.usb;

public class Usb_Interface {
   public static final int USB_MAXALTSETTING = 128;
   private Usb_Interface_Descriptor[] altsetting;
   private int num_altsetting;

   @Override
   public String toString() {
      return "Usb_Interface num_altsetting: 0x" + Integer.toHexString(this.num_altsetting);
   }

   public Usb_Interface_Descriptor[] getAltsetting() {
      return this.altsetting;
   }

   public int getNumAltsetting() {
      return this.num_altsetting;
   }
}
