package ch.ntb.usb;

import ch.ntb.usb.logger.LogUtil;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Device {
   private static final Logger logger = LogUtil.getLogger("ch.ntb.usb");
   private int maxPacketSize;
   private int idVendor;
   private int idProduct;
   private String filename;
   private String busName;
   private int dev_configuration;
   private int dev_interface;
   private int dev_altinterface;
   private long usbDevHandle;
   private boolean resetOnFirstOpen;
   private boolean resetDone;
   private int resetTimeout = 2000;
   private Usb_Device dev;

   protected Device(short idVendor, short idProduct) {
      this.resetOnFirstOpen = false;
      this.resetDone = false;
      this.maxPacketSize = -1;
      this.idVendor = idVendor;
      this.idProduct = idProduct;
      this.filename = null;
   }

   protected Device(short idVendor, short idProduct, String busName, String filename) {
      this.resetOnFirstOpen = false;
      this.resetDone = false;
      this.maxPacketSize = -1;
      this.idVendor = idVendor;
      this.idProduct = idProduct;
      this.busName = busName;
      this.filename = filename;
   }

   private void updateMaxPacketSize(Usb_Device device) throws USBException {
      this.maxPacketSize = -1;
      Usb_Config_Descriptor[] confDesc = device.getConfig();

      for (int i = 0; i < confDesc.length; i++) {
         Usb_Interface[] int_ = confDesc[i].getInterface();

         for (int j = 0; j < int_.length; j++) {
            Usb_Interface_Descriptor[] intDesc = int_[j].getAltsetting();

            for (int k = 0; k < intDesc.length; k++) {
               Usb_Endpoint_Descriptor[] epDesc = intDesc[k].getEndpoint();

               for (int l = 0; l < epDesc.length; l++) {
                  this.maxPacketSize = Math.max(epDesc[l].getWMaxPacketSize(), this.maxPacketSize);
               }
            }
         }
      }

      if (this.maxPacketSize <= 0) {
         throw new USBException("No USB endpoints found. Check the device configuration");
      }
   }

   private Usb_Device initDevice(int idVendorParam, int idProductParam, String busName, String filename) throws USBException {
      Usb_Bus bus = USB.getBus();

      for (Usb_Device device = null; bus != null; bus = bus.getNext()) {
         for (Usb_Device var8 = bus.getDevices(); var8 != null; var8 = var8.getNext()) {
            Usb_Device_Descriptor devDesc = var8.getDescriptor();
            if (busName != null && filename != null) {
               if (busName.compareTo(bus.getDirname()) == 0
                  && filename.compareTo(var8.getFilename()) == 0
                  && devDesc.getIdVendor() == this.idVendor
                  && devDesc.getIdProduct() == this.idProduct) {
                  logger.info("Device found. bus: " + bus.getDirname() + ", filename: " + var8.getFilename());
                  this.updateMaxPacketSize(var8);
                  return var8;
               }
            } else if (filename != null) {
               if (filename.compareTo(var8.getFilename()) == 0 && devDesc.getIdVendor() == this.idVendor && devDesc.getIdProduct() == this.idProduct) {
                  logger.info("Device found. bus: " + bus.getDirname() + ", filename: " + var8.getFilename());
                  this.updateMaxPacketSize(var8);
                  return var8;
               }
            } else if (busName != null) {
               if (busName.compareTo(bus.getDirname()) == 0 && devDesc.getIdVendor() == this.idVendor && devDesc.getIdProduct() == this.idProduct) {
                  logger.info("Device found. bus: " + bus.getDirname() + ", filename: " + var8.getFilename());
                  this.updateMaxPacketSize(var8);
                  return var8;
               }
            } else if (devDesc.getIdVendor() == this.idVendor && devDesc.getIdProduct() == this.idProduct) {
               logger.info("Device found. bus: " + bus.getDirname() + ", filename: " + var8.getFilename());
               this.updateMaxPacketSize(var8);
               return var8;
            }
         }
      }

      return null;
   }

   public void updateDescriptors() throws USBException {
      this.dev = this.initDevice(this.idVendor, this.idProduct, this.busName, this.filename);
   }

   public Usb_Device_Descriptor getDeviceDescriptor() {
      return this.dev == null ? null : this.dev.getDescriptor();
   }

   public Usb_Config_Descriptor[] getConfigDescriptors() {
      return this.dev == null ? null : this.dev.getConfig();
   }

   public void open(int configuration, int interface_, int altinterface) throws USBException {
      this.dev_configuration = configuration;
      this.dev_interface = interface_;
      this.dev_altinterface = altinterface;
      if (this.usbDevHandle != 0L) {
         throw new USBException("device opened, close or reset first");
      } else {
         this.dev = this.initDevice(this.idVendor, this.idProduct, this.busName, this.filename);
         if (this.dev != null) {
            long res = LibusbJava.usb_open(this.dev);
            if (res == 0L) {
               throw new USBException("LibusbJava.usb_open: " + LibusbJava.usb_strerror());
            }

            this.usbDevHandle = res;
         }

         if (this.dev != null && this.usbDevHandle != 0L) {
            this.claim_interface(this.usbDevHandle, configuration, interface_, altinterface);
            if (this.resetOnFirstOpen & !this.resetDone) {
               logger.info("reset on first open");
               this.resetDone = true;
               this.reset();

               try {
                  Thread.sleep((long)this.resetTimeout);
               } catch (InterruptedException var6) {
               }

               this.open(configuration, interface_, altinterface);
            }
         } else {
            throw new USBException("USB device with " + this.toString() + " not found on USB");
         }
      }
   }

   public void close() throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else {
         this.release_interface(this.usbDevHandle, this.dev_interface);
         if (LibusbJava.usb_close(this.usbDevHandle) < 0) {
            this.usbDevHandle = 0L;
            throw new USBException("LibusbJava.usb_close: " + LibusbJava.usb_strerror());
         } else {
            this.usbDevHandle = 0L;
            this.maxPacketSize = -1;
            logger.info("device closed");
         }
      }
   }

   public void reset() throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else {
         this.release_interface(this.usbDevHandle, this.dev_interface);
         if (LibusbJava.usb_reset(this.usbDevHandle) < 0) {
            this.usbDevHandle = 0L;
            throw new USBException("LibusbJava.usb_reset: " + LibusbJava.usb_strerror());
         } else {
            this.usbDevHandle = 0L;
            logger.info("device reset");
         }
      }
   }

   public int writeBulk(int out_ep_address, byte[] data, int size, int timeout, boolean reopenOnTimeout) throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else if (data == null) {
         throw new USBException("data must not be null");
      } else if (size > 0 && size <= data.length) {
         int lenWritten = LibusbJava.usb_bulk_write(this.usbDevHandle, out_ep_address, data, size, timeout);
         if (lenWritten >= 0) {
            logger.info("length written: " + lenWritten);
            if (logger.isLoggable(Level.FINEST)) {
               StringBuffer sb = new StringBuffer("bulkwrite, ep 0x" + Integer.toHexString(out_ep_address) + ": " + lenWritten + " Bytes sent: ");

               for (int i = 0; i < lenWritten; i++) {
                  sb.append("0x" + String.format("%1$02X", data[i]) + " ");
               }

               logger.info(sb.toString());
            }

            return lenWritten;
         } else if (lenWritten != LibusbJava.ERROR_TIMEDOUT) {
            throw new USBException("LibusbJava.usb_bulk_write: " + LibusbJava.usb_strerror());
         } else if (reopenOnTimeout) {
            logger.info("try to reopen");
            this.reset();
            this.open(this.dev_configuration, this.dev_interface, this.dev_altinterface);
            return this.writeBulk(out_ep_address, data, size, timeout, false);
         } else {
            throw new USBTimeoutException("LibusbJava.usb_bulk_write: " + LibusbJava.usb_strerror());
         }
      } else {
         throw new ArrayIndexOutOfBoundsException("invalid size: " + size);
      }
   }

   public int readBulk(int in_ep_address, byte[] data, int size, int timeout, boolean reopenOnTimeout) throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else if (data == null) {
         throw new USBException("data must not be null");
      } else if (size > 0 && size <= data.length) {
         int lenRead = LibusbJava.usb_bulk_read(this.usbDevHandle, in_ep_address, data, size, timeout);
         if (lenRead >= 0) {
            logger.info("length read: " + lenRead);
            if (logger.isLoggable(Level.FINEST)) {
               StringBuffer sb = new StringBuffer("bulkread, ep 0x" + Integer.toHexString(in_ep_address) + ": " + lenRead + " Bytes received: ");

               for (int i = 0; i < lenRead; i++) {
                  sb.append("0x" + String.format("%1$02X", data[i]) + " ");
               }

               logger.info(sb.toString());
            }

            return lenRead;
         } else if (lenRead != LibusbJava.ERROR_TIMEDOUT) {
            throw new USBException("LibusbJava.usb_bulk_read: " + LibusbJava.usb_strerror());
         } else if (reopenOnTimeout) {
            logger.info("try to reopen");
            this.reset();
            this.open(this.dev_configuration, this.dev_interface, this.dev_altinterface);
            return this.readBulk(in_ep_address, data, size, timeout, false);
         } else {
            throw new USBTimeoutException("LibusbJava.usb_bulk_read: " + LibusbJava.usb_strerror());
         }
      } else {
         throw new ArrayIndexOutOfBoundsException("invalid size: " + size);
      }
   }

   public int writeInterrupt(int out_ep_address, byte[] data, int size, int timeout, boolean reopenOnTimeout) throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else if (data == null) {
         throw new USBException("data must not be null");
      } else if (size > 0 && size <= data.length) {
         int lenWritten = LibusbJava.usb_interrupt_write(this.usbDevHandle, out_ep_address, data, size, timeout);
         if (lenWritten >= 0) {
            logger.info("length written: " + lenWritten);
            if (logger.isLoggable(Level.FINEST)) {
               StringBuffer sb = new StringBuffer("interruptwrite, ep 0x" + Integer.toHexString(out_ep_address) + ": " + lenWritten + " Bytes sent: ");

               for (int i = 0; i < lenWritten; i++) {
                  sb.append("0x" + String.format("%1$02X", data[i]) + " ");
               }

               logger.info(sb.toString());
            }

            return lenWritten;
         } else if (lenWritten != LibusbJava.ERROR_TIMEDOUT) {
            throw new USBException("LibusbJava.usb_interrupt_write: " + LibusbJava.usb_strerror());
         } else if (reopenOnTimeout) {
            logger.info("try to reopen");
            this.reset();
            this.open(this.dev_configuration, this.dev_interface, this.dev_altinterface);
            return this.writeInterrupt(out_ep_address, data, size, timeout, false);
         } else {
            throw new USBTimeoutException("LibusbJava.usb_interrupt_write: " + LibusbJava.usb_strerror());
         }
      } else {
         throw new ArrayIndexOutOfBoundsException("invalid size: " + size);
      }
   }

   public int readInterrupt(int in_ep_address, byte[] data, int size, int timeout, boolean reopenOnTimeout) throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else if (data == null) {
         throw new USBException("data must not be null");
      } else if (size > 0 && size <= data.length) {
         int lenRead = LibusbJava.usb_interrupt_read(this.usbDevHandle, in_ep_address, data, size, timeout);
         if (lenRead >= 0) {
            logger.info("length read: " + lenRead);
            if (logger.isLoggable(Level.FINEST)) {
               StringBuffer sb = new StringBuffer("interrupt, ep 0x" + Integer.toHexString(in_ep_address) + ": " + lenRead + " Bytes received: ");

               for (int i = 0; i < lenRead; i++) {
                  sb.append("0x" + String.format("%1$02X", data[i]) + " ");
               }

               logger.info(sb.toString());
            }

            return lenRead;
         } else if (lenRead != LibusbJava.ERROR_TIMEDOUT) {
            throw new USBException("LibusbJava.usb_interrupt_read: " + LibusbJava.usb_strerror());
         } else if (reopenOnTimeout) {
            logger.info("try to reopen");
            this.reset();
            this.open(this.dev_configuration, this.dev_interface, this.dev_altinterface);
            return this.readInterrupt(in_ep_address, data, size, timeout, false);
         } else {
            throw new USBTimeoutException("LibusbJava.usb_interrupt_read: " + LibusbJava.usb_strerror());
         }
      } else {
         throw new ArrayIndexOutOfBoundsException("invalid size: " + size);
      }
   }

   public int controlMsg(int requestType, int request, int value, int index, byte[] data, int size, int timeout, boolean reopenOnTimeout) throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else if (data == null) {
         throw new USBException("data must not be null");
      } else if (size >= 0 && size <= data.length) {
         int len = LibusbJava.usb_control_msg(this.usbDevHandle, requestType, request, value, index, data, size, timeout);
         if (len >= 0) {
            logger.info("length read/written: " + len);
            if (logger.isLoggable(Level.FINEST)) {
               StringBuffer sb = new StringBuffer("controlMsg: " + len + " Bytes received(written: ");

               for (int i = 0; i < len; i++) {
                  sb.append("0x" + String.format("%1$02X", data[i]) + " ");
               }

               logger.info(sb.toString());
            }

            return len;
         } else if (len != LibusbJava.ERROR_TIMEDOUT) {
            throw new USBException("LibusbJava.controlMsg: " + LibusbJava.usb_strerror());
         } else if (reopenOnTimeout) {
            logger.info("try to reopen");
            this.reset();
            this.open(this.dev_configuration, this.dev_interface, this.dev_altinterface);
            return this.controlMsg(requestType, request, value, index, data, size, timeout, false);
         } else {
            throw new USBTimeoutException("LibusbJava.controlMsg: " + LibusbJava.usb_strerror());
         }
      } else {
         throw new ArrayIndexOutOfBoundsException("invalid size: " + size);
      }
   }

   private void claim_interface(long usb_dev_handle, int configuration, int interface_, int altinterface) throws USBException {
      if (LibusbJava.usb_set_configuration(usb_dev_handle, configuration) < 0) {
         this.usbDevHandle = 0L;
         throw new USBException("LibusbJava.usb_set_configuration: " + LibusbJava.usb_strerror());
      } else if (LibusbJava.usb_claim_interface(usb_dev_handle, interface_) < 0) {
         this.usbDevHandle = 0L;
         throw new USBException("LibusbJava.usb_claim_interface: " + LibusbJava.usb_strerror());
      } else if (altinterface >= 0 && LibusbJava.usb_set_altinterface(usb_dev_handle, altinterface) < 0) {
         try {
            this.release_interface(usb_dev_handle, interface_);
         } catch (USBException var7) {
         }

         this.usbDevHandle = 0L;
         throw new USBException("LibusbJava.usb_set_altinterface: " + LibusbJava.usb_strerror());
      } else {
         logger.info("interface claimed");
      }
   }

   private void release_interface(long dev_handle, int interface_) throws USBException {
      if (LibusbJava.usb_release_interface(dev_handle, interface_) < 0) {
         this.usbDevHandle = 0L;
         throw new USBException("LibusbJava.usb_release_interface: " + LibusbJava.usb_strerror());
      } else {
         logger.info("interface released");
      }
   }

   public int getIdProduct() {
      return this.idProduct;
   }

   public int getIdVendor() {
      return this.idVendor;
   }

   public int getAltinterface() {
      return this.dev_altinterface;
   }

   public int getConfiguration() {
      return this.dev_configuration;
   }

   public int getInterface() {
      return this.dev_interface;
   }

   public int getMaxPacketSize() {
      return this.maxPacketSize;
   }

   public boolean isOpen() {
      return this.usbDevHandle != 0L;
   }

   public void setResetOnFirstOpen(boolean enable, int timeout) {
      this.resetOnFirstOpen = enable;
      this.resetTimeout = timeout;
   }

   protected String getFilename() {
      return this.filename;
   }

   protected String getBusName() {
      return this.busName;
   }

   public Usb_Device getDevice() {
      return this.dev;
   }

   @Override
   public String toString() {
      return "idVendor: 0x"
         + Integer.toHexString(this.getIdVendor() & 65535)
         + ", idProduct: 0x"
         + Integer.toHexString(this.getIdProduct() & 65535)
         + ", busName: "
         + this.getBusName()
         + ", filename: "
         + this.getFilename();
   }
}
