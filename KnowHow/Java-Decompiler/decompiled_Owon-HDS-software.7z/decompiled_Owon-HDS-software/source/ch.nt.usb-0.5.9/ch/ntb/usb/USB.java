package ch.ntb.usb;

import ch.ntb.usb.logger.LogUtil;
import java.util.LinkedList;
import java.util.logging.Logger;

public class USB {
   public static final int REQ_GET_STATUS = 0;
   public static final int REQ_CLEAR_FEATURE = 1;
   public static final int REQ_SET_FEATURE = 3;
   public static final int REQ_SET_ADDRESS = 5;
   public static final int REQ_GET_DESCRIPTOR = 6;
   public static final int REQ_SET_DESCRIPTOR = 7;
   public static final int REQ_GET_CONFIGURATION = 8;
   public static final int REQ_SET_CONFIGURATION = 9;
   public static final int REQ_GET_INTERFACE = 10;
   public static final int REQ_SET_INTERFACE = 11;
   public static final int REQ_SYNCH_FRAME = 12;
   public static final int REQ_TYPE_DIR_HOST_TO_DEVICE = 0;
   public static final int REQ_TYPE_DIR_DEVICE_TO_HOST = 128;
   public static final int REQ_TYPE_TYPE_STANDARD = 0;
   public static final int REQ_TYPE_TYPE_CLASS = 32;
   public static final int REQ_TYPE_TYPE_VENDOR = 64;
   public static final int REQ_TYPE_TYPE_RESERVED = 96;
   public static final int REQ_TYPE_RECIP_DEVICE = 0;
   public static final int REQ_TYPE_RECIP_INTERFACE = 1;
   public static final int REQ_TYPE_RECIP_ENDPOINT = 2;
   public static final int REQ_TYPE_RECIP_OTHER = 3;
   public static int HIGHSPEED_MAX_BULK_PACKET_SIZE = 512;
   public static int FULLSPEED_MAX_BULK_PACKET_SIZE = 64;
   private static final Logger logger = LogUtil.getLogger("ch.ntb.usb");
   private static LinkedList<Device> devices = new LinkedList<>();
   private static boolean initUSBDone = false;

   public static Device getDevice(short idVendor, short idProduct, String busName, String filename) {
      Device dev = getRegisteredDevice(idVendor, idProduct, busName, filename);
      if (dev != null) {
         logger.info("return already registered device: " + dev);
         return dev;
      } else {
         dev = new Device(idVendor, idProduct, busName, filename);
         logger.info("create new device: " + dev);
         devices.add(dev);
         return dev;
      }
   }

   public static Device getDevice(short idVendor, short idProduct) {
      return getDevice(idVendor, idProduct, null, null);
   }

   public static boolean unregisterDevice(Device dev) {
      return devices.remove(dev);
   }

   private static Device getRegisteredDevice(short idVendor, short idProduct, String busName, String filename) {
      for (Device dev : devices) {
         if (busName != null && filename != null) {
            if (busName.compareTo(dev.getBusName() == null ? "" : dev.getBusName()) == 0
               && filename.compareTo(dev.getFilename() == null ? "" : dev.getFilename()) == 0
               && dev.getIdVendor() == idVendor
               && dev.getIdProduct() == idProduct) {
               return dev;
            }
         } else if (filename != null) {
            if (filename.compareTo(dev.getFilename() == null ? "" : dev.getFilename()) == 0 && dev.getIdVendor() == idVendor && dev.getIdProduct() == idProduct
               )
             {
               return dev;
            }
         } else if (busName != null) {
            if (busName.compareTo(dev.getBusName() == null ? "" : dev.getBusName()) == 0 && dev.getIdVendor() == idVendor && dev.getIdProduct() == idProduct) {
               return dev;
            }
         } else if (dev.getIdVendor() == idVendor && dev.getIdProduct() == idProduct) {
            return dev;
         }
      }

      return null;
   }

   public static Usb_Bus getBus() throws USBException {
      if (!initUSBDone) {
         init();
      }

      LibusbJava.usb_find_busses();
      LibusbJava.usb_find_devices();
      Usb_Bus bus = LibusbJava.usb_get_busses();
      if (bus == null) {
         throw new USBException("LibusbJava.usb_get_busses(): " + LibusbJava.usb_strerror());
      } else {
         return bus;
      }
   }

   public static void init() {
      LibusbJava.usb_init();
      initUSBDone = true;
   }
}
