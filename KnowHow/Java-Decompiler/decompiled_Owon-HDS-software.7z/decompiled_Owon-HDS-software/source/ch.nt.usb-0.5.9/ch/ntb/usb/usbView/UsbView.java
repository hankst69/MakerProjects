package ch.ntb.usb.usbView;

import ch.ntb.usb.LibusbJava;
import ch.ntb.usb.Usb_Bus;
import ch.ntb.usb.Usb_Config_Descriptor;
import ch.ntb.usb.Usb_Device;
import ch.ntb.usb.Usb_Device_Descriptor;
import ch.ntb.usb.Usb_Endpoint_Descriptor;
import ch.ntb.usb.Usb_Interface_Descriptor;
import ch.ntb.usb.testApp.AbstractDeviceInfo;
import ch.ntb.usb.testApp.TestApp;
import ch.ntb.usb.testApp.TestDevice;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.tree.TreePath;

public class UsbView extends JFrame {
   private static final long serialVersionUID = 4693554326612734263L;
   private static final int APP_WIDTH = 600;
   private static final int APP_HIGHT = 800;
   private JPanel jContentPane = null;
   private JMenuBar jJMenuBar = null;
   private JMenu commandsMenu = null;
   private JMenuItem exitMenuItem = null;
   private JMenuItem updateMenuItem = null;
   JTree usbTree = null;
   private JSplitPane jSplitPane = null;
   private JTextArea jPropertiesArea = null;
   UsbTreeModel treeModel;
   JPopupMenu testAppPopup;
   protected JPopupMenu endpointPopup;

   public UsbView() {
      this.initialize();
   }

   private void initialize() {
      this.setDefaultCloseOperation(3);
      this.setJMenuBar(this.getJJMenuBar());
      this.setSize(600, 800);
      this.setContentPane(this.getJContentPane());
      this.setTitle("USB View");
   }

   private JPanel getJContentPane() {
      if (this.jContentPane == null) {
         this.jContentPane = new JPanel();
         this.jContentPane.setLayout(new BorderLayout());
         this.jContentPane.add(this.getJSplitPane(), "Center");
      }

      return this.jContentPane;
   }

   private JMenuBar getJJMenuBar() {
      if (this.jJMenuBar == null) {
         this.jJMenuBar = new JMenuBar();
         this.jJMenuBar.add(this.getFileMenu());
      }

      return this.jJMenuBar;
   }

   private JMenu getFileMenu() {
      if (this.commandsMenu == null) {
         this.commandsMenu = new JMenu();
         this.commandsMenu.setText("Commands");
         this.commandsMenu.add(this.getUpdateMenuItem());
         this.commandsMenu.add(this.getExitMenuItem());
      }

      return this.commandsMenu;
   }

   private JMenuItem getExitMenuItem() {
      if (this.exitMenuItem == null) {
         this.exitMenuItem = new JMenuItem();
         this.exitMenuItem.setText("Exit");
         this.exitMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               System.exit(0);
            }
         });
      }

      return this.exitMenuItem;
   }

   private JMenuItem getUpdateMenuItem() {
      if (this.updateMenuItem == null) {
         this.updateMenuItem = new JMenuItem();
         this.updateMenuItem.setText("Update");
         this.updateMenuItem.setAccelerator(KeyStroke.getKeyStroke(116, 0, true));
         this.updateMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               LibusbJava.usb_init();
               LibusbJava.usb_find_busses();
               LibusbJava.usb_find_devices();
               Usb_Bus bus = LibusbJava.usb_get_busses();
               if (bus != null) {
                  UsbView.this.treeModel.fireTreeStructureChanged(bus);
                  UsbView.this.expandAll(UsbView.this.usbTree);
               }
            }
         });
      }

      return this.updateMenuItem;
   }

   private JTree getUsbTree() {
      if (this.usbTree == null) {
         LibusbJava.usb_init();
         LibusbJava.usb_find_busses();
         LibusbJava.usb_find_devices();
         Usb_Bus bus = LibusbJava.usb_get_busses();
         this.treeModel = new UsbTreeModel(bus, this.jPropertiesArea);
         this.usbTree = new JTree(this.treeModel);
         this.expandAll(this.usbTree);
         this.usbTree.addTreeSelectionListener(this.treeModel);
         this.getJTestAppPopup();
         this.usbTree.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
               if (e.isPopupTrigger()) {
                  Object source = e.getSource();
                  if (source instanceof JTree) {
                     JTree tree = (JTree)source;
                     TreePath path = tree.getPathForLocation(e.getX(), e.getY());
                     if (path != null && path.getLastPathComponent() instanceof Usb_Interface_Descriptor) {
                        UsbView.this.usbTree.setSelectionPath(path);
                        UsbView.this.testAppPopup.show(tree, e.getX(), e.getY());
                     }
                  }
               }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
               if (e.isPopupTrigger() && e.isPopupTrigger()) {
                  Object source = e.getSource();
                  if (source instanceof JTree) {
                     JTree tree = (JTree)source;
                     TreePath path = tree.getPathForLocation(e.getX(), e.getY());
                     if (path != null && path.getLastPathComponent() instanceof Usb_Interface_Descriptor) {
                        UsbView.this.usbTree.setSelectionPath(path);
                        UsbView.this.testAppPopup.show(tree, e.getX(), e.getY());
                     }
                  }
               }
            }
         });
      }

      return this.usbTree;
   }

   private void getJTestAppPopup() {
      this.testAppPopup = new JPopupMenu();
      this.endpointPopup = new JPopupMenu();
      JMenuItem menuItem = new JMenuItem("Start a test application using this interface");
      menuItem.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            this.initAndStartTestApp();
         }

         private void initAndStartTestApp() {
            JTree tree = (JTree)UsbView.this.testAppPopup.getInvoker();
            TreePath path = tree.getSelectionPath();
            TreePath parent = path;
            Usb_Endpoint_Descriptor[] endpoints = null;
            int altinterface = -1;
            int interface_ = -1;
            int configuration = -1;
            short vendorId = -1;

            short productId;
            for (productId = -1; parent != null && !(parent.getLastPathComponent() instanceof Usb_Bus); parent = parent.getParentPath()) {
               Object usbObj = parent.getLastPathComponent();
               if (usbObj instanceof Usb_Interface_Descriptor) {
                  Usb_Interface_Descriptor usbIntDesc = (Usb_Interface_Descriptor)usbObj;
                  endpoints = usbIntDesc.getEndpoint();
                  interface_ = usbIntDesc.getBInterfaceNumber();
                  altinterface = usbIntDesc.getBAlternateSetting();
               } else if (usbObj instanceof Usb_Config_Descriptor) {
                  configuration = ((Usb_Config_Descriptor)usbObj).getBConfigurationValue();
               } else if (usbObj instanceof Usb_Device) {
                  Usb_Device_Descriptor devDesc = ((Usb_Device)usbObj).getDescriptor();
                  productId = devDesc.getIdProduct();
                  vendorId = devDesc.getIdVendor();
               }
            }

            if (parent != null) {
               Usb_Endpoint_Descriptor[] outEPs = null;
               int nofOutEPs = 0;
               Usb_Endpoint_Descriptor[] inEPs = null;
               int nofInEPs = 0;
               if (endpoints != null) {
                  outEPs = new Usb_Endpoint_Descriptor[endpoints.length];
                  inEPs = new Usb_Endpoint_Descriptor[endpoints.length];

                  for (int i = 0; i < endpoints.length; i++) {
                     int epAddr = endpoints[i].getBEndpointAddress() & 255;
                     if ((epAddr & 128) > 0) {
                        inEPs[nofInEPs++] = endpoints[i];
                     } else {
                        outEPs[nofOutEPs++] = endpoints[i];
                     }
                  }
               }

               TestDevice testDevice = new TestDevice();
               testDevice.setIdProduct(productId);
               testDevice.setIdVendor(vendorId);
               testDevice.setAltinterface(altinterface);
               testDevice.setConfiguration(configuration);
               testDevice.setInterface(interface_);
               if (inEPs != null) {
                  for (int ix = 0; ix < nofInEPs; ix++) {
                     int type = inEPs[ix].getBmAttributes() & 3;
                     switch (type) {
                        case 2:
                           testDevice.setInEPBulk(inEPs[ix].getBEndpointAddress() & 255);
                           testDevice.setInMode(AbstractDeviceInfo.TransferMode.Bulk);
                           break;
                        case 3:
                           testDevice.setInEPInt(inEPs[ix].getBEndpointAddress() & 255);
                           testDevice.setInMode(AbstractDeviceInfo.TransferMode.Interrupt);
                     }
                  }
               }

               if (outEPs != null) {
                  for (int ix = 0; ix < nofOutEPs; ix++) {
                     int type = outEPs[ix].getBmAttributes() & 3;
                     switch (type) {
                        case 2:
                           testDevice.setOutEPBulk(outEPs[ix].getBEndpointAddress() & 255);
                           testDevice.setOutMode(AbstractDeviceInfo.TransferMode.Bulk);
                           break;
                        case 3:
                           testDevice.setOutEPInt(outEPs[ix].getBEndpointAddress() & 255);
                           testDevice.setOutMode(AbstractDeviceInfo.TransferMode.Interrupt);
                     }
                  }
               }

               TestApp app = new TestApp(testDevice);
               app.setVisible(true);
            } else {
               System.out.println("error, could not find device node");
            }
         }
      });
      this.testAppPopup.add(menuItem);
   }

   private JSplitPane getJSplitPane() {
      if (this.jSplitPane == null) {
         this.jSplitPane = new JSplitPane();
         this.jSplitPane.setOrientation(0);
         this.jSplitPane.setContinuousLayout(true);
         this.jSplitPane.setDividerLocation(400);
         this.jSplitPane.setBottomComponent(this.createScrollPane(this.getJPropertiesArea()));
         this.jSplitPane.setTopComponent(this.createScrollPane(this.getUsbTree()));
      }

      return this.jSplitPane;
   }

   private JTextArea getJPropertiesArea() {
      if (this.jPropertiesArea == null) {
         this.jPropertiesArea = new JTextArea();
      }

      return this.jPropertiesArea;
   }

   private JScrollPane createScrollPane(Component view) {
      return new JScrollPane(view);
   }

   public static void main(String[] args) {
      UsbView application = new UsbView();
      application.setVisible(true);
   }

   void expandAll(JTree tree) {
      for (int row = 0; row < tree.getRowCount(); row++) {
         tree.expandRow(row);
      }
   }
}
