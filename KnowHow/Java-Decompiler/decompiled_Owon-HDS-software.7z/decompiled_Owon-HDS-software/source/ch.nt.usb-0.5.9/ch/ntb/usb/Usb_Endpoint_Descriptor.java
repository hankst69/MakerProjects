package ch.ntb.usb;

public class Usb_Endpoint_Descriptor extends Usb_Descriptor {
   public static final int USB_MAXENDPOINTS = 32;
   public static final int USB_ENDPOINT_ADDRESS_MASK = 15;
   public static final int USB_ENDPOINT_DIR_MASK = 128;
   public static final int USB_ENDPOINT_TYPE_MASK = 3;
   public static final int USB_ENDPOINT_TYPE_CONTROL = 0;
   public static final int USB_ENDPOINT_TYPE_ISOCHRONOUS = 1;
   public static final int USB_ENDPOINT_TYPE_BULK = 2;
   public static final int USB_ENDPOINT_TYPE_INTERRUPT = 3;
   private byte bEndpointAddress;
   private byte bmAttributes;
   private short wMaxPacketSize;
   private byte bInterval;
   private byte bRefresh;
   private byte bSynchAddress;
   private byte[] extra;
   private int extralen;

   public byte getBEndpointAddress() {
      return this.bEndpointAddress;
   }

   public byte getBInterval() {
      return this.bInterval;
   }

   public byte getBmAttributes() {
      return this.bmAttributes;
   }

   public byte getBRefresh() {
      return this.bRefresh;
   }

   public byte getBSynchAddress() {
      return this.bSynchAddress;
   }

   public byte[] getExtra() {
      return this.extra;
   }

   public int getExtralen() {
      return this.extralen;
   }

   public short getWMaxPacketSize() {
      return this.wMaxPacketSize;
   }

   @Override
   public String toString() {
      return "Usb_Endpoint_Descriptor bEndpointAddress: 0x" + Integer.toHexString(this.bEndpointAddress & 255);
   }
}
