package ch.ntb.usb;

import java.io.IOException;

public class USBException extends IOException {
   private static final long serialVersionUID = 1690857437804284710L;

   public USBException(String string) {
      super(string);
   }
}
