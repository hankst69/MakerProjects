package ch.ntb.usb;

public class Usb_Device_Descriptor extends Usb_Descriptor {
   public static final int USB_CLASS_PER_INTERFACE = 0;
   public static final int USB_CLASS_AUDIO = 1;
   public static final int USB_CLASS_COMM = 2;
   public static final int USB_CLASS_HID = 3;
   public static final int USB_CLASS_PRINTER = 7;
   public static final int USB_CLASS_MASS_STORAGE = 8;
   public static final int USB_CLASS_HUB = 9;
   public static final int USB_CLASS_DATA = 10;
   public static final int USB_CLASS_VENDOR_SPEC = 255;
   private short bcdUSB;
   private byte bDeviceClass;
   private byte bDeviceSubClass;
   private byte bDeviceProtocol;
   private byte bMaxPacketSize0;
   private short idVendor;
   private short idProduct;
   private short bcdDevice;
   private byte iManufacturer;
   private byte iProduct;
   private byte iSerialNumber;
   private byte bNumConfigurations;

   public short getBcdDevice() {
      return this.bcdDevice;
   }

   public short getBcdUSB() {
      return this.bcdUSB;
   }

   public byte getBDeviceClass() {
      return this.bDeviceClass;
   }

   public byte getBDeviceProtocol() {
      return this.bDeviceProtocol;
   }

   public byte getBDeviceSubClass() {
      return this.bDeviceSubClass;
   }

   public byte getBMaxPacketSize0() {
      return this.bMaxPacketSize0;
   }

   public byte getBNumConfigurations() {
      return this.bNumConfigurations;
   }

   public short getIdProduct() {
      return this.idProduct;
   }

   public short getIdVendor() {
      return this.idVendor;
   }

   public byte getIManufacturer() {
      return this.iManufacturer;
   }

   public byte getIProduct() {
      return this.iProduct;
   }

   public byte getISerialNumber() {
      return this.iSerialNumber;
   }

   @Override
   public String toString() {
      StringBuffer sb = new StringBuffer();
      sb.append(
         "Usb_Device_Descriptor idVendor: 0x"
            + Integer.toHexString(this.idVendor & '\uffff')
            + ", idProduct: 0x"
            + Integer.toHexString(this.idProduct & '\uffff')
      );
      return sb.toString();
   }
}
