package ch.ntb.usb.testApp;

public abstract class AbstractDeviceInfo {
   private short idVendor;
   private short idProduct;
   private String filename = null;
   private String busName = null;
   private int timeout;
   private int configuration;
   private int interface_;
   private int altinterface;
   private int outEPBulk = -1;
   private int inEPBulk = -1;
   private int outEPInt = -1;
   private int inEPInt = -1;
   private int sleepTimeout;
   private int maxDataSize;
   private AbstractDeviceInfo.TransferMode mode;
   private boolean compareData = true;
   private String manufacturer = null;
   private String product = null;
   private String serialVersion = null;

   public AbstractDeviceInfo() {
      this.initValues();
   }

   public abstract void initValues();

   public int getAltinterface() {
      return this.altinterface;
   }

   public int getConfiguration() {
      return this.configuration;
   }

   public short getIdProduct() {
      return this.idProduct;
   }

   public short getIdVendor() {
      return this.idVendor;
   }

   public int getInEPBulk() {
      return this.inEPBulk;
   }

   public int getInEPInt() {
      return this.inEPInt;
   }

   public int getInterface() {
      return this.interface_;
   }

   public int getMaxDataSize() {
      return this.maxDataSize;
   }

   public int getOutEPBulk() {
      return this.outEPBulk;
   }

   public int getOutEPInt() {
      return this.outEPInt;
   }

   public int getSleepTimeout() {
      return this.sleepTimeout;
   }

   public int getTimeout() {
      return this.timeout;
   }

   public void setAltinterface(int altinterface) {
      this.altinterface = altinterface;
   }

   public void setConfiguration(int configuration) {
      this.configuration = configuration;
   }

   public void setIdProduct(short idProduct) {
      this.idProduct = idProduct;
   }

   public void setIdVendor(short idVendor) {
      this.idVendor = idVendor;
   }

   public void setInEPBulk(int in_ep_bulk) {
      this.inEPBulk = in_ep_bulk;
   }

   public void setInEPInt(int in_ep_int) {
      this.inEPInt = in_ep_int;
   }

   public void setInterface(int interface_) {
      this.interface_ = interface_;
   }

   public void setMaxDataSize(int maxDataSize) {
      this.maxDataSize = maxDataSize;
   }

   public void setOutEPBulk(int out_ep_bulk) {
      this.outEPBulk = out_ep_bulk;
   }

   public void setOutEPInt(int out_ep_int) {
      this.outEPInt = out_ep_int;
   }

   public void setSleepTimeout(int sleepTimeout) {
      this.sleepTimeout = sleepTimeout;
   }

   public void setTimeout(int timeout) {
      this.timeout = timeout;
   }

   public AbstractDeviceInfo.TransferMode getMode() {
      return this.mode;
   }

   public void setMode(AbstractDeviceInfo.TransferMode mode) {
      this.mode = mode;
   }

   public boolean doCompareData() {
      return this.compareData;
   }

   public void setDoCompareData(boolean compareData) {
      this.compareData = compareData;
   }

   public String getManufacturer() {
      return this.manufacturer;
   }

   public void setManufacturer(String manufacturer) {
      this.manufacturer = manufacturer;
   }

   public String getProduct() {
      return this.product;
   }

   public void setProduct(String product) {
      this.product = product;
   }

   public String getSerialVersion() {
      return this.serialVersion;
   }

   public void setSerialVersion(String serialVersion) {
      this.serialVersion = serialVersion;
   }

   public String getFilename() {
      return this.filename;
   }

   public void setFilename(String filename) {
      this.filename = filename;
   }

   public String getBusName() {
      return this.busName;
   }

   public void setBusName(String busName) {
      this.busName = busName;
   }

   public static enum TransferMode {
      Bulk,
      Interrupt;
   }
}
