package ch.ntb.usb;

public class Usb_Config_Descriptor extends Usb_Descriptor {
   public static final int USB_MAXCONFIG = 8;
   private short wTotalLength;
   private byte bNumInterfaces;
   private byte bConfigurationValue;
   private byte iConfiguration;
   private byte bmAttributes;
   private byte MaxPower;
   private Usb_Interface[] interface_;
   private byte[] extra;
   private int extralen;

   public byte getBConfigurationValue() {
      return this.bConfigurationValue;
   }

   public byte getBmAttributes() {
      return this.bmAttributes;
   }

   public byte getBNumInterfaces() {
      return this.bNumInterfaces;
   }

   public byte[] getExtra() {
      return this.extra;
   }

   public int getExtralen() {
      return this.extralen;
   }

   public byte getIConfiguration() {
      return this.iConfiguration;
   }

   public Usb_Interface[] getInterface() {
      return this.interface_;
   }

   public byte getMaxPower() {
      return this.MaxPower;
   }

   public short getWTotalLength() {
      return this.wTotalLength;
   }

   @Override
   public String toString() {
      return "Usb_Config_Descriptor bNumInterfaces: 0x" + Integer.toHexString(this.bNumInterfaces);
   }
}
