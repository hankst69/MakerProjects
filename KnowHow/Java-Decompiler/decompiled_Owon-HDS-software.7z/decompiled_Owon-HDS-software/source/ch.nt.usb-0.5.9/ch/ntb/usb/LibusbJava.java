package ch.ntb.usb;

public class LibusbJava {
   public static int ERROR_SUCCESS;
   public static int ERROR_BAD_FILE_DESCRIPTOR;
   public static int ERROR_NO_SUCH_DEVICE_OR_ADDRESS;
   public static int ERROR_BUSY;
   public static int ERROR_INVALID_PARAMETER;
   public static int ERROR_TIMEDOUT;
   public static int ERROR_IO_ERROR;
   public static int ERROR_NOT_ENOUGH_MEMORY;

   public static native void usb_set_debug(int var0);

   public static native void usb_init();

   public static native int usb_find_busses();

   public static native int usb_find_devices();

   public static native Usb_Bus usb_get_busses();

   public static native long usb_open(Usb_Device var0);

   public static native int usb_close(long var0);

   public static native int usb_set_configuration(long var0, int var2);

   public static native int usb_set_altinterface(long var0, int var2);

   public static native int usb_clear_halt(long var0, int var2);

   public static native int usb_reset(long var0);

   public static native int usb_claim_interface(long var0, int var2);

   public static native int usb_release_interface(long var0, int var2);

   public static native int usb_control_msg(long var0, int var2, int var3, int var4, int var5, byte[] var6, int var7, int var8);

   public static native String usb_get_string(long var0, int var2, int var3);

   public static native String usb_get_string_simple(long var0, int var2);

   public static native String usb_get_descriptor(long var0, byte var2, byte var3, int var4);

   public static native String usb_get_descriptor_by_endpoint(long var0, int var2, byte var3, byte var4, int var5);

   public static native int usb_bulk_write(long var0, int var2, byte[] var3, int var4, int var5);

   public static native int usb_bulk_read(long var0, int var2, byte[] var3, int var4, int var5);

   public static native int usb_interrupt_write(long var0, int var2, byte[] var3, int var4, int var5);

   public static native int usb_interrupt_read(long var0, int var2, byte[] var3, int var4, int var5);

   public static native String usb_strerror();

   private static native int usb_error_no(int var0);

   static {
      String os = System.getProperty("os.name");
      if (os.contains("Windows")) {
         System.loadLibrary("LibusbJava");
      } else {
         System.loadLibrary("usbJava");
      }

      ERROR_SUCCESS = 0;
      ERROR_BAD_FILE_DESCRIPTOR = -usb_error_no(1);
      ERROR_NO_SUCH_DEVICE_OR_ADDRESS = -usb_error_no(2);
      ERROR_BUSY = -usb_error_no(3);
      ERROR_INVALID_PARAMETER = -usb_error_no(4);
      ERROR_TIMEDOUT = -usb_error_no(5);
      ERROR_IO_ERROR = -usb_error_no(6);
      ERROR_NOT_ENOUGH_MEMORY = -usb_error_no(7);
   }
}
