package com.owon.uppersoft.common.commjob.instance;

import java.util.Locale;
import javax.security.auth.login.Configuration;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class PortSetting extends PrototypePortSettingFrame implements Listener {
   protected Configuration config;
   protected String[] portType;
   protected String parityNone;
   protected final int SWT_Selection = 13;
   private PortSetting.SelectPortRunner selectPortRunner = new PortSetting.SelectPortRunner();
   private IDevice[] ids;

   public void handleEvent(Event event) {
      if (event.type == 13) {
         Object o = event.widget;
         if (o != this.btnOK) {
            if (o == this.refreshButton) {
               this.refreshUSBPort();
            } else if (o == this.portTypeCombo) {
               this.portTypeCombo.getText();
            }
         }
      }
   }

   public PortSetting(Shell shell, Configuration config) {
      super(shell);
      this.config = config;
      this.btnOK.addListener(13, this);
      this.refreshButton.addListener(13, this);
      this.portTypeCombo.setText("loading...");
      this.portTypeCombo.addListener(13, this);
      (new Thread() {
         @Override
         public void run() {
            PortSetting.this.refreshUSBPort();
         }
      }).start();
   }

   private void refreshUSBPort() {
   }

   public static void main_hide(String[] args) {
      try {
         Locale.setDefault(Locale.ENGLISH);
         new Shell();
      } catch (Exception var2) {
         var2.printStackTrace();
      }
   }

   class SelectPortRunner implements Runnable {
      @Override
      public void run() {
         PortSetting.this.usbCombo.removeAll();
         int length = PortSetting.this.ids.length;

         for (int i = 0; i < length; i++) {
            String sn = PortSetting.this.ids[i].getSerialNumber();
            if (sn == null) {
               sn = "?";
            }

            PortSetting.this.usbCombo.add(i + 1 + ". (SN: " + sn + ")");
         }

         PortSetting.this.usbCombo.select(0);
      }
   }
}
