package com.owon.uppersoft.common.commjob.instance;

import ch.ntb.usb.Usb_Device;

public interface IDevice {
   Usb_Device getUsb_Device();

   String getSerialNumber();

   void setSerialNumber(String var1);

   int getBAlternateSetting();

   int getBConfigurationValue();

   int getBInterfaceNumber();

   int getReadEndpoint();

   int getWriteEndpoint();
}
