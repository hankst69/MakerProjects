package com.owon.uppersoft.common.aspect;

public interface ILaunchable extends Runnable {
   String getText();
}
