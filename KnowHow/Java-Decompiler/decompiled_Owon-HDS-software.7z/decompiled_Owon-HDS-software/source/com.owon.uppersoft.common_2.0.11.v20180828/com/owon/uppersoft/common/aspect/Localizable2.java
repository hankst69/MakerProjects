package com.owon.uppersoft.common.aspect;

import java.util.ResourceBundle;

public interface Localizable2 {
   void localize(ResourceBundle var1);
}
