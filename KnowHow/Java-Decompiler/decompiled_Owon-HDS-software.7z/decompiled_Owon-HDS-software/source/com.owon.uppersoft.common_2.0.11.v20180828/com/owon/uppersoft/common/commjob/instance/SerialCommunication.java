package com.owon.uppersoft.common.commjob.instance;

import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import gnu.io.UnsupportedCommOperationException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.TooManyListenersException;

public class SerialCommunication implements ICommunication, SerialPortEventListener {
   public static final int OpenPortTimeout = 2000;
   private InputStream is;
   private OutputStream os;
   private SerialPort SrPt;
   private CommPortIdentifier portId;
   boolean dataAvai = false;

   public boolean openPort(String port) {
      try {
         this.portId = CommPortIdentifier.getPortIdentifier(port);
         this.SrPt = (SerialPort)this.portId.open(port, 2000);
         return true;
      } catch (NoSuchPortException var3) {
         var3.printStackTrace();
      } catch (PortInUseException var4) {
         var4.printStackTrace();
      }

      return false;
   }

   public void loadPort(int baudRate, int dataBits, int stopBits, int parity) {
      try {
         this.is = this.SrPt.getInputStream();
         this.os = this.SrPt.getOutputStream();
      } catch (IOException var10) {
         var10.printStackTrace();
      } catch (Exception var11) {
         var11.printStackTrace();
      }

      try {
         this.SrPt.addEventListener(this);
      } catch (TooManyListenersException var8) {
         var8.printStackTrace();
      } catch (Exception var9) {
         var9.printStackTrace();
      }

      try {
         this.SrPt.setSerialPortParams(baudRate, dataBits, stopBits, parity);
      } catch (UnsupportedCommOperationException var6) {
         var6.printStackTrace();
      } catch (Exception var7) {
         var7.printStackTrace();
      }

      this.SrPt.notifyOnDataAvailable(true);
   }

   @Override
   public int read(byte[] arr, int beg, int len) {
      try {
         int i = 0;

         while (!this.dataAvai) {
            this.slp(50);
            if (i++ > 200) {
               return -1;
            }
         }

         this.dataAvai = false;
         return this.is.read(arr, beg, len);
      } catch (IOException var5) {
         var5.printStackTrace();
         return -1;
      }
   }

   @Override
   public int write(byte[] arr, int beg, int len) {
      try {
         this.os.write(arr, beg, len);
         this.os.flush();
         return len - beg;
      } catch (IOException var5) {
         var5.printStackTrace();
         return -1;
      }
   }

   private void slp(int millis) {
      try {
         Thread.sleep((long)millis);
      } catch (InterruptedException var3) {
         var3.printStackTrace();
      }
   }

   public void serialEvent(SerialPortEvent event) {
      System.out.println(event.getEventType());
      switch (event.getEventType()) {
         case 1:
            if (this.dataAvai) {
               return;
            } else {
               this.slp(100);
               this.dataAvai = true;
            }
         case 2:
         case 3:
         case 4:
         case 5:
         case 6:
         case 7:
         case 8:
         case 9:
         case 10:
      }
   }

   @Override
   public boolean open(Object[] para) {
      String port = (String)para[0];
      int baudRate = Integer.parseInt((String)para[1]);
      if (this.openPort(port)) {
         this.loadPort(baudRate, 8, 1, 0);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public void close() {
      if (this.SrPt != null) {
         this.SrPt.close();
      }
   }

   @Override
   public boolean isConnected() {
      return false;
   }

   public static List<String> loadAvailablePort() {
      List<String> avaliblePortList = new ArrayList<>(5);
      Enumeration portList = CommPortIdentifier.getPortIdentifiers();

      while (portList.hasMoreElements()) {
         CommPortIdentifier portId = (CommPortIdentifier)portList.nextElement();
         if (portId.getPortType() == 1) {
            avaliblePortList.add(portId.getName());
         }
      }

      return avaliblePortList;
   }
}
