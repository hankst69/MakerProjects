package com.owon.uppersoft.common.aspect;

public interface RunRoutine {
   void before();

   void run();

   void after();
}
