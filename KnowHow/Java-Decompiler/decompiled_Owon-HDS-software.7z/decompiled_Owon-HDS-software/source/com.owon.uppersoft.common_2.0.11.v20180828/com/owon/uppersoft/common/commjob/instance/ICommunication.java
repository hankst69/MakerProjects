package com.owon.uppersoft.common.commjob.instance;

public interface ICommunication {
   int RWTimeOut = 1000;

   int read(byte[] var1, int var2, int var3);

   int write(byte[] var1, int var2, int var3);

   boolean open(Object[] var1);

   void close();

   boolean isConnected();
}
