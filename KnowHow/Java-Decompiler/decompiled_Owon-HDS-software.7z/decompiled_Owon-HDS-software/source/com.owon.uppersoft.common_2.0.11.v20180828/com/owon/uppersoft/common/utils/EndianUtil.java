package com.owon.uppersoft.common.utils;

public class EndianUtil {
   public static final short nextShortB(byte[] b, int p) {
      int ch2 = b[p++] & 255;
      int ch1 = b[p] & 255;
      return (short)(ch1 | ch2 << 8);
   }

   public static final int nextIntB(byte[] b, int p) {
      int ch4 = b[p++] & 255;
      int ch3 = b[p++] & 255;
      int ch2 = b[p++] & 255;
      int ch1 = b[p] & 255;
      return ch1 | ch2 << 8 | ch3 << 16 | ch4 << 24;
   }

   public static final short nextShortL(byte[] b, int p) {
      int ch2 = b[p++] & 255;
      int ch1 = b[p] & 255;
      return (short)(ch1 << 8 | ch2);
   }

   public static final int nextIntL(byte[] b, int p) {
      int ch4 = b[p++] & 255;
      int ch3 = b[p++] & 255;
      int ch2 = b[p++] & 255;
      int ch1 = b[p] & 255;
      return ch1 << 24 | ch2 << 16 | ch3 << 8 | ch4;
   }

   public static final long nextLongL(byte[] b, int p) {
      long tmp = (long)nextIntL(b, p);
      p += 4;
      return tmp | (long)nextIntL(b, p) << 32;
   }

   public static void main(String[] args) {
      long v = -2034550006L;
      byte[] bs = new byte[8];
      writeLongL(bs, 0, v);
      System.out.println(nextLongL(bs, 0));
   }

   public static final float nextFloatB(byte[] b, int p) {
      int v = nextIntB(b, p);
      return Float.intBitsToFloat(v);
   }

   public static final float nextFloatL(byte[] b, int p) {
      int v = nextIntL(b, p);
      return Float.intBitsToFloat(v);
   }

   public static final int int_reverse_Bytes(int i) {
      return Integer.reverseBytes(i);
   }

   public static final void writeIntB(byte[] b, int off, int v) {
      b[off++] = (byte)(v >>> 24);
      b[off++] = (byte)(v >>> 16);
      b[off++] = (byte)(v >>> 8);
      b[off] = (byte)v;
   }

   public static final void writeLongL(byte[] b, int off, long v) {
      for (int i = 0; i < 8; i++) {
         b[off++] = (byte)((int)v);
         v >>>= 8;
      }
   }
}
