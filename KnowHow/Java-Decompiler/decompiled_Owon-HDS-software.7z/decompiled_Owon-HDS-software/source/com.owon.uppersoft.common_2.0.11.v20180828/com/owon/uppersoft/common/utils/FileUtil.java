package com.owon.uppersoft.common.utils;

import java.io.File;

public class FileUtil {
   public static String getExtension(File f) {
      return f != null ? getExtension(f.getName()) : "";
   }

   public static String getExtension(String filename) {
      return getExtension(filename, "");
   }

   public static String getExtension(String filename, String defExt) {
      if (filename != null && filename.length() > 0) {
         int i = filename.lastIndexOf(".");
         return i > 0 && i < filename.length() - 1 ? filename.substring(i + 1) : defExt;
      } else {
         return defExt;
      }
   }

   public static void checkPath(String path) {
      checkPath(new File(path));
   }

   public static void checkPath(File file) {
      if (!file.exists()) {
         File parent = file.getParentFile();
         if (parent != null) {
            parent.mkdirs();
         }
      }
   }

   public static void deleteFile(String path) {
      deleteFile(new File(path));
   }

   public static void deleteFile(File file) {
      if (file.exists()) {
         if (file.isFile()) {
            file.delete();
         } else if (file.isDirectory()) {
            File[] files = file.listFiles();

            for (File f : files) {
               deleteFile(f);
            }

            file.delete();
         }
      }
   }

   public static void replaceFile(File src, File dest) {
      if (dest.exists()) {
         deleteFile(dest);
      }

      src.renameTo(dest);
   }

   public static void replaceInFile(File src, File destP) {
      File dest = new File(destP, src.getName());
      replaceFile(src, dest);
   }

   public static void main(String[] args) {
      TimeMeasure tm = new TimeMeasure();
      tm.start();
      deleteFile("F:/Alisoft");
      tm.stop();
      System.out.println(tm.measure());
   }
}
