package com.owon.uppersoft.common.action;

public interface ItemVisitor<T> {
   void invoke(T var1);

   String getText(T var1);
}
