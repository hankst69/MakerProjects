package com.owon.uppersoft.common.update;

import java.util.List;
import org.eclipse.swt.widgets.Shell;

public interface IUpdatable {
   Shell getMainShell();

   void notifyDestroy();

   void close();

   void startAgain();

   List<String> getUpdatableServers();

   String getRelativePath();

   String getConfigurationDir();

   String getProductVersion();
}
