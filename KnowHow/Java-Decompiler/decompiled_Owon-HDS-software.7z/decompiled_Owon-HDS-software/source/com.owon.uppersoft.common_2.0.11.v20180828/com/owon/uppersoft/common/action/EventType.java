package com.owon.uppersoft.common.action;

public enum EventType {
   TextEvent,
   EnabledEvent,
   ImageEvent,
   SelectEvent;
}
