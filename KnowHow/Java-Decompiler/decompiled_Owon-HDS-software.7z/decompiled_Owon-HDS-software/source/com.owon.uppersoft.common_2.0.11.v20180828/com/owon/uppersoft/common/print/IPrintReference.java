package com.owon.uppersoft.common.print;

public interface IPrintReference {
   double mmPerInch = 25.4;
   double inchPerMM = 0.03937007874015748;
   int A4PaperXPixels = 2480;
   int A4PaperYPixels = 3508;
   int A4PaperBorderTrim = 75;
   int DefaultPrinterDPI = 300;
   int A4PaperClientXPixels = 2330;
   int A4PaperClientYPixels = 3358;
}
