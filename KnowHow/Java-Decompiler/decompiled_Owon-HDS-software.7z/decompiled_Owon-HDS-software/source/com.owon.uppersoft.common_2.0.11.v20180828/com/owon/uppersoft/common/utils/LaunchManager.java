package com.owon.uppersoft.common.utils;

import java.io.File;
import java.io.IOException;
import org.eclipse.swt.program.Program;

public class LaunchManager {
   public static boolean tryOpenFile(File file) {
      if (file.exists()) {
         try {
            return Program.launch(file.getCanonicalPath());
         } catch (IOException var2) {
            var2.printStackTrace();
         }
      }

      return false;
   }

   public static boolean tryLaunchByName(String name) {
      return Program.launch(name);
   }

   public static void main(String[] args) {
      SystemPropertiesUtil.isWin32System();
      tryLaunchByName("launcher");
   }
}
