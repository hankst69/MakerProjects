package com.owon.uppersoft.common.commjob.instance;

import com.sun.jna.Library;
import com.sun.jna.Native;

public class Circult {
   public static native int Open_Sensor(String var0);

   public static void main(String[] args) {
      Circult.CLibrary.INSTANCE.USB_PM();
      Circult.CLibrary.INSTANCE.Open_Sensor("");
      System.out.println();
   }

   public interface CLibrary extends Library {
      Circult.CLibrary INSTANCE = (Circult.CLibrary)Native.loadLibrary("mcl_pm", Circult.CLibrary.class);

      Object USB_PM();

      int Open_Sensor(String var1);

      void Init_PM();
   }
}
