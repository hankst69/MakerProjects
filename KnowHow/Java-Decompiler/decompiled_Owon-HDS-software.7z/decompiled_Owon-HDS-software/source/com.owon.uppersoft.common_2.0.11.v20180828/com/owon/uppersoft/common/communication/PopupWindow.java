package com.owon.uppersoft.common.communication;

import com.owon.uppersoft.common.i18n.CommonMessageLib;
import java.util.ResourceBundle;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class PopupWindow {
   public static final int wndWidth = 180;
   public static final int wndHeight = 80;
   private Shell parent;
   private Shell shell;
   private Display display;
   private Text text;
   private int currentHeight;
   private boolean status;
   protected int moveStep = 2;
   protected int upPosition;
   protected int downPositon;
   protected int currentPosition;
   protected int leftPosition;
   private boolean use = true;
   final Runnable raise = new Runnable() {
      @Override
      public void run() {
         if (!(PopupWindow.this.isDisposed = PopupWindow.this.shell.isDisposed())) {
            PopupWindow.this.shell.setLocation(PopupWindow.this.leftPosition, PopupWindow.this.currentPosition);
            Shell var10000 = PopupWindow.this.shell;
            PopupWindow var10002 = PopupWindow.this;
            int var10004 = PopupWindow.this.currentHeight + PopupWindow.this.moveStep;
            var10002.currentHeight = var10004;
            var10000.setSize(180, var10004);
         }
      }
   };
   final Runnable fall = new Runnable() {
      @Override
      public void run() {
         if (!(PopupWindow.this.isDisposed = PopupWindow.this.shell.isDisposed())) {
            PopupWindow.this.shell.setLocation(PopupWindow.this.leftPosition, PopupWindow.this.currentPosition);
            Shell var10000 = PopupWindow.this.shell;
            PopupWindow var10002 = PopupWindow.this;
            int var10004 = PopupWindow.this.currentHeight - PopupWindow.this.moveStep;
            var10002.currentHeight = var10004;
            var10000.setSize(180, var10004);
         }
      }
   };
   final Runnable compute = new Runnable() {
      @Override
      public void run() {
         try {
            if (PopupWindow.this.isDisposed = PopupWindow.this.shell.isDisposed()) {
               return;
            }

            PopupWindow.this.isParentShellMinimized = PopupWindow.this.parent.getMinimized();
            if (PopupWindow.this.isParentShellMinimized) {
               return;
            }

            ResourceBundle bundle = CommonMessageLib.getDefaultResourceBundle();
            String msg = bundle.getString(PopupWindow.this.status ? "USB.connected" : "USB.disconnected");
            PopupWindow.this.text.setText(msg);
            PopupWindow.this.text.setForeground(PopupWindow.this.display.getSystemColor(PopupWindow.this.status ? 6 : 3));
            PopupWindow.this.shell.setVisible(true);
            PopupWindow.this.p = PopupWindow.this.parent.getLocation();
            PopupWindow.this.area = PopupWindow.this.parent.getClientArea();
            PopupWindow.this.currentHeight = PopupWindow.this.shell.getSize().y;
            PopupWindow.this.downPositon = PopupWindow.this.p.y + PopupWindow.this.area.y + PopupWindow.this.area.height;
            PopupWindow.this.upPosition = PopupWindow.this.downPositon - 80;
            PopupWindow.this.currentPosition = PopupWindow.this.downPositon;
            PopupWindow.this.leftPosition = PopupWindow.this.p.x + PopupWindow.this.area.x + PopupWindow.this.area.width - 180;
         } catch (RuntimeException var3) {
            var3.printStackTrace();
         }
      }
   };
   Point p;
   Rectangle area;
   boolean isDisposed;
   boolean isParentShellMinimized = false;

   public PopupWindow(Shell parent) {
      this.parent = parent;
      this.display = parent.getDisplay();
      this.shell = new Shell(parent, 16384);
      this.text = new Text(this.shell, 66);
      this.text.setBackground(this.shell.getBackground());
      this.shell.setLayout(new RowLayout());
      this.shell.setSize(180, 0);
      this.shell.open();
   }

   public void updateStatus(boolean status) {
      if (this.use) {
         this.status = status;
         this.run();
      }
   }

   private void moveUp() {
      while (!this.isDisposed) {
         try {
            Thread.sleep(10L);
            if ((this.currentPosition = this.currentPosition - this.moveStep) > this.upPosition) {
               this.display.asyncExec(this.raise);
               continue;
            }
            break;
         } catch (InterruptedException var2) {
            var2.printStackTrace();
         }
      }
   }

   private void moveDown() {
      while (!this.isDisposed) {
         try {
            Thread.sleep(10L);
            if ((this.currentPosition = this.currentPosition + this.moveStep) < this.downPositon) {
               this.display.asyncExec(this.fall);
               continue;
            }
            break;
         } catch (InterruptedException var2) {
            var2.printStackTrace();
         }
      }

      this.display.asyncExec(new Runnable() {
         @Override
         public void run() {
            if (!(PopupWindow.this.isDisposed = PopupWindow.this.shell.isDisposed())) {
               PopupWindow.this.shell.setVisible(false);
            }
         }
      });
   }

   protected void run() {
      this.display.syncExec(this.compute);
      if (!this.isParentShellMinimized) {
         this.moveUp();

         try {
            Thread.sleep(1000L);
         } catch (InterruptedException var2) {
            var2.printStackTrace();
         }

         this.moveDown();
      }
   }
}
