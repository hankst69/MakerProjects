package com.owon.uppersoft.common.aspect;

import org.eclipse.swt.graphics.GC;

public interface Drawable {
   void draw(GC var1);
}
