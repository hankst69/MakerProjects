package com.owon.uppersoft.common.aspect;

public interface Linkable {
   void link(String var1);
}
