package com.owon.uppersoft.common.update;

import com.owon.uppersoft.common.i18n.CommonMessageLib;
import com.owon.uppersoft.common.utils.FileUtil;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.swt.widgets.Shell;

public class CheckUpdateFrame extends ProgressMonitorDialog implements IRunnableWithProgress {
   private IUpdatable iu;
   private ResourceBundle bundle;
   private Runnable r;

   public CheckUpdateFrame(IUpdatable iu) {
      super(iu.getMainShell());
      this.iu = iu;
      this.bundle = CommonMessageLib.getDefaultResourceBundle();
      this.setCancelable(true);

      try {
         this.run(true, true, this);
      } catch (InvocationTargetException var3) {
         var3.printStackTrace();
      } catch (InterruptedException var4) {
      }
   }

   public void run(IProgressMonitor monitor) throws InvocationTargetException {
      try {
         monitor.beginTask("", 100);
         this.onCancel(monitor, "Info.DetectServers", 5);
         final UpdateDetection ud = new UpdateDetection(this.iu);
         final String url = ud.detectServers();
         if (url == null) {
            this.onTerminated(monitor, "Error.InternetConnection");
         }

         this.onCancel(monitor, "Info.CompareVersion", 20);
         boolean flag = ud.isUpdate();
         this.onCancel(monitor, "", 40);
         if (!flag) {
            this.onTerminated(monitor, "Info.DownManual");
         }

         final List<DownloadFile> urls = ud.getDownloadFileURLs();
         if (urls.size() == 0) {
            this.onCancel(monitor, "", 60);
            FileUtil.deleteFile(ud.getLocalUpdateXML());
            this.onCancel(monitor, "", 80);
            this.onTerminated(monitor, "Info.NewestVersion");
            return;
         }

         this.onCancel(monitor, "Info.PromptUpdate", 80);
         this.r = new Runnable() {
            @Override
            public void run() {
               new UpdateFrame(ud, url, urls).open();
            }
         };
      } catch (Exception var9) {
         return;
      } finally {
         monitor.done();
      }
   }

   public boolean close() {
      boolean b = super.close();
      if (this.r != null) {
         Shell s = this.iu.getMainShell();
         if (s != null) {
            s.getDisplay().syncExec(this.r);
         }
      }

      return b;
   }

   protected void onTerminated(IProgressMonitor monitor, final String key) throws Exception {
      this.r = new Runnable() {
         @Override
         public void run() {
            MessageDialog.openInformation(CheckUpdateFrame.this.getShell(), "", CheckUpdateFrame.this.bundle.getString(key));
         }
      };
      throw new Exception();
   }

   protected void onCancel(IProgressMonitor monitor, String key, int value) throws Exception {
      monitor.worked(value);
      if (key != null && key.length() != 0) {
         monitor.setTaskName(this.bundle.getString(key));
         monitor.subTask(this.bundle.getString(key));
      }

      if (monitor.isCanceled()) {
         this.r = null;
         throw new Exception();
      }
   }
}
