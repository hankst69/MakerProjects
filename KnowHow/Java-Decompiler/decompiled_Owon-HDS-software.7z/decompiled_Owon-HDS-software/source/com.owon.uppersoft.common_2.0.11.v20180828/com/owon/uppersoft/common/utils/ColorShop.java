package com.owon.uppersoft.common.utils;

import com.owon.uppersoft.common.aspect.Disposable;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Resource;
import org.eclipse.swt.widgets.Display;

public class ColorShop implements Disposable {
   private Map<RGB, Color> colorMap;
   private Display display;

   public ColorShop(Display display) {
      this.display = display;
      this.colorMap = new HashMap<>();
   }

   public Color getColor(RGB rgb) {
      Color c = this.colorMap.get(rgb);
      if (c == null) {
         c = new Color(this.display, rgb);
         this.colorMap.put(rgb, c);
      }

      return c;
   }

   @Override
   public void dispose() {
      for (Entry<RGB, Color> m : this.colorMap.entrySet()) {
         DisposeUtil.tryDispose((Resource)m.getValue());
      }

      this.colorMap.clear();
   }
}
