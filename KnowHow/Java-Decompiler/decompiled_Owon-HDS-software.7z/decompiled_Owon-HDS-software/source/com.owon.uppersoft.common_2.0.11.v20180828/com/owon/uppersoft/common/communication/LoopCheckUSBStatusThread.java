package com.owon.uppersoft.common.communication;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class LoopCheckUSBStatusThread implements Runnable {
   private boolean loop;
   private Display display;
   private LoopCheckUSBStatusThread.UpdateUSBStatus updateUSBStatus;
   private boolean status;
   private IUSBStatus usbStatus;
   private PopupWindow popup;
   private Thread t;

   public LoopCheckUSBStatusThread(Shell shell, IUSBStatus usbStatus) {
      this.display = shell.getDisplay();
      this.usbStatus = usbStatus;
      this.updateUSBStatus = new LoopCheckUSBStatusThread.UpdateUSBStatus();
      this.popup = new PopupWindow(shell);
   }

   public void turnOnCheck() {
      if (this.t == null || !this.t.isAlive()) {
         this.loop = true;
         this.t = new Thread(this);
         this.t.start();
      }
   }

   public void turnOffCheck() {
      if (this.t != null && this.t.isAlive()) {
         this.loop = false;
         this.t.stop();
      }
   }

   @Override
   public void run() {
      this.status = this.usbStatus.checkStatus();
      this.display.asyncExec(this.updateUSBStatus);
      if (this.usbStatus.shouldPopupCheck()) {
         this.popup.updateStatus(this.status);
      }

      boolean t = this.status;

      while (this.loop) {
         try {
            Thread.sleep(1000L);
         } catch (InterruptedException var3) {
            var3.printStackTrace();
         }

         this.status = this.usbStatus.checkStatus();
         if (t != this.status) {
            this.display.asyncExec(this.updateUSBStatus);
            if (this.usbStatus.shouldPopupCheck()) {
               this.popup.updateStatus(this.status);
            }

            t = this.status;
         }
      }
   }

   class UpdateUSBStatus implements Runnable {
      @Override
      public void run() {
         LoopCheckUSBStatusThread.this.usbStatus.usbStatus(LoopCheckUSBStatusThread.this.status);
      }
   }
}
