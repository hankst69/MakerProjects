package com.owon.uppersoft.common.commjob.instance;

import ch.ntb.usb.LibusbJava;
import ch.ntb.usb.USBException;
import ch.ntb.usb.Usb_Device;
import ch.ntb.usb.Usb_Device_Descriptor;
import java.util.ArrayList;
import java.util.List;

public class USBCommunication implements ICommunication {
   private short IdVender;
   private short IdProduct;
   private IDevice iDevice;
   private CDevice dev;
   private int WriteEndpoint;
   private int ReadEndpoint;
   private boolean reopenOnTimeout;

   public boolean openDevice() {
      this.reopenOnTimeout = false;
      this.dev = CDevice.getDevice(this.IdVender, this.IdProduct);

      try {
         if (this.iDevice == null) {
            this.restoreBackup();
         }

         try {
            if (this.iDevice != null) {
               this.WriteEndpoint = this.iDevice.getWriteEndpoint();
               this.ReadEndpoint = this.iDevice.getReadEndpoint();
               CDevice.simulateOpen(this.dev, this.iDevice);
               return true;
            }
         } catch (USBException var2) {
            this.iDevice = null;
            var2.printStackTrace();
         }
      } catch (USBException var3) {
         this.iDevice = null;
         var3.printStackTrace();
      }

      return false;
   }

   private void restoreBackup() throws USBException {
      try {
         List<IDevice> ld = CDevice.scanMatchedDevices(this.IdVender, this.IdProduct);
         if (ld.size() <= 0) {
            return;
         }

         this.iDevice = ld.get(0);
      } catch (Throwable var2) {
         var2.printStackTrace();
      }
   }

   @Override
   public int read(byte[] arr, int beg, int len) {
      try {
         return this.dev.readBulk(this.ReadEndpoint, arr, len, 1000, this.reopenOnTimeout);
      } catch (USBException var5) {
         var5.printStackTrace();
         return -1;
      }
   }

   @Override
   public int write(byte[] arr, int beg, int len) {
      try {
         return this.dev.writeBulk(this.WriteEndpoint, arr, len, 1000, this.reopenOnTimeout);
      } catch (USBException var5) {
         var5.printStackTrace();
         return -1;
      }
   }

   @Override
   public boolean open(Object[] para) {
      this.IdVender = (Short)para[0];
      this.IdProduct = (Short)para[1];
      System.out.println("start");

      try {
         return this.openDevice();
      } catch (Exception var3) {
         var3.printStackTrace();
         return false;
      }
   }

   @Override
   public void close() {
      try {
         if (this.dev != null && this.dev.isOpen()) {
            this.dev.close();
            System.out.println("over");
         }
      } catch (USBException var2) {
         var2.printStackTrace();
      }
   }

   @Override
   public boolean isConnected() {
      return this.dev.isOpen();
   }

   public static List<IDevice> loadAvailablePort(short idVender, short idProduct) {
      try {
         List<IDevice> udl = CDevice.scanMatchedDevices(idVender, idProduct);

         for (IDevice id : udl) {
            Usb_Device dev = id.getUsb_Device();
            long handle = LibusbJava.usb_open(dev);
            Usb_Device_Descriptor devDesc = dev.getDescriptor();
            String iSerialNumber = LibusbJava.usb_get_string_simple(handle, devDesc.getISerialNumber());
            id.setSerialNumber(iSerialNumber);
            LibusbJava.usb_close(handle);
         }

         return udl;
      } catch (USBException var10) {
         var10.printStackTrace();
      } catch (Throwable var11) {
         var11.printStackTrace();
      }

      return new ArrayList<>();
   }
}
