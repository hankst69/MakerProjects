package com.owon.uppersoft.common.commjob.instance;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class LANCommunication implements ICommunication {
   private Socket sck;

   private boolean connect(String add, int port) {
      try {
         this.sck = new Socket(add, port);
         this.sck.setSoTimeout(5000);
         return this.sck.isConnected();
      } catch (UnknownHostException var4) {
         var4.printStackTrace();
      } catch (IOException var5) {
         var5.printStackTrace();
      }

      return false;
   }

   @Override
   public int read(byte[] arr, int beg, int len) {
      InputStream is = null;
      if (this.sck != null && !this.sck.isClosed() && this.sck.isConnected()) {
         try {
            is = this.sck.getInputStream();
            System.out.println("avaialabe:" + is.available());
            return is.read(arr, beg, len);
         } catch (IOException var6) {
            var6.printStackTrace();
            return -1;
         } catch (Exception var7) {
            var7.printStackTrace();
            return -1;
         }
      } else {
         return -1;
      }
   }

   @Override
   public int write(byte[] arr, int beg, int len) {
      try {
         if (this.sck != null && !this.sck.isClosed() && this.sck.isConnected()) {
            OutputStream os = this.sck.getOutputStream();
            os.write(arr, beg, len);
            os.flush();
            return len;
         } else {
            return -1;
         }
      } catch (Exception var5) {
         var5.printStackTrace();
         return -1;
      }
   }

   @Override
   public boolean open(Object[] para) {
      String host = (String)para[0];
      int port = Integer.parseInt((String)para[1]);
      return this.connect(host, port);
   }

   @Override
   public void close() {
      try {
         if (this.sck != null) {
            this.sck.close();
         }
      } catch (IOException var2) {
         var2.printStackTrace();
      }
   }

   @Override
   public boolean isConnected() {
      return this.sck.isConnected();
   }
}
