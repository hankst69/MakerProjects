package com.owon.uppersoft.common.update;

public interface IUpdateReference {
   int BUFFER_SIZE = 10240;
   int TaskDelayTime = 0;
   int HttpURLConnectionTimeout = 1000;
   String TempDir = "downloadTemp";
}
