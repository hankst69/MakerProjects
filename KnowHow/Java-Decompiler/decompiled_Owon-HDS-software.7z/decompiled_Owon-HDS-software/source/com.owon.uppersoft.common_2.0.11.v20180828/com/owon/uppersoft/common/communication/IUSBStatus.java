package com.owon.uppersoft.common.communication;

public interface IUSBStatus {
   void usbStatus(boolean var1);

   boolean checkStatus();

   boolean shouldPopupCheck();
}
