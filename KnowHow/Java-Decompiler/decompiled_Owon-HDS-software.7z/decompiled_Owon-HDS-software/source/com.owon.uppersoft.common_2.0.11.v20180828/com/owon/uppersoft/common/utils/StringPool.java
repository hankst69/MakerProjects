package com.owon.uppersoft.common.utils;

public interface StringPool {
   String XMLFileFormatExtension = "xml";
   String CHMFileFormatExtension = "chm";
   String PDFFileFormatExtension = "pdf";
   String LAFileFormatExtension = "bin";
   String BINFileFormatExtension = "bin";
   String BMPFileFormatExtension = "bmp";
   String GIFFileFormatExtension = "gif";
   String PNGFileFormatExtension = "png";
   String XLSFileFormatExtension = "xls";
   String XLSFileFormatExtensionDesc = "Microsoft Office Excel Workbook(*.xls)";
   String TXTFileFormatExtension = "txt";
   String TXTFileFormatExtensionDesc = "Text(*.txt)";
   String CSVFileFormatExtension = "csv";
   String CSVFileFormatExtensionDesc = "Comma Separated Value Text(*.csv)";
   String DATFileFormatExtension = "dat";
   String DATFileFormatExtensionDesc = "Data Sheet(*.dat)";
   String EmptyString = "";
   String SemicolonString = ";";
   String LINE_SEPARATOR = SystemPropertiesUtil.LINE_SEPARATOR;
   String TRUE_STRING = "1";
   String FALSE_STRING = "0";
   String ONE = "1";
   String ZERO = "0";
   String[] EmptyStringArray = new String[]{""};
   String StarString = "*";
   String DotString = ".";
   String StarDotString = "*.";
   String SpaceString = " ";
   String Underline = "_";
   String Slash = "/";
   String BackSlash = "\\";
   int[] EmptyIntArray = new int[0];
   String UTF8EncodingString = "UTF-8";
   String ASCIIString = "ASCII";
}
