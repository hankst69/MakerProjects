package com.owon.uppersoft.common.commjob.instance;

import java.util.ArrayList;
import java.util.List;
import org.bridj.Pointer;
import org.bridj.Pointer.StringType;
import visa32.Visa32Library;

public class VisaCommunication implements ICommunication {
   private long defaultRM;
   private long vipSession;

   @Override
   public int read(byte[] arr, int beg, int len) {
      Pointer<Byte> pReadBuffer = Pointer.NULL;
      Pointer pReturnCount = Pointer.NULL;

      try {
         try {
            pReadBuffer = Pointer.allocateBytes((long)len);
            pReturnCount = Pointer.allocateLong();
            long visaStatus = Visa32Library.viRead(this.vipSession, pReadBuffer, (long)len, pReturnCount);
            if (visaStatus == 0L) {
               long returnCount = (Long)pReturnCount.get();
               if (returnCount != 0L) {
                  pReadBuffer.getBytes(arr);
                  System.out.println("returnCount:" + returnCount);
                  return (int)returnCount;
               }

               System.err.println("Error: Did not receive a response.");
            }

            System.out.println("err");
         } catch (Exception var14) {
            System.err.println(var14.toString());
         }

         return -1;
      } finally {
         if (pReadBuffer != Pointer.NULL) {
            pReadBuffer.release();
         }

         if (pReturnCount != Pointer.NULL) {
            pReturnCount.release();
         }
      }
   }

   @Override
   public int write(byte[] arr, int beg, int len) {
      String command = new String(arr, beg, len);
      Pointer<Byte> pBuffer = Pointer.NULL;
      Pointer pReturnCount = Pointer.allocateLong();
      long returnCount = 0L;

      try {
         pBuffer = Pointer.allocateBytes((long)len);
         pBuffer.setBytes(arr);
         long visaStatus = Visa32Library.viWrite(this.vipSession, pBuffer, (long)len, pReturnCount);
         if (visaStatus != 0L) {
            System.err.println(String.format("Error: Could not write %s.", command));
         } else {
            returnCount = (Long)pReturnCount.get();
            if (returnCount != (long)len) {
               System.err.println(String.format("Error: Could only write %d instead of %d bytes.", returnCount, len));
            }
         }

         return (int)returnCount;
      } catch (Exception var15) {
         System.err.println(var15.toString());
      } finally {
         if (pBuffer != Pointer.NULL) {
            pBuffer.release();
         }

         if (pReturnCount != Pointer.NULL) {
            pReturnCount.release();
         }
      }

      return -1;
   }

   @Override
   public boolean open(Object[] para) {
      String s = String.valueOf(para[0]);

      try {
         Pointer pViSession = Pointer.allocateLong();
         long status = Visa32Library.viOpenDefaultRM(pViSession);
         if (status < 0L) {
            return false;
         } else {
            this.defaultRM = pViSession.getCLong();
            Pointer<Byte> pBuffer = Pointer.NULL;
            pBuffer = Pointer.pointerToCString(s);
            pBuffer.setString(s, StringType.C);
            Pointer<Byte> pReadBuffer = Pointer.NULL;
            pReadBuffer = Pointer.allocateBytes(1024L);
            Pointer vi = Pointer.allocateLong();
            Pointer retCnt = Pointer.allocateLong();
            status = Visa32Library.viFindRsrc(this.defaultRM, pBuffer, vi, retCnt, pReadBuffer);
            if (status < 0L) {
               return false;
            } else {
               vi.getLong();
               Pointer instr = Pointer.allocateLong();
               if (retCnt.getLong() == 0L) {
                  return false;
               } else {
                  Visa32Library.viOpen(this.defaultRM, pReadBuffer, 0L, 0L, instr);
                  this.vipSession = instr.getCLong();
                  Visa32Library.viSetAttribute(this.vipSession, 1073676314L, 2000L);
                  return true;
               }
            }
         }
      } catch (Exception var11) {
         var11.printStackTrace();
         return false;
      }
   }

   @Override
   public void close() {
      long visaStatus = Visa32Library.viClose(this.vipSession);
      visaStatus = Visa32Library.viClose(this.defaultRM);
      System.out.println("close:" + visaStatus);
   }

   public List<String> findSrc() {
      List<String> list = new ArrayList<>();

      try {
         Pointer pViSession = Pointer.allocateLong();
         long status = Visa32Library.viOpenDefaultRM(pViSession);
         if (status < 0L) {
            System.out.println("Failed to initialise NI-VISA system.\n");
         }

         this.defaultRM = pViSession.getCLong();
         Pointer<Byte> pBuffer = Pointer.NULL;
         String s = "USB?*";
         pBuffer = Pointer.pointerToCString(s);
         pBuffer.setString(s, StringType.C);
         Pointer<Byte> pReadBuffer = Pointer.NULL;
         pReadBuffer = Pointer.allocateBytes(1024L);
         Pointer vi = Pointer.allocateLong();
         Pointer retCnt = Pointer.allocateLong();
         status = Visa32Library.viFindRsrc(this.defaultRM, pBuffer, vi, retCnt, pReadBuffer);

         for (long i = retCnt.getLong(); i > 0L; i--) {
            list.add(pReadBuffer.getString(StringType.C));
            Visa32Library.viFindNext(vi.getCLong(), pReadBuffer);
         }
      } catch (Exception var12) {
      }

      return list;
   }

   public static void main(String[] args) {
      VisaCommunication visa = new VisaCommunication();
      visa.findSrc();
   }

   @Override
   public boolean isConnected() {
      return false;
   }
}
