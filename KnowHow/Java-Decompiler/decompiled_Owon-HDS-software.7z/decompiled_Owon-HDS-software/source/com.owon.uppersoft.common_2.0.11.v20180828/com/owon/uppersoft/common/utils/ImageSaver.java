package com.owon.uppersoft.common.utils;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.ImageLoader;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

public class ImageSaver {
   public static void doSave(Shell shell, Image image, String infoDefault, String prompt) {
      FileDialog fd = new FileDialog(shell, 8192);
      String wildcard = "*.";
      String[] images = new String[]{wildcard + "bmp", wildcard + "png", wildcard + "gif"};
      fd.setFilterExtensions(images);
      fd.setFilterNames(images);
      String path = fd.open();
      if (path != null) {
         String ext = FileUtil.getExtension(path);
         int format = -1;
         if (ext.equalsIgnoreCase("bmp")) {
            format = 0;
         }

         if (ext.equalsIgnoreCase("png")) {
            format = 5;
         }

         if (ext.equalsIgnoreCase("gif")) {
            format = 0;
         }

         if (format == -1) {
            System.err.println("IMAGE_UNDEFINED");
            format = 0;
            path = path + ".bmp";
         }

         ImageLoader il = new ImageLoader();
         il.data = new ImageData[]{image.getImageData()};
         il.save(path, format);
         MessageDialog.openInformation(shell, infoDefault, prompt + path);
      }
   }

   public static void doSave(Shell shell, BufferedImage image, String infoDefault, String prompt) {
      FileDialog fd = new FileDialog(shell, 8192);
      String wildcard = "*.";
      String[] images = new String[]{wildcard + "bmp", wildcard + "png", wildcard + "gif"};
      fd.setFilterExtensions(images);
      fd.setFilterNames(images);
      String path = fd.open();
      if (path != null) {
         String ext = FileUtil.getExtension(path);

         try {
            ImageIO.write(image, ext, new File(path));
         } catch (IOException var10) {
            var10.printStackTrace();
         }

         MessageDialog.openInformation(shell, infoDefault, prompt + path);
      }
   }

   public static void main_hide(String[] args) {
      Display display = Display.getDefault();
      Image image = new Image(display, 600, 400);
      GC gc = new GC(image);
      gc.setForeground(display.getSystemColor(9));
      gc.drawLine(10, 10, 50, 50);
      ImageLoader il = new ImageLoader();
      il.data = new ImageData[]{image.getImageData()};
      il.save("c:/test.gif", 0);
   }
}
