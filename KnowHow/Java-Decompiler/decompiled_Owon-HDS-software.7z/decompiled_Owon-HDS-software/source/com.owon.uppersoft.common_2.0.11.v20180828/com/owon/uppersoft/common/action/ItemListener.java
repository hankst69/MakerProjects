package com.owon.uppersoft.common.action;

public interface ItemListener {
   void handle(EventType var1, Object var2);
}
