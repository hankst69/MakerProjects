package com.owon.uppersoft.common.utils;

public class MessagePool {
   public static final String Option_OK = "Option.OK";
   public static final String Option_Cancel = "Option.Cancel";
   public static final String Option_Yes = "Option.Yes";
   public static final String Option_No = "Option.No";
}
