package com.owon.uppersoft.common.aspect;

public interface Disposable {
   void dispose();
}
