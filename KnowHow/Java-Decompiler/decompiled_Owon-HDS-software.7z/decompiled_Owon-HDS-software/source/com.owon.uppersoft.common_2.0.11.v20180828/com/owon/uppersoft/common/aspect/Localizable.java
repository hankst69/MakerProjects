package com.owon.uppersoft.common.aspect;

public interface Localizable {
   void localize();
}
