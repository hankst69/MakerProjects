package com.owon.uppersoft.common.commjob.instance;

public class CommunicateFactory {
   public static ICommunication getComm(String type) {
      if (type.equalsIgnoreCase("USB")) {
         return new USBCommunication();
      } else {
         return (ICommunication)(type.equalsIgnoreCase("LAN") ? new LANCommunication() : new SerialCommunication());
      }
   }
}
