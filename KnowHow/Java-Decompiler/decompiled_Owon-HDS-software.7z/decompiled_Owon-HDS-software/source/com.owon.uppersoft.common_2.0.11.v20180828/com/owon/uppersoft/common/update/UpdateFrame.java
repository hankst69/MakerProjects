package com.owon.uppersoft.common.update;

import com.owon.uppersoft.common.i18n.CommonMessageLib;
import com.owon.uppersoft.common.utils.ShellUtil;
import java.io.File;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.program.Program;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;

public class UpdateFrame {
   private Text txtUrl;
   private Thread taskThd;
   private UpdateTask task;
   private Shell shell;
   private List<DownloadFile> files;
   private Composite bottomCom;
   private UpdateDetection ud;
   private Button cancelButton;
   private Button updateButton;
   private TableColumn urlTableColumn;
   private TableColumn progressTableColumn;
   private UpdateFrame.CloseNUpdate closeNupdate = new UpdateFrame.CloseNUpdate();
   private TableViewer tableViewer;

   public UpdateFrame(UpdateDetection ud, String url, List<DownloadFile> files) {
      this.ud = ud;
      this.files = files;
      this.createContents();
      this.txtUrl.setText("Downloading...");
      this.localize();
      this.task = new UpdateTask(this, url, files);
      this.taskThd = new Thread(this.task);
   }

   public void open() {
      this.shell.layout();
      this.shell.open();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   protected void createContents() {
      this.shell = new Shell(this.ud.getUpdatable().getMainShell(), 34032);
      this.shell.setSize(430, 250);
      GridLayout gridLayout = new GridLayout();
      this.shell.setLayout(gridLayout);
      this.txtUrl = new Text(this.shell, 586);
      GridData gd_txtUrl = new GridData(4, 16777216, true, false);
      gd_txtUrl.heightHint = 30;
      this.txtUrl.setLayoutData(gd_txtUrl);
      this.tableViewer = new TableViewer(this.shell, 67584);
      this.tableViewer.setLabelProvider(new UpdateFrame.TableLabelProvider());
      this.tableViewer.setContentProvider(new ArrayContentProvider());
      this.tableViewer.setInput(this.files);
      Table table = this.tableViewer.getTable();
      table.setHeaderVisible(true);
      GridData gd_table = new GridData(4, 4, true, true);
      table.setLayoutData(gd_table);
      this.urlTableColumn = new TableColumn(table, 131072);
      this.urlTableColumn.setWidth(350);
      this.progressTableColumn = new TableColumn(table, 131072);
      this.progressTableColumn.setWidth(50);
      this.bottomCom = new Composite(this.shell, 0);
      RowLayout rowLayout = new RowLayout();
      rowLayout.justify = true;
      this.bottomCom.setLayout(rowLayout);
      GridData gd_bottomCom = new GridData(4, 16777216, true, false);
      this.bottomCom.setLayoutData(gd_bottomCom);
      this.updateButton = new Button(this.bottomCom, 0);
      RowData rd_updateButton = new RowData();
      rd_updateButton.width = 100;
      this.updateButton.setLayoutData(rd_updateButton);
      this.updateButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            UpdateFrame.this.updateButton.setEnabled(false);
            UpdateFrame.this.taskThd.start();
         }
      });
      this.cancelButton = new Button(this.bottomCom, 0);
      RowData rd_cancelButton = new RowData();
      rd_cancelButton.width = 100;
      this.cancelButton.setLayoutData(rd_cancelButton);
      this.cancelButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            UpdateFrame.this.shell.close();
         }
      });
      this.shell.addShellListener(new ShellAdapter() {
         public void shellClosed(ShellEvent e) {
            if (UpdateFrame.this.taskThd.isAlive()) {
               UpdateFrame.this.task.setCancel();

               try {
                  UpdateFrame.this.taskThd.join();
               } catch (InterruptedException var3) {
                  var3.printStackTrace();
               }
            }
         }
      });
      ShellUtil.centerLoc(this.shell);
      this.shell.setFocus();
   }

   public void localize() {
      ResourceBundle bundle = CommonMessageLib.getDefaultResourceBundle();
      this.shell.setText(bundle.getString("Info.Title"));
      this.urlTableColumn.setText(bundle.getString("Info.DownloadFile"));
      this.progressTableColumn.setText(bundle.getString("Info.DownloadProgress"));
      this.cancelButton.setText(bundle.getString("Option.Cancel"));
      this.updateButton.setText(bundle.getString("Info.DoUpdate"));
   }

   public File getDownloadTempDir() {
      return this.ud.getDownloadTempDir();
   }

   public void downloadFailed() {
      this.shell.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            MessageDialog.openError(UpdateFrame.this.shell, "", CommonMessageLib.getDefaultResourceBundle().getString("Error.InternetConnection"));
            UpdateFrame.this.shell.close();
         }
      });
   }

   public void downloadFinished() {
      this.shell.getDisplay().asyncExec(this.closeNupdate);
   }

   public void setCurrentDownloadFile(final DownloadFile downloadFile, URL url) {
      this.shell.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            UpdateFrame.this.tableViewer.getTable().setFocus();
            UpdateFrame.this.tableViewer.setSelection(new StructuredSelection(downloadFile), true);
         }
      });
   }

   public void updateProgress() {
      this.shell.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            UpdateFrame.this.tableViewer.refresh();
         }
      });
   }

   class CloseNUpdate implements Runnable {
      @Override
      public void run() {
         if (!UpdateFrame.this.shell.isDisposed()) {
            UpdateFrame.this.cancelButton.setEnabled(false);
            UpdateFrame.this.shell.close();
         }

         IUpdatable iu = UpdateFrame.this.ud.getUpdatable();
         iu.notifyDestroy();
         iu.close();
         UpdateFrame.this.ud.filesUpdate(UpdateFrame.this.files);
         String eN = UpdateFrame.this.ud.getExecName();
         if (eN.length() == 0) {
            iu.startAgain();
         } else {
            Program.launch(eN);
         }
      }
   }

   class TableLabelProvider extends LabelProvider implements ITableLabelProvider {
      public String getColumnText(Object element, int columnIndex) {
         DownloadFile df = (DownloadFile)element;
         switch (columnIndex) {
            case 0:
               return df.getRelativePath().replaceAll("owon.", "");
            case 1:
               return df.getPercent();
            default:
               return "";
         }
      }

      public Image getColumnImage(Object element, int columnIndex) {
         return null;
      }
   }
}
