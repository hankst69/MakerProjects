package com.owon.uppersoft.hdoscilloscope.test;

import com.owon.uppersoft.common.utils.StringPool;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.printing.PrintDialog;
import org.eclipse.swt.printing.Printer;
import org.eclipse.swt.printing.PrinterData;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

public class PrintTextExample {
   public static void main(String[] args) {
      try {
         PrintTextExample window = new PrintTextExample();
         window.open();
      } catch (Exception var2) {
         var2.printStackTrace();
      }
   }

   public void open() {
      Shell shell = new Shell();
      Display display = shell.getDisplay();
      FileDialog fileDlg = new FileDialog(shell, 4096);
      String fileName = fileDlg.open();
      if (fileName != null) {
         PrintDialog printDlg = new PrintDialog(shell);
         PrinterData printerData = printDlg.open();
         if (printerData != null) {
            Printer printer = new Printer(printerData);

            try {
               String contents = this.getFileContents(fileName);
               PrintTextExample.MyPrinter p = new PrintTextExample.MyPrinter(printer, fileName, contents);
               p.print();
            } catch (Exception var10) {
               var10.printStackTrace();
            }

            printer.dispose();
         }
      }

      display.dispose();
   }

   private String getFileContents(String fileName) throws FileNotFoundException, IOException {
      StringBuffer contents = new StringBuffer();
      BufferedReader reader = null;

      try {
         reader = new BufferedReader(new FileReader(fileName));

         while (reader.ready()) {
            contents.append(reader.readLine());
            contents.append(StringPool.LINE_SEPARATOR);
         }
      } finally {
         if (reader != null) {
            try {
               reader.close();
            } catch (IOException var8) {
            }
         }
      }

      return contents.toString();
   }

   private class MyPrinter {
      private Printer printer;
      private String fileName;
      private String contents;
      private GC gc;
      private int xPos;
      private int yPos;
      private Rectangle bounds;
      private StringBuffer buf;
      private int lineHeight;

      public MyPrinter(Printer printer, String fileName, String contents) {
         this.printer = printer;
         this.fileName = fileName;
         this.contents = contents;
      }

      public void print() {
         if (this.printer.startJob(this.fileName)) {
            this.bounds = this.computePrintArea(this.printer);
            this.xPos = this.bounds.x;
            this.yPos = this.bounds.y;
            this.gc = new GC(this.printer);
            this.lineHeight = this.gc.getFontMetrics().getHeight();
            int tabWidth = this.gc.stringExtent(" ").x;
            this.printer.startPage();
            this.buf = new StringBuffer();
            int i = 0;

            for (int n = this.contents.length(); i < n; i++) {
               char c = this.contents.charAt(i);
               if (c == '\n') {
                  this.printBuffer();
                  this.printNewline();
               } else if (c == '\t') {
                  this.xPos += tabWidth;
               } else {
                  this.buf.append(c);
                  if (Character.isWhitespace(c)) {
                     this.printBuffer();
                  }
               }
            }

            this.printer.endPage();
            this.printer.endJob();
            this.gc.dispose();
         }
      }

      private void printBuffer() {
         int width = this.gc.stringExtent(this.buf.toString()).x;
         if (this.xPos + width > this.bounds.x + this.bounds.width) {
            this.printNewline();
         }

         this.gc.drawString(this.buf.toString(), this.xPos, this.yPos, false);
         this.xPos += width;
         this.buf.setLength(0);
      }

      private void printNewline() {
         this.xPos = this.bounds.x;
         this.yPos = this.yPos + this.lineHeight;
         if (this.yPos > this.bounds.y + this.bounds.height) {
            this.yPos = this.bounds.y;
            this.printer.endPage();
            this.printer.startPage();
         }
      }

      private Rectangle computePrintArea(Printer printer) {
         Rectangle rect = printer.getClientArea();
         Rectangle trim = printer.computeTrim(0, 0, 0, 0);
         Point dpi = printer.getDPI();
         int left = trim.x + dpi.x;
         if (left < rect.x) {
            left = rect.x;
         }

         int right = rect.width + trim.x + trim.width - dpi.x;
         if (right > rect.width) {
            right = rect.width;
         }

         int top = trim.y + dpi.y;
         if (top < rect.y) {
            top = rect.y;
         }

         int bottom = rect.height + trim.y + trim.height - dpi.y;
         if (bottom > rect.height) {
            bottom = rect.height;
         }

         return new Rectangle(left, top, right - left, bottom - top);
      }
   }
}
