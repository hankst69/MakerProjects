package com.owon.uppersoft.hdoscilloscope.data;

import java.io.File;
import java.util.List;

public interface IDataOutput {
   boolean outText(List<WaveForm> var1, DataTableDialog var2, File var3, WaveFormFile var4);

   boolean outXLS(List<WaveForm> var1, DataTableDialog var2, File var3, WaveFormFile var4);

   boolean outCSV(List<WaveForm> var1, DataTableDialog var2, File var3, WaveFormFile var4);
}
