package com.owon.uppersoft.hdoscilloscope.chart;

import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;

public abstract class AbstWFC implements WaveFormCurve {
   protected WaveFormFileCurve wffc;
   private int blockNum;

   public AbstWFC(WaveFormFileCurve wffc, WFReg wfreg) {
      this.wffc = wffc;
      wfreg.setCreate(true);
   }

   protected DrawEngine createDrawEngine(WaveFormFileCurve wffc, AbstWFC wfc) {
      return new DrawEngine(wffc.getDrawingPanel(), wfc);
   }

   @Override
   public int getBlockNum() {
      return this.blockNum;
   }

   public void setBlockNum(int blockNum) {
      this.blockNum = blockNum;
   }

   @Override
   public boolean isVisible() {
      return this.getWFReg().isShow();
   }

   @Override
   public void setVisible(boolean visible) {
      this.getWFReg().setShow(visible);
   }

   @Override
   public Color getColor() {
      RGB rgb = this.getRGB();
      if (rgb == null) {
         rgb = PropertiesItem.RGB_DARK_CYAN;
      }

      return Platform.getPlatform().getColorShop().getColor(rgb);
   }

   @Override
   public void setRGB(RGB rgb) {
      this.getWFReg().setRgb(rgb);
   }

   @Override
   public RGB getRGB() {
      return this.getWFReg().getRGB();
   }

   @Override
   public void draw(GraphicContext gx) {
      this.getScalableDrawEngine().draw(gx);
   }
}
