package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class DataPointAction extends DefaultAction {
   public DataPointAction(String id, int type) {
      super(id, type);
   }

   public void run() {
      DrawingPanel dp = Platform.getPlatform().getDrawingPanel();
      WaveFormFileCurve wffc = dp.getWaveFormFileCurve();
      if (wffc.isLineVisible()) {
         wffc.setLineVisible(false);
         this.setCheck(true);
         dp.redraw();
      }
   }
}
