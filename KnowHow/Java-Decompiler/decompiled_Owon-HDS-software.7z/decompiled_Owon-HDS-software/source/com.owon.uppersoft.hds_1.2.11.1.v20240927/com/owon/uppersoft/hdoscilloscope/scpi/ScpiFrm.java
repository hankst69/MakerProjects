package com.owon.uppersoft.hdoscilloscope.scpi;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.communication.loop.JobUnit;
import com.owon.uppersoft.hdoscilloscope.communication.loop.RapidCommunication;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.image.ImageShop;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

public class ScpiFrm implements Localizable2 {
   private Shell shell;
   private SCPIAction sa;
   private Shell parent;
   private Combo combo;
   private Text text;
   private ManipulateControl mc;
   private Button btnLoad;
   private Button btnSend;
   private Button btnClear;
   private Composite com;
   private Composite composite;
   private Button btnNewButton;
   private Button btnSigle;
   private Button btnLoop;
   private Button btnNewButton_1;
   private Spinner spinner;
   private int bufLen;
   private List<String> list;
   private boolean isLoop;
   private boolean isRun;
   private int time;
   private Group gpSetup;
   private Button btnCheckButton;
   private Spinner spinner_1;
   private Label lblNewLabel;

   public ScpiFrm(Shell parent, SCPIAction sa) {
      this.parent = parent;
      this.sa = sa;
      this.mc = sa.getManipulateControl();
      this.bufLen = 128;
   }

   public Shell getShell() {
      return this.shell;
   }

   public void open() {
      Display display = Display.getDefault();
      this.createContents();
      ShellUtil.centerLoc(this.shell);
      this.shell.open();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   protected void createContents() {
      this.shell = new Shell(this.parent, 1264);
      this.shell.addDisposeListener(new DisposeListener() {
         public void widgetDisposed(DisposeEvent e) {
            ScpiFrm.this.sa.release();
         }
      });
      this.shell.setSize(587, 480);
      this.shell.setLayout(new FillLayout(256));
      ImageShop is = Platform.getPlatform().getImageShop();
      this.shell.setImage(is.getImage("SCPI.gif"));
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 4;
      gridLayout.horizontalSpacing = 10;
      gridLayout.verticalSpacing = 10;
      gridLayout.marginHeight = 10;
      gridLayout.marginWidth = 10;
      this.com = new Composite(this.shell, 0);
      this.com.setLayout(gridLayout);
      this.btnLoad = new Button(this.com, 0);
      this.btnLoad.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ScpiFrm.this.openFile();
         }
      });
      this.combo = new Combo(this.com, 0);
      this.combo.setLayoutData(new GridData(4, 16777216, true, false, 1, 1));
      this.btnSend = new Button(this.com, 0);
      this.btnSend.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (ScpiFrm.this.text.getEditable()) {
               String s = ScpiFrm.this.text.getText();
               if (s.startsWith("hide")) {
                  ScpiFrm.this.composite.setVisible(true);
                  ScpiFrm.this.text.setEditable(false);
                  ScpiFrm.this.text.setText("");
                  return;
               }
            }

            String cmd = ScpiFrm.this.combo.getText();
            ScpiFrm.this.send(cmd, true);
         }
      });
      this.btnClear = new Button(this.com, 0);
      this.btnClear.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ScpiFrm.this.text.setText("");
         }
      });
      this.composite = new Composite(this.com, 0);
      this.composite.setLayout(new RowLayout(256));
      this.composite.setLayoutData(new GridData(16384, 16777216, false, false, 4, 1));
      this.btnNewButton = new Button(this.composite, 0);
      this.btnNewButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ScpiFrm.this.openScriptFile();
         }
      });
      this.btnNewButton.setText("load");
      this.btnSigle = new Button(this.composite, 16);
      this.btnSigle.setSelection(true);
      this.btnSigle.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ScpiFrm.this.isLoop = false;
         }
      });
      this.btnSigle.setText("sigle");
      this.btnLoop = new Button(this.composite, 16);
      this.btnLoop.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ScpiFrm.this.isLoop = true;
         }
      });
      this.btnLoop.setText("loop");
      this.spinner = new Spinner(this.composite, 2048);
      this.spinner.setMaximum(10000);
      this.spinner.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ScpiFrm.this.time = ScpiFrm.this.spinner.getSelection();
         }
      });
      this.spinner.setLayoutData(new RowData(65, -1));
      this.spinner.setSelection(1000);
      this.btnNewButton_1 = new Button(this.composite, 0);
      this.btnNewButton_1.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ScpiFrm.this.setRun();
         }
      });
      this.btnNewButton_1.setText("Start");
      this.gpSetup = new Group(this.com, 0);
      this.gpSetup.setLayout(new RowLayout(256));
      GridData gd_gpSetup = new GridData(16384, 16777216, false, false, 4, 1);
      gd_gpSetup.widthHint = 355;
      this.gpSetup.setLayoutData(gd_gpSetup);
      this.btnCheckButton = new Button(this.gpSetup, 32);
      this.lblNewLabel = new Label(this.gpSetup, 0);
      this.lblNewLabel.setLayoutData(new RowData(112, -1));
      this.spinner_1 = new Spinner(this.gpSetup, 2048);
      this.spinner_1.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ScpiFrm.this.bufLen = ScpiFrm.this.spinner_1.getSelection();
            ScpiFrm.this.lblNewLabel.setText("  Buffer:" + ScpiFrm.this.bufLen);
         }
      });
      this.spinner_1.setMaximum(1000000);
      this.spinner_1.setMinimum(128);
      this.text = new Text(this.com, 2634);
      this.text.addMouseListener(new MouseAdapter() {
         public void mouseDoubleClick(MouseEvent e) {
            ScpiFrm.this.text.setEditable(!ScpiFrm.this.text.getEditable());
            ScpiFrm.this.text.setText("");
         }
      });
      this.text.setLayoutData(new GridData(4, 4, true, true, 4, 1));
      this.addItems();
      this.composite.setVisible(false);
      this.time = 1000;
      this.localize(ResourceBundleProvider.getMessageLibResourceBundle());
   }

   public void localize(ResourceBundle bundle) {
      this.shell.setText(bundle.getString("MF.scpi"));
      this.btnLoad.setText("Load File");
      this.btnSend.setText("SEND");
      this.btnClear.setText("CLEAR");
      this.btnCheckButton.setText("Hex");
      this.lblNewLabel.setText("  Buffer:" + this.bufLen);
   }

   private void send(final String cmd, final boolean isDisp) {
      if (cmd.length() != 0) {
         this.mc.send(new JobUnit(cmd) {
            @Override
            public void doJob(RapidCommunication irc, ByteBuffer bbuf) {
               System.out.println(cmd);
               byte[] bs = cmd.getBytes();
               irc.write(bs, 0, bs.length);
               if (isDisp) {
                  if (ScpiFrm.this.shell.isDisposed()) {
                     return;
                  }

                  ScpiFrm.this.shell.getDisplay().asyncExec(new Runnable() {
                     @Override
                     public void run() {
                        ScpiFrm.this.text.append("[Send: ]");
                        ScpiFrm.this.text.append(cmd);
                        ScpiFrm.this.text.append("\r\n");
                     }
                  });
               }

               if (cmd.endsWith("?")) {
                  final byte[] bb = new byte[ScpiFrm.this.bufLen];
                  final int rn = irc.read(bb, 0, bb.length);
                  if (rn > 0) {
                     if (ScpiFrm.this.shell.isDisposed()) {
                        return;
                     }

                     ScpiFrm.this.shell.getDisplay().asyncExec(new Runnable() {
                        @Override
                        public void run() {
                           String s;
                           if (ScpiFrm.this.btnCheckButton.getSelection()) {
                              s = ScpiFrm.this.bytesToHexString(bb, 0, rn);
                           } else {
                              s = new String(bb, 0, rn).replaceAll("\u0000", "");
                           }

                           ScpiFrm.this.text.append("[Receive: ]");
                           ScpiFrm.this.text.append(s);
                           ScpiFrm.this.text.append("\r\n");
                        }
                     });
                  } else if (rn < 0) {
                     if (ScpiFrm.this.shell.isDisposed()) {
                        return;
                     }

                     ScpiFrm.this.shell.getDisplay().asyncExec(new Runnable() {
                        @Override
                        public void run() {
                           ScpiFrm.this.text.append("[Receive Error!]\r\n");
                        }
                     });
                  }
               }
            }
         });
      }
   }

   private String bytesToHexString(byte[] src, int start, int end) {
      StringBuilder stringBuilder = new StringBuilder("");
      if (src != null && src.length > 0) {
         for (int i = start; i < end; i++) {
            int v = src[i] & 255;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
               stringBuilder.append(0);
            }

            stringBuilder.append(hv + " ");
         }

         return stringBuilder.toString().toUpperCase();
      } else {
         return null;
      }
   }

   private void append(final String s) {
      this.shell.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            ScpiFrm.this.text.append(s + "\r\n");
         }
      });
   }

   private void setRun() {
      this.shell.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            ScpiFrm.this.isRun = !ScpiFrm.this.isRun;
            if (ScpiFrm.this.isRun) {
               ScpiFrm.this.btnNewButton_1.setText("Stop");
               new Thread(ScpiFrm.this.new runScript()).start();
            } else {
               ScpiFrm.this.btnNewButton_1.setText("Start");
            }
         }
      });
   }

   private void openFile() {
      FileDialog fd = new FileDialog(this.getShell(), 4096);
      String path = fd.open();
      if (path != null) {
         try {
            FileInputStream fis = new FileInputStream(path);
            this.combo.removeAll();
            this.addItems(fis);
         } catch (FileNotFoundException var4) {
            var4.printStackTrace();
         }
      }
   }

   private void openScriptFile() {
      if (this.isRun) {
         this.append("Script running,Stop First");
      } else {
         FileDialog fd = new FileDialog(this.getShell(), 4096);
         String path = fd.open();
         this.list = new ArrayList<>();
         if (path != null) {
            try {
               FileInputStream fis = new FileInputStream(path);
               BufferedReader dr = new BufferedReader(new InputStreamReader(fis));

               String s;
               while ((s = dr.readLine()) != null) {
                  this.list.add(s);
               }

               dr.close();
               fis.close();
               this.append("Load Script File Finish");
            } catch (FileNotFoundException var6) {
               var6.printStackTrace();
            } catch (IOException var7) {
               var7.printStackTrace();
            }
         }
      }
   }

   private void addItems() {
      InputStream fis = this.getClass().getResourceAsStream("SCPI.txt");
      this.addItems(fis);
   }

   private void addItems(InputStream fis) {
      try {
         BufferedReader dr = new BufferedReader(new InputStreamReader(fis));

         String s;
         while ((s = dr.readLine()) != null) {
            this.combo.add(s);
         }

         this.combo.select(0);
         dr.close();
         fis.close();
      } catch (FileNotFoundException var4) {
         var4.printStackTrace();
      } catch (IOException var5) {
         var5.printStackTrace();
      }
   }

   class runScript implements Runnable {
      @Override
      public void run() {
         ScpiFrm.this.append("Run Script Start");

         for (int i = 0; i < ScpiFrm.this.list.size(); i++) {
            ScpiFrm.this.send(ScpiFrm.this.list.get(i), true);

            try {
               Thread.sleep((long)ScpiFrm.this.time);
            } catch (InterruptedException var3) {
               var3.printStackTrace();
            }

            if (!ScpiFrm.this.isRun) {
               break;
            }

            if (ScpiFrm.this.isLoop && i == ScpiFrm.this.list.size() - 1) {
               i = -1;
            }
         }

         ScpiFrm.this.append("Run Script Finish");
         if (ScpiFrm.this.isRun) {
            ScpiFrm.this.setRun();
         }
      }
   }
}
