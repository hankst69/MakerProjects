package com.owon.uppersoft.hdoscilloscope.frame;

import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.Viewer;

public class MyContentProvider implements IStructuredContentProvider {
   public Object[] getElements(Object inputElement) {
      WaveFormFileCurve wffc = (WaveFormFileCurve)inputElement;
      return wffc.all_collect().toArray();
   }

   public void dispose() {
   }

   public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
   }
}
