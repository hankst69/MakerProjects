package com.owon.uppersoft.hdoscilloscope.test;

import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ILazyContentProvider;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

public class Snippet030VirtualLazyTableViewer {
   public Snippet030VirtualLazyTableViewer(Shell shell) {
      TableViewer v = new TableViewer(shell, 268435456);
      v.setLabelProvider(new Snippet030VirtualLazyTableViewer.MyTableLabelProvider(null));
      v.setContentProvider(new Snippet030VirtualLazyTableViewer.MyContentProvider(v));
      v.setUseHashlookup(true);
      Snippet030VirtualLazyTableViewer.MyModel[] model = this.createModel();
      v.setInput(model);
      v.setItemCount(model.length);
      Table t = v.getTable();
      t.setHeaderVisible(true);
      TableLayout tl = new TableLayout();
      t.setLayout(tl);
      tl.addColumnData(new ColumnWeightData(20));
      new TableColumn(t, 0).setText("0");
      tl.addColumnData(new ColumnWeightData(20));
      new TableColumn(t, 0).setText("1");
      tl.addColumnData(new ColumnWeightData(20));
      new TableColumn(t, 0).setText("2");
      tl.addColumnData(new ColumnWeightData(20));
      new TableColumn(t, 0).setText("3");
      v.getTable().setLinesVisible(true);
   }

   private Snippet030VirtualLazyTableViewer.MyModel[] createModel() {
      Snippet030VirtualLazyTableViewer.MyModel[] elements = new Snippet030VirtualLazyTableViewer.MyModel[10000];

      for (int i = 0; i < 10000; i++) {
         elements[i] = new Snippet030VirtualLazyTableViewer.MyModel(i);
      }

      return elements;
   }

   public static void main(String[] args) {
      Display display = new Display();
      Shell shell = new Shell(display);
      shell.setLayout(new FillLayout());
      new Snippet030VirtualLazyTableViewer(shell);
      shell.open();

      while (!shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }

      display.dispose();
   }

   private class MyContentProvider implements IStructuredContentProvider, ILazyContentProvider {
      private TableViewer viewer;
      private Snippet030VirtualLazyTableViewer.MyModel[] elements;

      public MyContentProvider(TableViewer viewer) {
         this.viewer = viewer;
      }

      public Object[] getElements(Object inputElement) {
         return this.elements;
      }

      public void dispose() {
      }

      public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
         this.elements = (Snippet030VirtualLazyTableViewer.MyModel[])newInput;
      }

      public void updateElement(int index) {
         this.viewer.replace(this.elements[index], index);
      }
   }

   public class MyModel {
      public int counter;

      public MyModel(int counter) {
         this.counter = counter;
      }

      @Override
      public String toString() {
         return "Item " + this.counter;
      }
   }

   private class MyTableLabelProvider implements ITableLabelProvider {
      private MyTableLabelProvider() {
      }

      public Image getColumnImage(Object element, int columnIndex) {
         return null;
      }

      public String getColumnText(Object element, int columnIndex) {
         Snippet030VirtualLazyTableViewer.MyModel mm = (Snippet030VirtualLazyTableViewer.MyModel)element;
         return mm.toString() + "," + columnIndex;
      }

      public void addListener(ILabelProviderListener listener) {
      }

      public void dispose() {
      }

      public boolean isLabelProperty(Object element, String property) {
         return false;
      }

      public void removeListener(ILabelProviderListener listener) {
      }
   }
}
