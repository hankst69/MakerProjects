package com.owon.uppersoft.hdoscilloscope.communication.loop;

import com.owon.uppersoft.common.commjob.instance.ICommunication;
import com.owon.uppersoft.common.commjob.instance.LANCommunication;
import com.owon.uppersoft.common.commjob.instance.USBCommunication;
import com.owon.uppersoft.common.commjob.instance.VisaCommunication;
import com.owon.uppersoft.hdoscilloscope.communication.usb.PersistBuffer;
import com.owon.uppersoft.hdoscilloscope.communication.usb.rapid.RapidLoop;
import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class RapidCommunication {
   static final short IdVender = 21317;
   static final short IdProduct = 4660;
   private String[] cmd = new String[]{":DATA:WAVE:SCREEN:HEAD?\r\n", ":DATA:WAVE:SCREEN:BMP?\r\n", ":DATA:WAVE:DEPMEM:All?\r\n"};
   private byte[] strBegin = "SPBXDS".getBytes();
   private ICommunication comm;
   private String fileType;
   private PersistBuffer pb;
   private String errKey;
   private ICommunicationListenerProvider iclp;
   private Configuration config;
   private RapidLoop rl;
   private File dest;

   public RapidCommunication(ICommunicationListenerProvider iclp) {
      this.iclp = iclp;
      this.config = Platform.getPlatform().getConfiguration();
   }

   public void startInit() {
      String portType = this.config.portType;
      Object[] para;
      if (portType.equalsIgnoreCase("USB")) {
         this.comm = new USBCommunication();
         para = new Short[]{(short)21317, (short)4660};
      } else if (portType.equalsIgnoreCase("LAN")) {
         this.comm = new LANCommunication();
         para = this.config.address.split(":");
      } else if (portType.equalsIgnoreCase("USBTMC")) {
         this.comm = new VisaCommunication();
         para = new Object[]{this.config.strusbtmc};
      } else {
         para = new String[]{"s", ""};
      }

      if (!this.comm.open(para)) {
         this.errKey = "Err.Unknown";
      }
   }

   public void startOnce() {
   }

   public void endOnce() {
   }

   public void endFinl() {
      this.comm.close();
   }

   public boolean getData() {
      return this.doGetData();
   }

   public void cancel() {
   }

   public String getFileType() {
      return this.fileType;
   }

   public CByteArrayInputStream byteInput() {
      return this.dest == null ? new CByteArrayInputStream(this.pb.getFile(), true) : new CByteArrayInputStream(this.dest);
   }

   public boolean setSavedFile(File file) {
      this.dest = file;
      return this.pb.renameTo(file);
   }

   public String getCommunicaitonErrorMsgKey() {
      return this.errKey;
   }

   public int read(byte[] arr, int beg, int len) {
      return this.comm.read(arr, beg, len);
   }

   public int write(byte[] arr, int beg, int len) {
      return this.comm.write(arr, beg, len);
   }

   public static void main(String[] args) {
   }

   private boolean doGetData() {
      if (this.pb == null) {
         this.pb = new PersistBuffer();
      }

      this.pb.init();
      RandomAccessFile raf = this.pb.raf();
      this.rl = Platform.getPlatform().getActionFactory().loopControl.getRapidLoop();
      if (this.config.usbRequestCMDidx == 1) {
         this.fileType = "bmp";
      } else {
         this.fileType = "bin";
      }

      String command = this.cmd[this.config.usbRequestCMDidx];
      byte[] arr = command.getBytes();
      this.comm.write(arr, 0, arr.length);
      byte[] b = this.readIncludeSize();
      if (b == null) {
         this.errKey = "Err.Unknown";
         return false;
      } else if (this.config.usbRequestCMDidx > 0) {
         try {
            if (this.config.usbRequestCMDidx == 2) {
               raf.write(this.strBegin);
            }

            raf.write(b, 4, b.length - 4);
         } catch (IOException var11) {
            var11.printStackTrace();
         }

         return true;
      } else {
         JSONObject jo = null;

         try {
            String s = new String(b, 4, b.length - 4).trim();
            jo = JSONObject.fromObject(s);
         } catch (Exception var13) {
            var13.printStackTrace();
            return false;
         }

         jo.element("IsSkipIfClosed", true);

         try {
            raf.write(this.strBegin);
            raf.write(this.setInt(jo.toString().length()));
            raf.writeBytes(jo.toString());
         } catch (IOException var12) {
            var12.printStackTrace();
         }

         JSONArray ja = jo.getJSONArray("CHANNEL");

         try {
            for (int i = 0; i < ja.size(); i++) {
               JSONObject ch = ja.getJSONObject(i);
               String disp = ch.getString("DISPLAY");
               String name = ch.getString("NAME");
               if (disp.equalsIgnoreCase("on")) {
                  this.writeString(":DATA:WAVE:SCREEN:" + name + "?\r\n");
                  b = this.readIncludeSize();
                  if (b == null) {
                     this.errKey = "Err.Connect";
                     return false;
                  }

                  raf.write(b);
               }
            }
         } catch (Exception var14) {
            var14.printStackTrace();
         }

         return true;
      }
   }

   public byte[] readIncludeSize() {
      byte[] b = new byte[10240];
      int num = this.comm.read(b, 0, b.length);
      if (num <= 4) {
         System.out.println(num);
         return null;
      } else {
         int len = this.getInt(b) + 4;
         if ((double)len > 1.6E8) {
            System.out.println("too long");
            return null;
         } else {
            if (this.iclp != null) {
               this.iclp.getCommunicationListener().communicateInfo(len, this.fileType);
            }

            System.out.println("len" + len);
            ByteBuffer bb = ByteBuffer.allocate(len);
            bb.put(b, 0, num);
            if (this.iclp != null) {
               this.iclp.getCommunicationListener().progressInfo(bb.position());
            }

            int time = 3;

            while (bb.remaining() > 0) {
               num = this.comm.read(b, 0, b.length);
               if (num <= 0) {
                  System.err.println("error");
                  if (time-- < 0) {
                     break;
                  }
               } else {
                  bb.put(b, 0, num);
                  if (this.iclp != null) {
                     this.iclp.getCommunicationListener().progressInfo(bb.position());
                  }

                  if (!this.keepOn()) {
                     break;
                  }
               }
            }

            return bb.array();
         }
      }
   }

   private int getInt(byte[] b) {
      int i = b[0] & 255;
      i += (b[1] & 255) << 8;
      i += (b[2] & 255) << 16;
      return i + ((b[3] & 0xFF) << 24);
   }

   private byte[] setInt(int i) {
      return new byte[]{(byte)(i & 0xFF), (byte)(i >> 8 & 0xFF), (byte)(i >> 16 & 0xFF), (byte)(i >> 24 & 0xFF)};
   }

   public void writeString(String s) {
      byte[] arr = s.getBytes();
      this.comm.write(arr, 0, arr.length);
   }

   private String readString() {
      byte[] arr = new byte[512];

      try {
         int rn = this.comm.read(arr, 0, arr.length);
         return rn < 0 ? "" : new String(arr, 0, rn);
      } catch (Exception var3) {
         var3.printStackTrace();
         return "";
      }
   }

   private String readStringWithoutExt() {
      return this.readString().replaceAll("->", "").trim();
   }

   public boolean getSavedData(JSONArray ja) {
      this.pb = new PersistBuffer();
      this.pb.init();
      RandomAccessFile raf = this.pb.raf();
      JSONObject jo = new JSONObject();
      jo.element("IDN", this.getIdn());
      jo.element("MODEL", this.getModel());
      jo.element("CHANNEL", ja);
      jo.element("DATATYPE", "internal");

      try {
         this.fileType = "bin";
         raf.write(this.strBegin);
         byte[] b = jo.toString().getBytes();
         raf.write(this.setInt(b.length));
         raf.write(b);
      } catch (IOException var6) {
         var6.printStackTrace();
      }

      try {
         for (int i = 0; i < ja.size(); i++) {
            String index = ja.getJSONObject(i).getString("index");
            this.writeString(":SAVE:READ:DATA " + index);
            raf.write(this.readIncludeSize());
         }
      } catch (Exception var7) {
         var7.printStackTrace();
      }

      return true;
   }

   public String getIdn() {
      this.writeString("*IDN?");
      return this.readStringWithoutExt();
   }

   public String getModel() {
      this.writeString(":MODEL?");
      return this.readStringWithoutExt();
   }

   private boolean keepOn() {
      if (this.rl != null) {
         this.rl.isKeepOn();
      }

      return true;
   }
}
