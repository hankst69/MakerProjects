package com.owon.uppersoft.hdoscilloscope;

import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;

public class OSCApplication implements IApplication {
   public Object start(IApplicationContext context) throws Exception {
      Main.main(null);
      return IApplication.EXIT_OK;
   }

   public void stop() {
   }
}
