package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail2.TrgComposite;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

public class EdgeComposite extends AbsTrgComposite implements Localizable2 {
   private Combo cplcb;
   private Combo rnfcb;
   private ItemCom itemCom;
   public static final byte[] mtr = "MTR".getBytes();
   private boolean use = false;
   private Label rnf_lbl;
   private Label cpl_lbl;

   public EdgeComposite(Composite parent, TrgComposite tc) {
      super(parent, 0, tc);
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 2;
      this.setLayout(gridLayout);
      this.rnf_lbl = new Label(this, 0);
      this.rnfcb = new Combo(this, 8);
      this.rnfcb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int idx = EdgeComposite.this.getEdgeTrg().edge = EdgeComposite.this.rnfcb.getSelectionIndex();
            String[] edge = new String[]{"RISE", "FALL"};
            String cmd = ":TRIGger:SINGle:EDGE " + edge[idx];
            EdgeComposite.this.submit(cmd);
         }
      });
      GridData gd_rnfcb = new GridData(131072, 16777216, false, false, 1, 1);
      gd_rnfcb.widthHint = 70;
      this.rnfcb.setLayoutData(gd_rnfcb);
      this.cpl_lbl = new Label(this, 0);
      this.cplcb = new Combo(this, 8);
      this.cplcb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int idx = EdgeComposite.this.getEdgeTrg().coupling = EdgeComposite.this.cplcb.getSelectionIndex();
            String cmd = ":TRIGger:SINGle:COUPling " + ManipulateControl.COUPLING[idx];
            EdgeComposite.this.submit(cmd);
         }
      });
      GridData gd_cplcb = new GridData(131072, 16777216, false, false, 1, 1);
      gd_cplcb.widthHint = 70;
      this.cplcb.setLayoutData(gd_cplcb);
      ManipulateControl mc = Platform.getPlatform().getManipulateControl();
      Item item = new Item("M.Trg.level", ":TRIGger:SINGle:EDGe:LEVel", new String[]{"mV", "V"}, new String[]{"+", "-"});
      this.cplcb.setItems(ManipulateControl.COUPLING);
      this.cplcb.select(0);
      this.rnfcb.setItems(ManipulateControl.toStrings(TrgControl.RiseFall));
      this.rnfcb.select(0);
      this.itemCom = new ItemCom(this, 0, item, mc);
      this.itemCom.setLayoutData(new GridData(16384, 16777216, false, false, 2, 1));
      this.updatelbl(this.getEdgeTrg().level);
      this.use = true;
   }

   private void updatelbl(int v) {
      String.format("/25 = %.2f div", (double)v / 25.0);
   }

   public void submit(String cmd) {
      Platform.getPlatform().getManipulateControl().send(cmd);
   }

   public void localize(ResourceBundle rb) {
      this.use = false;
      this.rnf_lbl.setText(rb.getString("M.Trg.Edge.rnf"));
      this.cpl_lbl.setText(rb.getString("M.Trg.Edge.coupling"));
      this.itemCom.localize(rb);
      int idx = this.rnfcb.getSelectionIndex();
      this.rnfcb.setItems(ManipulateControl.toStrings(TrgControl.RiseFall));
      this.rnfcb.select(idx);
      this.use = true;
   }

   @Override
   public void loadTrgGroup(TrgControl tc) {
      TrgGroup tg = tc.getCurrent();
      this.use = false;
      EdgeTrg et = tg.et;
      this.rnfcb.select(et.edge);
      this.cplcb.select(et.coupling);
      int l = et.level;
      this.updatelbl(l);
      this.use = true;
   }

   private EdgeTrg getEdgeTrg() {
      return this.tcom.getTrgControl().getCurrent().et;
   }
}
