package com.owon.uppersoft.hdoscilloscope.communication.serial;

import com.owon.uppersoft.common.logger.LoggerUtil;
import com.owon.uppersoft.common.utils.StringPool;
import com.owon.uppersoft.hdoscilloscope.communication.loop.ICommunicationListenerProvider;
import com.owon.uppersoft.hdoscilloscope.data.LogData;
import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import gnu.io.UnsupportedCommOperationException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.TooManyListenersException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SerialCommunication implements SerialPortEventListener {
   public static final int OpenPortTimeout = 2000;
   private InputStream is;
   private OutputStream os;
   private SerialPort SrPt;
   private CommPortIdentifier portId;
   private YModem ym;
   private int commStatus;
   public static final Logger logger = LoggerUtil.getFileLogger(SerialCommunication.class.getName(), Level.INFO, PropertiesItem.LogDir);
   private ICommunicationListenerProvider iclp;
   private SerialCommunication.WaitTimeout wt;

   public SerialCommunication(ICommunicationListenerProvider iclp) {
      this.iclp = iclp;
   }

   public static List<String> loadAvailablePort() {
      List<String> avaliblePortList = new ArrayList<>(5);
      Enumeration portList = CommPortIdentifier.getPortIdentifiers();

      while (portList.hasMoreElements()) {
         CommPortIdentifier portId = (CommPortIdentifier)portList.nextElement();
         if (portId.getPortType() == 1) {
            avaliblePortList.add(portId.getName());
         }
      }

      return avaliblePortList;
   }

   public boolean openPort(String port) {
      try {
         this.portId = CommPortIdentifier.getPortIdentifier(port);
         this.SrPt = (SerialPort)this.portId.open("OWON_SerialPort", 2000);
         return true;
      } catch (NoSuchPortException var3) {
         var3.printStackTrace();
      } catch (PortInUseException var4) {
         var4.printStackTrace();
      }

      return false;
   }

   public void loadPort(int baudRate, int dataBits, int stopBits, int parity) {
      try {
         this.is = this.SrPt.getInputStream();
         this.os = this.SrPt.getOutputStream();
      } catch (IOException var10) {
         var10.printStackTrace();
      } catch (Exception var11) {
         var11.printStackTrace();
      }

      try {
         this.SrPt.addEventListener(this);
      } catch (TooManyListenersException var8) {
         var8.printStackTrace();
      } catch (Exception var9) {
         var9.printStackTrace();
      }

      try {
         this.SrPt.setSerialPortParams(baudRate, dataBits, stopBits, parity);
      } catch (UnsupportedCommOperationException var6) {
         var6.printStackTrace();
      } catch (Exception var7) {
         var7.printStackTrace();
      }

      this.SrPt.notifyOnDataAvailable(true);
   }

   public void serialEvent(SerialPortEvent event) {
      switch (event.getEventType()) {
         case 1:
            logger.info(StringPool.LINE_SEPARATOR + "[SerialComm: data available]");
            this.responseOnDataAvaible();
            break;
         case 2:
            logger.fine("/*Output buffer empty*/");
            break;
         case 3:
            logger.fine("/*Clear to send*/");
            break;
         case 4:
            logger.fine("/*Data set ready*/");
            break;
         case 5:
            logger.fine("/*Ring indicator*/");
            break;
         case 6:
            logger.fine("/*Carrier detect*/");
            break;
         case 7:
            logger.severe("/*Overrun error*/");
            break;
         case 8:
            logger.severe("/*Parity error*/");
            break;
         case 9:
            logger.severe("/*Framing error*/");
            break;
         case 10:
            logger.info("/*Break interrupt*/");
            break;
         default:
            logger.severe(event.toString());
      }
   }

   private void responseOnDataAvaible() {
      if (this.isCommTerminated()) {
         int delay = 100;
         this.waitToReceiveAll(delay);
         int bufferSize = 1034;
         byte[] b = new byte[bufferSize];
         int size = 0;

         try {
            size = this.is.read(b);
         } catch (IOException var6) {
            var6.printStackTrace();
         }

         logger.info("[SerialComm: log]cancel when data available");
         LogData.logDataHex(b, 0, size);
      } else {
         this.wt.stepOn();
         int delay = 150;
         this.waitToReceiveAll(delay);
         int value = this.ym.responseOnDataAvaible();
         if (!this.isCommTerminated()) {
            this.commStatus = value;
         }
      }
   }

   private void waitToReceiveAll(int delay) {
      int delayRead = delay;

      try {
         Thread.sleep((long)delayRead);
      } catch (InterruptedException var4) {
         var4.printStackTrace();
      }
   }

   public boolean isCommTerminated() {
      return this.commStatus < -1 && this.commStatus > -10;
   }

   public boolean isCommEnd() {
      while (!this.isCommTerminated() || this.wt.isAlive()) {
         int delay = 1000;
         this.waitToReceiveAll(delay);
      }

      return true;
   }

   public boolean isCommFail() {
      return this.commStatus != -3 && this.commStatus != -7 && this.commStatus != -6 && this.commStatus != -5;
   }

   public boolean isCommCancel() {
      return this.commStatus == -7;
   }

   public void startComm() {
      this.commStatus = -1;
      this.ym = new YModem(this.is, this.os, this.iclp);
      this.ym.startTransaction();
      this.wt = new SerialCommunication.WaitTimeout();
      this.wt.startUp();
   }

   public void cancelComm(int type) {
      this.commStatus = type;
      this.ym.cancelTransaction();
   }

   private void cancelCommOnTimeout() {
      this.cancelComm(-6);
      this.close();
   }

   public String getFileType() {
      return this.ym.getFileType();
   }

   public ByteBuffer buf() {
      ByteBuffer buf = ByteBuffer.wrap(this.ym.getBigData(), 0, this.ym.getBigData().length);
      ((Buffer)buf).position(this.ym.getBigData().length);
      ((Buffer)buf).flip();
      return buf;
   }

   private byte[] getMatrixData() {
      return this.ym.getBigData();
   }

   private int getDataLength() {
      return this.ym.getBigData().length;
   }

   private int getDataBeginIndex() {
      return 0;
   }

   public boolean setSavedFile(File file) {
      FileOutputStream fileOutputStream = null;
      byte[] bigData = this.ym.getBigData();

      try {
         fileOutputStream = new FileOutputStream(file);
         fileOutputStream.write(bigData);
         fileOutputStream.flush();
         return true;
      } catch (FileNotFoundException var15) {
         Logger.getLogger("global").log(Level.SEVERE, null, var15);
         return false;
      } catch (IOException var16) {
         Logger.getLogger("global").log(Level.SEVERE, null, var16);
      } finally {
         try {
            if (fileOutputStream != null) {
               fileOutputStream.close();
            }
         } catch (IOException var14) {
            Logger.getLogger("global").log(Level.SEVERE, null, var14);
         }
      }

      return false;
   }

   public void close() {
      try {
         if (this.is != null) {
            this.is.close();
         }

         if (this.os != null) {
            this.os.close();
         }
      } catch (IOException var5) {
         var5.printStackTrace();
      } finally {
         if (this.portId.isCurrentlyOwned() && this.SrPt != null) {
            this.SrPt.close();
            logger.info("[SerialCom: log]closed.");
         }
      }
   }

   public static void main_hide(String[] args) {
      SerialCommunication serialComm = new SerialCommunication(null);
      List<String> list = loadAvailablePort();
      StringBuilder sb = new StringBuilder();

      for (Object ss : list) {
         sb.append(ss + " ");
      }

      logger.info(sb.toString());
      String portId = "COM1";
      serialComm.openPort(portId);
      serialComm.loadPort(115200, 8, 1, 0);
      serialComm.startComm();
      serialComm.isCommEnd();
      serialComm.setSavedFile(new File("bin." + serialComm.getFileType()));
      logger.info("file saved!");
   }

   class WaitTimeout extends Thread {
      private int delay = 10;
      private int counter;

      public void startUp() {
         this.counter = 0;
         this.start();
      }

      public void stepOn() {
         this.counter++;
      }

      @Override
      public void run() {
         int lastValue = 0;

         label34:
         while (!SerialCommunication.this.isCommTerminated() && SerialCommunication.this.commStatus <= -7 && SerialCommunication.this.commStatus >= -5) {
            lastValue = this.counter;

            for (int i = 0; i < 500; i++) {
               SerialCommunication.this.waitToReceiveAll(this.delay);
               if (lastValue < this.counter) {
                  SerialCommunication.logger.fine("[waitTimeout thread]" + lastValue + "return on " + i);
                  continue label34;
               }

               if (SerialCommunication.this.isCommTerminated()) {
                  return;
               }
            }

            SerialCommunication.logger.fine("[SerialComm: log]wait 500*10ms until timeout, cancle");
            SerialCommunication.this.cancelCommOnTimeout();
            break;
         }
      }
   }
}
