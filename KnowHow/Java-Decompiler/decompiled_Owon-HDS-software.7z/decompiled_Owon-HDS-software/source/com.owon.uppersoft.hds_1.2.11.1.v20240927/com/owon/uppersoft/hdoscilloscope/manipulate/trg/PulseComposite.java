package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail2.TrgComposite;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

public class PulseComposite extends AbsTrgComposite implements Localizable2 {
   private Combo cplcb;
   private Label sweeplbl;
   public static final byte[] mtr = "MTR".getBytes();
   private boolean use = false;
   private Label cpl_lbl;
   private Combo combo;
   private Label lbPolarity;
   private Combo cobPolarity;
   private Spinner spinner;
   private Combo combo_1;

   private EdgeTrg getEdgeTrg() {
      return this.tcom.getTrgControl().getCurrent().et;
   }

   public PulseComposite(Composite parent, TrgComposite tc) {
      super(parent, 0, tc);
      ManipulateControl mc = Platform.getPlatform().getManipulateControl();
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 4;
      this.setLayout(gridLayout);
      this.cpl_lbl = new Label(this, 0);
      this.cplcb = new Combo(this, 8);
      this.cplcb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int idx = PulseComposite.this.getEdgeTrg().coupling = PulseComposite.this.cplcb.getSelectionIndex();
            String cmd = ":TRIGger:SINGle:COUPling " + ManipulateControl.COUPLING[idx];
            PulseComposite.this.submit(cmd);
         }
      });
      GridData gd_cplcb = new GridData(16384, 16777216, false, false, 3, 1);
      gd_cplcb.widthHint = 60;
      this.cplcb.setLayoutData(gd_cplcb);
      this.cplcb.setItems(ManipulateControl.COUPLING);
      this.lbPolarity = new Label(this, 0);
      this.cobPolarity = new Combo(this, 8);
      this.cobPolarity.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int idx = PulseComposite.this.cobPolarity.getSelectionIndex();
            String[] polarity = new String[]{"positive", "negative"};
            String cmd = ":TRIGger:SINGle:polarity " + polarity[idx];
            PulseComposite.this.submit(cmd);
         }
      });
      this.cobPolarity.setLayoutData(new GridData(16384, 16777216, false, false, 3, 1));
      this.cobPolarity.setItems(ManipulateControl.toStrings(TrgControl.Polarity));
      this.cobPolarity.select(0);
      this.sweeplbl = new Label(this, 0);
      GridData gd_label = new GridData(16384, 16777216, false, false);
      gd_label.widthHint = 60;
      this.sweeplbl.setLayoutData(gd_label);
      this.combo = new Combo(this, 8);
      this.combo.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            String cmd = ":TRIGger:SINGle:SIGN " + PulseComposite.this.combo.getText();
            PulseComposite.this.submit(cmd);
         }
      });
      this.combo.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.combo.setItems(ManipulateControl.SIGNS);
      this.combo.select(0);
      this.spinner = new Spinner(this, 2048);
      this.spinner.setMinimum(1);
      this.combo_1 = new Combo(this, 8);
      this.combo_1.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int index = PulseComposite.this.combo_1.getSelectionIndex();
            int value = PulseComposite.this.spinner.getSelection();
            if (index == 0 && value < 30) {
               Platform.getPlatform().getManipulateControl().alert("Alert.pulse", null);
            } else if (index == 3 && value > 10) {
               Platform.getPlatform().getManipulateControl().alert("Alert.pulse", null);
            } else {
               String s = ":TRIGger:SINGle:Time " + value + PulseComposite.this.combo_1.getText();
               PulseComposite.this.submit(s);
            }
         }
      });
      this.combo_1.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.combo_1.setItems(ManipulateControl.TIME_UNITS);
      this.combo_1.select(0);
      this.updatelbl(this.getEdgeTrg().level);
      this.use = true;
   }

   private int getLevelValue() {
      return 0;
   }

   private void updatelbl(int v) {
      String.format("/25 = %.2f div", (double)v / 25.0);
   }

   public void submit(String cmd) {
      Platform.getPlatform().getManipulateControl().send(cmd);
   }

   public void localize(ResourceBundle rb) {
      this.use = false;
      this.cpl_lbl.setText(rb.getString("M.Trg.Edge.coupling"));
      this.lbPolarity.setText(rb.getString("M.Trg.pulse.polarity"));
      this.sweeplbl.setText(rb.getString("M.Trg.pulse.when"));
      this.use = true;
   }

   @Override
   public void loadTrgGroup(TrgControl tc) {
      TrgGroup tg = tc.getCurrent();
      this.use = false;
      EdgeTrg et = tg.et;
      this.cplcb.select(et.coupling);
      int l = et.level;
      this.use = true;
   }
}
