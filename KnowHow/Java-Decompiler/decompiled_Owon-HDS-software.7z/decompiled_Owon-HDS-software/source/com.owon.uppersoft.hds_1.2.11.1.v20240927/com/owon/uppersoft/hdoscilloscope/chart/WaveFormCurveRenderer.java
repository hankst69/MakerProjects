package com.owon.uppersoft.hdoscilloscope.chart;

import com.owon.uppersoft.hdoscilloscope.chart.model.ILowMovable;
import com.owon.uppersoft.hdoscilloscope.chart.model.LowMoveChecker;
import com.owon.uppersoft.hdoscilloscope.chart.model.deep.Pixel;
import java.util.List;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

public class WaveFormCurveRenderer {
   public static final void draw(AbstWFC curve, List<Pixel> pointSet, GraphicContext gx) {
      if (curve != null && curve.isVisible()) {
         GC gc = gx.gc;
         Color c = curve.getColor();
         if (c != null) {
            gc.setForeground(c);
         }

         if (gx.linevisible) {
            drawLines(curve, pointSet, gx);
         } else {
            drawPoints(curve, pointSet, gx);
         }
      }
   }

   protected static final void drawPoints(AbstWFC curve, List<Pixel> pointSet, GraphicContext gx) {
      GC gc = gx.gc;
      if (curve instanceof ILowMovable) {
         ILowMovable awfc = (ILowMovable)curve;
         LowMoveChecker lmc = awfc.getLowMoveChecker();
         if (lmc.isLowMovePatched()) {
            Point lp = lmc.lp;
            singlePoints(gc, pointSet, lp.x, lp.y);
            if (!lmc.isRightPointUsed()) {
               return;
            }

            Point rp = lmc.rp;
            singlePoints(gc, pointSet, rp.x, rp.y);
            return;
         }
      }

      singlePoints(gc, pointSet, 0, pointSet.size());
   }

   protected static final void drawLines(AbstWFC curve, List<Pixel> pointSet, GraphicContext gx) {
      GC gc = gx.gc;
      if (curve instanceof ILowMovable) {
         ILowMovable awfc = (ILowMovable)curve;
         LowMoveChecker lmc = awfc.getLowMoveChecker();
         if (lmc.isLowMovePatched()) {
            Point lp = lmc.lp;
            singleLines(gc, pointSet, lp.x, lp.y);
            if (!lmc.isRightPointUsed()) {
               return;
            }

            Point rp = lmc.rp;
            singleLines(gc, pointSet, rp.x, rp.y);
            return;
         }
      }

      singleLines(gc, pointSet, 0, pointSet.size());
   }

   public static final void singleLines(GC gc, List<Pixel> pointSet, int start, int end) {
      Pixel p1 = pointSet.get(start);
      gc.drawPoint(p1.x, p1.y);

      for (int i = start + 1; i < end; i++) {
         Pixel p2 = pointSet.get(i);
         gc.drawLine(p1.x, p1.y, p2.x, p2.y);
         p1 = p2;
      }
   }

   public static final void singlePoints(GC gc, List<Pixel> pointSet, int start, int end) {
      for (int i = start; i < end; i++) {
         Pixel p = pointSet.get(i);
         gc.drawPoint(p.x, p.y);
      }
   }
}
