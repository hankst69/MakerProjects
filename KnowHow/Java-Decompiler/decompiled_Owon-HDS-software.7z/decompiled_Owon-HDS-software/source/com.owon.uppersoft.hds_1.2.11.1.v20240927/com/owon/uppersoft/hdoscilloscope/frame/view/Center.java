package com.owon.uppersoft.hdoscilloscope.frame.view;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.chart.MarkDraw;
import com.owon.uppersoft.hdoscilloscope.chart.model.PrototypeWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.FFTInfo;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.FFTWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.TimeBaseRef;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.WndType;
import com.owon.uppersoft.hdoscilloscope.chart.model.math.IMath;
import com.owon.uppersoft.hdoscilloscope.chart.model.math.MathWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.data.math.MathWF;
import com.owon.uppersoft.hdoscilloscope.frame.MouseDragger;
import com.owon.uppersoft.hdoscilloscope.frame.MyContentProvider;
import com.owon.uppersoft.hdoscilloscope.frame.MyLabelProvider;
import com.owon.uppersoft.hdoscilloscope.frame.PrototypeCenter;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.Dbl_Txt;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import com.owon.uppersoft.hdoscilloscope.util.UnitConversionUtil;
import java.util.Iterator;
import java.util.ResourceBundle;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Widget;

public class Center extends PrototypeCenter implements Localizable2, Listener, ControlListener {
   protected ImageScale imgScale;
   protected DrawingPanel dp;
   protected InfoCom infoCom;
   private WaveFormFileCurve wffc;
   private Menu mfft;
   private Menu madc;
   private Menu mmath;
   private MenuItem[] menu_db_rms;
   private MenuItem[] menu_wndtype;
   private MenuItem[] math_menuitems;
   private MenuItem[] factor1;
   private MenuItem[] factor2;
   private MenuItem tofft;
   private MenuItem tomath;
   private MenuItem removewf;
   private MenuItem removefft;
   private MenuItem removemath;
   private MenuItem invertedMenuItem;
   private String cursor;
   private String timebase;
   private String volbase;
   private String dbbase;
   private String freqbase;
   private String curbase;
   private String notsupport;
   private int SWT_Selection = 13;

   public ImageScale getImageScale() {
      return this.imgScale;
   }

   public DrawingPanel getDrawingPanel() {
      return this.dp;
   }

   public InfoCom getInfoCom() {
      return this.infoCom;
   }

   public void resetSashes() {
      Configuration config = Platform.getPlatform().getConfiguration();
      this.downSash.setWeights(config.downSash);
      this.mainSash.setWeights(config.mainSash);
      this.upSash.setWeights(config.upSash);
   }

   public void resetSashes2() {
   }

   public Center(Composite parent) {
      super(parent);
      this.resetSashes();
      this.imgScale = new ImageScale(this.imgCom);
      this.dp = new DrawingPanel(this.canvas);
      this.imgScale.setWaveFormFileCurve(this.dp.getWaveFormFileCurve());
      this.infoCom = new InfoCom(this.infogroup);
      this.customizeContent();
   }

   public void removeWaveFormCurve() {
      Object[] os = this.ctv.getCheckedElements();
      WaveFormCurve wfc = this.wffc.getSelectedWaveFormCurve();
      this.wffc.removeWaveFormCurve(wfc);
      this.ctv.refresh();
      this.ctv.setCheckedElements(os);
      Iterator<WaveFormCurve> iw = this.wffc.all_collect().iterator();
      if (iw.hasNext()) {
         this.ctv.setSelection(new StructuredSelection(iw.next()), true);
         this.ctv.getTable().setFocus();
      }

      this.imgScale.redraw();
   }

   protected void moveTo(WaveFormCurve wfc) {
      wfc.setVisible(true);
      this.ctv.refresh();
      this.ctv.setChecked(wfc, wfc.isVisible());
      this.ctv.setSelection(new StructuredSelection(wfc), true);
      this.ctv.getTable().setFocus();
   }

   protected void selfRefresh(WaveFormCurve wfc) {
      this.ctv.refresh();
      this.setCurrentChannel(wfc, true);
   }

   public void toMath() {
      if (this.wffc.getWaveFormFile().isMathAvailable()) {
         MathWaveFormCurve wfc = (MathWaveFormCurve)this.wffc.addMathWaveFormFile();
         this.moveTo(wfc);
      }
   }

   public void gotoADC_FFT(boolean adc) {
      this.wffc.getReg().setAutoCreateFFT(true);
      WaveFormCurve wfc = this.wffc.getSelectedWaveFormCurve();
      if (adc) {
         wfc = this.wffc.addAlphaWaveFormFile(wfc);
      } else {
         if (wfc.getWaveForm().isLowMove()) {
            return;
         }

         wfc = this.wffc.addFFTWaveFormFile((PrototypeWaveFormCurve)wfc);
      }

      this.moveTo(wfc);
   }

   public void inverted(boolean b) {
      PrototypeWaveFormCurve awfc = (PrototypeWaveFormCurve)this.wffc.getSelectedWaveFormCurve();
      awfc.getScalableDrawEngine().setInverted(b);
      String fftStr = awfc.getWaveForm().getFFTName();
      WaveFormCurve w = this.wffc.getWaveFormCurve(fftStr);
      if (w != null) {
         FFTWaveFormCurve fwfc = (FFTWaveFormCurve)w;
         fwfc.datasUpdate();
      }

      w = this.wffc.getWaveFormCurve("math");
      if (w != null) {
         MathWaveFormCurve mwfc = (MathWaveFormCurve)w;
         mwfc.datasUpdate();
      }

      this.dp.redraw(true);
      this.selfRefresh(awfc);
   }

   public void showFFT() {
      PrototypeWaveFormCurve wfc = (PrototypeWaveFormCurve)this.wffc.getSelectedWaveFormCurve();
      this.moveTo(this.wffc.addFFTWaveFormFile(wfc));
   }

   public void changeCompute(int type) {
      WaveFormCurve wfc = this.wffc.getSelectedWaveFormCurve();
      FFTWaveFormCurve fwfc = (FFTWaveFormCurve)wfc;
      boolean rd = fwfc.changeMode(type);
      if (rd) {
         this.selfRefresh(fwfc);
      }
   }

   public void changeWndType(int type) {
      WaveFormCurve wfc = this.wffc.getSelectedWaveFormCurve();
      FFTWaveFormCurve fwfc = (FFTWaveFormCurve)wfc;
      boolean rd = fwfc.changeWndType(type);
      if (rd) {
         this.selfRefresh(fwfc);
      }
   }

   public void changeMathType(int type) {
      WaveFormCurve wfc = this.wffc.getSelectedWaveFormCurve();
      MathWaveFormCurve mw = (MathWaveFormCurve)wfc;
      boolean rd = mw.changeType(type);
      if (rd) {
         this.selfRefresh(mw);
      }
   }

   public MenuItem getInvertedMenuItem() {
      return this.invertedMenuItem;
   }

   protected void customizeContent() {
      this.wffc = this.dp.getWaveFormFileCurve();
      this.ctv = new CheckboxTableViewer(this.table);
      this.ctv.setLabelProvider(new MyLabelProvider());
      this.ctv.setContentProvider(new MyContentProvider());
      this.ctv.setInput(this.wffc);
      this.madc = new Menu(this.table);
      this.tofft = new MenuItem(this.madc, 0);
      this.tofft.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            Center.this.gotoADC_FFT(false);
         }
      });
      this.tomath = new MenuItem(this.madc, 0);
      this.tomath.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            Center.this.toMath();
         }
      });
      this.removewf = new MenuItem(this.madc, 0);
      this.removewf.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            Center.this.removeWaveFormCurve();
         }
      });
      this.invertedMenuItem = new MenuItem(this.madc, 32);
      this.invertedMenuItem.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            boolean b = ((MenuItem)e.widget).getSelection();
            Center.this.inverted(b);
            Center.this.getToolCom().getInvertedButton().setSelection(b);
         }
      });
      this.mfft = new Menu(this.table);
      this.removefft = new MenuItem(this.mfft, 0);
      this.removefft.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            Center.this.removeWaveFormCurve();
         }
      });
      new MenuItem(this.mfft, 2);
      this.menu_db_rms = new MenuItem[2];
      MenuItem mi = new MenuItem(this.mfft, 16);
      mi.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (((MenuItem)e.widget).getSelection()) {
               Center.this.changeCompute(1);
            }
         }
      });
      this.menu_db_rms[1] = mi;
      mi = new MenuItem(this.mfft, 16);
      mi.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (((MenuItem)e.widget).getSelection()) {
               Center.this.changeCompute(0);
            }
         }
      });
      this.menu_db_rms[0] = mi;
      new MenuItem(this.mfft, 2);
      WndType[] wts = FFTInfo.wndTypes;
      int len = wts.length;
      this.menu_wndtype = new MenuItem[len];

      for (final int i = 0; i < len; i++) {
         mi = new MenuItem(this.mfft, 16);
         mi.addSelectionListener(new SelectionAdapter() {
            public void widgetSelected(SelectionEvent e) {
               if (((MenuItem)e.widget).getSelection()) {
                  Center.this.changeWndType(i);
               }
            }
         });
         this.menu_wndtype[i] = mi;
      }

      this.mmath = new Menu(this.table);
      this.removemath = new MenuItem(this.mmath, 0);
      this.removemath.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            Center.this.removeWaveFormCurve();
         }
      });
      new MenuItem(this.mmath, 0);
      new MenuItem(this.mmath, 2);
      this.factor1 = new MenuItem[4];

      for (int i = 0; i < 4; i++) {
         mi = this.factor1[i] = new MenuItem(this.mmath, 0);
         mi.setText("CH" + i);
      }

      new MenuItem(this.mmath, 2);
      String[] math_types = IMath.math_types;
      len = math_types.length;
      this.math_menuitems = new MenuItem[len];

      for (final int i = 0; i < len; i++) {
         mi = this.math_menuitems[i] = new MenuItem(this.mmath, 16);
         mi.setText(math_types[i]);
         mi.addSelectionListener(new SelectionAdapter() {
            public void widgetSelected(SelectionEvent e) {
               if (((MenuItem)e.widget).getSelection()) {
                  Center.this.changeMathType(i);
               }
            }
         });
      }

      this.table.addMouseListener(new MouseAdapter() {
         public void mouseDown(MouseEvent e) {
            boolean b = true;
            if (!b) {
               Point p = new Point(e.x, e.y);
               TableItem ti = Center.this.table.getItem(p);
               if (ti != null) {
                  StructuredSelection ss = (StructuredSelection)Center.this.ctv.getSelection();
                  WaveFormCurve wfc = (WaveFormCurve)ss.getFirstElement();
                  Menu menu = wfc.getToolMenu();
                  if (menu != null) {
                     menu.setLocation(Center.this.table.toDisplay(p));
                     menu.setVisible(true);
                  }
               }
            }
         }
      });
      this.ctv.addSelectionChangedListener(new ISelectionChangedListener() {
         public void selectionChanged(SelectionChangedEvent event) {
            int index = Center.this.table.getSelectionIndex();
            if (index >= 0 && index < Center.this.table.getItemCount()) {
               WaveFormCurve wfc = (WaveFormCurve)Center.this.table.getItem(index).getData();
               Center.this.setCurrentChannel(wfc, false);
            }
         }
      });
      this.ctv.addCheckStateListener(new ICheckStateListener() {
         public void checkStateChanged(CheckStateChangedEvent event) {
            WaveFormCurve wfc = (WaveFormCurve)event.getElement();
            boolean checked = event.getChecked();
            if (wfc != null && wfc.isVisible() != checked) {
               wfc.setVisible(checked);
               Center.this.imgScale.redraw();
            }
         }
      });
      this.cursorCombo.addListener(this.SWT_Selection, this);
      this.timebaseCombo.addListener(this.SWT_Selection, this);
      this.volbaseCombo.addListener(this.SWT_Selection, this);
      this.rs.addListener(this.SWT_Selection, this);
      MouseDragger md = new MouseDragger() {
         @Override
         public void mouseDrag(MouseEvent e) {
            Center.this.dp.setDragging(true);
         }

         @Override
         public void mouseRelease(MouseEvent e) {
            Center.this.dp.setDragging(false);
         }
      };
      this.rs.addMouseListener(md);
      this.rs.addMouseMoveListener(md);
      this.mainCom.addDisposeListener(new DisposeListener() {
         public void widgetDisposed(DisposeEvent e) {
            Center.this.dp.dispose();
         }
      });
      this.tool_com.customizeContent(this);
      this.canvas.addControlListener(this);
   }

   public Menu applyFFTWFC(FFTWaveFormCurve fw) {
      FFTInfo fi = fw.getWaveForm().getFFTInfo();

      for (MenuItem mi : this.menu_db_rms) {
         mi.setSelection(false);
      }

      this.menu_db_rms[fw.getDb_Vrms()].setSelection(true);

      for (MenuItem mi : this.menu_wndtype) {
         mi.setSelection(false);
      }

      this.menu_wndtype[fw.getWndTypeIdx()].setSelection(true);
      fi.isWfreturnable();
      this.removefft.setEnabled(!fi.isProtoFFT());
      return this.mfft;
   }

   public Menu applyProtoWFC(PrototypeWaveFormCurve wfc) {
      FFTInfo fi = wfc.getWaveForm().getFFTInfo();
      boolean flag = wfc.getWaveForm().isFFTComputable();
      this.tofft.setEnabled(flag);
      String s = (String)this.tofft.getData();
      if (!flag && s != null) {
         s = s + ". " + this.notsupport;
      }

      this.tofft.setText(s);
      this.invertedMenuItem.setSelection(this.wffc.getReg().getWFReg(wfc.getStrChannelType()).isInverted());
      this.removewf.setEnabled(fi.isProtoFFT());
      return this.madc;
   }

   public Menu applyMathWFC(MathWaveFormCurve mf) {
      for (MenuItem mi : this.math_menuitems) {
         mi.setSelection(false);
      }

      this.math_menuitems[mf.getType()].setSelection(true);
      return this.mmath;
   }

   public void controlMoved(ControlEvent e) {
   }

   public void controlResized(ControlEvent e) {
      this.dp.updateBound();
      this.updateMarksLocation();
      this.dp.redraw();
   }

   public void selectOnTable(WaveFormCurve wfc) {
      if (wfc != null) {
         this.ctv.setSelection(new StructuredSelection(wfc), true);
         this.ctv.getTable().setFocus();
      }
   }

   protected void updateBorderTitle() {
      WaveFormCurve wfc = this.wffc.getSelectedWaveFormCurve();
      String chName = wfc == null ? "" : wfc.getStrChannelType() + " ";
      String tmp = chName + this.cursor;
      if (!this.cursorGroup.getText().equals(tmp)) {
         this.cursorGroup.setText(tmp);
      }

      String tb = "";
      String vb = "";
      if (wfc instanceof PrototypeWaveFormCurve) {
         tb = this.timebase;
         vb = wfc.getWaveForm().isCurrMeas() ? this.curbase : this.volbase;
      }

      if (wfc instanceof FFTWaveFormCurve) {
         FFTWaveFormCurve fw = (FFTWaveFormCurve)wfc;
         tb = this.freqbase;
         if (fw.getDb_Vrms() == 1) {
            vb = this.dbbase;
         } else {
            vb = this.volbase;
         }
      }

      if (wfc instanceof MathWaveFormCurve) {
         tb = this.timebase;
      }

      tmp = chName + tb;
      if (!this.timebaseGroup.getText().equals(tmp)) {
         this.timebaseGroup.setText(tmp);
      }

      tmp = chName + vb;
      if (!this.volbaseGroup.getText().equals(tmp)) {
         this.volbaseGroup.setText(tmp);
      }
   }

   public void localize(ResourceBundle bundle) {
      this.cursor = bundle.getString("Center.cursor");
      this.timebase = bundle.getString("Center.Timebase");
      this.volbase = bundle.getString("Center.Volbase");
      this.dbbase = bundle.getString("Center.dbbase");
      this.freqbase = bundle.getString("Center.freqbase");
      this.curbase = bundle.getString("Center.curbase");
      this.updateBorderTitle();
      this.numLabel.setText(bundle.getString("Center.num"));
      this.cursorTypeLabel.setText(bundle.getString("Center.cursorType"));
      this.tbTypeLabel.setText(bundle.getString("Center.tbScale"));
      this.vbTypleLabel.setText(bundle.getString("Center.vbScale"));
      this.infoCom.localize(bundle);
      String[] markComboTxts = new String[]{
         bundle.getString("Center.markNone"), bundle.getString("Center.markH"), bundle.getString("Center.markV"), bundle.getString("Center.markAll")
      };
      this.cursorCombo.setItems(markComboTxts);
      this.cursorCombo.select(this.dp.getMarkDraw().getMarkDrawMode());
      this.tool_com.localize(bundle);
      this.notsupport = bundle.getString("Center.NotSupportCompute");
      String s = bundle.getString("Center.toWF");
      this.tomath.setText(bundle.getString("Center.tomath"));
      this.removewf.setText(bundle.getString("Center.remove"));
      this.invertedMenuItem.setText(bundle.getString("Center.Inverted"));
      s = bundle.getString("Center.toFFT");
      this.tofft.setText(s);
      this.tofft.setData(s);
      this.menu_db_rms[1].setText(bundle.getString("Center.todb"));
      this.menu_db_rms[0].setText(bundle.getString("Center.torms"));
      WndType[] wts = FFTInfo.wndTypes;
      int len = wts.length;

      for (int i = 0; i < len; i++) {
         this.menu_wndtype[i].setText(bundle.getString("Center." + wts[i].name()));
      }

      this.removefft.setText(bundle.getString("Center.remove"));
      this.removemath.setText(bundle.getString("Center.remove"));
      this.dp.localize();
   }

   public void setWaveFormFile(WaveFormFile wff) {
      this.dp.setWaveFormFile(wff);
      this.imgScale.redraw();
      this.ctv.refresh();

      for (WaveFormCurve wfc : this.wffc.all_collect()) {
         this.ctv.setChecked(wfc, wfc.isVisible());
      }

      this.tomath.setEnabled(wff.isMathAvailable());
      this.tool_com.applyWaveFormFile(wff);
      if (this.wffc.getWaveformsNumber() <= 0) {
         this.infogroup.setText("");
         this.cursorGroup.setText("");
         this.timebaseGroup.setText("");
         this.volbaseGroup.setText("");
         this.volbaseCombo.removeAll();
         this.timebaseCombo.removeAll();
         this.updateMarksLocation();
         this.infoCom.setEmptyWF(wff, true);
      } else {
         this.infoCom.setEmptyWF(wff, false);
         String lsc = this.wffc.getLastSelectedChannel();
         WaveFormCurve wfc = this.wffc.getWaveFormCurve(lsc);
         if (wfc == null) {
            Iterator<WaveFormCurve> iw = this.wffc.all_collect().iterator();
            if (iw.hasNext()) {
               wfc = iw.next();
            }
         }

         if (wfc != null) {
            this.ctv.setSelection(new StructuredSelection(wfc), true);
         }
      }
   }

   protected void setCurrentChannel(WaveFormCurve curve, boolean force) {
      if (curve != null) {
         if (force || !curve.equals(this.wffc.getSelectedWaveFormCurve())) {
            this.tool_com.applyWaveFormCurve(curve);
            this.wffc.setSelectedWaveFormCurve(curve);
            this.updateMarksLocation();
            this.updateBlockInfo(curve);
            this.infoCom.setWaveFormCurve(curve);
            this.volbaseCombo.removeAll();
            this.timebaseCombo.removeAll();
            if (curve.getWaveForm() instanceof MathWF) {
               this.volbaseCombo.add("-");
               this.timebaseCombo.add("-");
               this.volbaseCombo.setEnabled(false);
               this.timebaseCombo.setEnabled(false);
            }

            if (curve instanceof FFTWaveFormCurve && curve.getWaveForm().getFFTInfo().isProtoFFT()) {
               FFTWaveFormCurve fwf = (FFTWaveFormCurve)curve;
               int zr = fwf.getZoomRate();

               for (Object o : curve.xb_collect()) {
                  TimeBaseRef tbr = (TimeBaseRef)o;
                  this.timebaseCombo.add(tbr.zoomFreqBase(zr));
               }
            } else {
               for (Object o : curve.xb_collect()) {
                  this.timebaseCombo.add(o.toString());
               }
            }

            if (curve.getWaveForm() != null && curve.getWaveForm().isCurrMeas()) {
               for (Object o : curve.yb_collect()) {
                  String s = o.toString();
                  if (o instanceof Dbl_Txt) {
                     Dbl_Txt dt = (Dbl_Txt)o;
                     s = UnitConversionUtil.getCurrentLabel_ma(
                        dt.v() * this.wffc.getSelectedWaveFormCurve().getWaveForm().getIntAttenuationMultiple() * (double)curve.getWaveForm().getCurRate()
                     );
                  }

                  this.volbaseCombo.add(s);
               }
            } else {
               for (Object o : curve.yb_collect()) {
                  String s = o.toString();
                  if (o instanceof Dbl_Txt) {
                     Dbl_Txt dt = (Dbl_Txt)o;
                     s = UnitConversionUtil.getVoltageLabel_V(dt.v() * this.wffc.getSelectedWaveFormCurve().getWaveForm().getIntAttenuationMultiple());
                  }

                  this.volbaseCombo.add(s);
               }
            }

            this.volbaseCombo.select(curve.baseIdxOnY());
            this.timebaseCombo.select(curve.baseIdxOnX());
            this.updateBorderTitle();
            this.imgScale.redraw();
         }
      }
   }

   public void updateMarksLocation() {
      String s = "";
      WaveFormCurve curve = this.wffc.getSelectedWaveFormCurve();
      if (curve == null) {
         this.dxvLabel.setText(s);
         this.x1vLabel.setText(s);
         this.x2vLabel.setText(s);
         this.dyvLabel.setText(s);
         this.y1vLabel.setText(s);
         this.y2vLabel.setText(s);
      } else {
         MarkDraw md = this.dp.getMarkDraw();
         int[] verticalMarks = md.getVerticalMarks();
         int[] horizontalMarks = md.getHorizontalMarks();
         if (md.isHorizontalMarksDraw()) {
            double y1 = curve.valueAtY((double)horizontalMarks[0]);
            double y2 = curve.valueAtY((double)horizontalMarks[1]);
            double rateY = curve.rateAtY();
            y1 *= rateY;
            y2 *= rateY;
            this.y1vLabel.setText(curve.unitForY(y1));
            this.y2vLabel.setText(curve.unitForY(y2));
            this.dyvLabel.setText(curve.unitForY(Math.abs(y2 - y1)));
         } else {
            this.dyvLabel.setText(s);
            this.y1vLabel.setText(s);
            this.y2vLabel.setText(s);
         }

         if (md.isVerticalMarksDraw()) {
            double x1 = curve.valueAtX((double)verticalMarks[0]);
            double x2 = curve.valueAtX((double)verticalMarks[1]);
            int rateX = curve.rateAtX();
            x1 *= (double)rateX;
            x2 *= (double)rateX;
            this.x1vLabel.setText(curve.unitForX(x1));
            this.x2vLabel.setText(curve.unitForX(x2));
            this.dxvLabel.setText(curve.unitForX(Math.abs(x2 - x1)));
         } else {
            this.dxvLabel.setText(s);
            this.x1vLabel.setText(s);
            this.x2vLabel.setText(s);
         }
      }
   }

   public void updateBlockInfo(WaveFormCurve curve) {
      WaveForm wf = curve.getWaveForm();
      if (curve != null && wf != null) {
         int h = this.dp.getSize().y;
         double yper = (double)h * 1.0 / (double)wf.getWaveFormFile().getYGraticuleNum();
         int blockNum = curve.getBlockNum();
         int halfV = (int)((double)blockNum * yper);
         this.rs.setMaximum(halfV << 1);
         this.rs.setMinimum(0);
         this.rs.setPageIncrement(h);
         double loc = curve.getScalableDrawEngine().getZeroYLocation();
         double bloc = (double)(h >> 1) - loc;
         this.rs.setSelection(halfV - (int)bloc);
         double v = bloc / yper + 0.01;
         this.numrangeLabel.setText(String.format("[%d~%d]", -blockNum, blockNum));
         this.numvLabel.setText(String.format("%.2f", v));
      }
   }

   public void handleEvent(Event event) {
      if (event.type == this.SWT_Selection) {
         Widget w = event.widget;
         if (w == this.cursorCombo) {
            MarkDraw md = this.dp.getMarkDraw();
            int index = this.cursorCombo.getSelectionIndex();
            if (index != md.getMarkDrawMode()) {
               md.setMarkDrawMode(index);
               this.dp.redraw(false);
               this.updateMarksLocation();
            }
         } else if (w != this.timebaseCombo) {
            if (w == this.volbaseCombo) {
               WaveFormCurve curve = this.wffc.getSelectedWaveFormCurve();
               if (curve != null) {
                  int index = this.volbaseCombo.getSelectionIndex();
                  int i = curve.baseIdxOnY();
                  if (index != i) {
                     curve.setBaseIdxOnY(index);
                     this.dp.redraw();
                     this.updateMarksLocation();
                     this.ctv.refresh();
                     this.updateBlockInfo(curve);
                  }
               }
            } else if (w == this.rs) {
               WaveFormCurve curve = this.wffc.getSelectedWaveFormCurve();
               if (curve != null) {
                  int h = this.dp.getSize().y;
                  int yper = h / this.wffc.getWaveFormFile().getYGraticuleNum();
                  int blockNum = curve.getBlockNum();
                  int halfV = blockNum * yper;
                  int bloc = this.rs.getSelection();
                  int yloc = bloc - halfV + (h >> 1);
                  double v = (double)(halfV - bloc) / (double)yper;
                  curve.getScalableDrawEngine().setZeroYLocation((double)yloc);
                  this.imgScale.redraw();
                  this.updateMarksLocation();
                  this.numvLabel.setText(String.format("%.2f", v));
               }
            }
         } else {
            int index = this.timebaseCombo.getSelectionIndex();
            WaveFormCurve curve = this.wffc.getSelectedWaveFormCurve();
            if (curve.isChannel()) {
               WaveFormFileCurve wffc = this.dp.getWaveFormFileCurve();

               for (WaveFormCurve wfc : wffc.wfc_collect()) {
                  if (curve.isChannel() && index != wfc.baseIdxOnX()) {
                     wfc.setBaseIdxOnX(index);
                  }
               }

               this.dp.redraw();
               this.updateMarksLocation();
               this.ctv.refresh();
            } else {
               if (curve == null) {
                  return;
               }

               int i = curve.baseIdxOnX();
               if (index != i) {
                  curve.setBaseIdxOnX(index);
                  this.dp.redraw();
                  this.updateMarksLocation();
                  this.ctv.refresh();
               }
            }
         }
      }
   }
}
