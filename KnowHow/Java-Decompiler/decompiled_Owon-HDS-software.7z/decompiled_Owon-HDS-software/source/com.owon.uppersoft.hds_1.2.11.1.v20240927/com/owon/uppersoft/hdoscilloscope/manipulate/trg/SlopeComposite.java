package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail2.TrgComposite;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

public class SlopeComposite extends AbsTrgComposite implements Localizable2 {
   private ItemCom[] ics;
   private Label lbWhen;
   private Combo combo;
   private boolean use = false;
   private Label lbSlope;
   private Combo cobSlope;
   private Spinner spinner;
   private Combo combo_1;

   private EdgeTrg getEdgeTrg() {
      return this.tcom.getTrgControl().getCurrent().et;
   }

   public SlopeComposite(Composite parent, TrgComposite tc) {
      super(parent, 0, tc);
      final ManipulateControl mc = Platform.getPlatform().getManipulateControl();
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 4;
      this.setLayout(gridLayout);
      this.ics = new ItemCom[2];
      String[] v = new String[]{"mV", "V"};
      this.lbWhen = new Label(this, 0);
      this.lbWhen.setLayoutData(new GridData(131072, 16777216, false, false, 1, 1));
      this.combo = new Combo(this, 0);
      this.combo.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.combo.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            String cmd = ":TRIGger:SINGle:SIGN " + SlopeComposite.this.combo.getText();
            mc.send(cmd);
         }
      });
      this.combo.setItems(ManipulateControl.SIGNS);
      this.combo.select(0);
      Item item = new Item("M.Trg.highlevel", ":TRIGger:SINGle:ULevel", v, new String[]{"+", "-"});
      this.spinner = new Spinner(this, 2048);
      this.spinner.setMinimum(1);
      this.spinner.setIncrement(10);
      this.combo_1 = new Combo(this, 8);
      this.combo_1.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int index = SlopeComposite.this.combo_1.getSelectionIndex();
            int value = SlopeComposite.this.spinner.getSelection();
            if (index == 0 && value < 100) {
               Platform.getPlatform().getManipulateControl().alert("Alert.slope", null);
            } else if (index == 3 && value > 10) {
               Platform.getPlatform().getManipulateControl().alert("Alert.slope", null);
            } else {
               String s = ":TRIGger:SINGle:Time " + value + SlopeComposite.this.combo_1.getText();
               mc.send(s);
            }
         }
      });
      this.combo_1.setItems(ManipulateControl.TIME_UNITS);
      this.combo_1.select(0);
      this.lbSlope = new Label(this, 0);
      this.cobSlope = new Combo(this, 8);
      this.cobSlope.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int idx = SlopeComposite.this.cobSlope.getSelectionIndex();
            String[] edge = new String[]{"RISE", "FALL"};
            String cmd = ":TRIGger:SINGle:Slope " + edge[idx];
            mc.send(cmd);
         }
      });
      this.cobSlope.setItems(ManipulateControl.toStrings(TrgControl.RiseFall));
      this.cobSlope.select(0);
      this.cobSlope.setLayoutData(new GridData(16384, 16777216, false, false, 3, 1));
      ItemCom itemCom = new ItemCom(this, 0, item, mc);
      itemCom.setLayoutData(new GridData(16384, 16777216, false, false, 4, 1));
      this.ics[0] = itemCom;
      item = new Item("M.Trg.lowlevel", ":TRIGger:SINGle:LLevel", v, new String[]{"+", "-"});
      ItemCom itemCom_1 = new ItemCom(this, 0, item, mc);
      itemCom_1.setLayoutData(new GridData(16384, 16777216, false, false, 4, 1));
      this.ics[1] = itemCom_1;
   }

   public void localize(ResourceBundle rb) {
      for (int i = 0; i < this.ics.length; i++) {
         this.ics[i].localize(rb);
      }

      this.lbWhen.setText(rb.getString("M.Trg.slope.when"));
      this.lbSlope.setText(rb.getString("M.Trg.slope.slope"));
   }

   @Override
   public void loadTrgGroup(TrgControl tc) {
      tc.getCurrent();
   }
}
