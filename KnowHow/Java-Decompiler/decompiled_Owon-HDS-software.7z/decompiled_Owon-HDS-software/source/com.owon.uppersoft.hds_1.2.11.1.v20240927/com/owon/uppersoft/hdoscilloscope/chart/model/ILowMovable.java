package com.owon.uppersoft.hdoscilloscope.chart.model;

public interface ILowMovable {
   LowMoveChecker getLowMoveChecker();
}
