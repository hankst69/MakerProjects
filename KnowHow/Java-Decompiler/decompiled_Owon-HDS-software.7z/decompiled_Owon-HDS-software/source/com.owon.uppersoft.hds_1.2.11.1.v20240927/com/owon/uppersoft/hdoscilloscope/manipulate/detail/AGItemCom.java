package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import java.util.ResourceBundle;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

public class AGItemCom extends Composite implements Localizable2 {
   private Label lblNewLabel;
   private ManipulateControl mc;
   private String id;
   private String prefix;
   private Spinner spinner;
   private Combo combo;

   public AGItemCom(Composite parent, int style, ManipulateControl mc, String id, String unit, String prefix) {
      super(parent, style);
      this.mc = mc;
      this.id = id;
      this.prefix = prefix;
      this.setLayout(new RowLayout(256));
      this.lblNewLabel = new Label(this, 0);
      this.lblNewLabel.addMouseListener(new MouseAdapter() {
         public void mouseUp(MouseEvent e) {
         }
      });
      this.lblNewLabel.setLayoutData(new RowData(70, -1));
      this.spinner = new Spinner(this, 2048);
      this.spinner.setMinimum(1);
      this.combo = new Combo(this, 0);
   }

   public void localize(ResourceBundle bundle) {
      this.lblNewLabel.setText(bundle.getString("Mp." + this.id));
   }
}
