package com.owon.uppersoft.hdoscilloscope.chart;

import com.owon.uppersoft.common.aspect.Disposable;
import com.owon.uppersoft.common.utils.DisposeUtil;
import com.owon.uppersoft.hdoscilloscope.model.IPublicM;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;

public class MarkDraw implements ContextDrawable, Disposable {
   private Color markLineColor;
   private boolean verticalMarkLineVisible = false;
   private boolean horizontalMarkLineVisible = false;
   public static final int NO_MARKS = 0;
   public static final int HORIZONTAL_MARKS = 1;
   public static final int VERTICAL_MARKS = 2;
   public static final int ALL_MARKS = 3;
   private int markDrawMode;
   private int[] verticalMarks;
   private int[] horizontalMarks;
   private DrawingPanel dp;
   private int bgWidth;
   private int bgHeight;
   public static final int HORIZONTAL_MARK_SELECTED = 0;
   public static final int VERTICAL_MARK_SELECTED = 1;
   public static final int NO_MARK_SELECTED = -1;
   private int markSelectedType = -1;
   private int markSelectedIndex = -1;
   private double[] hr = new double[2];
   private double[] vr = new double[2];

   private void setVerticalMarkLineVisible(boolean verticalMarkLineVisible) {
      this.verticalMarkLineVisible = verticalMarkLineVisible;
   }

   private void setHorizontalMarkLineVisible(boolean horizontalMarkLineVisible) {
      this.horizontalMarkLineVisible = horizontalMarkLineVisible;
   }

   public void setMarkDrawMode(int mode) {
      this.markDrawMode = mode;
      switch (this.markDrawMode) {
         case 0:
         default:
            this.setVerticalMarkLineVisible(false);
            this.setHorizontalMarkLineVisible(false);
            break;
         case 1:
            this.setVerticalMarkLineVisible(false);
            this.setHorizontalMarkLineVisible(true);
            break;
         case 2:
            this.setVerticalMarkLineVisible(true);
            this.setHorizontalMarkLineVisible(false);
            break;
         case 3:
            this.setVerticalMarkLineVisible(true);
            this.setHorizontalMarkLineVisible(true);
      }
   }

   public int getMarkDrawMode() {
      return this.markDrawMode;
   }

   public boolean isHorizontalMarksDraw() {
      return this.markDrawMode == 1 || this.markDrawMode == 3;
   }

   public boolean isVerticalMarksDraw() {
      return this.markDrawMode == 2 || this.markDrawMode == 3;
   }

   public int[] getVerticalMarks() {
      return this.verticalMarks;
   }

   public int[] getHorizontalMarks() {
      return this.horizontalMarks;
   }

   public MarkDraw(DrawingPanel dp) {
      this.markLineColor = new Color(dp.getComposite().getDisplay(), IPublicM.DefaultMarkLine);
      this.dp = dp;
      this.verticalMarks = new int[2];
      this.horizontalMarks = new int[2];
      this.vr[0] = this.hr[0] = 0.3333333333333333;
      this.vr[1] = this.hr[1] = 0.6666666666666666;
      this.setMarkDrawMode(0);
   }

   public void updateBound(Point size) {
      this.bgWidth = size.x;
      this.bgHeight = size.y;
      if (this.bgWidth > 0 && this.bgHeight > 0) {
         this.verticalMarks[0] = (int)(this.vr[0] * (double)this.bgWidth);
         this.verticalMarks[1] = (int)(this.vr[1] * (double)this.bgWidth);
         this.horizontalMarks[0] = (int)(this.hr[0] * (double)this.bgHeight);
         this.horizontalMarks[1] = (int)(this.hr[1] * (double)this.bgHeight);
      }
   }

   public int isMarksSelected(Point point) {
      int x = point.x;
      int y = point.y;
      int horizontalIndex = this.getMarkIndex(y, this.horizontalMarks);
      if (this.horizontalMarkLineVisible && horizontalIndex > -1) {
         this.markSelectedIndex = horizontalIndex;
         this.markSelectedType = 0;
         return this.markSelectedType;
      } else {
         int verticalIndex = this.getMarkIndex(x, this.verticalMarks);
         if (this.verticalMarkLineVisible && verticalIndex > -1) {
            this.markSelectedIndex = verticalIndex;
            this.markSelectedType = 1;
            return this.markSelectedType;
         } else {
            this.markSelectedIndex = -1;
            this.markSelectedType = -1;
            return this.markSelectedType;
         }
      }
   }

   public void setSelectedMarkLocation(Point point) {
      if (this.markSelectedType == 0) {
         this.setMark(this.markSelectedIndex, point.y, this.horizontalMarks, this.bgHeight, this.hr);
      }

      if (this.markSelectedType == 1) {
         this.setMark(this.markSelectedIndex, point.x, this.verticalMarks, this.bgWidth, this.vr);
      }
   }

   private void setMark(int index, int v, int[] marks, int range, double[] rate) {
      if (v <= 0) {
         v = 0;
      }

      if (v >= range) {
         v = range - 1;
      }

      marks[index] = v;
      rate[index] = (double)v / (double)range;
   }

   private int getMarkIndex(int v, int[] marks) {
      int v0 = v - 1;
      int v1 = v + 1;
      int len = marks.length;

      for (int j = 0; j < len; j++) {
         if (marks[j] >= v0 && marks[j] <= v1) {
            return j;
         }
      }

      return -1;
   }

   @Override
   public void draw(GraphicContext gx) {
      GC gc = gx.gc;
      this.drawVerticalMarkLines(gc);
      this.drawHorizontalMarkLines(gc);
   }

   private void drawHorizontalMarkLines(GC gc) {
      if (this.horizontalMarkLineVisible) {
         gc.setForeground(this.markLineColor);
         int len = this.horizontalMarks.length;

         for (int i = 0; i < len; i++) {
            int y = this.horizontalMarks[i];
            gc.drawLine(0, y, this.bgWidth, y);
         }
      }
   }

   private void drawVerticalMarkLines(GC gc) {
      if (this.verticalMarkLineVisible) {
         gc.setForeground(this.markLineColor);
         int len = this.verticalMarks.length;

         for (int i = 0; i < len; i++) {
            int x = this.verticalMarks[i];
            gc.drawLine(x, 0, x, this.bgHeight);
         }
      }
   }

   public RGB getMarkLineRGB() {
      return this.markLineColor.getRGB();
   }

   public void setMarkLineRGB(RGB rgb) {
      if (rgb != null) {
         DisposeUtil.tryDispose(this.markLineColor);
         this.markLineColor = new Color(this.dp.getComposite().getDisplay(), rgb);
      }
   }

   public void dispose() {
      DisposeUtil.tryDispose(this.markLineColor);
   }
}
