package com.owon.uppersoft.hdoscilloscope.manipulate.detail2;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.manipulate.IPack;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateFrame;
import java.nio.ByteBuffer;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class MultiMeterComposite extends Composite implements IPack, Localizable2 {
   protected Shell shell;
   protected ManipulateFrame mf;

   public MultiMeterComposite(Composite parent, ManipulateFrame mf) {
      super(parent, 0);
      this.mf = mf;
      GridLayout gridLayout = new GridLayout();
      gridLayout.verticalSpacing = 10;
      gridLayout.marginHeight = 10;
      gridLayout.horizontalSpacing = 15;
      gridLayout.marginWidth = 10;
      gridLayout.numColumns = 5;
      this.setLayout(gridLayout);
      Label manualLabel = new Label(this, 16777216);
      GridData gd_manualLabel = new GridData(16777216, 16777216, false, false);
      gd_manualLabel.widthHint = 70;
      manualLabel.setLayoutData(gd_manualLabel);
      manualLabel.setText("Manual");
      Label label_1 = new Label(this, 16777216);
      GridData gd_label_1 = new GridData(16777216, 16777216, false, false);
      gd_label_1.widthHint = 70;
      label_1.setLayoutData(gd_label_1);
      label_1.setText("|| / △");
      Label autoLabel = new Label(this, 16777216);
      GridData gd_autoLabel = new GridData(16777216, 16777216, false, false);
      gd_autoLabel.widthHint = 70;
      autoLabel.setLayoutData(gd_autoLabel);
      autoLabel.setText("Auto");
      Label maLabel = new Label(this, 16777216);
      GridData gd_maLabel = new GridData(16777216, 16777216, false, false);
      gd_maLabel.widthHint = 70;
      maLabel.setLayoutData(gd_maLabel);
      maLabel.setText("mA");
      Label label_4 = new Label(this, 16777216);
      GridData gd_label_4 = new GridData(16777216, 16777216, false, false);
      gd_label_4.widthHint = 70;
      label_4.setLayoutData(gd_label_4);
      label_4.setText("10A");
      Button f1Button = new Button(this, 0);
      GridData gd_f1Button = new GridData(16777216, 16777216, false, false);
      gd_f1Button.heightHint = 30;
      gd_f1Button.widthHint = 80;
      f1Button.setLayoutData(gd_f1Button);
      f1Button.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            MultiMeterComposite.this.send((byte)1);
         }
      });
      f1Button.setText("F1");
      Button f2Button = new Button(this, 0);
      GridData gd_f2Button = new GridData(16777216, 16777216, false, false);
      gd_f2Button.heightHint = 30;
      gd_f2Button.widthHint = 80;
      f2Button.setLayoutData(gd_f2Button);
      f2Button.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            MultiMeterComposite.this.send((byte)2);
         }
      });
      f2Button.setText("F2");
      Button f3Button = new Button(this, 0);
      GridData gd_f3Button = new GridData(16777216, 16777216, false, false);
      gd_f3Button.heightHint = 30;
      gd_f3Button.widthHint = 80;
      f3Button.setLayoutData(gd_f3Button);
      f3Button.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            MultiMeterComposite.this.send((byte)3);
         }
      });
      f3Button.setText("F3");
      Button f4Button = new Button(this, 0);
      GridData gd_f4Button = new GridData(16777216, 16777216, false, false);
      gd_f4Button.heightHint = 30;
      gd_f4Button.widthHint = 80;
      f4Button.setLayoutData(gd_f4Button);
      f4Button.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            MultiMeterComposite.this.send((byte)4);
         }
      });
      f4Button.setText("F4");
      Button f5Button = new Button(this, 0);
      GridData gd_f5Button = new GridData(16777216, 16777216, false, false);
      gd_f5Button.heightHint = 30;
      gd_f5Button.widthHint = 80;
      f5Button.setLayoutData(gd_f5Button);
      f5Button.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            MultiMeterComposite.this.send((byte)5);
         }
      });
      f5Button.setText("F5");
      Button abtn = new Button(this, 0);
      GridData gd_abtn = new GridData(16777216, 16777216, false, false);
      gd_abtn.heightHint = 30;
      gd_abtn.widthHint = 80;
      abtn.setLayoutData(gd_abtn);
      abtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            MultiMeterComposite.this.send((byte)97);
         }
      });
      abtn.setText("A");
      Button vbtn = new Button(this, 0);
      GridData gd_vbtn = new GridData(16777216, 16777216, false, false);
      gd_vbtn.heightHint = 30;
      gd_vbtn.widthHint = 80;
      vbtn.setLayoutData(gd_vbtn);
      vbtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            MultiMeterComposite.this.send((byte)118);
         }
      });
      vbtn.setText("V");
      Button rbtn = new Button(this, 0);
      GridData gd_rbtn = new GridData(16777216, 16777216, false, false);
      gd_rbtn.heightHint = 30;
      gd_rbtn.widthHint = 80;
      rbtn.setLayoutData(gd_rbtn);
      rbtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            MultiMeterComposite.this.send((byte)114);
         }
      });
      rbtn.setText("R");
      Button setbtn = new Button(this, 0);
      GridData gd_setbtn = new GridData(16777216, 16777216, false, false);
      gd_setbtn.heightHint = 30;
      gd_setbtn.widthHint = 80;
      setbtn.setLayoutData(gd_setbtn);
      setbtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            MultiMeterComposite.this.send((byte)115);
         }
      });
      setbtn.setText("SET");
   }

   void send(byte t) {
      Platform pf = Platform.getPlatform();
      pf.getActionFactory().getManipulateControl();
      this.mf.rewindRun();
   }

   public void localize(ResourceBundle bundle) {
   }

   public void storeFromUI() {
   }

   @Override
   public void pack(ByteBuffer bb) {
   }
}
