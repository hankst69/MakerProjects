package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.common.print.PageSetup;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import org.eclipse.swt.graphics.Rectangle;

public class PageSetupAction extends DefaultAction {
   public PageSetupAction(String id) {
      super(id);
   }

   public void run() {
      Platform platform = Platform.getPlatform();
      PageSetup pageSetup = new PageSetup(platform.getShell());
      Rectangle customizeTrim = pageSetup.open(platform.getPrintService().getCustomizeTrim());
      platform.getPrintService().setCustomizeTrim(customizeTrim);
   }
}
