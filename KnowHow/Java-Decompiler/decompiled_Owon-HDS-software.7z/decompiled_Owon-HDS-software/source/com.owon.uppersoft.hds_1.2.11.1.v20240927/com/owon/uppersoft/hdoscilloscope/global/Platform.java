package com.owon.uppersoft.hdoscilloscope.global;

import com.owon.uppersoft.common.utils.ColorShop;
import com.owon.uppersoft.hdoscilloscope.action.ActionFactory;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.communication.loop.LoopControl;
import com.owon.uppersoft.hdoscilloscope.frame.MainFrame;
import com.owon.uppersoft.hdoscilloscope.frame.view.Center;
import com.owon.uppersoft.hdoscilloscope.image.ImageShop;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import com.owon.uppersoft.hdoscilloscope.pref.PreferencesFactory;
import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import com.owon.uppersoft.hdoscilloscope.print.PrintService;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Platform {
   private MainFrame mf;
   private Display display = Display.getDefault();
   private ImageShop IMAGESHOP;
   private ColorShop COLORSHOP;
   private PrintService PRINTSERVICE;
   private PreferencesFactory pf = new PreferencesFactory(PropertiesItem.CONFIGURATION_DIR, "pref.properties");
   private Configuration CONFIG = this.pf.getConfiguration();
   private ActionFactory af;
   private Shell shell;
   private Center center;
   private DrawingPanel dp;
   private static Platform platform;

   private Platform() {
      this.IMAGESHOP = new ImageShop(this.display);
      this.COLORSHOP = new ColorShop(this.display);
      this.PRINTSERVICE = new PrintService(this.display);
   }

   private void dispose() {
      this.pf.persistConfiguration(this.CONFIG);
      this.IMAGESHOP.dispose();
      this.COLORSHOP.dispose();
      this.PRINTSERVICE.dispose();
   }

   public MainFrame getMainFrame() {
      return this.mf;
   }

   public Display getDisplay() {
      return this.display;
   }

   public ImageShop getImageShop() {
      return this.IMAGESHOP;
   }

   public ColorShop getColorShop() {
      return this.COLORSHOP;
   }

   public PrintService getPrintService() {
      return this.PRINTSERVICE;
   }

   public Configuration getConfiguration() {
      return this.CONFIG;
   }

   public void setMainFrame(MainFrame mf) {
      this.mf = mf;
      this.af = mf.getActionFactory();
      this.shell = mf.getShell();
      this.center = mf.getCenter();
      this.dp = this.center.getDrawingPanel();
   }

   public ActionFactory getActionFactory() {
      return this.af;
   }

   public Shell getShell() {
      return this.shell;
   }

   public PreferencesFactory getPreferencesFactory() {
      return this.pf;
   }

   public Center getCenter() {
      return this.center;
   }

   public DrawingPanel getDrawingPanel() {
      return this.dp;
   }

   public static Platform getPlatform() {
      if (platform == null) {
         platform = new Platform();
      }

      return platform;
   }

   public LoopControl getLoopControl() {
      return this.getActionFactory().loopControl;
   }

   public ManipulateControl getManipulateControl() {
      return this.getActionFactory().manipulate.getManipulateControl();
   }

   public static void reset() {
      if (platform != null) {
         platform.dispose();
         platform = null;
      }
   }
}
