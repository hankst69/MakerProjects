package com.owon.uppersoft.hdoscilloscope.chart.model;

import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import org.eclipse.swt.graphics.Point;

public class LowMoveChecker {
   private boolean EnableLowMovePatched = true;
   private boolean isLowMovePatched = false;
   private boolean isRightPointUsed = false;
   private WaveForm wf;
   public Point lp;
   public Point rp;

   public LowMoveChecker(WaveForm wf) {
      this.wf = wf;
      this.lp = new Point(0, 0);
      this.rp = new Point(0, 0);
   }

   public boolean isLowMovePatched() {
      return this.isLowMovePatched;
   }

   public boolean isRightPointUsed() {
      return this.isRightPointUsed;
   }

   public void patchLowMove() {
      if (this.EnableLowMovePatched) {
         if (!this.wf.isLowMove()) {
            this.isLowMovePatched = false;
         } else {
            this.isLowMovePatched = true;
            this.isRightPointUsed = false;
            this.lp.x = this.wf.lp.x;
            this.lp.y = this.wf.lp.y;
         }
      }
   }
}
