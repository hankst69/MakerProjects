package com.owon.uppersoft.hdoscilloscope.data;

import java.io.PrintStream;

public class LogData {
   public static final int BINARY = 2;
   public static final int DEC = 10;
   public static final int HEX = 16;
   public static final int OCTAL = 8;
   public static PrintStream out = System.out;

   public static void logDataHex(byte[] data) {
      logDataHex(data, 0, data.length);
   }

   public static void logDataHex(byte[] data, int offset, int length) {
      out.print("Data: ");

      for (int i = offset; i < length; i++) {
         out.print("0x" + Integer.toHexString(data[i] & 255) + " ");
      }

      out.println();
   }

   public static void logDataDec(byte[] data) {
      logDataDec(data, 0, data.length);
   }

   public static void logDataDec(byte[] data, int offset, int length) {
      out.print("Data: ");

      for (int i = offset; i < length; i++) {
         out.print((data[i] & 0xFF) + " ");
      }

      out.println();
   }
}
