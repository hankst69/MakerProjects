package com.owon.uppersoft.hdoscilloscope.data.normal;

import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;

public class DefaultWFF extends WaveFormFile {
   @Override
   public void wfFullScreenNum(int intFullScreenDataNum, WaveForm wf) {
      this.confirmPublicM();
   }

   @Override
   public void confirmPublicM() {
      this.confirmPublicMWithGraticuleNum(this.getXBlockPixels());
   }

   @Override
   public double getXGraticuleNum() {
      return this.getMt().getxGraticuleNum();
   }

   @Override
   public int getYGraticuleNum() {
      return this.getMt().getyGraticuleNum();
   }

   @Override
   public int getXPointNum() {
      return (int)((double)this.getMt().getxBlockPixels() * this.getMt().getxGraticuleNum());
   }

   @Override
   public int getYPointNum() {
      return this.getMt().getyBlockPixels() * this.getMt().getyGraticuleNum();
   }
}
