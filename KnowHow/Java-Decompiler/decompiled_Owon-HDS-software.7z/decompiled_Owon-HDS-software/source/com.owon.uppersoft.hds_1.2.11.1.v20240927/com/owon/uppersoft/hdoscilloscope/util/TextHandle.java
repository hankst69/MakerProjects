package com.owon.uppersoft.hdoscilloscope.util;

import java.util.logging.Handler;
import java.util.logging.LogRecord;
import javax.swing.JTextArea;
import javax.swing.text.Document;

public class TextHandle extends Handler {
   JTextArea ta;

   public TextHandle(JTextArea ta) {
      this.ta = ta;
   }

   @Override
   public void close() throws SecurityException {
   }

   @Override
   public void flush() {
   }

   @Override
   public void publish(LogRecord record) {
      String t = record.getMessage();
      Document doc = this.ta.getDocument();
      int len = doc.getLength();
      if (len >= 2000) {
         this.ta.replaceRange("", 0, 1000);
      }

      this.ta.append(t);
      len = doc.getLength();
      this.ta.setCaretPosition(len);
   }
}
