package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.DbFFTDrawCompute;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.control.FFTControl;
import com.owon.uppersoft.hdoscilloscope.model.MachineType;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

public class FFTComposite extends Composite implements Localizable2 {
   private Combo fm_base_cb;
   private Combo freq_cb;
   private Combo zoom_cb;
   private Combo fm_cb;
   private Combo wnd_cb;
   private Combo chl_cb;
   private Label chl_lbl;
   private Label wnd_lbl;
   private Label fm_lbl;
   private Label zoom_lbl;
   private Label freq_lbl;
   private boolean on = false;
   private Label xbaseback;
   private Button onoffButton;

   public FFTComposite(Composite parent, final ManipulateControl mc) {
      super(parent, 0);
      GridLayout gridLayout = new GridLayout();
      gridLayout.horizontalSpacing = 10;
      gridLayout.verticalSpacing = 10;
      gridLayout.marginHeight = 10;
      gridLayout.marginWidth = 10;
      gridLayout.numColumns = 3;
      this.setLayout(gridLayout);
      this.onoffButton = new Button(this, 32);
      this.onoffButton.setLayoutData(new GridData(4, 16777216, false, false, 3, 1));
      this.chl_lbl = new Label(this, 0);
      GridData gd_chl_lbl = new GridData(4, 16777216, false, false);
      gd_chl_lbl.widthHint = 100;
      this.chl_lbl.setLayoutData(gd_chl_lbl);
      this.chl_cb = new Combo(this, 8);
      GridData gd_chl_cb = new GridData(16384, 16777216, true, false, 2, 1);
      gd_chl_cb.widthHint = 80;
      this.chl_cb.setLayoutData(gd_chl_cb);
      this.wnd_lbl = new Label(this, 0);
      GridData gd_wnd_lbl = new GridData(4, 16777216, false, false);
      this.wnd_lbl.setLayoutData(gd_wnd_lbl);
      this.wnd_cb = new Combo(this, 8);
      GridData gd_wnd_cb = new GridData(16384, 16777216, true, false, 2, 1);
      gd_wnd_cb.widthHint = 80;
      this.wnd_cb.setLayoutData(gd_wnd_cb);
      this.fm_lbl = new Label(this, 0);
      GridData gd_fm_lbl = new GridData(4, 16777216, false, false);
      this.fm_lbl.setLayoutData(gd_fm_lbl);
      this.fm_cb = new Combo(this, 8);
      GridData gd_fm_cb = new GridData(4, 16777216, false, false);
      gd_fm_cb.widthHint = 80;
      this.fm_cb.setLayoutData(gd_fm_cb);
      this.fm_base_cb = new Combo(this, 8);
      GridData gd_fm_base_cb = new GridData(16384, 16777216, true, false);
      gd_fm_base_cb.widthHint = 90;
      this.fm_base_cb.setLayoutData(gd_fm_base_cb);
      this.zoom_lbl = new Label(this, 0);
      GridData gd_zoom_lbl = new GridData(4, 16777216, false, false);
      this.zoom_lbl.setLayoutData(gd_zoom_lbl);
      this.zoom_cb = new Combo(this, 8);
      GridData gd_zoom_cb = new GridData(16384, 16777216, true, false, 2, 1);
      gd_zoom_cb.widthHint = 80;
      this.zoom_cb.setLayoutData(gd_zoom_cb);
      this.freq_lbl = new Label(this, 0);
      GridData gd_freq_lbl = new GridData(4, 16777216, false, false);
      this.freq_lbl.setLayoutData(gd_freq_lbl);
      this.freq_cb = new Combo(this, 8);
      GridData gd_freq_cb = new GridData(4, 16777216, false, false);
      gd_freq_cb.widthHint = 80;
      this.freq_cb.setLayoutData(gd_freq_cb);
      this.chl_cb.setItems(ManipulateControl.CHANNELS);
      this.wnd_cb.setItems(FFTControl.wnds);
      this.zoom_cb.setItems(FFTControl.zooms);
      this.fm_cb.setItems(FFTControl.fms);
      MachineType mt = mc.mt;
      final String[] rms_t = ManipulateControl.toStrings(mt.getYbaseList());
      final String[] db_t = ManipulateControl.toStrings(DbFFTDrawCompute.dBbasesTxt);
      this.fm_base_cb.setItems(rms_t);
      this.chl_cb.select(0);
      this.wnd_cb.select(0);
      this.zoom_cb.select(0);
      this.freq_cb.select(0);
      this.fm_base_cb.select(0);
      this.fm_cb.select(0);
      final FFTControl fc = mc.fc;
      this.onoffButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (FFTComposite.this.on) {
               fc.on = FFTComposite.this.onoffButton.getSelection();
               String cmd = ":FFT:display " + (fc.on ? "on" : "off");
               mc.send(cmd);
            }
         }
      });
      this.freq_cb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (FFTComposite.this.on) {
               int idx = FFTComposite.this.freq_cb.getSelectionIndex();
               fc.xbaseidx = idx;
               if (fc.on) {
                  String cmd = ":FFT:ch ";
                  mc.send(cmd);
               }
            }
         }
      });
      this.chl_cb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (FFTComposite.this.on) {
               int idx = FFTComposite.this.chl_cb.getSelectionIndex();
               fc.chl = idx;
               if (fc.on) {
                  String cmd = ":HORIzontal:Scale ";
                  mc.send(cmd);
               }
            }
         }
      });
      this.wnd_cb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (FFTComposite.this.on) {
               int idx = FFTComposite.this.wnd_cb.getSelectionIndex();
               fc.wnd = idx;
               if (fc.on) {
                  String cmd = ":HORIzontal:Scale ";
                  mc.send(cmd);
               }
            }
         }
      });
      this.fm_cb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (FFTComposite.this.on) {
               int idx = FFTComposite.this.fm_cb.getSelectionIndex();
               fc.vrms_db = idx;
               fc.ybaseidx = 0;
               FFTComposite.this.on = false;
               String[] ybase;
               if (idx == 0) {
                  ybase = rms_t;
               } else {
                  ybase = db_t;
               }

               FFTComposite.this.fm_base_cb.setItems(ybase);
               FFTComposite.this.fm_base_cb.select(0);
               FFTComposite.this.on = true;
               if (fc.on) {
                  String cmd = ":HORIzontal:Scale ";
                  mc.send(cmd);
               }
            }
         }
      });
      this.fm_base_cb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (FFTComposite.this.on) {
               int idx = FFTComposite.this.fm_base_cb.getSelectionIndex();
               FFTComposite.this.fm_cb.getSelectionIndex();
               fc.ybaseidx = idx;
               if (fc.on) {
                  String cmd = ":HORIzontal:Scale ";
                  mc.send(cmd);
               }
            }
         }
      });
      this.zoom_cb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (FFTComposite.this.on) {
               int idx = FFTComposite.this.zoom_cb.getSelectionIndex();
               fc.zoom = idx;
               FFTComposite.this.xbaseback.setText("X 1 / " + FFTComposite.this.zoom_cb.getText().substring(1));
               if (fc.on) {
                  String cmd = ":HORIzontal:Scale ";
                  mc.send(cmd);
               }
            }
         }
      });
      this.xbaseback = new Label(this, 0);
      this.xbaseback.setLayoutData(new GridData(4, 16777216, false, false));
      this.xbaseback.setText("X 1 / " + this.zoom_cb.getText().substring(1));
      this.on = true;
   }

   public void localize(ResourceBundle bundle) {
      this.chl_lbl.setText(bundle.getString("M.FFT.chl"));
      this.wnd_lbl.setText(bundle.getString("M.FFT.wnd"));
      this.fm_lbl.setText(bundle.getString("M.FFT.fm"));
      this.zoom_lbl.setText(bundle.getString("M.FFT.zoom"));
      this.freq_lbl.setText(bundle.getString("M.FFT.freq"));
      this.onoffButton.setText(bundle.getString("M.FFT.onoff"));
   }
}
