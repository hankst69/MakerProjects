package com.owon.uppersoft.hdoscilloscope.model;

import com.owon.uppersoft.hdoscilloscope.model.detail.Idn;
import com.owon.uppersoft.hdoscilloscope.model.detail.ModelBean;
import com.owon.uppersoft.hdoscilloscope.model.detail.ModelDetail;
import java.util.List;

public class MachineType {
   protected Idn idn;
   protected ModelBean model;
   public int more = 0;

   public double getxGraticuleNum() {
      return this.model.getxGraticuleNum();
   }

   public int getxBlockPixels() {
      return this.model.getxBlockPixels();
   }

   public int getyBlockPixels() {
      return this.model.getyBlockPixels();
   }

   public int getyGraticuleNum() {
      return this.model.getyGraticuleNum();
   }

   public int getChLen() {
      return this.model.getChLen();
   }

   public MachineType(Idn idn) {
      this.idn = idn;
      this.model = new ModelDetail().getModel(idn);
   }

   public List<Dbl_Txt> getXbaseList() {
      return PublicM.StrHs_1ns.subList(this.model.getXbaseIndex(), PublicM.StrHs_1ns.size());
   }

   public List<Dbl_Txt> getYbaseList() {
      return PublicM.StrVv.subList(this.model.getYbaseIndex(), PublicM.StrVv.size());
   }

   public int getMaxBit() {
      System.out.println("maxbit:" + this.model.getMaxBit());
      return this.model.getMaxBit();
   }

   public Idn getIdn() {
      return this.idn;
   }

   protected void init() {
   }

   public String getIniFileName() {
      return this.idn.getModel();
   }

   public static void main(String[] args) {
   }
}
