package com.owon.uppersoft.hdoscilloscope.chart.model.fft.math;

public class FFTFunction {
   public static final void fft(Complex[] TD, Complex[] FD, Complex[] X2, int power, int length) {
      int count = 1 << power;
      int[] W = CosSinTable.getTable(count);
      Complex[] X1 = TD;
      Complex tc = new Complex();

      for (int k = 0; k < power; k++) {
         int q = 1 << k;

         for (int j = 0; j < q; j++) {
            int tt = power - k;
            int bfsize = 1 << tt;
            int s = bfsize >> 1;

            for (int i = 0; i < s; i++) {
               int p = j << tt;
               int t1 = i + p;
               int t2 = t1 + s;
               int o = i << k << 1;
               Complex.Add(X1[t1], X1[t2], X2[t1]);
               Complex.Sub(X1[t1], X1[t2], tc);
               Complex.Mul_r10(tc, W[o], W[o + 1], X2[t2]);
            }
         }

         Complex[] Xtmp = X1;
         X1 = X2;
         X2 = Xtmp;
      }

      for (int j = 0; j < count; j++) {
         int p = 0;

         for (int i = 0; i < power; i++) {
            if ((j & 1 << i) != 0) {
               p += 1 << power - i - 1;
            }
         }

         FD[j] = X1[p];
      }
   }

   public static final int powers(int size) {
      int i;
      for (i = 0; size > 1; i++) {
         size >>= 1;
      }

      return i;
   }

   public static final void fft_adc(int[] wnd_adc, int start, int end, Complex[] TD, Complex[] FD, Complex[] X2) {
      int length = end - start;
      if (length > 0) {
         int power = powers(length);
         length = 1 << power;
         int i = start;

         for (int j = 0; i < end; j++) {
            Complex tmp = TD[j];
            tmp.re = wnd_adc[i];
            tmp.im = 0;
            i++;
         }

         fft(TD, FD, X2, power, length);
      }
   }

   public static void main(String[] args) {
      int[] d = new int[]{0, 1, 2, 3, 4, 5, 6, 7};
      Complex[] TD = new Complex[2048];
      Complex[] FD = new Complex[2048];
      Complex[] X2 = new Complex[2048];

      for (int i = 0; i < 2048; i++) {
         TD[i] = new Complex();
         FD[i] = new Complex();
         X2[i] = new Complex();
      }

      fft_adc(d, 0, d.length, TD, FD, X2);

      for (int i = 0; i < TD.length; i++) {
         System.out.println(TD[i]);
      }
   }
}
