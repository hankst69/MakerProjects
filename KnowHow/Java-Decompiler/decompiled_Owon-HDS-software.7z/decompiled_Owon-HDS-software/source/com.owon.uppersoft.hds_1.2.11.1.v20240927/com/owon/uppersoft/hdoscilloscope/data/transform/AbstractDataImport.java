package com.owon.uppersoft.hdoscilloscope.data.transform;

import com.owon.uppersoft.common.logger.LoggerUtil;
import com.owon.uppersoft.hdoscilloscope.chart.model.ControlManger;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.util.DBG;
import java.io.File;
import java.util.logging.Logger;

public abstract class AbstractDataImport implements IDataImport {
   public static final Logger logger = LoggerUtil.getConsoleLogger(RapidDataImport.class.getName(), DBG.global);

   @Override
   public WaveFormFile getWaveFormFile(File file, ControlManger cm) {
      return this.loadWaveFormFile(file, cm);
   }

   private WaveFormFile loadWaveFormFile(File f, ControlManger cm) {
      WaveFormFile waveFormFile = null;
      waveFormFile = this.readBinary(new CByteArrayInputStream(f), cm);
      if (waveFormFile != null) {
         waveFormFile.setRaw(false);
         waveFormFile.setOrginalFile(f);
      }

      return waveFormFile;
   }
}
