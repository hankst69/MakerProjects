package com.owon.uppersoft.hdoscilloscope.manipulate;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.action.ActionFactory;
import com.owon.uppersoft.hdoscilloscope.communication.loop.JobUnit;
import com.owon.uppersoft.hdoscilloscope.communication.loop.LoopControl;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.model.detail.Idn;
import java.util.ResourceBundle;
import org.eclipse.swt.widgets.Display;

public class ManiAction extends DefaultAction {
   private ActionFactory af;
   private ManipulateFrame mf;
   private ManipulateControl mc;
   public short machine_id = 0;
   public short version_id = 0;
   public String mchhdr = "";
   public String cmdhdr = "";
   private boolean deal = false;

   public ManiAction(String id, ActionFactory af) {
      super(id);
      this.af = af;
   }

   public ManipulateControl getManipulateControl() {
      return this.mc;
   }

   public void updateRSButton(final boolean run) {
      if (this.mf != null) {
         Display display = Platform.getPlatform().getDisplay();
         display.syncExec(new Runnable() {
            @Override
            public void run() {
               ManiAction.this.mf.updateRSButton(run);
            }
         });
      }
   }

   public void release() {
      LoopControl lc = this.af.loopControl;
      lc.setUse(false);
      this.mf = null;
      this.reEnable();
   }

   public void reEnable() {
      this.deal = false;
   }

   public void run() {
      if (!this.deal) {
         this.deal = true;
         if (this.mf == null) {
            final LoopControl lc = this.af.loopControl;
            Display.getDefault().asyncExec(new Runnable() {
               @Override
               public void run() {
                  JobUnit ju = new JobUnit("*ODN?\r\n".getBytes());
                  lc.activeSend(ju);
                  int num = ju.getResNum();
                  if (num <= 0) {
                     ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle2();
                     ResourceBundleProvider.getMessageLibResourceBundle().getString("Err.Default");
                     bundle.getString("Warn.noSupportMmScpi");
                     ManiAction.this.reEnable();
                  } else {
                     String s = new String(ju.re_arr, 0, num);
                     System.out.println(s);
                     ManiAction.this.loadMani(lc, new Idn(s));
                  }
               }
            });
         } else {
            this.mf.forceFocus();
         }
      }
   }

   private void loadMani(LoopControl lc, Idn idn) {
      this.mc = new ManipulateControl(lc, idn);
      this.mf = new ManipulateFrame(this.af.getShell(), lc, this, this.mc);
      this.mf.open();
   }

   public void localize(ResourceBundle bundle) {
      super.localize(bundle);
      if (this.mf != null) {
         this.mf.localize(bundle);
      }
   }
}
