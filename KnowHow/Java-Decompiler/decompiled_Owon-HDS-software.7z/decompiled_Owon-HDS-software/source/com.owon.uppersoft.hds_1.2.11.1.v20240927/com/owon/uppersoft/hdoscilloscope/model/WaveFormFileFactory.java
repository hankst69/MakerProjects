package com.owon.uppersoft.hdoscilloscope.model;

import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.data.normal.DefaultWFF;

public class WaveFormFileFactory {
   public static final WaveFormFile createWaveFormFile() {
      WaveFormFile wff = new DefaultWFF();
      return wff;
   }

   public static final int getPixelsPerBlock() {
      return 50;
   }
}
