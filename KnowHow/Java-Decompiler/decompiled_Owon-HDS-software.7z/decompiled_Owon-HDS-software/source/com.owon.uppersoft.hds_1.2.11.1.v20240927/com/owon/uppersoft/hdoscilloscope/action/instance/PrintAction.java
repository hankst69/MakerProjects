package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class PrintAction extends DefaultAction {
   public PrintAction(String id) {
      super(id);
   }

   public void run() {
      Platform platform = Platform.getPlatform();
      platform.getPrintService().printProcedure(platform.getShell());
   }
}
