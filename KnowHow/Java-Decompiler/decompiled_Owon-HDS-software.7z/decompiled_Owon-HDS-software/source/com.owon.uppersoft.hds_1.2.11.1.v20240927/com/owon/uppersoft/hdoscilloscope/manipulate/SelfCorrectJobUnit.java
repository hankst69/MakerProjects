package com.owon.uppersoft.hdoscilloscope.manipulate;

import com.owon.uppersoft.hdoscilloscope.communication.loop.IRapidCommunication;
import com.owon.uppersoft.hdoscilloscope.communication.loop.JobUnit;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.util.DBG;
import java.lang.reflect.InvocationTargetException;
import java.nio.ByteBuffer;
import java.util.ResourceBundle;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class SelfCorrectJobUnit extends JobUnit implements IRunnableWithProgress {
   public static final String crs = ":SDSLCRS#";
   public static final String crs0 = ":SDSLCRS0";
   public static final String csp = ":SDSLCSP#";
   public static final String csp0 = ":SDSLCSP0";
   private Shell sh;
   private Display dp;
   private Button btn;
   private ProgressMonitorDialog pmd;
   private int progress = 10;
   private IRapidCommunication irc;
   public static final int InitGapTime = 1000;
   public static final int MaxGapTime = 8000;
   public static final int IncretGapTime = 1000;
   public static final int MaxErrTimes = 3;

   public SelfCorrectJobUnit(Button btn, Shell shell) {
      super(":SDSLCRS#".getBytes(), ":SDSLCRS0".getBytes());
      this.btn = btn;
      this.sh = shell;
      this.dp = shell.getDisplay();
   }

   protected void afterJob(IRapidCommunication irc, ByteBuffer bbuf) {
      this.irc = irc;
      this.progress = this.re_arr[this.re_arr.length - 1];
      DBG.configln("progress: " + this.progress);
      Platform.getPlatform().getLoopControl().getRapidLoop().suspendGet();
      this.dp.syncExec(new SelfCorrectJobUnit.SCErrRunner(null));
   }

   private void runProgress() {
      this.pmd = new ProgressMonitorDialog(this.sh);

      try {
         this.pmd.run(true, true, this);
      } catch (InvocationTargetException var2) {
         var2.printStackTrace();
      } catch (InterruptedException var3) {
         var3.printStackTrace();
      }
   }

   public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
      try {
         this.dp.syncExec(new SelfCorrectJobUnit.SCInitRunner(null));
         monitor.beginTask(" ", this.progress);
         monitor.setTaskName(" ");
         monitor.subTask(" ");
         ":SDSLCSP#".getBytes();
         byte[] re = ":SDSLCSP0".getBytes();
         int tt = 1000;

         try {
            int gv = 0;
            int errTimes = 0;

            while (gv < this.progress && !monitor.isCanceled()) {
               Thread.sleep((long)tt);
               if (this.getReqNum() < 0 || this.getResNum() < 0) {
                  if (++errTimes >= 3) {
                     this.dp.syncExec(new SelfCorrectJobUnit.SCErrUSBRunner(null));
                     break;
                  }
               }

               DBG.configln("res: " + this.getResNum());
               int lgv = gv;
               gv = re[re.length - 1] & 255;
               int del = gv - lgv;
               if (del <= 0) {
                  if (tt <= 8000) {
                     tt += 1000;
                  }
               } else {
                  tt = 1000;
                  monitor.worked(del);
                  DBG.configln("selfcorrect progress: " + gv);
               }
            }
         } catch (InterruptedException var12) {
            var12.printStackTrace();
         }
      } catch (Exception var13) {
         var13.printStackTrace();
      } finally {
         monitor.done();
         this.dp.syncExec(new SelfCorrectJobUnit.SCEndRunner(null));
      }
   }

   public static void main(String[] args) {
      Shell s = new Shell();
      Button btn = new Button(s, 0);
      SelfCorrectJobUnit scj = new SelfCorrectJobUnit(btn, s);
      scj.runProgress();
   }

   private final class SCEndRunner implements Runnable {
      private SCEndRunner() {
      }

      @Override
      public void run() {
         if (SelfCorrectJobUnit.this.btn != null && !SelfCorrectJobUnit.this.btn.isDisposed()) {
            SelfCorrectJobUnit.this.btn.setEnabled(true);
            Platform.getPlatform().getLoopControl().getRapidLoop().resumeGet();
         }
      }
   }

   private final class SCErrRunner implements Runnable {
      private SCErrRunner() {
      }

      @Override
      public void run() {
         if (SelfCorrectJobUnit.this.progress <= 0) {
            ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle();
            MessageDialog dialog = new MessageDialog(
               SelfCorrectJobUnit.this.sh, "", null, "Unknow SelfCorrect Progress!", 1, new String[]{rb.getString("CS.OK")}, 0
            );
            dialog.open();
         } else {
            SelfCorrectJobUnit.this.runProgress();
         }
      }
   }

   private final class SCErrUSBRunner implements Runnable {
      private SCErrUSBRunner() {
      }

      @Override
      public void run() {
         ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle();
         MessageDialog dialog = new MessageDialog(
            SelfCorrectJobUnit.this.sh, "", null, rb.getString("Err.USBConnect"), 1, new String[]{rb.getString("CS.OK")}, 0
         );
         dialog.open();
      }
   }

   private final class SCInitRunner implements Runnable {
      private SCInitRunner() {
      }

      @Override
      public void run() {
         SelfCorrectJobUnit.this.pmd.setCancelable(false);
         SelfCorrectJobUnit.this.pmd.getShell().setText(ResourceBundleProvider.getMessageLibResourceBundle2().getString("M.SelfCorrect.title"));
      }
   }
}
