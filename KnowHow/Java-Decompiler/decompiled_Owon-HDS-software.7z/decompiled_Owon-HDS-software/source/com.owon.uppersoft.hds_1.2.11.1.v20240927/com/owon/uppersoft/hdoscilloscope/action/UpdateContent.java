package com.owon.uppersoft.hdoscilloscope.action;

import com.owon.uppersoft.common.update.IUpdatable;
import com.owon.uppersoft.common.utils.LaunchManager;
import com.owon.uppersoft.hdoscilloscope.frame.MainFrame;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import java.util.Arrays;
import java.util.List;
import org.eclipse.swt.widgets.Shell;

public class UpdateContent implements IUpdatable {
   private MainFrame mf;
   private Configuration config;

   public UpdateContent(MainFrame mf) {
      this.mf = mf;
      this.config = Platform.getPlatform().getConfiguration();
   }

   public Shell getMainShell() {
      return this.mf.getShell();
   }

   public void close() {
      this.mf.getShell().close();
   }

   public void startAgain() {
      LaunchManager.tryLaunchByName(this.config.getLauncher());
   }

   public String getRelativePath() {
      return this.config.getUpdateXML();
   }

   public List<String> getUpdatableServers() {
      return Arrays.asList(this.config.getUpdateServer());
   }

   public String getConfigurationDir() {
      return PropertiesItem.CONFIGURATION_DIR;
   }

   public void notifyDestroy() {
      this.mf.getActionFactory().help.closeHelpHandle();
   }

   public String getProductVersion() {
      return this.config.getVersionId();
   }
}
