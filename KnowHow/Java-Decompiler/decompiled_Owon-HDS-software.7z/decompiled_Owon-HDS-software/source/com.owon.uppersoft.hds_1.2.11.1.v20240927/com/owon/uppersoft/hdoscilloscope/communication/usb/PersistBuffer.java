package com.owon.uppersoft.hdoscilloscope.communication.usb;

import com.owon.uppersoft.common.utils.FileUtil;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class PersistBuffer {
   private RandomAccessFile raf;
   private File tmp;
   private File dir = new File(Platform.getPlatform().getPreferencesFactory().confDir(), "temp");

   public PersistBuffer() {
      FileUtil.deleteFile(this.dir);
      this.dir.mkdirs();
   }

   public boolean init() {
      try {
         this.tmp = File.createTempFile("bin", null, this.dir);
         this.raf = new RandomAccessFile(this.tmp, "rw");
         return true;
      } catch (IOException var2) {
         var2.printStackTrace();
         return false;
      }
   }

   public RandomAccessFile raf() {
      return this.raf;
   }

   public void close() {
      try {
         if (this.raf != null) {
            this.raf.close();
         }
      } catch (IOException var2) {
         var2.printStackTrace();
      }
   }

   public void dispose() {
      if (this.tmp != null) {
         this.tmp.delete();
      }
   }

   public File getFile() {
      return this.tmp;
   }

   public boolean renameTo(File file) {
      boolean b = this.tmp.renameTo(file);
      if (b) {
         return true;
      } else {
         RandomAccessFile raf = null;
         RandomAccessFile raf2 = null;

         try {
            try {
               long len = this.tmp.length();
               raf = new RandomAccessFile(this.tmp, "rw");
               raf2 = new RandomAccessFile(file, "rw");
               long n = raf.getChannel().transferTo(0L, len, raf2.getChannel());
               if (n >= len) {
                  System.out.println(this.tmp.delete());
                  return true;
               }
            } finally {
               if (raf != null) {
                  raf.close();
               }

               if (raf2 != null) {
                  raf2.close();
               }
            }

            return false;
         } catch (FileNotFoundException var14) {
            var14.printStackTrace();
            return false;
         } catch (IOException var15) {
            var15.printStackTrace();
            return false;
         }
      }
   }
}
