package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.custom.IntPropertyChangeAdapter;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.util.CRadioButtons;
import java.util.ResourceBundle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;

public final class ChannelGroupComposite extends Composite implements Localizable2 {
   private ChannelComposite chlcom;

   public ChannelGroupComposite(Composite parent, ManipulateControl mc) {
      super(parent, 0);
      GridLayout gridLayout = new GridLayout();
      gridLayout.marginHeight = 10;
      gridLayout.marginWidth = 10;
      this.setLayout(gridLayout);
      IntPropertyChangeAdapter pcl = new IntPropertyChangeAdapter() {
         @Override
         protected void idx(int i) {
            ChannelGroupComposite.this.chlcom.load(i);
         }
      };
      CRadioButtons cbr = new CRadioButtons(this, ManipulateControl.CHANNELS, pcl, 0, mc.mt.getChLen());
      GridData gd_cbr = new GridData();
      cbr.setLayoutData(gd_cbr);
      this.chlcom = new ChannelComposite(this, mc.cc, mc);
      this.chlcom.load(0);
      GridData gd_chlcom = new GridData(4, 4, true, false);
      gd_chlcom.heightHint = 100;
      this.chlcom.setLayoutData(gd_chlcom);
   }

   public void localize(ResourceBundle bundle) {
      this.chlcom.localize(bundle);
   }
}
