package com.owon.uppersoft.hdoscilloscope.autoplay;

public interface IAutoPlayer {
   String iniFileName = "filename.ini";

   void playSingle(int var1);

   void playStart();

   void playPause();

   void playContinue();

   void playEnd();

   void fastForward();

   void fastBackward();

   void endFast();

   void previous();

   void next();

   void setPlayAttribute(PlayAttribute var1);
}
