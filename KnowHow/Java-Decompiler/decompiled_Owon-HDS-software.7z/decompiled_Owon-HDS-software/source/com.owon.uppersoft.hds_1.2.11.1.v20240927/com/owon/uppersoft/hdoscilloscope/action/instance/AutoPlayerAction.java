package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.autoplay.AutoPlayerFrame;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import java.util.List;
import java.util.ResourceBundle;

public class AutoPlayerAction extends DefaultAction {
   private AutoPlayerFrame apf;

   public AutoPlayerAction(String id) {
      super(id);
   }

   public void run() {
      this.autoplayer();
   }

   public void autoplayer() {
      if (this.apf != null && !this.apf.getShell().isDisposed()) {
         this.apf.getShell().setActive();
      } else {
         Platform pf = Platform.getPlatform();
         Configuration conf = pf.getConfiguration();
         List<String> iniList = conf.iniList;
         this.apf = new AutoPlayerFrame(iniList);
         this.apf.open();
         conf.iniList = this.apf.returnHistoryList();
         this.apf = null;
      }
   }

   private void localizePlayer(ResourceBundle bundle) {
      if (this.apf != null) {
         this.apf.localize(bundle);
      }
   }

   public void localize(ResourceBundle bundle) {
      super.localize(bundle);
      this.localizePlayer(bundle);
   }
}
