package com.owon.uppersoft.hdoscilloscope.chart.model.fft;

import com.owon.uppersoft.hdoscilloscope.chart.DrawEngine;
import com.owon.uppersoft.hdoscilloscope.data.TxtEntry;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.model.PublicM;
import com.owon.uppersoft.hdoscilloscope.util.UnitConversionUtil;
import java.util.Collection;
import java.util.List;
import org.eclipse.swt.graphics.Point;

public class VrmsFFTDrawCompute implements IFFTCompute {
   public static String[] rmsbasesTxt;
   private WaveForm wf;
   private int[] data;
   private DrawEngine dren;
   private int dataLength;
   private double zeroY;
   private int[] oadc;
   private PublicM pm;
   private FFTInfo fi;
   private FFTWaveFormCurve fw;
   private int posOffset = 0;
   private Collection<? extends Object> yb_coll;
   private double timeScope;
   private double rmsScope;
   private double xbase;
   private double ybase;
   private double timePerPix;
   private double voltPerPix;
   private double xpp;
   private double ypp;
   private int xbaseidx;
   private int ybaseidx;

   public VrmsFFTDrawCompute(FFTWaveFormCurve fw, DrawEngine dren, WaveForm wf, int length, int[] oadc) {
      this.fw = fw;
      this.dren = dren;
      this.wf = wf;
      this.pm = wf.getPublicM();
      this.fi = wf.getFFTInfo();
      this.dataLength = length;
      this.oadc = oadc;
      this.data = new int[this.dataLength >> 1];
      this.yb_coll = ((List)PublicM.yb_coll()).subList(0, 10);
   }

   @Override
   public void controlResize(Point lastsize, Point size) {
      this.updateValueRate(size);
   }

   @Override
   public void updateWndType() {
      this.windowing();
      this.computeDren();
   }

   @Override
   public void resumeToMode() {
      Point size = this.dren.getSize();
      this.resetXYBase();
      this.resize(size);
      this.updateValueRate(size);
      this.windowing();
      this.computeDren();
      this.fw.setBlockNum(40);
   }

   protected void resetXYBase() {
      this.xbaseidx = this.fi.getfreqIdx();
      this.ybaseidx = this.wf.getIntVoltageBase();
      this.xbase = this.fi.getFreq(this.xbaseidx);
      this.ybase = PublicM.getchVvValue(this.ybaseidx);
      WaveFormFile wff = this.wf.getWaveFormFile();
      this.timeScope = this.xbase * wff.getXGraticuleNum();
      this.rmsScope = this.ybase * (double)wff.getYGraticuleNum();
   }

   protected void resize(Point size) {
      WaveFormFile wff = this.wf.getWaveFormFile();
      int ypointScope = wff.getYPointNum();
      this.xpp = (double)size.x * this.fi.getMaxfreqPercent() * (double)this.fi.getZoomRate() / (double)this.data.length;
      this.ypp = (double)size.y / (double)ypointScope;
      this.zeroY = (double)(size.y >> 1) - (double)this.fi.loc0 * this.ypp;
      this.posOffset = -this.fi.posOffset * size.x / wff.getXPointNum();
   }

   protected void updateValueRate(Point size) {
      this.timePerPix = this.timeScope / (double)size.x;
      this.voltPerPix = this.rmsScope / (double)size.y;
   }

   protected void windowing() {
      FFTUtil.compute_rms(this.oadc, this.data, FFTInfo.wndTypes[this.fw.getWndTypeIdx()]);
   }

   protected void computeDren() {
      this.dren
         .initPts(
            this.data,
            0,
            this.data.length,
            (double)this.posOffset,
            this.zeroY,
            this.xpp,
            this.ypp,
            this.xbase / this.wf.getFFTInfo().getFreq(this.xbaseidx),
            this.ybase / PublicM.getchVvValue(this.ybaseidx)
         );
   }

   @Override
   public double rateAtY() {
      return this.wf.getRateYAsAttenuation();
   }

   @Override
   public int rateAtX() {
      return 1;
   }

   @Override
   public Collection<? extends Object> xb_collect() {
      return this.fi.tb_collect();
   }

   @Override
   public Collection<? extends Object> yb_collect() {
      return this.yb_coll;
   }

   @Override
   public String getFreqBaseTxt(int zoomRate) {
      return this.fi.getFreqTxt(zoomRate, this.xbaseidx);
   }

   @Override
   public String getXBaseTxt() {
      return this.getFreqBaseTxt(this.fw.getZoomRate());
   }

   @Override
   public String getYBaseTxt() {
      return PublicM.getStrVvValue(this.ybaseidx);
   }

   @Override
   public void setBaseIdxOnX(int idx) {
      this.xbaseidx = idx;
      this.dren.setXScale(this.xbase / this.fi.getFreq(this.xbaseidx));
   }

   @Override
   public void setBaseIdxOnY(int idx) {
      this.ybaseidx = idx;
      this.dren.setAbsoluteScaleY(this.ybase / PublicM.getchVvValue(this.ybaseidx));
   }

   @Override
   public double valueAtX(double x) {
      return (x - this.dren.getZeroXLocation()) * this.timePerPix / this.dren.getXScale();
   }

   @Override
   public double valueAtY(double y) {
      return (this.dren.getZeroYLocation() - y) * this.voltPerPix / this.dren.getAbsoluteScaleY();
   }

   @Override
   public int baseIdxOnX() {
      return this.xbaseidx;
   }

   @Override
   public int baseIdxOnY() {
      return this.ybaseidx;
   }

   @Override
   public String unitForX(double x) {
      x /= (double)this.fi.getZoomRate();
      return UnitConversionUtil.getFrequencyLabel_Hz(x);
   }

   @Override
   public String unitForY(double y) {
      return UnitConversionUtil.getVoltageLabel_V(y);
   }

   @Override
   public Collection<TxtEntry> txts_coll() {
      return this.wf.getArgTxts();
   }
}
