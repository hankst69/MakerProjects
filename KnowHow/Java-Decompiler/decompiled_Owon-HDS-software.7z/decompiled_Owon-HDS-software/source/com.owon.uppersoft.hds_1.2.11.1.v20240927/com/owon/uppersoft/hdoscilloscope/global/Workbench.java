package com.owon.uppersoft.hdoscilloscope.global;

import com.owon.uppersoft.common.aspect.RunRoutine;
import com.owon.uppersoft.hdoscilloscope.frame.MainFrame;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.util.SplashscreenUtil;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;

public class Workbench implements RunRoutine {
   private SplashscreenUtil splashscreen;
   private boolean show;
   private MainFrame window;
   private Display display = Platform.getPlatform().getDisplay();

   public void launch() {
      this.show = Platform.getPlatform().getConfiguration().showSplashscreen;

      try {
         this.before();
         this.run();
         this.after();
      } catch (Exception var5) {
         ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
         String errDefault = bundle.getString("Err.Default");
         String msg = bundle.getString("Err.Unknown");
         MessageDialog.openError(this.display.getActiveShell(), errDefault, msg + var5.getMessage());
         var5.printStackTrace();
      }
   }

   public void before() {
      if (this.show) {
         this.splashscreen = new SplashscreenUtil(this.display);
         this.splashscreen.show();
      }
   }

   public void run() {
      this.window = new MainFrame(this.display);
   }

   public void after() {
      if (this.show) {
         this.splashscreen.close();
      }

      this.window.open();
   }
}
