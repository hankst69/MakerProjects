package com.owon.uppersoft.hdoscilloscope.model.detail;

public class ModelBean {
   private double xGraticuleNum;
   private int xBlockPixels;
   private int yBlockPixels;
   private int yGraticuleNum;
   private int chLen;
   private int xbaseIndex;
   private int ybaseIndex;
   private int maxBit;

   public ModelBean(String s) {
      String[] ss = s.split(",");
      if (ss.length != 8) {
         this.baseSet();
      } else {
         this.xbaseIndex = Integer.parseInt(ss[0].trim());
         this.ybaseIndex = Integer.parseInt(ss[1].trim());
         this.chLen = Integer.parseInt(ss[2].trim());
         this.maxBit = Integer.parseInt(ss[3].trim());
         this.xBlockPixels = Integer.parseInt(ss[4].trim());
         this.yBlockPixels = Integer.parseInt(ss[5].trim());
         this.xGraticuleNum = Double.parseDouble(ss[6].trim());
         this.yGraticuleNum = Integer.parseInt(ss[7].trim());
      }
   }

   private void baseSet() {
      this.xbaseIndex = 0;
      this.ybaseIndex = 0;
      this.maxBit = 12;
      this.xGraticuleNum = 15.2;
      this.xBlockPixels = 50;
      this.yBlockPixels = 50;
      this.yGraticuleNum = 10;
      this.chLen = 2;
   }

   public double getxGraticuleNum() {
      return this.xGraticuleNum;
   }

   public void setxGraticuleNum(double xGraticuleNum) {
      this.xGraticuleNum = xGraticuleNum;
   }

   public int getxBlockPixels() {
      return this.xBlockPixels;
   }

   public void setxBlockPixels(int xBlockPixels) {
      this.xBlockPixels = xBlockPixels;
   }

   public int getyBlockPixels() {
      return this.yBlockPixels;
   }

   public void setyBlockPixels(int yBlockPixels) {
      this.yBlockPixels = yBlockPixels;
   }

   public int getyGraticuleNum() {
      return this.yGraticuleNum;
   }

   public void setyGraticuleNum(int yGraticuleNum) {
      this.yGraticuleNum = yGraticuleNum;
   }

   public int getChLen() {
      return this.chLen;
   }

   public void setChLen(int chLen) {
      this.chLen = chLen;
   }

   public int getXbaseIndex() {
      return this.xbaseIndex;
   }

   public void setXbaseIndex(int xbaseIndex) {
      this.xbaseIndex = xbaseIndex;
   }

   public int getYbaseIndex() {
      return this.ybaseIndex;
   }

   public void setYbaseIndex(int ybaseIndex) {
      this.ybaseIndex = ybaseIndex;
   }

   public int getMaxBit() {
      return this.maxBit;
   }

   public void setMaxBit(int maxBit) {
      this.maxBit = maxBit;
   }
}
