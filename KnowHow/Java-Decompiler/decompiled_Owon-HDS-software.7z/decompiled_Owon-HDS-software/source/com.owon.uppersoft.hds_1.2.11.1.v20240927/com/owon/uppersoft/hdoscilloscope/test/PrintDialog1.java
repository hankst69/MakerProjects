package com.owon.uppersoft.hdoscilloscope.test;

import org.eclipse.swt.printing.PrintDialog;
import org.eclipse.swt.printing.Printer;
import org.eclipse.swt.printing.PrinterData;
import org.eclipse.swt.widgets.Shell;

public class PrintDialog1 {
   public static void main(String[] args) {
      Shell shell = new Shell();
      PrintDialog dlg = new PrintDialog(shell);
      PrinterData printerData = dlg.open();
      if (printerData != null) {
         Printer printer = new Printer(printerData);
         System.out.println(printer.getBounds());
         System.out.println(printer.getClientArea());
         System.out.println(printer.computeTrim(0, 0, 0, 0));
      }
   }
}
