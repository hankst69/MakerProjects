package com.owon.uppersoft.hdoscilloscope.data;

import com.owon.uppersoft.common.utils.StringPool;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.util.SimpleStringFormatter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class DefaultDataOutput implements IDataOutput {
   @Override
   public boolean outText(final List<WaveForm> list, DataTableDialog dtd, final File file, WaveFormFile wff) {
      final boolean sequence = dtd.isSequenceSelected();
      ProgressBarDialog pbd = new ProgressBarDialog() {
         @Override
         protected void execute() {
            int rowCount = 0;

            for (WaveForm wf : list) {
               rowCount = Math.max(wf.getIntADCollectionNum(), rowCount);
            }

            file.delete();
            SimpleStringFormatter ssf = new SimpleStringFormatter();

            try {
               FileWriter fw = new FileWriter(file);
               String ln = StringPool.LINE_SEPARATOR;
               if (sequence) {
                  fw.append(ssf.emptyblock);
               }

               for (WaveForm wf : list) {
                  fw.append(ssf.valueToStringOnRight(wf.getStrChannelTypeWithUnit()));
               }

               fw.append(ln);
               ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle();
               int alen = list.get(0).getArgTxts().size();

               for (int j = 0; j < alen; j++) {
                  int k = 0;

                  for (WaveForm wf : list) {
                     List<TxtEntry> tes = wf.getArgTxts();
                     TxtEntry tej = tes.get(j);
                     if (!tej.common) {
                        tej.localize(rb);
                        if (k == 0) {
                           fw.append(ssf.valueToStringOnLeft(tej.n));
                           k++;
                        }

                        fw.append(ssf.valueToStringOnRight(tej.v));
                        k++;
                     }
                  }

                  fw.append(ln);
               }

               int util = rowCount / 100;
               this.setProgressMaximum(100);

               for (int i = 0; i < rowCount; i++) {
                  if (this.isCancel()) {
                     fw.close();
                     return;
                  }

                  if (sequence) {
                     fw.append(ssf.valueToStringOnLeft(i + 1));
                  }

                  for (WaveForm wfx : list) {
                     if (wfx != null && wfx.getIntADCollectionNum() - 1 >= i) {
                        String ss = String.format("%.3f", wfx.voltAt(i));
                        fw.append(ssf.valueToStringOnRight(ss));
                     } else {
                        fw.append(ssf.emptyblock);
                     }
                  }

                  fw.append(ln);
                  if (i % util == 0) {
                     this.addProgressValue(1);
                  }
               }

               fw.flush();
               fw.close();
            } catch (IOException var13) {
               var13.printStackTrace();
            }
         }
      };
      pbd.open();
      return pbd.isFinished();
   }

   @Override
   public boolean outXLS(List<WaveForm> list, DataTableDialog dtd, File out, WaveFormFile wff) {
      return dtd.getWff().containMemDepth() ? this.outXLSCurrentPage(list, dtd, out, wff) : this.outXLSAllPages(list, dtd, out, wff);
   }

   public boolean outXLSAllPages(final List<WaveForm> list, DataTableDialog dtd, final File out, WaveFormFile wff) {
      final boolean sequence = dtd.isSequenceSelected();
      ProgressBarDialog pbd = new ProgressBarDialog() {
         @Override
         protected void execute() {
            int allRowCount = 0;
            int everySheetCount = 5000;

            for (WaveForm wf : list) {
               allRowCount = Math.max(wf.getIntADCollectionNum(), allRowCount);
            }

            int lastSheetPage = allRowCount % everySheetCount;
            int allSheetPage = allRowCount / everySheetCount;
            if (lastSheetPage != 0) {
               allSheetPage++;
            }

            out.delete();

            try {
               WritableWorkbook wwb = Workbook.createWorkbook(out);
               WritableSheet ws = null;
               this.setProgressMaximum(allSheetPage);

               for (int currentSheetPage = allSheetPage; currentSheetPage > 0; currentSheetPage--) {
                  ws = wwb.createSheet("Sheet" + currentSheetPage, 0);
                  int rowIdx = 0;
                  int length = 0;
                  length = everySheetCount;
                  if (currentSheetPage == allSheetPage && lastSheetPage != 0) {
                     length = lastSheetPage;
                  }

                  int chlRow = rowIdx++;
                  ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle();
                  int baseRow = rowIdx;
                  int alen = list.get(0).getArgTxts().size();

                  for (int j = 0; j < alen; j++) {
                     int k = 0;

                     for (WaveForm wf : list) {
                        List<TxtEntry> tes = wf.getArgTxts();
                        TxtEntry tej = tes.get(j);
                        if (!tej.common) {
                           tej.localize(rb);
                           if (k == 0) {
                              Label label = new Label(k, j + baseRow, tej.n);
                              ws.addCell(label);
                              k++;
                           }

                           Label label = new Label(k, j + baseRow, tej.v);
                           ws.addCell(label);
                           k++;
                        }
                     }
                  }

                  rowIdx += alen;
                  int dataRow = rowIdx;
                  if (sequence) {
                     int index = (currentSheetPage - 1) * everySheetCount + 1;
                     int end = rowIdx + length;

                     for (int row = rowIdx; row < end; index++) {
                        Number labelN = new Number(0, row, (double)index);
                        ws.addCell(labelN);
                        row++;
                     }
                  }

                  int channelsOrder = 1;

                  for (WaveForm wfx : list) {
                     if (this.isCancel()) {
                        wwb.close();
                        return;
                     }

                     if (wfx != null) {
                        String name = wfx.getStrChannelType();
                        Label label = new Label(channelsOrder, chlRow, name);
                        ws.addCell(label);
                        int index = (currentSheetPage - 1) * everySheetCount;
                        int end = dataRow + length;

                        for (int row = dataRow; row < end; index++) {
                           Number labelN = new Number(channelsOrder, row, wfx.voltAt(index));
                           ws.addCell(labelN);
                           row++;
                        }

                        channelsOrder++;
                     }
                  }

                  this.addProgressValue(1);
               }

               wwb.write();
               wwb.close();
            } catch (RowsExceededException var24) {
               Logger.getLogger(DataTableDialog.class.getName()).log(Level.SEVERE, null, var24);
            } catch (WriteException var25) {
               Logger.getLogger(DataTableDialog.class.getName()).log(Level.SEVERE, null, var25);
            } catch (IOException var26) {
               Logger.getLogger(DataTableDialog.class.getName()).log(Level.SEVERE, null, var26);
            }
         }
      };
      pbd.open();
      return pbd.isFinished();
   }

   public boolean outXLSCurrentPage(final List<WaveForm> list, final DataTableDialog dtd, final File out, WaveFormFile wff) {
      final boolean sequence = dtd.isSequenceSelected();
      ProgressBarDialog pbd = new ProgressBarDialog() {
         @Override
         protected void execute() {
            int allRowCount = 0;
            int everySheetCount = 5000;

            for (WaveForm wf : list) {
               allRowCount = Math.max(wf.getIntADCollectionNum(), allRowCount);
            }

            int lastSheetPage = allRowCount % everySheetCount;
            int allSheetPage = allRowCount / everySheetCount;
            if (lastSheetPage != 0) {
               allSheetPage++;
            }

            out.delete();

            try {
               WritableWorkbook wwb = Workbook.createWorkbook(out);
               WritableSheet ws = null;
               int currentSheetPage = dtd.getCurrentPage();
               ws = wwb.createSheet("Sheet" + currentSheetPage, 0);
               int rowIdx = 0;
               int chlRow = rowIdx++;
               ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle();
               int alen = list.get(0).getArgTxts().size();
               int baseRow = rowIdx;

               for (int j = 0; j < alen; j++) {
                  int k = 0;

                  for (WaveForm wf : list) {
                     List<TxtEntry> tes = wf.getArgTxts();
                     TxtEntry tej = tes.get(j);
                     if (!tej.common) {
                        tej.localize(rb);
                        if (k == 0) {
                           Label label = new Label(k, j + baseRow, tej.n);
                           ws.addCell(label);
                           k++;
                        }

                        Label label = new Label(k, j + baseRow, tej.v);
                        ws.addCell(label);
                        k++;
                     }
                  }
               }

               rowIdx += alen;
               int dataRow = rowIdx;
               int length = 0;
               length = everySheetCount;
               if (currentSheetPage == allSheetPage && lastSheetPage != 0) {
                  length = lastSheetPage;
               }

               if (sequence) {
                  int index = (currentSheetPage - 1) * everySheetCount + 1;
                  int end = rowIdx + length;

                  for (int row = rowIdx; row < end; index++) {
                     Number labelN = new Number(0, row, (double)index);
                     ws.addCell(labelN);
                     row++;
                  }
               }

               this.setProgressMaximum(list.size());
               int channelsOrder = 1;

               for (WaveForm wfx : list) {
                  if (this.isCancel()) {
                     wwb.close();
                     return;
                  }

                  if (wfx != null) {
                     String name = wfx.getStrChannelTypeWithUnit();
                     Label label = new Label(channelsOrder, chlRow, name);
                     ws.addCell(label);
                     int index = (currentSheetPage - 1) * everySheetCount;
                     int end = dataRow + length;

                     for (int row = dataRow; row < end; index++) {
                        Number labelN = new Number(channelsOrder, row, wfx.voltAt(index));
                        ws.addCell(labelN);
                        row++;
                     }

                     channelsOrder++;
                     this.addProgressValue(1);
                  }
               }

               wwb.write();
               wwb.close();
            } catch (RowsExceededException var24) {
               Logger.getLogger(DataTableDialog.class.getName()).log(Level.SEVERE, null, var24);
            } catch (WriteException var25) {
               Logger.getLogger(DataTableDialog.class.getName()).log(Level.SEVERE, null, var25);
            } catch (IOException var26) {
               Logger.getLogger(DataTableDialog.class.getName()).log(Level.SEVERE, null, var26);
            }
         }
      };
      pbd.open();
      return pbd.isFinished();
   }

   @Override
   public boolean outCSV(final List<WaveForm> list, DataTableDialog dtd, final File out, WaveFormFile wff) {
      final boolean sequence = dtd.isSequenceSelected();
      ProgressBarDialog pbd = new ProgressBarDialog() {
         @Override
         protected void execute() {
            int rowCount = 0;

            for (WaveForm wf : list) {
               System.out.println(wf.getIntADCollectionNum() + ",,,,,,sdfsdfs");
               rowCount = Math.max(wf.getIntADCollectionNum(), rowCount);
            }

            out.delete();

            try {
               FileWriter fw = new FileWriter(out);

               for (WaveForm wf : list) {
                  fw.append("," + wf.getStrChannelTypeWithUnit());
               }

               fw.append("\r\n");
               ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle();
               int alen = list.get(0).getArgTxts().size();

               for (int j = 0; j < alen; j++) {
                  int k = 0;

                  for (WaveForm wf : list) {
                     List<TxtEntry> tes = wf.getArgTxts();
                     TxtEntry tej = tes.get(j);
                     if (!tej.common) {
                        tej.localize(rb);
                        if (k == 0) {
                           fw.append(tej.n);
                           k++;
                        }

                        fw.append(",");
                        fw.append(tej.v);
                        k++;
                     }
                  }

                  fw.append("\r\n");
               }

               int util = rowCount / 100;
               this.setProgressMaximum(100);

               for (int i = 0; i < rowCount; i++) {
                  if (this.isCancel()) {
                     fw.close();
                     return;
                  }

                  if (sequence) {
                     fw.append(String.valueOf(i + 1));
                  }

                  for (WaveForm wfx : list) {
                     if (wfx != null && wfx.getIntADCollectionNum() - 1 >= i) {
                        String ss = String.format("%.3f", wfx.voltAt(i));
                        fw.append("," + ss);
                     } else {
                        fw.append(",");
                     }
                  }

                  fw.append("\r\n");
                  if (i % util == 0) {
                     this.addProgressValue(1);
                  }
               }

               fw.flush();
               fw.close();
            } catch (IOException var11) {
               var11.printStackTrace();
            }
         }
      };
      pbd.open();
      return pbd.isFinished();
   }
}
