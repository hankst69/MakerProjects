package com.owon.uppersoft.hdoscilloscope.manipulate;

import com.owon.uppersoft.hdoscilloscope.communication.loop.JobUnit;
import com.owon.uppersoft.hdoscilloscope.communication.loop.LoopControl;
import com.owon.uppersoft.hdoscilloscope.custom.RB2Lobject;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.manipulate.control.ChannelControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.control.FFTControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.control.SampleControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.control.TimeControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.trg.TrgControl;
import com.owon.uppersoft.hdoscilloscope.model.MachineFactory;
import com.owon.uppersoft.hdoscilloscope.model.MachineType;
import com.owon.uppersoft.hdoscilloscope.model.detail.Idn;
import java.text.MessageFormat;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

public class ManipulateControl {
   public static final String[] SWITCH = new String[]{"ON", "OFF"};
   public static final String[] CHANNELSCOUPLING = new String[]{"DC", "AC", "Gnd"};
   public static final String[] COUPLING = new String[]{"DC", "AC"};
   public static final RB2Lobject[] SamplingMode = new RB2Lobject[]{new RB2Lobject("M.Sample.Name"), new RB2Lobject("M.Sample.PKdetect")};
   public static final String[] SAMPLING = new String[]{"sample", "peak"};
   public static final String[] DEEPS = new String[]{"4k", "8k"};
   public static final String[] CHANNELS = new String[]{"CH1", "CH2", "CH3", "CH4"};
   public static final String[] PROBES = new String[]{"1X", "10X", "100X", "1000X", "10000X"};
   public static final String[] SampleTimes = new String[]{"4", "16", "64", "128"};
   public static final String[] VOL_UNITS = new String[]{"uv", "mv", "v", "kv"};
   public static final String[] TIME_UNITS = new String[]{"ns", "us", "ms", "s"};
   public static final String[] SIGNS = new String[]{">", "=", "<"};
   public final String[] uFreq = new String[]{"MHz", "kHz", "Hz", "mHz", "uHz"};
   public final String[] uAmp = new String[]{"mVpp", "Vpp", "mVrms", "Vrms"};
   public final String[] uOffset = new String[]{"mV", "V"};
   public final String[] uPercent = new String[]{"%"};
   public final String[] uTime = new String[]{"nsec", "usec", "msec", "sec", "Ksec"};
   public final String[] uSource = new String[]{"Internal", "External", "Manual"};
   public final String[] uModType = new String[]{"AM", "FM", "PM", "FSK", "PWM"};
   public final String[] uModShape = new String[]{"Sine", "Square", "Ramp", "Noise", "Arb"};
   public final String[] uDegree = new String[]{"Degree"};
   public final String[] uCycle = new String[]{"Ncycle", "Gate"};
   public final String[] uPolarity = new String[]{"Positive", "Negative"};
   public final String[] uBuiltin = new String[]{
      "StairD",
      "StairU",
      "StairUD",
      "Trapezia",
      "RoundHalf",
      "AbsSine",
      "AbsSineHalf",
      "SineTra",
      "SineVer",
      "ExpRise",
      "ExpFall",
      "Sinc",
      "Tan",
      "Cot",
      "Sqrt",
      "x^2",
      "Rectangle",
      "Gauss",
      "Hamming",
      "Hann",
      "Bartlett",
      "Blackman",
      "Laylight",
      "DC",
      "Heart",
      "Round"
   };
   public final String[] uCycles = new String[]{"Cyc", "Infinite"};
   public boolean hasMM = false;
   public boolean hasUE = true;
   public ChannelControl cc;
   public FFTControl fc;
   public TrgControl tc;
   public LoopControl lc;
   public SampleControl sc;
   public TimeControl tic;
   public MachineType mt;
   public int pixelsPerBlock;
   public Platform pf;

   public static final String[] toStrings(Object[] los) {
      String[] sts = new String[los.length];

      for (int i = 0; i < sts.length; i++) {
         sts[i] = los[i].toString();
      }

      return sts;
   }

   public static final String[] toStrings(List li) {
      String[] sts = new String[li.size()];
      int i = 0;

      for (Object o : li) {
         sts[i] = o.toString();
         i++;
      }

      return sts;
   }

   public ManipulateControl(LoopControl lc, Idn idn) {
      this.lc = lc;
      this.pf = Platform.getPlatform();
      this.mt = MachineFactory.getMachinetype(idn);
      this.pixelsPerBlock = 25;
      this.tc = new TrgControl(this.mt.getChLen());
      this.fc = new FFTControl();
      this.cc = new ChannelControl(this.mt.getChLen());
      this.sc = new SampleControl();
      this.tic = new TimeControl();
   }

   public void send(String s) {
      System.out.println(s);
      this.send(new JobUnit(s));
   }

   public void send(JobUnit p) {
      boolean b = this.lc.isKeepOn();
      if (b) {
         this.lc.addJobUnit(p);
      } else {
         this.lc.activeSend(p);
      }
   }

   public LoopControl getLoopControl() {
      return this.lc;
   }

   public void askstop() {
      Platform.getPlatform().getActionFactory().loopControl.stopLoop();
   }

   public void alert(String s, Object[] obj) {
      ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle2();
      Shell sh = Platform.getPlatform().getMainFrame().getShell();
      String format = MessageFormat.format(rb.getString(s), obj);
      MessageDialog dialog = new MessageDialog(sh, "", null, format, 1, new String[]{"OK"}, 0);
      dialog.open();
   }
}
