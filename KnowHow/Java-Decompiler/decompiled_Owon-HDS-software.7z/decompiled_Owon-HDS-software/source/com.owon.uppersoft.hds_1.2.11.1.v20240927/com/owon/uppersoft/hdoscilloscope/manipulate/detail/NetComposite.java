package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.MessageErrRunner;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import java.util.ResourceBundle;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class NetComposite extends Composite implements Localizable2 {
   private Text text;
   private Text txtIP;
   private Text txtPort;
   private Text txtsm;
   private Text txtgw;
   private Label iplbl;
   private Label smlbl;
   private Label gwlbl;
   private ManipulateControl mc;
   private Shell shell;
   public static final int port_max = 4000;
   public static final int LEN = 4;
   private FocusAdapter fa = new FocusAdapter() {
      public void focusLost(FocusEvent e) {
         Text txt = (Text)e.widget;
         String p = txt.getText();
         String m = "^(22[0-3]|2[0-1]\\d|1\\d{2}|[1-9]\\d|[1-9])\\.(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)\\.(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)\\.(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)$";
         if (!p.matches(m)) {
            MessageErrRunner mer = ResourceBundleProvider.getMessageErrRunner();
            mer.setInfo("Err.BadIp", 1, NetComposite.this.shell);
            System.out.println(txt.setFocus());
         }
      }
   };
   private Label labPort;
   private Button setbtn;
   private Button rebootbtn;
   private Text rblbl;
   private Label buglbl;

   public NetComposite(Composite parent, final ManipulateControl mc) {
      super(parent, 0);
      this.mc = mc;
      this.shell = parent.getShell();
      GridLayout gridLayout = new GridLayout();
      gridLayout.marginWidth = 10;
      gridLayout.marginHeight = 10;
      gridLayout.numColumns = 4;
      this.setLayout(gridLayout);
      this.text = new Text(this, 72);
      GridData gd_text = new GridData(4, 4, true, false, 4, 2);
      gd_text.widthHint = 300;
      gd_text.heightHint = 40;
      this.text.setLayoutData(gd_text);
      this.iplbl = this.createLabel(this);
      this.txtIP = this.createIPModeText(this, this.shell, "192.168.1.80");
      this.labPort = new Label(this, 0);
      this.labPort.setLayoutData(new GridData());
      Composite c = new Composite(this, 0);
      GridLayout gridLayout_1 = new GridLayout();
      gridLayout_1.marginWidth = 0;
      gridLayout_1.numColumns = 2;
      c.setLayout(gridLayout_1);
      this.txtPort = new Text(c, 2048);
      this.txtPort.setText(String.valueOf(3000));
      this.txtPort.addKeyListener(new KeyAdapter() {
         public void keyPressed(KeyEvent e) {
            if ("0123456789".indexOf(e.character) < 0) {
               if (e.keyCode == 8 || e.keyCode == 127) {
                  return;
               }

               e.doit = false;
            }
         }
      });
      GridData gd_tp = new GridData(1, 16777216, false, false);
      gd_tp.widthHint = 40;
      this.txtPort.setLayoutData(gd_tp);
      Label l1 = new Label(c, 0);
      l1.setText("(0~4000)");
      GridData gd_l1 = new GridData(4, 16777216, false, false);
      l1.setLayoutData(gd_l1);
      GridData gd_txtPort = new GridData(4, 16777216, false, false);
      c.setLayoutData(gd_txtPort);
      this.gwlbl = this.createLabel(this);
      this.txtgw = this.createIPModeText(this, this.shell, "192.168.1.1");
      this.smlbl = this.createLabel(this);
      this.txtsm = this.createIPModeText(this, this.shell, "255.255.255.0");
      this.setbtn = new Button(this, 0);
      GridData gd_button = new GridData(16384, 16777216, false, false, 1, 1);
      gd_button.widthHint = 120;
      this.setbtn.setLayoutData(gd_button);
      this.setbtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            mc.pf.getConfiguration().address = NetComposite.this.txtIP.getText() + ":" + NetComposite.this.txtPort.getText();
            NetComposite.this.sendSET();
         }
      });
      this.rebootbtn = new Button(this, 0);
      GridData gd_button_1 = new GridData(16384, 16777216, false, false, 3, 1);
      gd_button_1.widthHint = 120;
      this.rebootbtn.setLayoutData(gd_button_1);
      this.rebootbtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            NetComposite.this.sendREBOOT();
         }
      });
      this.rblbl = new Text(this, 72);
      GridData gdl = new GridData(4, 4, true, false, 4, 2);
      gdl.widthHint = 300;
      gdl.heightHint = 50;
      this.rblbl.setLayoutData(gdl);
      this.rblbl.setVisible(false);
      this.buglbl = new Label(this, 0);
      this.buglbl.setLayoutData(new GridData(4, 16777216, false, false, 4, 1));
      this.buglbl.setVisible(false);
   }

   public void localize(ResourceBundle rb) {
      this.text.setText(rb.getString("CMD.prompt"));
      this.labPort.setText(rb.getString("CMD.portset"));
      this.iplbl.setText(rb.getString("CMD.ipset"));
      this.gwlbl.setText(rb.getString("CMD.gatewayset"));
      this.smlbl.setText(rb.getString("CMD.submaskset"));
      this.setbtn.setText(rb.getString("CMD.setNet"));
      this.rebootbtn.setText(rb.getString("CMD.reboot"));
      this.rblbl.setText(rb.getString("CMD.rebootprompt"));
   }

   private void logUSB(String d) {
      String sn = Platform.getPlatform().getConfiguration().iDevice.getSerialNumber();
      boolean b = this.mc.getLoopControl().isKeepOn();
      this.buglbl.setText(d + (b ? " on" : " off_" + sn));
   }

   private void sendREBOOT() {
   }

   private void sendSET() {
      getAddress(this.txtIP.getText());
      getAddress(this.txtsm.getText());
      getAddress(this.txtgw.getText());
      int v = 0;

      try {
         v = Integer.valueOf(this.txtPort.getText());
      } catch (NumberFormatException var3) {
         var3.printStackTrace();
      }

      if (v > 4000) {
         int var4 = 4000;
         this.txtPort.setText("" + var4);
      } else if (v < 0) {
         int var5 = 0;
         this.txtPort.setText("" + var5);
      }
   }

   public static final byte[] getAddress(String txt) {
      int len = 4;
      byte[] a = new byte[len];
      String[] ss = txt.split("\\.");
      len = ss.length;

      try {
         for (int i = 0; i < len; i++) {
            a[i] = (byte)Integer.parseInt(ss[i]);
         }
      } catch (NumberFormatException var5) {
         var5.printStackTrace();
      }

      for (int i = len; i < 4; i++) {
         a[i] = 1;
      }

      return a;
   }

   private Label createLabel(Composite parent) {
      Label lbl = new Label(parent, 0);
      GridData gd = new GridData(4, 16777216, false, false);
      gd.widthHint = 80;
      lbl.setLayoutData(gd);
      return lbl;
   }

   private Text createIPModeText(Composite parent, Shell shell, String vt) {
      Text txt = new Text(parent, 2048);
      txt.setText(vt);
      txt.addKeyListener(new KeyAdapter() {
         public void keyPressed(KeyEvent e) {
            if ("0123456789.".indexOf(e.character) < 0) {
               if (e.keyCode == 8 || e.keyCode == 127) {
                  return;
               }

               e.doit = false;
            }
         }
      });
      GridData gd_txt = new GridData(1, 16777216, false, false);
      gd_txt.widthHint = 134;
      txt.setLayoutData(gd_txt);
      return txt;
   }
}
