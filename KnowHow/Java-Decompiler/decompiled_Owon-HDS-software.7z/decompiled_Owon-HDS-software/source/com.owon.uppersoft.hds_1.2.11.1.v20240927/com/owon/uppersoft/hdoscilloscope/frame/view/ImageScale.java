package com.owon.uppersoft.hdoscilloscope.frame.view;

import com.owon.uppersoft.common.utils.DisposeUtil;
import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.ColorDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;

public class ImageScale implements PaintListener, MouseListener, MouseMoveListener, DisposeListener, ControlListener {
   private int halfH = 8;
   private WaveFormFileCurve wffc;
   private Color bgColor;
   private Font lfont;
   private Composite mainCom;
   private Point size;
   private int[] polygon = new int[10];
   private boolean showArrow = true;
   private int selectedY;
   private boolean isDown;

   public ImageScale(Composite mainCom) {
      this.mainCom = mainCom;
      Display display = mainCom.getDisplay();
      Configuration cfg = Platform.getPlatform().getConfiguration();
      this.bgColor = new Color(display, cfg.imgScalergb);
      mainCom.setBackground(this.bgColor);
      mainCom.addPaintListener(this);
      mainCom.addMouseListener(this);
      mainCom.addMouseMoveListener(this);
      mainCom.addDisposeListener(this);
      mainCom.addControlListener(this);
   }

   public void setWaveFormFileCurve(WaveFormFileCurve wffc) {
      if (wffc != null) {
         this.wffc = wffc;
         this.mainCom.redraw();
      }
   }

   public final int[] setupPolygon(int y1, int y2, int w, int halfH) {
      int[] p = this.polygon;
      p[0] = 0;
      p[1] = y1;
      p[2] = w - 8;
      p[3] = y1;
      p[4] = w;
      p[5] = y1 + halfH;
      p[6] = w - 8;
      p[7] = y2;
      p[8] = 0;
      p[9] = y2;
      return this.polygon;
   }

   public void paintControl(PaintEvent e) {
      GC gc = e.gc;
      if (this.wffc != null) {
         int s = this.wffc.getWaveformsNumber();
         WaveFormCurve curve = this.wffc.getSelectedWaveFormCurve();
         if (s > 0) {
            gc.setForeground(this.mainCom.getDisplay().getSystemColor(2));

            for (WaveFormCurve wfc : this.wffc.all_collect()) {
               if (wfc != null && wfc.isVisible() && !wfc.equals(curve)) {
                  String name = wfc.getStrChannelType();
                  int y = (int)wfc.getScalableDrawEngine().getZeroYLocation();
                  y = this.patchY(y);
                  gc.setBackground(wfc.getColor());
                  if (this.showArrow) {
                     gc.fillPolygon(this.setupPolygon(y - this.halfH, y + this.halfH, this.size.x, this.halfH));
                  } else {
                     gc.fillRectangle(0, y - this.halfH, this.size.x, this.halfH << 1);
                  }

                  gc.drawString(name, 0, y - this.halfH, true);
               }
            }

            String name = curve.getStrChannelType();
            int y = (int)curve.getScalableDrawEngine().getZeroYLocation();
            y = this.patchY(y);
            gc.setBackground(curve.getColor());
            if (this.showArrow) {
               gc.fillPolygon(this.setupPolygon(y - this.halfH, y + this.halfH, this.size.x, this.halfH));
            } else {
               gc.fillRectangle(0, y - this.halfH, this.size.x, this.halfH << 1);
            }

            Font oldFont = gc.getFont();
            if (this.lfont == null) {
               FontData fd = oldFont.getFontData()[0];
               this.lfont = new Font(this.mainCom.getDisplay(), fd.getName(), fd.getHeight(), 2);
            }

            gc.setFont(this.lfont);
            gc.drawString(name, 0, y - this.halfH, true);
            gc.setFont(oldFont);
            this.wffc.getDrawingPanel().redraw();
         }
      }
   }

   public void mouseDoubleClick(MouseEvent e) {
      this.setDown(false);
      if (e.button == 1) {
         Composite c = (Composite)e.getSource();
         ColorDialog ds = new ColorDialog(c.getShell());
         WaveFormCurve curve = this.wffc.getSelectedWaveFormCurve();
         if (curve != null) {
            int y = (int)curve.getScalableDrawEngine().getZeroYLocation();
            y = this.patchY(y);
            if (e.y >= y - this.halfH && e.y <= y + this.halfH) {
               ds.setRGB(curve.getRGB());
               RGB rgb = ds.open();
               if (rgb == null) {
                  return;
               }

               curve.setRGB(rgb);
               c.redraw();
               return;
            }
         }

         ds.setRGB(this.bgColor.getRGB());
         RGB rgb = ds.open();
         if (rgb != null) {
            DisposeUtil.tryDispose(this.bgColor);
            this.bgColor = new Color(this.mainCom.getDisplay(), rgb);
            this.mainCom.setBackground(this.bgColor);
            c.redraw();
         }
      }
   }

   protected void setDown(boolean b) {
      this.isDown = b;
   }

   public void mouseDown(MouseEvent e) {
      this.setDown(true);
      int s = this.wffc.getWaveformsNumber();
      if (s <= 0) {
         this.setDown(false);
      } else {
         WaveFormCurve curve = this.wffc.getSelectedWaveFormCurve();
         int y = (int)curve.getScalableDrawEngine().getZeroYLocation();
         y = this.patchY(y);
         if (e.y >= y - this.halfH && e.y <= y + this.halfH) {
            this.selectedY = e.y;
         } else {
            for (WaveFormCurve wfc : this.wffc.all_collect()) {
               if (wfc.isVisible() && wfc != curve) {
                  y = (int)wfc.getScalableDrawEngine().getZeroYLocation();
                  y = this.patchY(y);
                  if (e.y >= y - this.halfH && e.y <= y + this.halfH) {
                     this.selectedY = e.y;
                     Platform.getPlatform().getCenter().selectOnTable(wfc);
                     return;
                  }
               }
            }

            this.setDown(false);
         }
      }
   }

   public void mouseUp(MouseEvent e) {
      this.setDown(false);
      this.wffc.getDrawingPanel().setDragging(false);
   }

   public void mouseMove(MouseEvent e) {
      if (this.isDown) {
         WaveFormCurve curve = this.wffc.getSelectedWaveFormCurve();
         if (curve != null) {
            int offset = e.y - this.selectedY;
            ScalableDrawEngine dren = curve.getScalableDrawEngine();
            int orgY = (int)dren.getZeroYLocation();
            int newY = offset + orgY;
            newY = this.patchY(newY);
            this.selectedY = e.y;
            this.wffc.getDrawingPanel().setDragging(true);
            dren.setZeroYLocation((double)newY);
            this.mainCom.redraw();
            Center center = Platform.getPlatform().getCenter();
            center.updateMarksLocation();
            center.updateBlockInfo(curve);
         }
      }
   }

   public void redraw() {
      this.mainCom.redraw();
   }

   public void setBounds(int x, int y, int width, int height) {
      this.mainCom.setBounds(x, y, width, height);
   }

   private final int patchY(int y) {
      if (y < 0) {
         y = 0;
      }

      if (y > this.size.y) {
         y = this.size.y;
      }

      return y;
   }

   public RGB getBackgoundRGB() {
      return this.bgColor.getRGB();
   }

   public void widgetDisposed(DisposeEvent e) {
      DisposeUtil.tryDispose(this.bgColor);
      DisposeUtil.tryDispose(this.lfont);
   }

   public void controlMoved(ControlEvent e) {
   }

   public void controlResized(ControlEvent e) {
      this.size = this.mainCom.getSize();
   }
}
