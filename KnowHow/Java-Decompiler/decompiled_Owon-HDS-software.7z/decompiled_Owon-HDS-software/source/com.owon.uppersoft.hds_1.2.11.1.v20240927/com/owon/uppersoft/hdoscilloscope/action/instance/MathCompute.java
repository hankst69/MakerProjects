package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.frame.MainFrame;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class MathCompute extends DefaultAction {
   public MathCompute(String id) {
      super(id);
   }

   public void run() {
      MainFrame mf = Platform.getPlatform().getMainFrame();
      mf.getShell();
   }
}
