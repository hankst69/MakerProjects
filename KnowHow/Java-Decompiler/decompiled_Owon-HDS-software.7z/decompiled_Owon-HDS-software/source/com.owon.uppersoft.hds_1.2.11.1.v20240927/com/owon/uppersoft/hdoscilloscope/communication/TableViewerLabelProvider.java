package com.owon.uppersoft.hdoscilloscope.communication;

import net.sf.json.JSONObject;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;

class TableViewerLabelProvider implements ITableLabelProvider {
   public String getColumnText(Object element, int column) {
      JSONObject jo = (JSONObject)element;
      switch (column) {
         case 0:
            return jo.getString("index");
         case 1:
            return jo.getString("wave_character");
         case 2:
            return jo.getString("display_switch");
         default:
            return "";
      }
   }

   public void addListener(ILabelProviderListener arg0) {
   }

   public void dispose() {
   }

   public boolean isLabelProperty(Object arg0, String arg1) {
      return false;
   }

   public void removeListener(ILabelProviderListener arg0) {
   }

   public Image getColumnImage(Object arg0, int arg1) {
      return null;
   }
}
