package com.owon.uppersoft.hdoscilloscope.manipulate.control;

import com.owon.uppersoft.hdoscilloscope.manipulate.IPack;
import java.nio.ByteBuffer;

public class TimeControl implements IPack {
   public int dmidx;
   public int tbidx;
   public int horpos;

   @Override
   public void pack(ByteBuffer bb) {
      this.packhp(bb);
      this.packdm(bb);
      this.packtb(bb);
   }

   public void packhp(ByteBuffer bb) {
      bb.put("MHR".getBytes());
      bb.put((byte)118);
      bb.putInt(this.horpos);
   }

   public void packtb(ByteBuffer bb) {
      bb.put("MHR".getBytes());
      bb.put((byte)98);
      bb.put((byte)this.tbidx);
   }

   public void packdm(ByteBuffer bb) {
      bb.put("MDP".getBytes());
      bb.put((byte)this.dmidx);
   }
}
