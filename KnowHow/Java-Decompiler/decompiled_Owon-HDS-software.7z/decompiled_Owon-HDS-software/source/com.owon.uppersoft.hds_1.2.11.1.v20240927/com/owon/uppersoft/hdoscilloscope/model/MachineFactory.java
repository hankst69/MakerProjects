package com.owon.uppersoft.hdoscilloscope.model;

import com.owon.uppersoft.hdoscilloscope.model.detail.Idn;

public class MachineFactory {
   public static MachineType getMachinetype(Idn idn) {
      return new MachineType(idn);
   }
}
