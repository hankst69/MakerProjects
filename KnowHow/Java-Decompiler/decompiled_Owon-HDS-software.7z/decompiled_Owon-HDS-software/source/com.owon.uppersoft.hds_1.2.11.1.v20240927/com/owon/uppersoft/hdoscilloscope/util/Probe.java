package com.owon.uppersoft.hdoscilloscope.util;

public class Probe {
   private String s;
   private int i;

   public static void main(String[] args) {
   }

   public Probe(String s) {
      this.s = s;
      this.i = Integer.parseInt(s.substring(1));
   }

   public Probe(int i) {
      this.i = i;
      this.s = "X" + i;
   }

   public String getS() {
      return this.s;
   }

   public int getI() {
      return this.i;
   }
}
