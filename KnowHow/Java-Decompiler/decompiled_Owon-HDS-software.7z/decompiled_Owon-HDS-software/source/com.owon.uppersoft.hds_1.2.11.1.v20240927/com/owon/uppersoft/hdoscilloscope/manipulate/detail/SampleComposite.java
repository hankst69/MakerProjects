package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.control.SampleControl;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

public class SampleComposite extends Composite implements SelectionListener, Localizable2 {
   private SampleControl sc;
   private ManipulateControl mc;
   private boolean use = false;
   private Combo spltypecbb;
   private Combo timescbb;
   private Label timeslbl;

   public SampleComposite(Composite parent, ManipulateControl mc, SampleControl sc) {
      super(parent, 0);
      this.sc = sc;
      this.mc = mc;
      GridLayout gridLayout = new GridLayout();
      gridLayout.marginHeight = 10;
      gridLayout.marginWidth = 10;
      gridLayout.numColumns = 3;
      this.setLayout(gridLayout);
      this.spltypecbb = new Combo(this, 8);
      this.spltypecbb.setLayoutData(new GridData(80, -1));
      this.timeslbl = new Label(this, 131072);
      this.timeslbl.setLayoutData(new GridData(60, -1));
      this.timeslbl.setVisible(false);
      this.timescbb = new Combo(this, 8);
      this.timescbb.setVisible(false);
      this.custom();
      this.use = true;
   }

   void custom() {
      this.timescbb.setItems(ManipulateControl.SampleTimes);
      this.spltypecbb.setItems(ManipulateControl.toStrings(ManipulateControl.SamplingMode));
      this.timescbb.select(this.sc.times);
      int idx = this.sc.type;
      this.spltypecbb.select(idx);
      this.timescbb.setEnabled(idx == 2);
      this.spltypecbb.addSelectionListener(this);
      this.timescbb.addSelectionListener(this);
   }

   public void widgetDefaultSelected(SelectionEvent e) {
   }

   public void widgetSelected(SelectionEvent e) {
      Object o = e.getSource();
      if (o == this.spltypecbb) {
         int idx = this.sc.type = this.spltypecbb.getSelectionIndex();
         this.timescbb.setEnabled(idx == 2);
         String cmd = ":ACQUire:Mode " + ManipulateControl.SAMPLING[idx];
         this.mc.send(cmd);
      } else if (o == this.timescbb) {
         this.sc.times = this.timescbb.getSelectionIndex();
         String cmd = ":ACQUire:average:num " + ManipulateControl.SampleTimes[this.sc.times];
         this.mc.send(cmd);
      }
   }

   public void localize(ResourceBundle rb) {
      this.use = false;
      this.timeslbl.setText(rb.getString("M.Sample.times") + ":");
      int idx = this.spltypecbb.getSelectionIndex();
      this.spltypecbb.setItems(ManipulateControl.toStrings(ManipulateControl.SamplingMode));
      this.spltypecbb.select(idx);
      this.use = true;
   }
}
