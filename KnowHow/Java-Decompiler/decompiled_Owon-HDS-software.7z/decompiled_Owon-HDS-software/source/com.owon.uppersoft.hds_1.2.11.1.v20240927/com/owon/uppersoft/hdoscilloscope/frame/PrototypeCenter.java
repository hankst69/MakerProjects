package com.owon.uppersoft.hdoscilloscope.frame;

import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Scale;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;

public class PrototypeCenter {
   private Text text;
   protected CheckboxTableViewer ctv;
   protected Scale rs;
   protected Table table;
   protected Label vbTypleLabel;
   protected Label tbTypeLabel;
   protected Label numvLabel;
   protected Label numrangeLabel;
   protected Label x2vLabel;
   protected Label x1vLabel;
   protected Label dxvLabel;
   protected Label y2vLabel;
   protected Label y1vLabel;
   protected Label dyvLabel;
   protected Label cursorTypeLabel;
   protected Label numLabel;
   protected Label x2Label;
   protected Label x1Label;
   protected Label dxLabel;
   protected Label y2Label;
   protected Label y1Label;
   protected Label dyLabel;
   protected Group volbaseGroup;
   protected Group timebaseGroup;
   protected Group cursorGroup;
   protected Combo cursorCombo;
   protected Combo timebaseCombo;
   protected Combo volbaseCombo;
   protected SashForm mainSash;
   protected SashForm downSash;
   protected Group infogroup;
   protected Composite canvas;
   protected Composite imgCom;
   protected Composite wftool;
   protected ToolComposite tool_com;
   protected Composite mainCom;
   protected SashForm upSash;

   public PrototypeCenter(Composite parent) {
      this.mainCom = new Composite(parent, 0);
      this.mainCom.setLayout(new FillLayout());
      this.mainSash = new SashForm(this.mainCom, 512);
      this.createContent();
   }

   protected void createContent() {
      this.upSash = new SashForm(this.mainSash, 256);
      Composite chartCom = new Composite(this.upSash, 0);
      GridLayout gridLayout_6 = new GridLayout();
      gridLayout_6.verticalSpacing = 0;
      gridLayout_6.marginHeight = 0;
      gridLayout_6.horizontalSpacing = 0;
      gridLayout_6.marginWidth = 0;
      gridLayout_6.numColumns = 4;
      chartCom.setLayout(gridLayout_6);
      this.imgCom = new Composite(chartCom, 536870912);
      GridData gd_imgCom = new GridData(4, 4, false, true);
      gd_imgCom.widthHint = 25;
      this.imgCom.setLayoutData(gd_imgCom);
      this.canvas = new Composite(chartCom, 537133056);
      GridData gd_canvas = new GridData(4, 4, true, true);
      gd_canvas.minimumWidth = 5;
      this.canvas.setLayoutData(gd_canvas);
      this.rs = new Scale(chartCom, 512);
      this.rs.setLayoutData(new GridData(4, 4, false, true));
      Label l1 = new Label(chartCom, 2);
      l1.setLayoutData(new GridData(16777216, 4, false, true));
      Composite right = new Composite(this.upSash, 0);
      GridLayout gridLayout_2 = new GridLayout();
      gridLayout_2.verticalSpacing = 0;
      gridLayout_2.marginWidth = 0;
      gridLayout_2.marginHeight = 0;
      gridLayout_2.horizontalSpacing = 0;
      right.setLayout(gridLayout_2);
      this.cursorGroup = new Group(right, 4194304);
      GridLayout gridLayout_3 = new GridLayout();
      gridLayout_3.marginWidth = 10;
      gridLayout_3.marginHeight = 15;
      gridLayout_3.verticalSpacing = 10;
      gridLayout_3.numColumns = 2;
      this.cursorGroup.setLayout(gridLayout_3);
      this.cursorGroup.setLayoutData(new GridData(4, 4, true, true));
      this.dyLabel = new Label(this.cursorGroup, 0);
      this.dyLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.dyLabel.setText("dy:");
      this.dyvLabel = new Label(this.cursorGroup, 0);
      this.dyvLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.dyvLabel.setText("-");
      this.y1Label = new Label(this.cursorGroup, 0);
      this.y1Label.setLayoutData(new GridData(4, 16777216, false, false));
      this.y1Label.setText("y1:");
      this.y1vLabel = new Label(this.cursorGroup, 0);
      this.y1vLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.y1vLabel.setText("-");
      this.y2Label = new Label(this.cursorGroup, 0);
      this.y2Label.setLayoutData(new GridData(4, 16777216, false, false));
      this.y2Label.setText("y2:");
      this.y2vLabel = new Label(this.cursorGroup, 0);
      this.y2vLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.y2vLabel.setText("-");
      this.dxLabel = new Label(this.cursorGroup, 0);
      this.dxLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.dxLabel.setText("dx:");
      this.dxvLabel = new Label(this.cursorGroup, 0);
      this.dxvLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.dxvLabel.setText("-");
      this.x1Label = new Label(this.cursorGroup, 0);
      this.x1Label.setLayoutData(new GridData(4, 16777216, false, false));
      this.x1Label.setText("x1:");
      this.x1vLabel = new Label(this.cursorGroup, 0);
      this.x1vLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.x1vLabel.setText("-");
      this.x2Label = new Label(this.cursorGroup, 0);
      this.x2Label.setLayoutData(new GridData(4, 16777216, false, false));
      this.x2Label.setText("x2:");
      this.x2vLabel = new Label(this.cursorGroup, 0);
      this.x2vLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.x2vLabel.setText("-");
      this.numLabel = new Label(this.cursorGroup, 0);
      GridData gd_numLabel = new GridData(4, 16777216, false, false);
      gd_numLabel.widthHint = 60;
      this.numLabel.setLayoutData(gd_numLabel);
      this.numrangeLabel = new Label(this.cursorGroup, 0);
      this.numrangeLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.numrangeLabel.setText("[?~?]");
      Label label = new Label(this.cursorGroup, 0);
      label.setLayoutData(new GridData(4, 16777216, false, false));
      label.setText(" ");
      this.numvLabel = new Label(this.cursorGroup, 0);
      this.numvLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.numvLabel.setText("-");
      this.cursorTypeLabel = new Label(this.cursorGroup, 0);
      this.cursorTypeLabel.setLayoutData(new GridData(4, 16777216, false, false));
      this.cursorCombo = new Combo(this.cursorGroup, 8);
      this.cursorCombo.setLayoutData(new GridData(4, 16777216, true, false));
      this.timebaseGroup = new Group(right, 4194304);
      GridLayout gridLayout_4 = new GridLayout();
      gridLayout_4.marginWidth = 10;
      gridLayout_4.marginHeight = 10;
      gridLayout_4.numColumns = 2;
      this.timebaseGroup.setLayout(gridLayout_4);
      this.timebaseGroup.setLayoutData(new GridData(4, 4, true, false));
      this.tbTypeLabel = new Label(this.timebaseGroup, 0);
      GridData gd_tbTypeLabel = new GridData(4, 16777216, false, false);
      gd_tbTypeLabel.widthHint = 60;
      this.tbTypeLabel.setLayoutData(gd_tbTypeLabel);
      this.timebaseCombo = new Combo(this.timebaseGroup, 8);
      this.timebaseCombo.setLayoutData(new GridData(4, 16777216, true, false));
      this.volbaseGroup = new Group(right, 4194304);
      GridLayout gridLayout_5 = new GridLayout();
      gridLayout_5.marginWidth = 10;
      gridLayout_5.marginHeight = 10;
      gridLayout_5.numColumns = 2;
      this.volbaseGroup.setLayout(gridLayout_5);
      this.volbaseGroup.setLayoutData(new GridData(4, 4, true, false));
      this.vbTypleLabel = new Label(this.volbaseGroup, 0);
      GridData gd_vbTypleLabel = new GridData(4, 16777216, false, false);
      gd_vbTypleLabel.widthHint = 60;
      this.vbTypleLabel.setLayoutData(gd_vbTypleLabel);
      this.volbaseCombo = new Combo(this.volbaseGroup, 8);
      this.volbaseCombo.setLayoutData(new GridData(4, 16777216, true, false));
      this.downSash = new SashForm(this.mainSash, 256);
      this.wftool = new Composite(this.downSash, 0);
      GridLayout gridLayout_7 = new GridLayout();
      gridLayout_7.marginHeight = 0;
      gridLayout_7.verticalSpacing = 0;
      gridLayout_7.marginWidth = 0;
      gridLayout_7.horizontalSpacing = 0;
      this.wftool.setLayout(gridLayout_7);
      TableLayout tl = new TableLayout();
      tl.addColumnData(new ColumnWeightData(2));
      tl.addColumnData(new ColumnWeightData(2));
      tl.addColumnData(new ColumnWeightData(2));
      tl.addColumnData(new ColumnWeightData(2));
      this.table = new Table(this.wftool, 67616);
      this.table.setLayoutData(new GridData(4, 4, true, true));
      this.table.setHeaderVisible(false);
      this.table.setLinesVisible(true);
      this.table.setLayout(tl);
      TableColumn tc = new TableColumn(this.table, 131072);
      tc.setWidth(100);
      tc = new TableColumn(this.table, 131072);
      tc.setWidth(100);
      tc = new TableColumn(this.table, 131072);
      tc.setWidth(100);
      tc = new TableColumn(this.table, 16384);
      tc.setWidth(100);
      this.tool_com = new ToolComposite(this.wftool, 0);
      GridData gd_tool_com = new GridData(4, 16777216, true, false);
      this.tool_com.getMainCom().setLayoutData(gd_tool_com);
      Label label_2 = new Label(this.wftool, 258);
      label_2.setLayoutData(new GridData(4, 16777216, true, false));
      this.infogroup = new Group(this.downSash, 0);
      FillLayout fillLayout = new FillLayout(512);
      fillLayout.marginWidth = 10;
      fillLayout.marginHeight = 5;
      this.infogroup.setLayout(fillLayout);
   }

   public ToolComposite getToolCom() {
      return this.tool_com;
   }

   public SashForm getDownSash() {
      return this.downSash;
   }

   public SashForm getUpSash() {
      return this.upSash;
   }

   public SashForm getMainSash() {
      return this.mainSash;
   }

   public Composite getMainCom() {
      return this.mainCom;
   }

   public Combo getCursorCombo() {
      return this.cursorCombo;
   }

   public Group getInfogroup() {
      return this.infogroup;
   }

   public void setXYModeOn(boolean e) {
      this.timebaseCombo.setEnabled(e);
      this.cursorCombo.setEnabled(e);
   }

   public void append(final String s) {
      this.mainCom.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            PrototypeCenter.this.text.append(s);
         }
      });
   }
}
