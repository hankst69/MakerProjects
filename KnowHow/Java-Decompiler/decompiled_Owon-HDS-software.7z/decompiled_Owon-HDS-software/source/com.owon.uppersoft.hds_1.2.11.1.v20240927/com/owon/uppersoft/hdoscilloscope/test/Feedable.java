package com.owon.uppersoft.hdoscilloscope.test;

import org.eclipse.swt.graphics.Color;

public interface Feedable {
   int getValue(int var1);

   void setValue(int var1, int var2);

   Color getColor(int var1);

   void setColor(Color var1, int var2);

   String getString(int var1);

   void setString(int var1, String var2);

   int getSize();
}
