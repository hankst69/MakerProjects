package com.owon.uppersoft.hdoscilloscope.chart.model.fft.math;

public interface IComplex {
   double re();

   double im();
}
