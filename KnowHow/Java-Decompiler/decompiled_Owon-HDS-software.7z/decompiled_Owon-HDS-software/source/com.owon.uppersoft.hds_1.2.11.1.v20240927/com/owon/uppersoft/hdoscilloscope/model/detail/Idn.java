package com.owon.uppersoft.hdoscilloscope.model.detail;

public class Idn {
   private String vender;
   private String model;
   private String sn;
   private String ver;
   private String realModel;

   public Idn(String idn) {
      this(idn.split(","));
   }

   public Idn(String[] idn) {
      if (idn.length == 1) {
         try {
            this.setRealModel(idn[0]);
         } catch (Exception var2) {
         }
      } else if (idn.length < 4) {
         this.vender = this.model = this.sn = this.ver = "";
      } else {
         this.vender = idn[0].trim();
         this.realModel = this.model = idn[1].trim();
         this.sn = idn[2].trim();
         this.ver = idn[3].replace("->", "").trim();
      }
   }

   public String getVender() {
      return this.vender;
   }

   public void setVender(String vender) {
      this.vender = vender;
   }

   public String getModel() {
      return this.model;
   }

   public void setModel(String model) {
      this.model = model;
   }

   public String getSn() {
      return this.sn;
   }

   public void setSn(String sn) {
      this.sn = sn;
   }

   public String getVer() {
      return this.ver;
   }

   public void setVer(String ver) {
      this.ver = ver;
   }

   public String getRealModel() {
      return this.realModel;
   }

   public void setRealModel(String realModel) {
      this.realModel = realModel;
   }
}
