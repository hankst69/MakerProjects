package com.owon.uppersoft.hdoscilloscope.action.instance2;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class Open4kAction extends DefaultAction {
   public Open4kAction(String id, int type) {
      super(id, type);
   }

   public void run() {
      boolean b = !Platform.getPlatform().getMainFrame().isDisp4k();
      this.setCheck(b);
      Platform.getPlatform().getMainFrame().setDisp4k(b);
   }
}
