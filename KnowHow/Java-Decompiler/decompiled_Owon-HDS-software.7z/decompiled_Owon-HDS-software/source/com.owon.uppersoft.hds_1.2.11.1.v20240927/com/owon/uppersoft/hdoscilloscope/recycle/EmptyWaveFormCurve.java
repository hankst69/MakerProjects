package com.owon.uppersoft.hdoscilloscope.recycle;

import com.owon.uppersoft.hdoscilloscope.chart.GraphicContext;
import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.TxtEntry;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;
import java.util.Collection;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Menu;

/** @deprecated */
public class EmptyWaveFormCurve implements WaveFormCurve {
   private WaveForm wf;

   public EmptyWaveFormCurve(WaveForm wf, WaveFormFileCurve wffc) {
      this.wf = wf;
   }

   @Override
   public boolean equals(WaveFormCurve wfc) {
      return this == wfc;
   }

   @Override
   public boolean isChannel() {
      return false;
   }

   @Override
   public int getCurveType() {
      return 4;
   }

   @Override
   public int baseIdxOnX() {
      return 0;
   }

   @Override
   public int baseIdxOnY() {
      return 0;
   }

   @Override
   public Collection<? extends Object> xb_collect() {
      return PropertiesItem.StickStringList;
   }

   @Override
   public Collection<? extends Object> yb_collect() {
      return PropertiesItem.StickStringList;
   }

   @Override
   public Collection<TxtEntry> txts_coll() {
      return PropertiesItem.EmptyTxtEntryArray;
   }

   @Override
   public String getStrChannelType() {
      return this.wf.getStrChannelType();
   }

   @Override
   public WaveForm getWaveForm() {
      return this.wf;
   }

   @Override
   public String getXBaseTxt() {
      return "-";
   }

   @Override
   public String getYBaseTxt() {
      return "-";
   }

   @Override
   public int rateAtX() {
      return 0;
   }

   @Override
   public double rateAtY() {
      return 0.0;
   }

   @Override
   public void setBaseIdxOnX(int idx) {
   }

   @Override
   public void setBaseIdxOnY(int idx) {
   }

   @Override
   public String unitForX(double x) {
      return "-";
   }

   @Override
   public String unitForY(double y) {
      return "-";
   }

   @Override
   public double valueAtX(double x) {
      return 0.0;
   }

   @Override
   public double valueAtY(double y) {
      return 0.0;
   }

   @Override
   public int getBlockNum() {
      return 40;
   }

   @Override
   public Color getColor() {
      return Platform.getPlatform().getColorShop().getColor(PropertiesItem.RGB_DARK_CYAN);
   }

   @Override
   public RGB getRGB() {
      return PropertiesItem.RGB_DARK_CYAN;
   }

   @Override
   public boolean isVisible() {
      return false;
   }

   @Override
   public void setRGB(RGB rgb) {
   }

   @Override
   public void setVisible(boolean v) {
   }

   @Override
   public void applyToolComposite() {
      Platform.getPlatform().getCenter().getToolCom().applyEmptyWFC(this);
   }

   @Override
   public Menu getToolMenu() {
      return null;
   }

   @Override
   public WFReg getWFReg() {
      return new WFReg();
   }

   @Override
   public void controlResize(Point lastsize, Point size) {
   }

   @Override
   public void draw(GraphicContext gc) {
   }

   @Override
   public ScalableDrawEngine getScalableDrawEngine() {
      return new ScalableDrawEngine() {
         public void initPts(double x0, double y0, double xpp, double ypp, double xscale, double absoluteScaleY) {
         }

         @Override
         public double getAbsoluteScaleY() {
            return 1.0;
         }

         @Override
         public double getXScale() {
            return 1.0;
         }

         @Override
         public void setAbsoluteScaleY(double absoluteScaleY) {
         }

         @Override
         public void setXScale(double xscale) {
         }

         @Override
         public double getZeroXLocation() {
            return 0.0;
         }

         @Override
         public double getZeroYLocation() {
            return 0.0;
         }

         @Override
         public boolean isPointSelected(Point p) {
            return false;
         }

         @Override
         public void resizeTo(Point lastSize, Point sz) {
         }

         @Override
         public void setZeroXoffset(double x) {
         }

         @Override
         public void setZeroYLocation(double y) {
         }

         @Override
         public void draw(GraphicContext gx) {
         }

         @Override
         public double getPixYPerPoint() {
            return 0.0;
         }

         @Override
         public Point getSize() {
            return new Point(0, 0);
         }

         @Override
         public void setInverted(boolean invert) {
         }
      };
   }
}
