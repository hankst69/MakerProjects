package com.owon.uppersoft.hdoscilloscope.manipulate.mm;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.common.commjob.instance.USBCommunication;
import com.owon.uppersoft.hdoscilloscope.action.ActionFactory;
import com.owon.uppersoft.hdoscilloscope.communication.loop.LoopControl;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.detail.Idn;
import java.util.ResourceBundle;
import org.eclipse.swt.widgets.Display;

public class MMManiAction extends DefaultAction {
   private ActionFactory af;
   private MultiMeterComposite mf;
   public short machine_id = 0;
   public short version_id = 0;
   public String mchhdr = "";
   public String cmdhdr = "";
   private boolean deal = false;

   public MMManiAction(String id, ActionFactory af) {
      super(id);
      this.af = af;
   }

   public void updateRSButton(boolean run) {
      if (this.mf != null) {
         Display display = Platform.getPlatform().getDisplay();
         display.syncExec(new Runnable() {
            @Override
            public void run() {
            }
         });
      }
   }

   public void release() {
      LoopControl lc = this.af.loopControl;
      lc.setUse(false);
      this.mf = null;
      this.reEnable();
   }

   public void reEnable() {
      this.deal = false;
   }

   public void run() {
      if (!this.deal) {
         this.deal = true;
         USBCommunication usb = new USBCommunication();
         usb.open(new Short[]{(short)21317, (short)4660});
         byte[] request = ":DMM:MEAS?".getBytes();

         while (true) {
            usb.write(request, 0, request.length);
            byte[] response = new byte[512];
            int len = usb.read(response, 0, response.length);
            System.out.println(new String(response, 0, len));

            try {
               Thread.sleep(1000L);
            } catch (InterruptedException var6) {
               var6.printStackTrace();
            }
         }
      }
   }

   private void loadMani(LoopControl lc, Idn idn) {
   }

   public void localize(ResourceBundle bundle) {
      super.localize(bundle);
   }
}
