package com.owon.uppersoft.hdoscilloscope.test;

import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;

public class TestScroll {
   protected Shell shell;

   public static void main(String[] args) {
      try {
         TestScroll window = new TestScroll();
         window.open();
      } catch (Exception var2) {
         var2.printStackTrace();
      }
   }

   public void open() {
      this.createContents();
      this.shell.open();
      this.shell.layout();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   protected void createContents() {
      this.shell = new Shell();
      this.shell.setLayout(new FillLayout());
      this.shell.setSize(500, 375);
      this.shell.setText("SWT Application");
      Menu menu = new Menu(this.shell, 2);
      this.shell.setMenuBar(menu);
      MenuItem menuItem = new MenuItem(menu, 64);
      menuItem.setText("Menu Item");
      Menu menu_1 = new Menu(menuItem);
      menuItem.setMenu(menu_1);
      ScrolledComposite scrolledComposite = new ScrolledComposite(this.shell, 2816);
      scrolledComposite.getVerticalBar().setIncrement(50);
      scrolledComposite.getHorizontalBar().setIncrement(50);
      Composite composite = new Composite(scrolledComposite, 0);
      RowLayout rowLayout = new RowLayout(512);
      composite.setLayout(rowLayout);
      composite.setLocation(0, 0);
      Composite composite_1 = new Composite(composite, 0);
      RowData rd_composite_1 = new RowData();
      rd_composite_1.height = 279;
      rd_composite_1.width = 354;
      composite_1.setLayoutData(rd_composite_1);
      composite.setSize(1024, 768);
      scrolledComposite.setContent(composite);
   }
}
