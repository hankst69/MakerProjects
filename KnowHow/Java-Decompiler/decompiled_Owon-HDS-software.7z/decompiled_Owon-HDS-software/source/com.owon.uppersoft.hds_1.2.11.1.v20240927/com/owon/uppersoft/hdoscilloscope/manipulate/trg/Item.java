package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

public class Item {
   private String lbName;
   private String cmdPrefix;
   private String[] units;
   private String[] signs;

   public Item(String lbName, String cmdPrefix, String[] units, String[] signs) {
      this.lbName = lbName;
      this.cmdPrefix = cmdPrefix;
      this.units = units;
      this.signs = signs;
   }

   public String getLbName() {
      return this.lbName;
   }

   public void setLbName(String lbName) {
      this.lbName = lbName;
   }

   public String getCmdPrefix() {
      return this.cmdPrefix;
   }

   public void setCmdPrefix(String cmdPrefix) {
      this.cmdPrefix = cmdPrefix;
   }

   public String[] getUnits() {
      return this.units;
   }

   public void setUnits(String[] units) {
      this.units = units;
   }

   public String[] getSigns() {
      return this.signs;
   }

   public void setSigns(String[] signs) {
      this.signs = signs;
   }

   public static void main(String[] args) {
   }
}
