package com.owon.uppersoft.hdoscilloscope.autoplay;

import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.image.ImageShop;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Scale;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;

public class AutoPlayerFrame implements Listener {
   private static final String BACK_SLANT = "/";
   private List<PlayAttribute> playAttrList;
   private PlayAttribute currtAttr;
   private boolean isPlayModeTurn = true;
   private ReadiniFile readini;
   private IAutoPlayer iap;
   private Shell shell;
   private Display display;
   private ImageShop imgShop;
   private int scaleMAX = 0;
   private boolean playThreadRunState = false;
   private boolean isPlayThreadOver = true;
   private boolean isShellClosed = false;
   private boolean isMouseDown = false;
   private AutoPlayerFrame.FastPlayState faPlySate = null;
   private static int FastBtnCurrentState = 1;
   private Spinner delayTimeSpinner;
   private CLabel playFileLabel;
   private Label fileCountLabel;
   private Label historyLabel;
   private Label playModeLabel;
   private Label timeLabel;
   private Label foldsPathLabel;
   private Button cancelBtn;
   private Button addHistoryBtn;
   private Button startBtn;
   private Button endBtn;
   private Button fastBtn;
   private Button previousBtn;
   private Button nextBtn;
   private Combo playerModeCombo;
   private Combo historyCombo;
   private Scale currentIndexScale;
   private Button btnTranform;

   public AutoPlayerFrame(List<String> folderPathList) {
      this.readini = new ReadiniFile();
      this.playAttrList = new ArrayList<>(folderPathList.size() + 10);
      this.imgShop = Platform.getPlatform().getImageShop();
      this.initPlayAttrList(folderPathList);
      this.iap = new ImagePlayer(this, null);
   }

   public void open() {
      this.createContents();
      this.setForCurrentPlayAttribute(0);
      this.reset();
      this.display = this.shell.getDisplay();
      this.shell.pack();
      this.shell.open();

      while (!this.shell.isDisposed()) {
         if (!this.display.readAndDispatch()) {
            this.display.sleep();
         }
      }
   }

   private void setForCurrentPlayAttribute(int select) {
      this.historyCombo.removeAll();

      for (PlayAttribute pa : this.playAttrList) {
         this.historyCombo.add(pa.getPlayFolderPath());
      }

      if (this.playAttrList.isEmpty()) {
         this.delayTimeSpinner.setSelection(0);
         this.currentIndexScale.setSelection(0);
         this.fileCountLabel.setText("0/0");
      } else {
         this.currtAttr = this.playAttrList.get(select);
         this.iap.setPlayAttribute(this.currtAttr);
         if (this.currtAttr.getPlayFileList() == null) {
            File f = new File(this.currtAttr.getPlayFolderPath(), "filename.ini");
            this.currtAttr.setPlayFileList(this.readini.readFileList(f));
         }

         this.currtAttr.resetCurrentIndex();
         this.historyCombo.select(select);
         int playerMode = this.currtAttr.getPlayerMode();
         this.playerModeCombo.select(playerMode);
         this.isPlayModeTurn = playerMode == 0;
         this.delayTimeSpinner.setSelection(this.currtAttr.getDelayTime());
         this.playFileLabel.setText(this.currtAttr.getPlayFolderPath());
         this.scaleMAX = this.currtAttr.getPlayFileList().size() - 1;
         this.currentIndexScale.setMaximum(this.scaleMAX);
         this.currentIndexScale.setPageIncrement((this.scaleMAX + 10) / 10);
         String imgName = null;
         if (this.isPlayModeTurn) {
            this.setScaleValue(0);
            imgName = "AutoPlayerContinueFront.gif";
         } else {
            this.setScaleValue(this.scaleMAX);
            imgName = "AutoPlayerContinueBack.gif";
         }

         this.startBtn.setImage(this.imgShop.getImage(imgName));
      }
   }

   private void reset() {
      this.iap.playEnd();
      this.isPlayThreadOver = true;
      this.playThreadRunState = false;
      this.isMouseDown = false;
      this.faPlySate = null;
      FastBtnCurrentState = 1;
      String imgName = "AutoPlayerFastStop.gif";
      this.fastBtn.setImage(this.imgShop.getImage(imgName));
      this.endBtn.setEnabled(false);
      this.previousBtn.setEnabled(false);
      this.nextBtn.setEnabled(false);
      this.fastBtn.setEnabled(false);
      this.addHistoryBtn.setEnabled(true);
      this.historyCombo.setEnabled(true);
      this.playerModeCombo.setEnabled(true);
      if (!this.playAttrList.isEmpty()) {
         this.currtAttr.resetCurrentIndex();
      }

      if (this.isPlayModeTurn) {
         imgName = "AutoPlayerContinueFront.gif";
         this.setScaleValue(0);
      } else {
         imgName = "AutoPlayerContinueBack.gif";
         this.setScaleValue(this.scaleMAX);
      }

      this.startBtn.setImage(this.imgShop.getImage(imgName));
      if (this.playAttrList.isEmpty()) {
         this.fileCountLabel.setText("0/0");
      }
   }

   private void showStartBtnImage(boolean b) {
      String imgName = null;
      if (b) {
         imgName = this.isPlayModeTurn ? "AutoPlayerContinueFront.gif" : "AutoPlayerContinueBack.gif";
      } else {
         imgName = "AutoPlayerPause.gif";
      }

      this.startBtn.setImage(this.imgShop.getImage(imgName));
      this.previousBtn.setEnabled(b);
      this.nextBtn.setEnabled(b);
      this.endBtn.setEnabled(true);
      this.fastBtn.setEnabled(true);
      this.addHistoryBtn.setEnabled(false);
      this.historyCombo.setEnabled(false);
      this.playerModeCombo.setEnabled(false);
   }

   private void isPausePlay(boolean b) {
      if (!this.playAttrList.isEmpty()) {
         if (b) {
            this.iap.playPause();
            this.playThreadRunState = false;
            this.showStartBtnImage(true);
         } else {
            this.iap.playContinue();
            this.playThreadRunState = true;
            this.showStartBtnImage(false);
         }
      }
   }

   private boolean addPlayAttribute(PlayAttribute pa) {
      if (pa == null) {
         return false;
      } else {
         this.playAttrList.add(pa);
         return true;
      }
   }

   private boolean isHistoryCorrect(String folderPath) {
      return this.addPlayAttribute(this.findiniFile(folderPath));
   }

   private void initPlayAttrList(List<String> folderPathList) {
      if (folderPathList != null) {
         for (String path : folderPathList) {
            PlayAttribute pa = this.findiniFile(path);
            this.addPlayAttribute(pa);
         }
      }
   }

   private PlayAttribute findiniFile(String folderPath) {
      if (folderPath != null && folderPath.length() != 0) {
         File inifile = new File(folderPath, "filename.ini");
         return !inifile.exists() ? null : new PlayAttribute(-1, 1000, 0, folderPath, null);
      } else {
         return null;
      }
   }

   private void setScaleValue(int sel) {
      this.currentIndexScale.setSelection(sel);
      this.fileCountLabel.setText(sel + 1 + "/" + (this.scaleMAX + 1));
   }

   public void setScaleSelect(final int value) {
      this.display.syncExec(new Runnable() {
         @Override
         public void run() {
            if (!AutoPlayerFrame.this.isShellClosed) {
               AutoPlayerFrame.this.setScaleValue(value);
            }
         }
      });
   }

   public void resetThreadContext() {
      this.display.asyncExec(new Runnable() {
         @Override
         public void run() {
            if (!AutoPlayerFrame.this.isShellClosed) {
               AutoPlayerFrame.this.reset();
            }
         }
      });
   }

   public void doOpenFile(final File f) {
      this.display.syncExec(new Runnable() {
         @Override
         public void run() {
            if (!AutoPlayerFrame.this.isShellClosed) {
               Platform.getPlatform().getActionFactory().open.doOpenFile(f, false);
            }
         }
      });
   }

   public List<String> returnHistoryList() {
      List<String> folderPathList = new ArrayList<>(this.playAttrList.size());

      for (PlayAttribute pa : this.playAttrList) {
         folderPathList.add(pa.getPlayFolderPath());
      }

      return folderPathList;
   }

   public void handleEvent(Event event) {
      Object o = event.widget;
      if (o == this.currentIndexScale) {
         switch (event.type) {
            case 3:
               if (this.playThreadRunState) {
                  this.isMouseDown = true;
                  this.isPausePlay(true);
               }
               break;
            case 4:
               if (!this.playThreadRunState && this.isMouseDown) {
                  this.isPausePlay(false);
               }

               this.isMouseDown = false;
               break;
            case 13:
               if (this.playAttrList.isEmpty()) {
                  return;
               }

               int sel = this.currentIndexScale.getSelection();
               this.currtAttr.setCurrentIndex(this.isPlayModeTurn ? sel - 1 : sel + 1);
               this.fileCountLabel.setText(sel + 1 + "/" + (this.scaleMAX + 1));
         }
      } else if (o == this.startBtn) {
         if (!this.playAttrList.isEmpty()) {
            if (this.isPlayThreadOver) {
               this.playFileLabel.setText(this.currtAttr.getPlayFolderPath());
               this.iap.setPlayAttribute(this.currtAttr);
               this.iap.playStart();
               this.playThreadRunState = true;
               this.isPlayThreadOver = false;
               this.showStartBtnImage(false);
            } else {
               this.isPausePlay(this.playThreadRunState);
            }
         }
      } else if (o == this.endBtn) {
         this.reset();
      } else if (o == this.fastBtn) {
         if (this.faPlySate == null) {
            this.faPlySate = new AutoPlayerFrame.FastPlayState();
         }

         String imgName = null;
         switch (this.faPlySate.getNextState()) {
            case -1:
               imgName = "AutoPlayerFastBack.gif";
               this.iap.fastBackward();
               break;
            case 0:
               imgName = "AutoPlayerFastStop.gif";
               this.iap.endFast();
               break;
            case 1:
               imgName = "AutoPlayerFastFront.gif";
               this.iap.fastForward();
         }

         this.fastBtn.setImage(this.imgShop.getImage(imgName));
      } else if (o == this.previousBtn) {
         if (!this.playAttrList.isEmpty()) {
            this.iap.previous();
            this.setScaleValue(this.currtAttr.getCurrentIndex());
         }
      } else if (o == this.nextBtn) {
         if (!this.playAttrList.isEmpty()) {
            this.iap.next();
            this.setScaleValue(this.currtAttr.getCurrentIndex());
         }
      } else if (o == this.delayTimeSpinner) {
         if (!this.playAttrList.isEmpty()) {
            this.currtAttr.setDelayTime(this.delayTimeSpinner.getSelection());
         }
      } else if (o == this.cancelBtn) {
         this.shell.close();
      } else if (o == this.addHistoryBtn) {
         DirectoryDialog dd = new DirectoryDialog(this.shell);
         String filePath = dd.open();
         if (filePath != null && filePath.length() != 0) {
            this.addHistory(filePath);
         }
      } else if (o == this.playerModeCombo) {
         if (!this.playAttrList.isEmpty()) {
            int playMode = this.playerModeCombo.getSelectionIndex();
            this.currtAttr.setPlayerMode(playMode);
            this.currtAttr.resetCurrentIndex();
            String imgName = null;
            if (playMode == 0) {
               this.setScaleValue(0);
               this.isPlayModeTurn = true;
               imgName = "AutoPlayerContinueFront.gif";
            } else {
               this.setScaleValue(this.currtAttr.getPlayFileList().size() - 1);
               this.isPlayModeTurn = false;
               imgName = "AutoPlayerContinueBack.gif";
            }

            this.startBtn.setImage(this.imgShop.getImage(imgName));
         }
      } else if (o == this.historyCombo) {
         if (!this.playAttrList.isEmpty()) {
            this.setForCurrentPlayAttribute(this.historyCombo.getSelectionIndex());
         }
      } else if (o == this.shell) {
         if (this.iap != null) {
            this.iap.playEnd();
         }

         this.isShellClosed = true;
      } else {
         if (o == this.btnTranform) {
            FormatTransform ft = new FormatTransform();
            String path = ft.open();
            if (path != null) {
               this.addHistory(path);
            }
         }
      }
   }

   private void addHistory(String filePath) {
      ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle();

      for (PlayAttribute pa : this.playAttrList) {
         if (filePath.equals(pa.getPlayFolderPath())) {
            this.playFileLabel.setText(filePath + rb.getString("AutoPlay.ExistedThis"));
            return;
         }
      }

      if (this.isHistoryCorrect(filePath)) {
         this.setForCurrentPlayAttribute(this.historyCombo.getItemCount());
      } else {
         this.playFileLabel.setText(filePath + rb.getString("AutoPlay.EffectOption"));
         this.fileCountLabel.setText("0/0");
      }
   }

   protected void createContents() {
      this.shell = new Shell(Platform.getPlatform().getShell(), 16544);
      this.shell.setLayout(new FillLayout());
      Composite com = new Composite(this.shell, 0);
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 7;
      com.setLayout(gridLayout);
      this.historyLabel = new Label(com, 0);
      this.historyLabel.setLayoutData(new GridData(16384, 16777216, false, false, 3, 1));
      this.historyCombo = new Combo(com, 8);
      this.historyCombo.setLayoutData(new GridData(4, 16777216, false, false, 2, 1));
      this.addHistoryBtn = new Button(com, 0);
      GridData gd_addHistoryBtn = new GridData(16384, 16777216, false, false, 1, 1);
      gd_addHistoryBtn.widthHint = 100;
      this.addHistoryBtn.setLayoutData(gd_addHistoryBtn);
      this.btnTranform = new Button(com, 0);
      this.btnTranform.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.playModeLabel = new Label(com, 0);
      GridData gd_playModeLabel = new GridData(16384, 16777216, false, false, 3, 1);
      gd_playModeLabel.widthHint = 150;
      this.playModeLabel.setLayoutData(gd_playModeLabel);
      this.playerModeCombo = new Combo(com, 8);
      this.playerModeCombo.setLayoutData(new GridData(4, 128, false, false, 2, 1));
      this.timeLabel = new Label(com, 0);
      GridData gd_timeLabel = new GridData(4, 16777216, false, false);
      gd_timeLabel.widthHint = 160;
      this.timeLabel.setLayoutData(gd_timeLabel);
      this.delayTimeSpinner = new Spinner(com, 2048);
      GridData gd_delayTimeSpinner = new GridData(16384, 16777216, true, false);
      gd_delayTimeSpinner.widthHint = 60;
      this.delayTimeSpinner.setLayoutData(gd_delayTimeSpinner);
      this.delayTimeSpinner.setIncrement(500);
      this.delayTimeSpinner.setMaximum(10000);
      this.foldsPathLabel = new Label(com, 0);
      this.foldsPathLabel.setLayoutData(new GridData(16384, 16777216, false, false, 3, 1));
      this.playFileLabel = new CLabel(com, 0);
      this.playFileLabel.setLayoutData(new GridData(4, 16777216, true, false, 4, 1));
      this.currentIndexScale = new Scale(com, 0);
      GridData gd_currentIndexScale = new GridData(4, 16777216, true, false, 7, 1);
      gd_currentIndexScale.widthHint = 500;
      this.currentIndexScale.setLayoutData(gd_currentIndexScale);
      this.currentIndexScale.setPageIncrement(10);
      this.currentIndexScale.setMaximum(10);
      this.startBtn = new Button(com, 0);
      this.startBtn.setLayoutData(new GridData(4, 16777216, false, false));
      this.endBtn = new Button(com, 0);
      this.endBtn.setLayoutData(new GridData(4, 16777216, false, false));
      this.previousBtn = new Button(com, 0);
      this.nextBtn = new Button(com, 0);
      this.nextBtn.setLayoutData(new GridData(4, 16777216, false, false));
      this.fastBtn = new Button(com, 0);
      this.fastBtn.setLayoutData(new GridData(4, 16777216, false, false));
      this.fastBtn.setVisible(false);
      this.fileCountLabel = new Label(com, 0);
      this.fileCountLabel.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.cancelBtn = new Button(com, 0);
      GridData gd_cancelBtn = new GridData(16777216, 16777216, false, false);
      gd_cancelBtn.widthHint = 100;
      this.cancelBtn.setLayoutData(gd_cancelBtn);
      this.addListener();
      this.endBtn.setImage(this.imgShop.getImage("AutoPlayerStop.gif"));
      this.previousBtn.setImage(this.imgShop.getImage("AutoPlayerPrevious.gif"));
      this.nextBtn.setImage(this.imgShop.getImage("AutoPlayerNext.gif"));
      this.fastBtn.setImage(this.imgShop.getImage("AutoPlayerFastStop.gif"));
      this.shell.setImage(Platform.getPlatform().getImageShop().getImage("player.png"));
      this.localize();
      ShellUtil.centerLoc(this.shell);
   }

   private void addListener() {
      this.shell.addListener(21, this);
      this.currentIndexScale.addListener(3, this);
      this.currentIndexScale.addListener(4, this);
      this.historyCombo.addListener(13, this);
      this.addHistoryBtn.addListener(13, this);
      this.cancelBtn.addListener(13, this);
      this.startBtn.addListener(13, this);
      this.endBtn.addListener(13, this);
      this.playerModeCombo.addListener(13, this);
      this.currentIndexScale.addListener(13, this);
      this.delayTimeSpinner.addListener(13, this);
      this.fastBtn.addListener(13, this);
      this.previousBtn.addListener(13, this);
      this.nextBtn.addListener(13, this);
      this.btnTranform.addListener(13, this);
   }

   public Shell getShell() {
      return this.shell;
   }

   public void localize() {
      this.localize(ResourceBundleProvider.getMessageLibResourceBundle());
   }

   public void localize(ResourceBundle bundle) {
      if (!this.shell.isDisposed()) {
         this.shell.setText(bundle.getString("AutoPlay.ShellTitle"));
         this.historyLabel.setText(bundle.getString("AutoPlay.historyLabelText"));
         this.addHistoryBtn.setText(bundle.getString("AutoPlay.AddHistoryBtnText"));
         String[] temp = new String[]{bundle.getString("AutoPlay.Turn"), bundle.getString("AutoPlay.Reverse")};
         this.playerModeCombo.setItems(temp);
         this.playModeLabel.setText(bundle.getString("AutoPlay.PlayMode"));
         this.timeLabel.setText(bundle.getString("AutoPlay.PlayTimeDelay"));
         this.foldsPathLabel.setText(bundle.getString("AutoPlay.PlayFolderPath"));
         this.cancelBtn.setText(bundle.getString("AutoPlay.Close"));
         this.btnTranform.setText(bundle.getString("AutoPlay.transform"));
      }
   }

   class FastPlayState {
      private static final int FAST_forward = 1;
      private static final int FAST_neutral = 0;
      private static final int FAST_backword = -1;
      private int[] state = new int[]{0, 1, 0, -1};

      public int getNextState() {
         if (AutoPlayerFrame.FastBtnCurrentState == this.state.length) {
            AutoPlayerFrame.FastBtnCurrentState = 0;
         }

         int[] var10000 = this.state;
         int var10001 = AutoPlayerFrame.FastBtnCurrentState;
         AutoPlayerFrame.FastBtnCurrentState = var10001 + 1;
         return var10000[var10001];
      }
   }
}
