package com.owon.uppersoft.hdoscilloscope.communication.loop;

import com.owon.uppersoft.common.commjob.instance.ICommunication;

public abstract class Communication implements ICommunication {
   public static void main(String[] args) {
   }

   public String readString(int len) {
      byte[] arr = new byte[len];
      int num = this.read(arr, 0, len);
      return num < 0 ? null : new String(arr, 0, num);
   }

   String readString() {
      return this.readString(512);
   }

   int writeString(String s) {
      byte[] arr = s.getBytes();
      return this.write(arr, 0, arr.length);
   }
}
