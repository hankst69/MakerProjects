package com.owon.uppersoft.hdoscilloscope.data;

import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import com.owon.uppersoft.hdoscilloscope.util.SimpleStringFormatter;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class InfoPart {
   public static final int HeaderLength = 4;
   public static final int TimeLength = 30;
   public static final int VERSION = 1;
   public static final int BLOCKSIZE = 38;
   public int version = 1;
   private Date date;
   public static final String DateSaveFormat = "yyyy-MM-dd HH:mm:ss";
   public static final String DateShowFormat = "yyyy-MM-dd HH:mm:ss";
   private static DateFormat showPatern = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
   private static DateFormat saveParten = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
   private static SimpleStringFormatter saveFormatter = new SimpleStringFormatter(30, '\u0000');

   public void readin(CByteArrayInputStream ba) {
      int p = 0;
      int blocksize = ba.nextInt();
      p += 4;
      this.version = ba.nextInt();
      p += 4;
      int len = 30;
      byte[] bs = new byte[len];
      ba.get(bs, 0, len);
      p += len;
      this.setTimestamp(new String(bs, 0, len));
   }

   public String getTimestamp() {
      return this.date == null ? "?" : showPatern.format(this.date);
   }

   public void setTimestamp(String time) {
      try {
         this.date = showPatern.parse(time);
      } catch (ParseException var3) {
         this.date = null;
         var3.printStackTrace();
      }
   }

   public void setTimestamp() {
      this.date = new Date();
   }

   public static final void write(RandomAccessFile raf, File f) {
      try {
         raf.seek(f.length());
         raf.writeBytes("INFO");
         raf.writeInt(Integer.reverseBytes(1));
         raf.writeInt(Integer.reverseBytes(38));
         Date dat = new Date();
         String timestamp = saveParten.format(dat);
         raf.writeBytes(saveFormatter.valueToStringOnLeft(timestamp));
      } catch (IOException var4) {
         var4.printStackTrace();
      }
   }

   public static void main(String[] args) {
      Date dat = new Date();
      String timestamp = showPatern.format(dat);
      System.out.println(saveFormatter.valueToStringOnLeft(timestamp));
   }
}
