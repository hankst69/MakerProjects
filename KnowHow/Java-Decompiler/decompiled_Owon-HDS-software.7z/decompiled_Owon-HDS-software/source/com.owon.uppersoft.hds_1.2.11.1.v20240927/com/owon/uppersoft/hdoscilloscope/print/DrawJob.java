package com.owon.uppersoft.hdoscilloscope.print;

import com.owon.uppersoft.common.aspect.Disposable;
import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.common.utils.DisposeUtil;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.TxtEntry;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import java.util.Collection;
import java.util.ResourceBundle;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.graphics.Transform;
import org.eclipse.swt.widgets.Display;

public class DrawJob implements Disposable, Localizable2 {
   public static final int NoBGPrint = 0;
   public static final int BGPrint = 1;
   private int printMode = 0;
   private PrintService ps;
   private Font font;
   private Image image;

   public DrawJob(PrintService ps, Display display) {
      this.ps = ps;
      FontData fdata = new FontData("Arial", 10, 0);
      this.font = new Font(display, fdata);
      this.localize(ResourceBundleProvider.getMessageLibResourceBundle());
   }

   public int getPrintMode() {
      return this.printMode;
   }

   public void updatePrintMode(int printMode) {
      if (this.printMode != printMode) {
         this.forceUpdatePrintMode(printMode);
      }
   }

   public void forceUpdatePrintMode(int printMode) {
      this.printMode = printMode;
      this.updateImage();
   }

   void updateImage() {
      DrawingPanel dp = Platform.getPlatform().getDrawingPanel();
      Point size = dp.getSize();
      if (this.image == null) {
         this.image = new Image(Platform.getPlatform().getDisplay(), size.x, size.y);
      }

      GC gc = new GC(this.image);
      if (this.printMode == 1) {
         dp.drawingPaint(gc);
      } else {
         gc.setBackground(this.ps.getPaperBackground());
         gc.fillRectangle(0, 0, size.x, size.y);
         dp.drawingPrint(gc);
      }

      gc.dispose();
   }

   public void dispose() {
      DisposeUtil.tryDispose(this.image);
      DisposeUtil.tryDispose(this.font);
   }

   public void draw(GC gc, Transform transform, Rectangle clientRect) {
      this.scaleDraw(gc, transform, clientRect);
      this.drawSelf(gc, transform);
   }

   private void scaleDraw(GC gc, Transform transform, Rectangle clientRect) {
      DrawingPanel dp = Platform.getPlatform().getDrawingPanel();
      WaveFormFileCurve wffc = dp.getWaveFormFileCurve();
      int length = wffc.getWaveformsNumber();
      int strExtW = gc.stringExtent("CHXX").x;
      int strExtH = gc.stringExtent("CHXX").y;
      Point size = dp.getSize();
      int w = strExtW + strExtH + size.x;
      int h = size.y + (length + 1) * strExtH;
      double scaleX = (double)clientRect.width / (double)w;
      double scaleY = (double)clientRect.height / (double)h;
      double scale = 1.0;
      if (scaleX < 1.0 || scaleY < 1.0) {
         scale = scaleX < scaleY ? scaleX : scaleY;
      }

      transform.scale((float)scale, (float)scale);
      gc.setTransform(transform);
   }

   private void drawSelf(GC gc, Transform transform) {
      DrawingPanel dp = Platform.getPlatform().getDrawingPanel();
      WaveFormFileCurve wffc = dp.getWaveFormFileCurve();
      int strExtW = gc.stringExtent("CHXX").x;
      int strExtH = gc.stringExtent("CHXX").y;
      int shortline = strExtH;
      Point size = dp.getSize();
      gc.setFont(this.font);
      gc.setAdvanced(true);
      int i = 0;

      for (WaveFormCurve wfc : wffc.all_collect()) {
         String str = wfc.getStrChannelType();
         int y = (int)wfc.getScalableDrawEngine().getZeroYLocation();
         gc.setForeground(wfc.getColor());
         gc.drawString(str, 0, y - (strExtH >> 1), true);
         gc.drawLine(strExtW, y, strExtW + shortline, y);
         Collection<TxtEntry> it = wfc.txts_coll();
         WaveForm wf = wfc.getWaveForm();
         str = str + "\t\t" + wfc.getXBaseTxt() + "\t" + wfc.getYBaseTxt() + "\t" + "/" + (wf == null ? "" : wf.getRateYAsAttenuation()) + "\t";
         if (it != null) {
            for (TxtEntry te : it) {
               te.localize(ResourceBundleProvider.getMessageLibResourceBundle());
               str = str + te.n + te.v + "\t";
            }
         }

         gc.drawText(str, strExtW + shortline, size.y + (i + 1) * strExtH, true);
         i++;
      }

      transform.translate((float)shortline + (float)strExtW, 0.0F);
      gc.setTransform(transform);
      gc.setClipping(0, 0, size.x, size.y);
      gc.drawImage(this.image, 0, 0);
   }

   public void localize(ResourceBundle bundle) {
   }
}
