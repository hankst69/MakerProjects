package com.owon.uppersoft.hdoscilloscope.pref;

import java.util.HashMap;
import java.util.Map;

public class Reg {
   public static boolean AutoApplyZeroLocation = false;
   private boolean autoCreateFFT = false;
   private boolean autoApplyFFT = false;
   private String lastSelChlName;
   private boolean lineVisible = false;
   private boolean XYChosen;
   public Map<String, WFReg> txt_WFReg = new HashMap<>();

   public void setXYChosen(boolean XYChosen) {
      this.XYChosen = XYChosen;
   }

   public boolean isXYChosen() {
      return this.XYChosen;
   }

   public void setLineVisible(boolean lineVisible) {
      this.lineVisible = lineVisible;
   }

   public boolean isLineVisible() {
      return this.lineVisible;
   }

   public void setLastSelChlName(String lastSelChlName) {
      this.lastSelChlName = lastSelChlName;
   }

   public String getLastSelChlName() {
      return this.lastSelChlName;
   }

   protected Reg() {
      this.txt_WFReg.put("CH1", new WFReg().setRgb(PropertiesItem.RGB_CH1));
      this.txt_WFReg.put("CH2", new WFReg().setRgb(PropertiesItem.RGB_CH2));
      this.txt_WFReg.put("CH3", new WFReg().setRgb(PropertiesItem.RGB_CH3));
      this.txt_WFReg.put("CH4", new WFReg().setRgb(PropertiesItem.RGB_CH4));
      this.txt_WFReg.put("math", new MathReg().setRgb(PropertiesItem.RGB_GREEN));
   }

   public Map<String, WFReg> getTxt_WFReg() {
      return this.txt_WFReg;
   }

   public WFReg getWFReg(String name) {
      WFReg wr = this.txt_WFReg.get(name);
      if (wr != null) {
         return wr;
      } else {
         if (name.equalsIgnoreCase("math")) {
            wr = new MathReg();
         } else if (name.startsWith("fft")) {
            wr = new FFTReg();
         } else {
            wr = new WFReg();
         }

         this.txt_WFReg.put(name, wr);
         return wr;
      }
   }

   public FFTReg getFFTReg(String name) {
      return (FFTReg)this.getWFReg(name);
   }

   public MathReg getMathReg() {
      return (MathReg)this.getWFReg("math");
   }

   public void setAutoCreateFFT(boolean autoCreateFFT) {
      this.autoCreateFFT = autoCreateFFT;
   }

   public boolean isAutoCreateFFT() {
      return this.autoCreateFFT;
   }

   public boolean isAutoApplyFFT() {
      return this.autoApplyFFT;
   }

   public void setAutoApplyFFT(boolean autoApplyFFT) {
      this.autoApplyFFT = autoApplyFFT;
   }
}
