package com.owon.uppersoft.hdoscilloscope.autoplay;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ReadiniFile {
   public List<String> readFileList(File inifile) {
      return this.readPropertiesData(inifile);
   }

   public List<String> readFileList(String inifilePath) {
      return this.readPropertiesData(new File(inifilePath));
   }

   private List<String> readPropertiesData(File iniFilePath) {
      List<String> fList = new ArrayList<>();

      try {
         BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(iniFilePath), "UTF-8"));
         String line = null;

         while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.length() != 0) {
               fList.add(line);
            }
         }

         reader.close();
         return fList;
      } catch (FileNotFoundException var5) {
         var5.printStackTrace();
         return fList;
      } catch (IOException var6) {
         var6.printStackTrace();
         return fList;
      }
   }

   public static void main(String[] args) {
      ReadiniFile r = new ReadiniFile();
      List<String> a = r.readFileList("c:\\haha\\you\\filename.ini");

      for (int i = 0; i < a.size(); i++) {
         System.out.println(a.get(i));
      }

      System.out.println("haha");
   }
}
