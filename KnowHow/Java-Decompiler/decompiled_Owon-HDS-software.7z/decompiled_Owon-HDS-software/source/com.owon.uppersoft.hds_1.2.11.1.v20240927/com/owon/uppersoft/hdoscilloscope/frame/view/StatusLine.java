package com.owon.uppersoft.hdoscilloscope.frame.view;

import ch.ntb.usb.USBException;
import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.common.communication.ArrowButtonMenu;
import com.owon.uppersoft.common.communication.IUSBStatus;
import com.owon.uppersoft.hdoscilloscope.communication.usb.CDevice;
import com.owon.uppersoft.hdoscilloscope.communication.usb.IDevice;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Text;

public class StatusLine extends Composite implements Localizable2, IUSBStatus {
   private Label labEmpty;
   private Composite progressCom;
   private Label labProgress;
   private Composite firmCom;
   private Text txtPath;
   private Label checkStatusToolItem;
   private Label statusToolItem;
   private Platform platform;
   private StackLayout firmComLayout;
   private ProgressBar pb;
   private ArrowButtonMenu arrowBtnMenu;
   private String infoNoFileLoop;

   public StatusLine(Composite parent, int style) {
      super(parent, style);
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 5;
      this.setLayout(gridLayout);
      this.txtPath = new Text(this, 8);
      this.txtPath.setLayoutData(new GridData(4, 16777216, true, true));
      this.firmCom = new Composite(this, 0);
      this.firmComLayout = new StackLayout();
      this.firmCom.setLayout(this.firmComLayout);
      GridData gd_firmCom = new GridData(131072, 16777216, false, false);
      gd_firmCom.widthHint = 100;
      this.firmCom.setLayoutData(gd_firmCom);
      this.progressCom = new Composite(this.firmCom, 0);
      GridLayout gridLayout_1 = new GridLayout(2, false);
      gridLayout_1.verticalSpacing = 0;
      gridLayout_1.marginWidth = 0;
      gridLayout_1.marginHeight = 0;
      gridLayout_1.horizontalSpacing = 0;
      this.progressCom.setLayout(gridLayout_1);
      this.pb = new ProgressBar(this.progressCom, 0);
      GridData gd_pb = new GridData(16777216, 16777216, false, false);
      gd_pb.widthHint = 50;
      this.pb.setLayoutData(gd_pb);
      this.labProgress = new Label(this.progressCom, 0);
      GridData gd_lp = new GridData(16777216, 16777216, false, false);
      gd_lp.widthHint = 50;
      this.labProgress.setLayoutData(gd_lp);
      this.firmComLayout.topControl = this.labEmpty;
      Configuration conf = Platform.getPlatform().getConfiguration();
      this.arrowBtnMenu = new ArrowButtonMenu(this.getShell(), conf.getReinstallUSBDriverCommand(), conf.notifyUSBchange);
      this.checkStatusToolItem = new Label(this, 131072);
      GridData gd_checkStatusToolItem = new GridData(150, -1);
      this.checkStatusToolItem.setLayoutData(gd_checkStatusToolItem);
      this.statusToolItem = new Label(this, 0);
      GridData gd_statusToolItem = new GridData(16384, 4, false, true);
      this.statusToolItem.setLayoutData(gd_statusToolItem);
      this.platform = Platform.getPlatform();
      this.statusToolItem.setImage(this.platform.getImageShop().getImage("uncheck_connect.gif"));
      Button arrowBtn = new Button(this, 8389636);
      arrowBtn.setLayoutData(new GridData());
      arrowBtn.setMenu(this.arrowBtnMenu.getMenu());
      arrowBtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            StatusLine.this.arrowBtnMenu.setVisible(true);
         }
      });
   }

   public void setPath(String path) {
      this.txtPath.setText(path);
   }

   public void prepareShowProgress() {
      this.firmComLayout.topControl = this.progressCom;
      this.firmCom.layout();
   }

   public void hideProgressBar() {
      this.firmComLayout.topControl = this.labEmpty;
      this.firmCom.layout();
   }

   public void usbStatus(boolean flag) {
      if (!this.isDisposed()) {
         if (flag) {
            this.checkStatusToolItem.setForeground(this.getDisplay().getSystemColor(6));
            this.statusToolItem.setImage(this.platform.getImageShop().getImage("good_connect.png"));
         } else {
            this.checkStatusToolItem.setForeground(this.getDisplay().getSystemColor(3));
            this.statusToolItem.setImage(this.platform.getImageShop().getImage("bad_connect.png"));
         }
      }
   }

   public boolean checkStatus() {
      List<IDevice> usb = null;

      try {
         usb = CDevice.scanMatchedDevices((short)21317, (short)4660);
      } catch (USBException var3) {
         var3.printStackTrace();
      } catch (Throwable var4) {
         var4.printStackTrace();
      }

      return !usb.isEmpty();
   }

   public void setStatusText(String txt) {
      this.checkStatusToolItem.setText(txt);
   }

   public void setInfoNoFileLoop(String infoNoFileLoop) {
      this.infoNoFileLoop = infoNoFileLoop;
   }

   public String getInfoNoFileLoop() {
      return this.infoNoFileLoop;
   }

   public void localize(ResourceBundle bundle) {
      String checkInfo = bundle.getString("MF.checkUSB");
      this.checkStatusToolItem.setText(checkInfo);
      this.statusToolItem.setToolTipText(checkInfo);
      this.infoNoFileLoop = ResourceBundleProvider.getMessageLibResourceBundle().getString("Info.NoFileLoop");
      this.arrowBtnMenu.localize();
   }

   public ProgressBar getProgressBar() {
      return this.pb;
   }

   public Label getLabProgress() {
      return this.labProgress;
   }

   public boolean shouldPopupCheck() {
      return this.arrowBtnMenu.getShouldPopupCheck();
   }
}
