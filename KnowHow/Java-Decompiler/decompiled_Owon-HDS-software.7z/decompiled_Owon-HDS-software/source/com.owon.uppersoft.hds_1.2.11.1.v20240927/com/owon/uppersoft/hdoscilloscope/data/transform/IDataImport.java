package com.owon.uppersoft.hdoscilloscope.data.transform;

import com.owon.uppersoft.hdoscilloscope.chart.model.ControlManger;
import com.owon.uppersoft.hdoscilloscope.data.InfoPart;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import java.io.File;

public interface IDataImport {
   WaveFormFile getWaveFormFile(File var1, ControlManger var2);

   WaveFormFile readBinary(CByteArrayInputStream var1, ControlManger var2);

   WaveFormFile readBinary(CByteArrayInputStream var1, ControlManger var2, InfoPart var3);
}
