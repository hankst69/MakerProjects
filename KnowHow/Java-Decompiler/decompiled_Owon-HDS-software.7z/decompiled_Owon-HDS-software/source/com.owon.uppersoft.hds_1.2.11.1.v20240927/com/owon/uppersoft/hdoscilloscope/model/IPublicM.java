package com.owon.uppersoft.hdoscilloscope.model;

import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import org.eclipse.swt.graphics.RGB;

public interface IPublicM {
   boolean USBCMDChooseable = false;
   boolean NewFunctionPrompt = false;
   int DefaultMajorGraticuleLength = 4;
   int DefaultMinorGraticuleLength = 2;
   int DefalutInvisibleYGraticuleNumEitherPart = 6;
   int DefalutMinorGraticulesInMajor = 5;
   RGB DefaultBackground = PropertiesItem.RGB_BLACK;
   RGB DefaultGrid = PropertiesItem.RGB_LIGHT_BLUE;
   RGB DefaultMarkLine = PropertiesItem.RGB_CYAN;
   RGB DefaultCScaleBG = PropertiesItem.RGB_CYAN;
   RGB DefaultXYModeRGB = PropertiesItem.RGB_RED;
   boolean DefaultVerticalMarkLineVisible = false;
   boolean DefaultHorizontalMarkLineVisible = false;
   int DefaultFFTScopeUnits = 10;
   boolean DefaultLineVisible = false;
   boolean DefaultDottGraticulevisible = false;
   boolean DefaultCenterCrossVisible = true;
   int DefaultLowMoveTimeBaseIndex = 22;
   double DefaultLowMoveBlankRatio = 0.08;
   int[] DefaultDashLines = new int[]{1, 4};
   int DefaultIndecsCount = 10;
   int DefaultIndecsOffset = 0;
   boolean DefaultZeroVoltageVisible = false;
   String XYModeChannel0 = "CH1";
   String XYModeChannel1 = "CH2";
   boolean USBResponseSpeedDebug = false;
   int MaxChannelNumber = 4;
   String DefaultIdn = "OWON,XDS3102a,0000000,V1.0";
   int[] precision = new int[]{8, 12, 14};
}
