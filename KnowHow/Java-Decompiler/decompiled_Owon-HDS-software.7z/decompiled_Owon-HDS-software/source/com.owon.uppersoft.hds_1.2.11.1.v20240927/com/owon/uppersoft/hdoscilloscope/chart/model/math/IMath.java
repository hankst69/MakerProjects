package com.owon.uppersoft.hdoscilloscope.chart.model.math;

public interface IMath {
   String[] math_types = new String[]{"ch1 + ch2", "ch1 - ch2", "ch2 - ch1", "ch1 * ch2", "ch1 / ch2", "ch2 / ch1", "ch1 * ch1", "ch2 * ch2"};
}
