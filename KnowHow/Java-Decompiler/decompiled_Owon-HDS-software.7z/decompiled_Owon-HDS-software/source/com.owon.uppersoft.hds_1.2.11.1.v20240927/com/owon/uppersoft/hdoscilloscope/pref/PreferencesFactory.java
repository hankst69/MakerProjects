package com.owon.uppersoft.hdoscilloscope.pref;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.Properties;

public class PreferencesFactory {
   private File confDir;
   private String prefFilePath;

   public PreferencesFactory(String confDirPath, String prefFilePath) {
      this.confDir = new File(confDirPath);
      this.prefFilePath = prefFilePath;

      try {
         this.confDir = this.confDir.getCanonicalFile();
      } catch (IOException var4) {
         var4.printStackTrace();
      }

      this.confDir.mkdirs();
   }

   public File confDir() {
      return this.confDir;
   }

   public Configuration getConfiguration() {
      Configuration con = new Configuration();
      File file = new File(this.confDir, this.prefFilePath);
      if (file.exists() && file.isFile()) {
         Properties p = new Properties();

         try {
            p.load(new FileInputStream(file));
         } catch (FileNotFoundException var5) {
            var5.printStackTrace();
         } catch (IOException var6) {
            var6.printStackTrace();
         }

         con.loadConfigurationFromProperties(p);
         return con;
      } else {
         return con;
      }
   }

   public void persistConfiguration(Configuration con) {
      Properties p = new Properties();
      con.persistConfigurationToProperties(p);
      File file = new File(this.confDir, this.prefFilePath);

      try {
         p.store(new FileOutputStream(file), null);
      } catch (FileNotFoundException var5) {
         var5.printStackTrace();
      } catch (IOException var6) {
         var6.printStackTrace();
      }
   }

   public static void main_hide(String[] args) {
      PreferencesFactory pf = new PreferencesFactory("conf", "pref.properties");
      Configuration con = pf.getConfiguration();
      System.out.println(con);
      con.locale = Locale.SIMPLIFIED_CHINESE;
      pf.persistConfiguration(con);
   }
}
