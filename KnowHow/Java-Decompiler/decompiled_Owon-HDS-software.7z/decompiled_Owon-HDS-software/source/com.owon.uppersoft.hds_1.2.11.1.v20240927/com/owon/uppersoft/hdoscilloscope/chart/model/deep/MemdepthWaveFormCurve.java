package com.owon.uppersoft.hdoscilloscope.chart.model.deep;

import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.chart.model.PrototypeWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;

public class MemdepthWaveFormCurve extends PrototypeWaveFormCurve {
   private AbstMemEngine dren;
   private Pixel4in1Engine p4;
   private Pixel1Engine p1;
   private boolean isNeedCom;
   protected double x0;
   protected double y0;
   protected double xpp;
   protected double ypp;
   protected double xscale;
   protected double yscale;
   protected double lastScale;
   protected double absoluteScaleY;
   protected double intZeroYPoint;

   public MemdepthWaveFormCurve(WaveForm wf, WaveFormFileCurve fileCurve, WFReg wfreg) {
      super(wf, fileCurve, wfreg);
   }

   protected void assureP1() {
      if (this.p1 == null) {
         this.p1 = new Pixel1Engine(this.wffc.getDrawingPanel(), this);
      }
   }

   @Override
   public int getCurveType() {
      return 1;
   }

   @Override
   public boolean isChannel() {
      return true;
   }

   protected boolean isDataNum4xLargerThanFullScreen() {
      return !((double)(4 * this.dren.getSize().x) * this.xscale > (double)this.wf.getIntFullScreenDataNum());
   }

   @Override
   public void applyToolComposite() {
      Platform.getPlatform().getCenter().getToolCom().applyProtoWFC(this, false);
   }

   public double getAbsoluteScaleY() {
      return this.absoluteScaleY;
   }

   @Override
   protected void initPoints(WaveFormFileCurve fileCurve) {
      this.x0 = 0.0;
      this.xpp = 0.25;
      this.lastScale = this.xscale = 1.0;
      this.absoluteScaleY = this.yscale = 1.0;
      this.ypp = (double)fileCurve.getDrawingPanel().getSize().y / (double)this.intFullScreenYPointNum;
      this.intZeroYPoint = (double)((fileCurve.getWaveFormFile().getYPointNum() >> 1) - this.wf.getIntZeroYPoint());
      this.y0 = this.intZeroYPoint * this.ypp;
      this.assureP1();
      this.dren = this.p1;
      if (!this.isDataNum4xLargerThanFullScreen()) {
         this.isNeedCom = false;
         if (this.wf.isLowMove()) {
            long offset = (long)(this.wf.getIntADCollectionNum() - this.wf.getIntLowMoveNum() - this.wf.getScreenStartLocation());
            this.x0 = (double)(offset * (long)this.dren.getSize().x / (long)this.wf.getIntFullScreenDataNum());
         } else {
            long offset = (long)this.wf.getScreenStartLocation();
            if (offset > 0L) {
               this.x0 = (double)(-offset * (long)this.dren.getSize().x / (long)this.wf.getIntFullScreenDataNum());
            }
         }

         this.dren.setXScale(1.0);
      } else {
         this.isNeedCom = true;
         this.dren = this.p4 = new Pixel4in1Engine(fileCurve.getDrawingPanel(), this);
      }
   }

   @Override
   public void setBaseIdxOnX(int index) {
      double timeBase = this.pm.getTimeBaseValue_mS(index);
      this.currentTimeBaseIndex = index;
      this.lastScale = this.xscale;
      this.xscale = this.basicTimeBase / timeBase;
      if (this.isDataNum4xLargerThanFullScreen() && this.isNeedCom) {
         this.dren = this.p4;
      } else {
         this.dren = this.p1;
      }

      this.dren.setXScale(this.xscale);
   }

   public boolean isNeedCom() {
      return this.isNeedCom;
   }

   @Override
   public ScalableDrawEngine getScalableDrawEngine() {
      return this.dren;
   }
}
