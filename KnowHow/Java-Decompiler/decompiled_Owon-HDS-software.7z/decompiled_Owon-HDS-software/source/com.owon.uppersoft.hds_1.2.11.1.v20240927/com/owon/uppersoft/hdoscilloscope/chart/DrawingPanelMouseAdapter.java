package com.owon.uppersoft.hdoscilloscope.chart;

import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.frame.MouseDragger;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Display;

public class DrawingPanelMouseAdapter extends MouseDragger {
   private Cursor horizontalResizeCursor;
   private Cursor verticalResizeCursor;
   private Cursor defaultCursor;
   public static final int MARK_SELECTED_MODE = 0;
   public static final int CURVE_SELECTED_MODE = 1;
   public static final int NO_SELECTED_MODE = -1;
   private int selectedMode;
   private Point draggedPoint;
   private DrawingPanel dp;
   private Point tmpPoint;
   private Platform platform;

   public DrawingPanelMouseAdapter(DrawingPanel dp) {
      Display display = dp.getComposite().getDisplay();
      this.horizontalResizeCursor = display.getSystemCursor(7);
      this.verticalResizeCursor = display.getSystemCursor(9);
      this.defaultCursor = display.getSystemCursor(0);
      this.dp = dp;
      this.selectedMode = -1;
      this.draggedPoint = new Point(0, 0);
      this.tmpPoint = new Point(0, 0);
      this.platform = Platform.getPlatform();
   }

   @Override
   public void mouseDoubleClick(MouseEvent e) {
      this.platform.getActionFactory().bgColor.doSetBackground();
   }

   @Override
   public void mousePress(MouseEvent e) {
      this.draggedPoint.x = e.x;
      this.draggedPoint.y = e.y;
      if (this.selectedMode == 1) {
         WaveFormCurve pointSelectedCurve = this.dp.getWaveFormFileCurve().getPointSelectedCurve();
         this.platform.getCenter().selectOnTable(pointSelectedCurve);
      }
   }

   @Override
   public void mouseRelease(MouseEvent e) {
      this.selectedMode = -1;
      this.dp.setCursor(this.defaultCursor);
      this.dp.setDragging(false);
      this.dp.setDragMark(false);
   }

   @Override
   public void mouseDrag(MouseEvent e) {
      double zeroXoffset = (double)(e.x - this.draggedPoint.x);
      this.draggedPoint.x = e.x;
      this.draggedPoint.y = e.y;
      switch (this.selectedMode) {
         case -1:
         default:
            return;
         case 0:
            this.dp.setDragMark(true);
            this.dp.getMarkDraw().setSelectedMarkLocation(this.draggedPoint);
            this.platform.getCenter().updateMarksLocation();
            this.dp.redraw();
            return;
         case 1:
            WaveFormCurve curve = this.dp.getWaveFormFileCurve().getPointSelectedCurve();
            if (curve.isChannel()) {
               WaveFormFileCurve wffc = this.dp.getWaveFormFileCurve();

               for (WaveFormCurve wfc : wffc.wfc_collect()) {
                  if (wfc.isChannel()) {
                     wfc.getScalableDrawEngine().setZeroXoffset(zeroXoffset);
                  }
               }
            } else {
               this.dp.setDragging(true);
               curve.getScalableDrawEngine().setZeroXoffset(zeroXoffset);
            }

            this.platform.getCenter().updateMarksLocation();
            this.dp.redraw();
      }
   }

   @Override
   public void mouseMoveWithoutDrag(MouseEvent e) {
      this.tmpPoint.x = e.x;
      this.tmpPoint.y = e.y;
      int selected = this.dp.getMarkDraw().isMarksSelected(this.tmpPoint);
      switch (selected) {
         case -1:
         default:
            if (this.dp.getWaveFormFileCurve().isPointSelected(this.tmpPoint)) {
               this.selectedMode = 1;
               this.dp.setCursor(this.verticalResizeCursor);
               return;
            }

            boolean flag = this.selectedMode != -1;
            if (flag) {
               this.dp.setCursor(this.defaultCursor);
               this.selectedMode = -1;
            }

            return;
         case 0:
            this.selectedMode = 0;
            this.dp.setCursor(this.horizontalResizeCursor);
            return;
         case 1:
            this.selectedMode = 0;
            this.dp.setCursor(this.verticalResizeCursor);
      }
   }
}
