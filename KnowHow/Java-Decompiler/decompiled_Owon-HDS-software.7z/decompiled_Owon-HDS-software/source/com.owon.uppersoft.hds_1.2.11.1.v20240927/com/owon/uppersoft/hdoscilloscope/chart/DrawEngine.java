package com.owon.uppersoft.hdoscilloscope.chart;

import com.owon.uppersoft.hdoscilloscope.chart.model.deep.Pixel;
import com.owon.uppersoft.hdoscilloscope.pref.Reg;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.swt.graphics.Point;

public class DrawEngine implements ScalableDrawEngine {
   private DrawingPanel dp;
   protected WFReg wfreg;
   protected AbstWFC curve;
   protected List<Pixel> pts;
   protected double xpp;
   protected double ypp;
   protected double x0;
   protected double y0;
   protected double xscale;
   protected double absoluteScaleY;
   protected double lastScaleX;
   protected int[] adc;
   protected int start;
   protected int len;
   protected double zeroXoffset;
   protected double zeroYoffset;
   public static final int DefaultNoAction = 0;
   public static final int DefaultXScale = 1;
   public static final int DefaultYScale = 2;
   public static final int DefaultZeroYOffset = 3;
   public static final int DefaultZeroXOffset = 4;
   public static final int DefaultDatasUpdate = 5;

   public DrawEngine(DrawingPanel dp, AbstWFC curve) {
      this.dp = dp;
      this.curve = curve;
      this.wfreg = curve.getWFReg();
   }

   @Override
   public Point getSize() {
      return this.dp.getSize();
   }

   public List<Pixel> getPointSet() {
      return this.pts;
   }

   public void initPts(int[] adc, int start, int len, double x0, double y0, double xpp, double ypp, double xscale, double absoluteScaleY) {
      this.adc = adc;
      this.start = start;
      this.len = len;
      this.x0 = x0;
      if (Reg.AutoApplyZeroLocation) {
         y0 = this.wfreg.getZeroLocRate() * (double)this.getSize().y;
      }

      this.y0 = y0;
      this.xpp = xpp;
      this.ypp = ypp;
      this.xscale = xscale;
      this.lastScaleX = xscale;
      this.absoluteScaleY = absoluteScaleY;
      this.pts = new ArrayList<>(len);
      double pixXinterval = xpp * xscale;
      double pixYperPoint = ypp * absoluteScaleY;
      if (this.wfreg.isInverted()) {
         pixYperPoint = -pixYperPoint;
      }

      int end = start + len;

      for (int i = start; i < end; i++) {
         int x = (int)(x0 + (double)i * pixXinterval);
         int y = (int)(y0 - (double)adc[i] * pixYperPoint);
         Pixel p = new Pixel(x, y);
         this.pts.add(p);
      }
   }

   public void initPts(double x0, double y0, double xpp, double ypp, double xscale, double absoluteScaleY) {
      int[] adc = this.curve.getWaveForm().getIntADCollection();
      int start = 0;
      int len = adc.length;
      this.initPts(adc, start, len, x0, y0, xpp, ypp, xscale, absoluteScaleY);
   }

   public void initPts(int[] adc, int start, int len, double x0, double y0, double xpp, double ypp) {
      this.initPts(adc, start, len, x0, y0, xpp, ypp, 1.0, 1.0);
   }

   @Override
   public void resizeTo(Point lsz, Point sz) {
      if (lsz.x != 0 && lsz.y != 0 && sz.x != 0 && sz.y != 0) {
         boolean xr = false;
         boolean yr = false;
         if (lsz.x != sz.x) {
            xr = true;
         }

         if (lsz.y != sz.y) {
            yr = true;
         }

         if (xr & yr) {
            int length = this.pts.size();
            double rx = (double)sz.x / (double)lsz.x;
            this.x0 *= rx;
            this.xpp *= rx;
            double ry = (double)sz.y / (double)lsz.y;
            this.y0 *= ry;
            this.ypp *= ry;
            double pixXinterval = this.xpp * this.xscale;
            double pixYperPoint = this.ypp * this.absoluteScaleY;

            for (int i = 0; i < length; i++) {
               Pixel p = this.pts.get(i);
               p.x = (int)(this.x0 + (double)i * pixXinterval);
               p.y = (int)(this.y0 - (double)this.adc[i] * pixYperPoint);
            }
         } else if (xr) {
            int length = this.pts.size();
            double rx = (double)sz.x / (double)lsz.x;
            this.x0 *= rx;
            this.xpp *= rx;
            double pixXinterval = this.xpp * this.xscale;

            for (int i = 0; i < length; i++) {
               Pixel p = this.pts.get(i);
               double locationX = (double)i * pixXinterval + this.x0;
               p.x = (int)locationX;
            }
         } else if (yr) {
            double ry = (double)sz.y / (double)lsz.y;
            this.y0 *= ry;
            this.ypp *= ry;
            double pixYperPoint = this.ypp * this.absoluteScaleY;
            int end = this.start + this.len;
            int i = 0;

            for (int j = this.start; j < end; j++) {
               Pixel p = this.pts.get(i);
               double locationY = this.y0 - (double)this.adc[j] * pixYperPoint;
               p.y = (int)locationY;
               i++;
            }
         }
      }
   }

   @Override
   public void setInverted(boolean invert) {
      this.wfreg.setInverted(invert);
      this.datasUpdate();
   }

   @Override
   public double getZeroXLocation() {
      return this.x0;
   }

   @Override
   public double getZeroYLocation() {
      return this.y0;
   }

   @Override
   public void setZeroXoffset(double zeroXoffset) {
      this.zeroXoffset = zeroXoffset;
      this.x0 += zeroXoffset;
      this.presetCurve(4);
   }

   @Override
   public void setZeroYLocation(double zeroYLocation) {
      Reg.AutoApplyZeroLocation = false;
      this.zeroYoffset = zeroYLocation - this.y0;
      this.y0 = zeroYLocation;
      this.wfreg.setZeroLocRate(this.y0 / (double)this.getSize().y);
      this.presetCurve(3);
   }

   @Override
   public void setXScale(double xscale) {
      this.xscale = xscale;
      this.presetCurve(1);
   }

   @Override
   public void setAbsoluteScaleY(double absoluteScaleY) {
      this.absoluteScaleY = absoluteScaleY;
      this.presetCurve(2);
   }

   @Override
   public double getXScale() {
      return this.xscale;
   }

   @Override
   public double getAbsoluteScaleY() {
      return this.absoluteScaleY;
   }

   @Override
   public double getPixYPerPoint() {
      return this.ypp;
   }

   public void datasUpdate() {
      this.presetCurve(5);
   }

   private void presetCurve(int actionStatus) {
      int length = this.pts.size();
      switch (actionStatus) {
         case 0:
         default:
            break;
         case 1:
            Point sz = this.getSize();
            double halfBoundWidth = (double)sz.x / 2.0;
            this.x0 = halfBoundWidth - (halfBoundWidth - this.x0) / this.lastScaleX * this.xscale;
            double pixXinterval = this.xpp * this.xscale;

            for (int i = 0; i < length; i++) {
               Pixel p = this.pts.get(i);
               double locationX = (double)i * pixXinterval + this.x0;
               p.x = (int)locationX;
            }

            this.lastScaleX = this.xscale;
            break;
         case 2:
            double pixYperPoint = this.ypp * this.absoluteScaleY;
            int end = this.start + this.len;
            int i = 0;

            for (int j = this.start; j < end; j++) {
               Pixel p = this.pts.get(i);
               double locationY = this.y0 - (double)this.adc[j] * pixYperPoint;
               p.y = (int)locationY;
               i++;
            }
            break;
         case 3:
            int offset = (int)this.zeroYoffset;

            for (int i = 0; i < length; i++) {
               Pixel p = this.pts.get(i);
               p.y += offset;
            }
            break;
         case 4:
            int offset = (int)this.zeroXoffset;

            for (int i = 0; i < length; i++) {
               Pixel p = this.pts.get(i);
               p.x += offset;
            }
            break;
         case 5:
            double pixYperPoint = this.ypp * this.absoluteScaleY;
            if (this.wfreg.isInverted()) {
               pixYperPoint = -pixYperPoint;
            }

            int end = this.start + this.len;
            int i = this.start;

            for (int j = 0; i < end; j++) {
               Pixel p = this.pts.get(j);
               p.y = (int)(this.y0 - (double)this.adc[i] * pixYperPoint);
               i++;
            }
      }
   }

   @Override
   public boolean isPointSelected(Point p) {
      int x = p.x;
      int y = p.y;
      List<Pixel> pointSet = this.getPointSet();
      int length = pointSet.size();
      int minX = pointSet.get(0).x;
      int maxX = pointSet.get(length - 1).x;
      if (x >= minX + 1 && x <= maxX - 1) {
         double pixXinterval = this.xpp * this.xscale;
         int index = (int)(((double)x - this.x0) / pixXinterval);
         if (index < 0) {
            index = 0;
         }

         if (index >= length) {
            index = length - 1;
         }

         int y1;
         int y3;
         if (index != length - 1) {
            y1 = pointSet.get(index).y;
            y3 = pointSet.get(index + 1).y;
         } else {
            y1 = pointSet.get(index - 1).y;
            y3 = pointSet.get(index).y;
         }

         int y2 = (y1 + y3) / 2;
         boolean flag2 = (y2 + 2 - y) * (y2 - 2 - y) <= 0;
         boolean flag1 = (y1 - y) * (y3 - y) <= 0;
         return flag1 || flag2;
      } else {
         return false;
      }
   }

   @Override
   public void draw(GraphicContext gx) {
      WaveFormCurveRenderer.draw(this.curve, this.pts, gx);
   }
}
