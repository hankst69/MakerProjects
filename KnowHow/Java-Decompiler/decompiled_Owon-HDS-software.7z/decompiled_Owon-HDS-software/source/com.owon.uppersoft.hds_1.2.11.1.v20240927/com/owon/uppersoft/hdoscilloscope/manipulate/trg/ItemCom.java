package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

public class ItemCom extends Composite implements Localizable2 {
   private Button sign;
   private Spinner spinner;
   private Combo unit;
   private int index;
   private Label lblNewLabel;
   private Item item;
   private ManipulateControl mc;

   public ItemCom(Composite parent, int style, Item item, ManipulateControl mc) {
      super(parent, style);
      this.item = item;
      this.mc = mc;
      this.setLayout(new RowLayout(256));
      if (item.getLbName() != null) {
         this.lblNewLabel = new Label(this, 0);
         this.lblNewLabel.setLayoutData(new RowData(70, -1));
      }

      this.sign = new Button(this, 0);
      this.sign.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ItemCom.this.setSign();
         }
      });
      this.setSign();
      this.spinner = new Spinner(this, 2048);
      this.spinner.setMinimum(0);
      this.spinner.setMaximum(1000);
      this.unit = new Combo(this, 8);
      this.unit.setItems(item.getUnits());
      this.unit.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ItemCom.this.send();
         }
      });
      this.unit.select(0);
   }

   private void setSign() {
      String[] signs = this.item.getSigns();
      if (signs != null && signs.length != 0) {
         if (this.index >= signs.length) {
            this.index = 0;
         }

         this.sign.setText(signs[this.index++]);
      } else {
         this.sign.setVisible(false);
      }
   }

   private void send() {
      String s = this.item.getCmdPrefix() + " " + this.sign.getText() + this.spinner.getText() + this.unit.getText();
      this.mc.send(s);
   }

   public void localize(ResourceBundle bundle) {
      if (this.item.getLbName() != null) {
         this.lblNewLabel.setText(bundle.getString(this.item.getLbName()));
      }
   }
}
