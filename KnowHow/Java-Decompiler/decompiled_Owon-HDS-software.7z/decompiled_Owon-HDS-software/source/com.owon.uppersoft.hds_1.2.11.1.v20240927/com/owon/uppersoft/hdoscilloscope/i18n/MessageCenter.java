package com.owon.uppersoft.hdoscilloscope.i18n;

public interface MessageCenter {
   String ErrDefault = "Err.Default";
   String ErrFileUnwriteable = "Err.FileUnwriteable";
   String ErrFileUnreadable = "Err.FileUnreadable";
   String ErrFileUncreatable = "Err.FileUncreatable";
   String ErrNotBINFile = "Err.NotBINFile";
   String ErrFileUnsavable = "Err.FileUnsavable";
   String ErrFileNotExist = "Err.FileNotExist";
   String ErrSerialConnect = "Err.SerialConnect";
   String ErrUSBConnect = "Err.USBConnect";
   String ErrLANConnect = "Err.LANConnect";
   String ErrBadContentFile = "Err.BadContentFile";
   String ErrBadFormatFile = "Err.BadFormatFile";
   String ErrUnknown = "Err.Unknown";
   String ErrStopState = "Err.StopState";
   String InfoDefault = "Info.Default";
   String InfoBMPReceive = "Info.BMPReceive";
   String InfoImageSaved = "Info.ImageSaved";
   String InfoIfPrintBG = "Info.IfPrintBG";
   String InfoFileExist = "Info.FileExist";
   String InfoXYModeUnsupported = "Info.XYModeUnsupported";
   String InfoFileSaved = "Info.FileSaved";
   String InfoDepMemXLSPrompt = "Info.DepMemXLSPrompt";
   String InfoNoFileLoop = "Info.NoFileLoop";
   String WarnDefault = "Warn.Default";
   String WarnBMPReceive = "Warn.BMPReceive";
   String OptionsYes = "Options.Yes";
   String OptionsNo = "Options.No";
   String OptionsOK = "Options.OK";
   String OptionsCancel = "Options.Cancel";
}
