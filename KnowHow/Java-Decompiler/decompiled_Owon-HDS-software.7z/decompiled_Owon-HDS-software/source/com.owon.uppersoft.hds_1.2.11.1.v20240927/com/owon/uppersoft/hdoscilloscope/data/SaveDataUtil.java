package com.owon.uppersoft.hdoscilloscope.data;

import com.owon.uppersoft.common.utils.FileUtil;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.io.File;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

public class SaveDataUtil {
   public void saveData(DataTableDialog dtd, WaveFormFile wff) {
      List<WaveForm> list = dtd.getSelectedChannels();
      Shell shell = dtd.getShell();
      if (list.size() == 0) {
         ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
         String msg = bundle.getString("DT.promptSelection");
         MessageDialog.openInformation((Shell)shell.getParent(), "", msg);
      } else {
         FileDialog fd = new FileDialog(shell, 8192);
         String wildcard = "*.";
         String[] ss = new String[]{wildcard + "xls", wildcard + "txt", wildcard + "csv"};
         fd.setFilterExtensions(ss);
         ss = new String[]{"Microsoft Office Excel Workbook(*.xls)", "Text(*.txt)", "Comma Separated Value Text(*.csv)"};
         fd.setFilterNames(ss);
         String path = fd.open();
         if (path != null) {
            ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
            String infoDefault = bundle.getString("Info.Default");
            String infoSaved = bundle.getString("Info.FileSaved");
            String ext = FileUtil.getExtension(path);
            File file = new File(path);
            IDataOutput ido = wff.getDataOutput();
            boolean success = false;
            if (ext.equalsIgnoreCase("csv")) {
               success = ido.outCSV(list, dtd, file, wff);
               if (success) {
                  MessageDialog.openInformation(shell, infoDefault, infoSaved + path);
               }
            } else if (ext.equalsIgnoreCase("xls")) {
               success = ido.outXLS(list, dtd, file, wff);
               if (success) {
                  if (dtd.getWff().containMemDepth()) {
                     infoSaved = bundle.getString("Info.DepMemXLSPrompt") + infoSaved;
                  }

                  MessageDialog.openInformation(shell, infoDefault, infoSaved + path);
               }
            } else if (ext.equalsIgnoreCase("txt")) {
               success = ido.outText(list, dtd, file, wff);
               if (success) {
                  MessageDialog.openInformation(shell, infoDefault, infoSaved + path);
               }
            }
         }
      }
   }
}
