package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.communication.PortSetting;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;

public class PortsAction extends DefaultAction {
   public PortsAction(String id) {
      super(id);
   }

   public void run() {
      Platform platform = Platform.getPlatform();
      Configuration conf = platform.getConfiguration();
      if (!conf.haveClickCOMM) {
         this.setImage(platform.getImageShop().getImage("ports.gif"));
         conf.haveClickCOMM = true;
      }

      new PortSetting(Platform.getPlatform().getShell(), platform.getConfiguration()).open();
   }
}
