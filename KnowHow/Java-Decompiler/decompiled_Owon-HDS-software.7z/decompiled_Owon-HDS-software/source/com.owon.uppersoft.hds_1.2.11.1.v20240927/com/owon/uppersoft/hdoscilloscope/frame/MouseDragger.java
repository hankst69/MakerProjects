package com.owon.uppersoft.hdoscilloscope.frame;

import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;

public class MouseDragger implements MouseListener, MouseMoveListener {
   private boolean down;
   private boolean shutdown;

   public void mouseDoubleClick(MouseEvent e) {
   }

   public boolean isDown() {
      return this.down;
   }

   public void setShutdown(boolean shutdown) {
      this.shutdown = shutdown;
   }

   public boolean isShutdown() {
      return this.shutdown;
   }

   public void mouseDown(MouseEvent e) {
      if (!this.shutdown) {
         this.down = true;
         this.mousePress(e);
      }
   }

   public void mouseUp(MouseEvent e) {
      if (!this.shutdown) {
         this.down = false;
         this.mouseRelease(e);
      }
   }

   public void mouseMove(MouseEvent e) {
      if (!this.shutdown) {
         if (this.down) {
            this.mouseDrag(e);
         } else {
            this.mouseMoveWithoutDrag(e);
         }
      }
   }

   public void mousePress(MouseEvent e) {
   }

   public void mouseRelease(MouseEvent e) {
   }

   public void mouseDrag(MouseEvent e) {
   }

   public void mouseMoveWithoutDrag(MouseEvent e) {
   }
}
