package com.owon.uppersoft.hdoscilloscope.action.instance2;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class KeepAction extends DefaultAction {
   public KeepAction(String id) {
      super(id);
   }

   public void run() {
      Platform.getPlatform();
      Platform.getPlatform().getActionFactory().loopControl.DoLoop();
   }
}
