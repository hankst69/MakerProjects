package com.owon.uppersoft.hdoscilloscope.data.normal;

import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;

public class DefaultWF extends WaveForm {
   private WaveFormFile dwff;

   public DefaultWF(WaveFormFile wff) {
      this.dwff = wff;
      this.prepareFFTInfo();
   }

   @Override
   public WaveFormFile getWaveFormFile() {
      return this.dwff;
   }

   @Override
   public WaveFormCurve createWFC(WaveFormFileCurve wffc, WFReg wr) {
      WaveFormCurve wfc;
      if (this.isDepMem()) {
         wfc = new DefaultMemdepthWFC(this, wffc, wr);
      } else {
         wfc = new DefaultAlphaWFC(this, wffc, wr);
      }

      return wfc;
   }

   @Override
   public void setDblPeriod(double dblPeriod) {
      super.setDblPeriod(dblPeriod);
   }
}
