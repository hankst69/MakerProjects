package com.owon.uppersoft.hdoscilloscope.chart.model.fft.math;

public class Complex implements IComplex {
   public int re;
   public int im;

   public Complex() {
   }

   public Complex(int r, int i) {
      this.re = r;
      this.im = i;
   }

   @Override
   public final double re() {
      return (double)this.re;
   }

   @Override
   public final double im() {
      return (double)this.im;
   }

   public final double abs() {
      return Math.hypot((double)this.re, (double)this.im);
   }

   public static final void Add(Complex a, Complex b, Complex c) {
      c.re = a.re + b.re;
      c.im = a.im + b.im;
   }

   public static final void Sub(Complex a, Complex b, Complex c) {
      c.re = a.re - b.re;
      c.im = a.im - b.im;
   }

   public static final void Mul_r10(Complex a, int r, int i, Complex c) {
      c.re = a.re * r - a.im * i >> 10;
      c.im = a.re * i + a.im * r >> 10;
   }

   public static final void Mul_r10(Complex a, Complex b, Complex c) {
      c.re = a.re * b.re - a.im * b.im >> 10;
      c.im = a.re * b.im + a.im * b.re >> 10;
   }

   public static final void Mul(Complex a, Complex b, Complex c) {
      c.re = a.re * b.re - a.im * b.im;
      c.im = a.re * b.im + a.im * b.re;
   }

   public final void to1() {
      if (Math.abs(this.re) < 1) {
         this.re = 1;
      }

      if (Math.abs(this.im) < 1) {
         this.im = 1;
      }
   }

   public Complex times(Complex b) {
      Complex c = new Complex();
      Mul(this, b, c);
      return c;
   }

   public Complex minus(Complex b) {
      Complex c = new Complex();
      Sub(this, b, c);
      return c;
   }

   public Complex plus(Complex b) {
      Complex c = new Complex();
      Add(this, b, c);
      return c;
   }

   @Override
   public String toString() {
      return this.re + "," + this.im;
   }

   public static void main(String[] args) {
      Complex a = new Complex();
      Complex b = new Complex(-3, 4);
      System.out.println("a            = " + a);
      System.out.println("b            = " + b);
      System.out.println("Re(a)        = " + a.re);
      System.out.println("Im(a)        = " + a.im);
      System.out.println("b + a        = " + b.plus(a));
      System.out.println("a - b        = " + a.minus(b));
      System.out.println("a * b        = " + a.times(b));
      System.out.println("b * a        = " + b.times(a));
      System.out.println("|a|          = " + a.abs());
   }
}
