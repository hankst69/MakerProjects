package com.owon.uppersoft.hdoscilloscope.communication.usb.rapid;

import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.io.File;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class ShowImageDialog2 {
   private Shell parent;
   private Shell shell;
   private Display display;
   private Label composite;
   private Text text;
   private String imagePath;
   private Image image;

   public static void main(String[] args) {
      try {
         ShowImageDialog2 window = new ShowImageDialog2(null, "");
         window.open();
      } catch (Exception var2) {
         var2.printStackTrace();
      }
   }

   public ShowImageDialog2(Shell parent, String imagePath) {
      this.parent = parent;
      this.imagePath = imagePath;
   }

   public ShowImageDialog2(Shell parent, Image img) {
      this.parent = parent;
      this.image = img;
      this.imagePath = "";
   }

   public void open() {
      this.display = Display.getDefault();
      this.display.asyncExec(new Runnable() {
         @Override
         public void run() {
            ShowImageDialog2.this.createContents();
            ShowImageDialog2.this.shell.pack();
            ShellUtil.centerLoc(ShowImageDialog2.this.shell);
            ShowImageDialog2.this.shell.open();

            while (!ShowImageDialog2.this.shell.isDisposed()) {
               if (!ShowImageDialog2.this.display.readAndDispatch()) {
                  ShowImageDialog2.this.display.sleep();
               }
            }
         }
      });
   }

   protected void createContents() {
      this.shell = new Shell(this.parent, 2080);
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 2;
      this.shell.setLayout(gridLayout);
      if (this.image == null) {
         this.image = new Image(this.display, this.imagePath);
      }

      this.composite = new Label(this.shell, 0);
      this.composite.setLayoutData(new GridData(16777216, 4, true, true, 2, 1));
      this.composite.setImage(this.image);
      this.text = new Text(this.shell, 10);
      this.text.setLayoutData(new GridData(16384, 16777216, true, false));
      this.text.setText(this.imagePath);
      Button button = new Button(this.shell, 0);
      button.setVisible(false);
      button.setLayoutData(new GridData());
      button.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ShowImageDialog2.this.shell.close();
         }
      });
      button.setText(ResourceBundleProvider.getMessageLibResourceBundle().getString("MF.ok"));
   }

   public void changeImage(final String imagePath) {
      this.image = new Image(this.display, imagePath);
      this.display.asyncExec(new Runnable() {
         @Override
         public void run() {
            ShowImageDialog2.this.composite.setImage(ShowImageDialog2.this.image);
            ShowImageDialog2.this.text.setText(imagePath);
         }
      });
   }

   public void changeImage(final File file) {
      this.image = new Image(this.display, file.getPath());
      this.display.asyncExec(new Runnable() {
         @Override
         public void run() {
            ShowImageDialog2.this.composite.setImage(ShowImageDialog2.this.image);
            ShowImageDialog2.this.text.setText(file.getPath());
         }
      });
   }

   public void changeImage(Image img) {
      this.image = img;
      this.display.asyncExec(new Runnable() {
         @Override
         public void run() {
            ShowImageDialog2.this.composite.setImage(ShowImageDialog2.this.image);
            ShowImageDialog2.this.text.setText("");
         }
      });
   }

   public boolean isDispose() {
      return this.shell.isDisposed();
   }

   public void close() {
      this.display.asyncExec(new Runnable() {
         @Override
         public void run() {
            ShowImageDialog2.this.shell.close();
         }
      });
   }

   public void setVisible(final boolean b) {
      this.display.asyncExec(new Runnable() {
         @Override
         public void run() {
            ShowImageDialog2.this.shell.setVisible(b);
         }
      });
   }
}
