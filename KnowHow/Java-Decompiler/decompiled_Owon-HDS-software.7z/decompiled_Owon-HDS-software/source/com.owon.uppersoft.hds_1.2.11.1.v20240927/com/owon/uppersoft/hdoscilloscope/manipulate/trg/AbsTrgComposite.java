package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import com.owon.uppersoft.hdoscilloscope.manipulate.detail2.TrgComposite;
import org.eclipse.swt.widgets.Composite;

public abstract class AbsTrgComposite extends Composite {
   protected TrgComposite tcom;

   public AbsTrgComposite(Composite parent, int style, TrgComposite tc) {
      super(parent, style);
      this.tcom = tc;
   }

   public AbsTrgComposite load(TrgControl tc) {
      this.loadTrgGroup(tc);
      return this;
   }

   protected abstract void loadTrgGroup(TrgControl var1);
}
