package com.owon.uppersoft.hdoscilloscope.chart.model.fft;

public enum WndType {
   hamming(IFFTRef.hamming),
   rectangle(IFFTRef.rectangle),
   blackman(IFFTRef.blackman),
   hanning(IFFTRef.hanning);

   private int[] mults;

   private WndType(int[] mults) {
      this.mults = mults;
   }

   public final void wnding(int[] adc, int start, int end, int len, int[] wnd_adc) {
      int half = len >> 1;
      int center = start + end >> 1;
      start = center - half;
      end = center + half;
      int i = start;

      for (int j = 0; i < end; j++) {
         wnd_adc[j] = adc[i] * this.mults[j] >> 16;
         i++;
      }
   }
}
