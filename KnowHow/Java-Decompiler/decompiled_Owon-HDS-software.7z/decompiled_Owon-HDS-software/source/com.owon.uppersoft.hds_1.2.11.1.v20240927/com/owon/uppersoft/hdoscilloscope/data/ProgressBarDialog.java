package com.owon.uppersoft.hdoscilloscope.data;

import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;

public class ProgressBarDialog {
   private Display display;
   private Shell shell;
   private Thread thread;
   private ProgressBar progressBar;
   private boolean isCancel = false;

   public void open() {
      this.display = Display.getDefault();
      this.createContents();
      this.shell.pack();
      ShellUtil.centerLoc(this.shell);
      this.shell.open();

      while (!this.shell.isDisposed()) {
         if (!this.display.readAndDispatch()) {
            this.display.sleep();
         }
      }
   }

   protected void createContents() {
      this.shell = new Shell(67616);
      this.shell.addShellListener(new ShellAdapter() {
         public void shellClosed(ShellEvent e) {
            ProgressBarDialog.this.isCancel = true;
         }
      });
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      this.shell.setText(bundle.getString("Options.process"));
      GridLayout gl_shell = new GridLayout(2, false);
      gl_shell.marginTop = 5;
      gl_shell.marginBottom = 5;
      gl_shell.marginRight = 5;
      gl_shell.marginLeft = 5;
      this.shell.setLayout(gl_shell);
      this.progressBar = new ProgressBar(this.shell, 0);
      GridData gd_progressBar = new GridData(4, 16777216, true, true, 1, 1);
      gd_progressBar.minimumWidth = 200;
      this.progressBar.setLayoutData(gd_progressBar);
      Button cancelButton = new Button(this.shell, 0);
      cancelButton.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      cancelButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ProgressBarDialog.this.isCancel = true;
         }
      });
      cancelButton.setText(bundle.getString("Options.Cancel"));
      this.executeThread();
   }

   private void executeThread() {
      this.thread = new Thread() {
         @Override
         public void run() {
            ProgressBarDialog.this.execute();
            ProgressBarDialog.this.display.syncExec(new Runnable() {
               @Override
               public void run() {
                  ProgressBarDialog.this.shell.close();
               }
            });
         }
      };
      this.thread.start();
   }

   protected void execute() {
   }

   public void setProgressMaximum(final int value) {
      this.display.syncExec(new Runnable() {
         @Override
         public void run() {
            ProgressBarDialog.this.progressBar.setMaximum(value);
         }
      });
   }

   public void addProgressValue(final int value) {
      this.display.syncExec(new Runnable() {
         @Override
         public void run() {
            ProgressBarDialog.this.progressBar.setSelection(ProgressBarDialog.this.progressBar.getSelection() + value);
         }
      });
   }

   public void cancel() {
      this.isCancel = true;
   }

   public boolean isCancel() {
      return this.isCancel;
   }

   public boolean isFinished() {
      return !this.isCancel;
   }
}
