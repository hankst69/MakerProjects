package com.owon.uppersoft.hdoscilloscope.util;

import com.owon.uppersoft.common.utils.StringPool;

public class SimpleStringFormatter {
   public static int DefaultLength = 16;
   public static char DefaultHoldPlace = ' ';
   private int length;
   private char holdPlace;
   public final String emptyblock;

   public SimpleStringFormatter() {
      this(DefaultLength, DefaultHoldPlace);
   }

   public SimpleStringFormatter(int length, char aHoldPlace) {
      this.length = length;
      this.holdPlace = aHoldPlace;
      StringBuilder sb = new StringBuilder();

      for (int i = 0; i < length; i++) {
         sb.append(this.holdPlace);
      }

      this.emptyblock = sb.toString();
   }

   public String valueToStringOnRight(int value) {
      return this.valueToStringOnRight(String.valueOf(value));
   }

   public String valueToStringOnRight(double value) {
      return this.valueToStringOnRight(String.valueOf(value));
   }

   public String valueToStringOnRight(String value) {
      if (value == null) {
         return this.emptyblock;
      } else {
         char[] charArray = this.emptyblock.toCharArray();
         char[] valueArray = value.toCharArray();
         int l = valueArray.length;
         System.arraycopy(valueArray, 0, charArray, this.length - l, l);
         return new String(charArray);
      }
   }

   public String valueToStringOnLeft(int value) {
      return this.valueToStringOnLeft(String.valueOf(value));
   }

   public String valueToStringOnLeft(double value) {
      return this.valueToStringOnLeft(String.valueOf(value));
   }

   public String valueToStringOnLeft(String value) {
      if (value == null) {
         return this.emptyblock;
      } else {
         char[] charArray = this.emptyblock.toCharArray();
         char[] valueArray = value.toCharArray();
         int l = valueArray.length;
         System.arraycopy(valueArray, 0, charArray, 0, l);
         return new String(charArray);
      }
   }

   public static void main_hide(String[] args) {
      SimpleStringFormatter ssf = new SimpleStringFormatter();
      StringBuilder sb = new StringBuilder();
      String ln = StringPool.LINE_SEPARATOR;
      sb.append(ssf.valueToStringOnRight(""));
      sb.append(ln);
      sb.append(ssf.valueToStringOnRight(4578));
      sb.append(ln);
      sb.append(ssf.valueToStringOnRight("CH1/10"));
      sb.append(ln);
      sb.append(ln);
      String a = null;
      sb.append(ssf.valueToStringOnRight(a));
      sb.append(ln);
      System.out.print(sb);
   }
}
