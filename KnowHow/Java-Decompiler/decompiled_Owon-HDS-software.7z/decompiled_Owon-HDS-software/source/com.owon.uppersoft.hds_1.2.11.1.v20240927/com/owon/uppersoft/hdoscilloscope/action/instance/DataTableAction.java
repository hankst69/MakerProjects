package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.data.DataTableDialog;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import java.util.ResourceBundle;

public class DataTableAction extends DefaultAction {
   private DataTableDialog dtd;

   public DataTableAction(String id) {
      super(id);
   }

   public void run() {
      Platform pf = Platform.getPlatform();
      if (this.isDtdExist()) {
         this.dtd.getShell().setActive();
      } else {
         this.dtd = new DataTableDialog(pf.getShell(), pf.getDrawingPanel().getWaveFormFileCurve().getWaveFormFile());
         this.dtd.open();
         this.dtd = null;
      }
   }

   private void localizeTable(ResourceBundle bundle) {
      if (this.dtd != null) {
         this.dtd.localize(bundle);
      }
   }

   public void shutdown() {
      if (this.isDtdExist()) {
         this.dtd.getShell().close();
      }
   }

   protected final boolean isDtdExist() {
      return this.dtd != null && !this.dtd.getShell().isDisposed();
   }

   public void localize(ResourceBundle bundle) {
      super.localize(bundle);
      this.localizeTable(bundle);
   }
}
