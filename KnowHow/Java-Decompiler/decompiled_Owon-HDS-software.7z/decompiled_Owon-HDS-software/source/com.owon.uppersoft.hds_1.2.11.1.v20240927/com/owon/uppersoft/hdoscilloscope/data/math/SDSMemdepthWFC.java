package com.owon.uppersoft.hdoscilloscope.data.math;

import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.deep.MemdepthWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;

public class SDSMemdepthWFC extends MemdepthWaveFormCurve {
   public SDSMemdepthWFC(WaveForm wf, WaveFormFileCurve fileCurve, WFReg wfreg) {
      super(wf, fileCurve, wfreg);
   }
}
