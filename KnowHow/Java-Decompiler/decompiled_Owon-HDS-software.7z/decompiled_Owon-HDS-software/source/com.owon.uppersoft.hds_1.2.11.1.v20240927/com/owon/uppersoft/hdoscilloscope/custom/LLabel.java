package com.owon.uppersoft.hdoscilloscope.custom;

import com.owon.uppersoft.common.aspect.Localizable2;
import java.util.ResourceBundle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

public class LLabel implements Localizable2 {
   private Label lbl;

   public LLabel(Composite parent, int style) {
      this.lbl = new Label(parent, style);
   }

   public void localize(ResourceBundle bundle) {
      this.lbl.setText(bundle.getString(this.lbl.getData().toString()));
   }

   public void setData(Object data) {
      this.lbl.setData(data);
   }

   public void setLayoutData(Object layoutData) {
      this.lbl.setLayoutData(layoutData);
   }
}
