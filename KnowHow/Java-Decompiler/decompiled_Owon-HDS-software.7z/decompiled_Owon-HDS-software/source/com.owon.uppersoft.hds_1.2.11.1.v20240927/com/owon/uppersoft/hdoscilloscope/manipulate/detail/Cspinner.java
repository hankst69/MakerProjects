package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Spinner;

public class Cspinner extends Composite {
   private boolean sign;
   private Button btnSign;
   private Spinner spinner;
   private int digits;

   public Cspinner(Composite parent, int style) {
      super(parent, style);
      GridLayout gridLayout = new GridLayout(2, false);
      gridLayout.horizontalSpacing = 0;
      gridLayout.marginHeight = 0;
      gridLayout.verticalSpacing = 0;
      gridLayout.marginWidth = 0;
      this.setLayout(gridLayout);
      this.btnSign = new Button(this, 0);
      this.btnSign.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            Cspinner.this.sign = !Cspinner.this.sign;
            if (Cspinner.this.sign) {
               Cspinner.this.btnSign.setText("+");
            } else {
               Cspinner.this.btnSign.setText("-");
            }
         }
      });
      this.sign = true;
      this.btnSign.setText("+");
      this.spinner = new Spinner(this, 2048);
      this.spinner.setIncrement(10);
      this.spinner.setMaximum(1000);
      this.spinner.setMinimum(1);
      this.setDigits(2);
      this.spinner.setSelection(10);
      this.spinner.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
   }

   public void EnableSign(boolean b) {
      this.btnSign.setEnabled(b);
   }

   public void setMaximum(int value) {
      this.spinner.setMaximum(value);
   }

   public void setMinimum(int value) {
      this.spinner.setMinimum(value);
   }

   public void setIncrement(int value) {
      this.spinner.setIncrement(value);
   }

   public double getSelection() {
      double i = (double)this.spinner.getSelection() / Math.pow(10.0, (double)this.digits);
      return this.sign ? i : -i;
   }

   public void setDigits(int value) {
      this.digits = value;
      this.spinner.setDigits(value);
   }
}
