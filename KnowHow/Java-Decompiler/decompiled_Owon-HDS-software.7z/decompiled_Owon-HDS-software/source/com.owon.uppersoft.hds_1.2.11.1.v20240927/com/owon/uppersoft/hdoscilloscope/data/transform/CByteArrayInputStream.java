package com.owon.uppersoft.hdoscilloscope.data.transform;

import com.owon.uppersoft.hdoscilloscope.util.DBG;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import sun.nio.ch.DirectBuffer;

public class CByteArrayInputStream {
   private ByteBuffer buf = null;
   private FileChannel fc = null;
   private File file = null;
   private boolean toDel = false;
   private RandomAccessFile raf;

   public CByteArrayInputStream(File file) {
      this(file, false);
   }

   public CByteArrayInputStream(File file, boolean toDel) {
      this.file = file;
      this.toDel = toDel;

      try {
         this.raf = new RandomAccessFile(file, "rw");
         this.fc = this.raf.getChannel();
         this.buf = this.fc.map(MapMode.READ_WRITE, 0L, file.length());
         this.buf.order(ByteOrder.LITTLE_ENDIAN);
      } catch (FileNotFoundException var4) {
         var4.printStackTrace();
      } catch (IOException var5) {
         var5.printStackTrace();
      }
   }

   public CByteArrayInputStream(File file, RandomAccessFile raf, boolean toDel) {
      this.file = file;
      this.raf = raf;
      this.toDel = toDel;

      try {
         this.fc = raf.getChannel();
         this.buf = this.fc.map(MapMode.READ_WRITE, 0L, file.length());
         this.buf.order(ByteOrder.LITTLE_ENDIAN);
      } catch (FileNotFoundException var5) {
         var5.printStackTrace();
      } catch (IOException var6) {
         var6.printStackTrace();
      }
   }

   public ByteBuffer buf() {
      return this.buf;
   }

   public CByteArrayInputStream(ByteBuffer buf) {
      this.buf = buf;
      this.toDel = false;
      this.buf.order(ByteOrder.LITTLE_ENDIAN);
   }

   public CByteArrayInputStream(byte[] array, int beg, int len) {
      this.buf = ByteBuffer.wrap(array, beg, len);
      ((Buffer)this.buf).position(len);
      ((Buffer)this.buf).flip();
      this.toDel = false;
      this.buf.order(ByteOrder.LITTLE_ENDIAN);
   }

   public File getFile() {
      return this.file;
   }

   protected void setToDel(boolean toDel) {
      this.toDel = toDel;
   }

   protected boolean isToDel() {
      return this.toDel;
   }

   public InputStream getInputStream() {
      if (this.buf.hasArray()) {
         return new ByteArrayInputStream(this.buf.array(), this.buf.position(), this.buf.limit());
      } else {
         try {
            return new FileInputStream(this.file);
         } catch (FileNotFoundException var2) {
            var2.printStackTrace();
            return null;
         }
      }
   }

   public RandomAccessFile getRandomAccessFile() {
      return this.raf;
   }

   public void dispose() {
      if (this.fc != null) {
         try {
            this.fc.close();
         } catch (IOException var2) {
            var2.printStackTrace();
         }

         if (this.buf instanceof DirectBuffer) {
            DirectBuffer db = (DirectBuffer)this.buf;
            db.cleaner().clean();
            DBG.dbgln("[RELEASE CByteArrayInputStream]");
         }

         if (this.toDel) {
            this.file.delete();
         }
      }
   }

   public final void get(byte[] bs, int beg, int len) {
      this.buf.get(bs, beg, len);
   }

   public final int byteAt(int i) {
      return this.buf.getShort(i);
   }

   public final int nextInt() {
      return this.buf.getInt();
   }

   public final short nextShort() {
      return this.buf.getShort();
   }

   public final int pointer() {
      return this.buf.position();
   }

   public final void reset(int offset) {
      ((Buffer)this.buf).position(offset);
   }

   public final void skip(int offset) {
      ((Buffer)this.buf).position(this.buf.position() + offset);
   }

   public final int available() {
      return this.buf.remaining();
   }

   public final byte nextByte() {
      return this.buf.get();
   }

   public final float nextFloat() {
      return this.buf.getFloat();
   }
}
