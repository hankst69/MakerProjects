package com.owon.uppersoft.hdoscilloscope.i18n;

import com.owon.uppersoft.hdoscilloscope.global.Platform;
import java.util.ResourceBundle;

public class ResourceBundleProvider {
   private static final String MESSAGELIB_BUNDLE = "com.owon.uppersoft.hdoscilloscope.i18n.OSCMsgLib";
   public static final String MESSAGELIB2_BUNDLE = "com.owon.uppersoft.hdoscilloscope.i18n.OSCMsgLib2";
   private static ResourceBundle msgBundle;
   private static ResourceBundle msgBundle2;
   private static MessageErrRunner mr;

   static {
      updateLocale();
   }

   public static void updateLocale() {
      msgBundle = ResourceBundle.getBundle("com.owon.uppersoft.hdoscilloscope.i18n.OSCMsgLib");
      msgBundle2 = ResourceBundle.getBundle("com.owon.uppersoft.hdoscilloscope.i18n.OSCMsgLib2");
   }

   public static ResourceBundle getMessageLibResourceBundle() {
      return msgBundle;
   }

   public static ResourceBundle getMessageLibResourceBundle2() {
      return msgBundle2;
   }

   public static String applyManufacture(String key) {
      if (Platform.getPlatform().getConfiguration().isNeutral()) {
         key = key + ".oem";
      } else {
         key = key + ".owon";
      }

      return key;
   }

   public static MessageErrRunner getMessageErrRunner() {
      if (mr == null) {
         mr = new MessageErrRunner();
      }

      return mr;
   }
}
