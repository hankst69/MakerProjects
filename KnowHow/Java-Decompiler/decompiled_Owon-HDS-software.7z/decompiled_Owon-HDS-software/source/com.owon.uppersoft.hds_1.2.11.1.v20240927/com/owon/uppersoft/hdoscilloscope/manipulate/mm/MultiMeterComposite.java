package com.owon.uppersoft.hdoscilloscope.manipulate.mm;

import com.owon.uppersoft.hdoscilloscope.custom.LObject;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import java.nio.ByteBuffer;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;

public class MultiMeterComposite extends Composite {
   private Combo cbb;
   protected Shell shell;
   MultiMeterComposite.MMa ta = new MultiMeterComposite.MMa();
   MultiMeterComposite.MMv tv = new MultiMeterComposite.MMv();
   MultiMeterComposite.MMr tr = new MultiMeterComposite.MMr();
   boolean lsn = false;
   private Button autobtn;
   private Button absbtn;
   private Button mAbtn;
   MMtype mmt;

   public MultiMeterComposite(Composite parent, int style) {
      super(parent, style);
      Composite composite_1 = new Composite(this, 0);
      composite_1.setBounds(10, 10, 390, 29);
      final Button aButton = new Button(composite_1, 8390672);
      aButton.setText("A");
      aButton.setBounds(10, 0, 83, 26);
      final Button vButton = new Button(composite_1, 8390672);
      vButton.setBounds(122, 0, 83, 26);
      vButton.setText("V");
      final Button rButton = new Button(composite_1, 8390672);
      rButton.setBounds(229, 0, 83, 26);
      rButton.setText("R");
      aButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (aButton.getSelection()) {
               MultiMeterComposite.this.swtichMMType(97);
            }
         }
      });
      vButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (vButton.getSelection()) {
               MultiMeterComposite.this.swtichMMType(118);
            }
         }
      });
      rButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (rButton.getSelection()) {
               MultiMeterComposite.this.swtichMMType(114);
            }
         }
      });
      this.absbtn = new Button(this, 2);
      this.absbtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (MultiMeterComposite.this.lsn) {
               MultiMeterComposite.this.absbtn.setText(MultiMeterComposite.this.absbtn.getSelection() ? "||" : "△");
            }
         }
      });
      this.absbtn.setText(this.absbtn.getSelection() ? "||" : "△");
      this.absbtn.setBounds(138, 45, 58, 29);
      this.autobtn = new Button(this, 2);
      this.autobtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (MultiMeterComposite.this.lsn) {
               MultiMeterComposite.this.autobtn.setText(MultiMeterComposite.this.autobtn.getSelection() ? "auto" : "manual");
            }
         }
      });
      this.autobtn.setBounds(214, 45, 86, 29);
      this.autobtn.setText(this.autobtn.getSelection() ? "auto" : "manual");
      this.cbb = new Combo(this, 8);
      this.cbb.setBounds(10, 50, 108, 21);
      this.mAbtn = new Button(this, 2);
      this.mAbtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (MultiMeterComposite.this.lsn) {
               MultiMeterComposite.this.mAbtn.setText(MultiMeterComposite.this.mAbtn.getSelection() ? "mA" : "10A");
            }
         }
      });
      this.mAbtn.setText(this.mAbtn.getSelection() ? "mA" : "10A");
      this.mAbtn.setBounds(321, 45, 79, 29);
      aButton.setSelection(true);
      this.mmt = this.ta;
      this.load(this.mmt);
   }

   void load(MMtype mmt) {
      this.lsn = false;
      this.cbb.setItems(mmt.getSets());
      this.cbb.select(0);
      this.absbtn.setSelection(mmt.abson);
      this.autobtn.setSelection(mmt.autoon);
      this.mAbtn.setVisible(mmt == this.ta);
      this.lsn = true;
   }

   void swtichMMType(int t) {
      switch (t) {
         case 97:
         default:
            this.mmt = this.ta;
            break;
         case 114:
            this.mmt = this.tr;
            break;
         case 118:
            this.mmt = this.tv;
      }

      if (this.mmt != null) {
         this.load(this.mmt);
      }
   }

   public void storeFromUI() {
      this.mmt.set = this.cbb.getSelectionIndex();
      this.mmt.abson = this.absbtn.getSelection();
      this.mmt.autoon = this.autobtn.getSelection();
      if (this.mmt == this.ta) {
         this.ta.mAon = this.mAbtn.getSelection();
      }
   }

   public void pack(ByteBuffer bb) {
      this.mmt.pack(bb);
   }

   class MMa extends MMtype {
      String[] da = new String[]{"DCA", "ACA"};
      boolean mAon;

      public void set_mA(boolean mA) {
         this.mAon = mA;
      }

      @Override
      protected void packself(ByteBuffer bb) {
         bb.put((byte)(this.mAon ? 0 : 1));
      }

      public MMa() {
         super(97);
      }

      @Override
      public String[] getSets() {
         return this.da;
      }
   }

   class MMr extends MMtype {
      String[] da;
      LObject[] los = new LObject[]{new LObject("M.MM.R"), new LObject("M.MM.DIODE"), new LObject("M.MM.BUZZER"), new LObject("M.MM.C")};

      public MMr() {
         super(114);
         this.da = ManipulateControl.toStrings(this.los);
      }

      @Override
      public String[] getSets() {
         return this.da;
      }
   }

   class MMv extends MMtype {
      String[] da = new String[]{"DCV", "ACV"};

      public MMv() {
         super(118);
      }

      @Override
      public String[] getSets() {
         return this.da;
      }
   }
}
