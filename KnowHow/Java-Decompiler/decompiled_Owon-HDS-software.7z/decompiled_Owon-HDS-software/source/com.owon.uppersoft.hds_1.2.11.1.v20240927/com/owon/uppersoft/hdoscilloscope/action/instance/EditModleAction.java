package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.communication.UploadAgSavedWFFrame;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class EditModleAction extends DefaultAction {
   public EditModleAction(String id) {
      super(id);
   }

   public void run() {
      Platform platform = Platform.getPlatform();
      new UploadAgSavedWFFrame(platform.getShell()).open();
   }
}
