package com.owon.uppersoft.hdoscilloscope.manipulate;

import com.owon.uppersoft.hdoscilloscope.communication.loop.ICommunicationListener;
import com.owon.uppersoft.hdoscilloscope.communication.loop.ICommunicationListenerProvider;

public class CommListenerProvider implements ICommunicationListenerProvider, ICommunicationListener {
   @Override
   public ICommunicationListener getCommunicationListener() {
      return this;
   }

   @Override
   public void communicateInfo(int length, String fileType) {
      System.out.printf("length: %d,  fileType: %s%n", length, fileType);
   }

   @Override
   public void progressInfo(int value) {
      System.out.printf("value: %d%n", value);
   }

   @Override
   public void communicateInfo_ifn(int times, String fileType) {
   }

   @Override
   public void progressInfo_ifn(int value) {
   }

   @Override
   public void resetICL() {
   }

   @Override
   public void setICL() {
   }
}
