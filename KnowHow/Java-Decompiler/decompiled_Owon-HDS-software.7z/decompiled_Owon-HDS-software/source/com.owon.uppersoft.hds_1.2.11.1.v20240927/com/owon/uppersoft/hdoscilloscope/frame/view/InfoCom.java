package com.owon.uppersoft.hdoscilloscope.frame.view;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.data.MultiMeter;
import com.owon.uppersoft.hdoscilloscope.data.TxtEntry;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.ResourceBundle;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class InfoCom implements Localizable2 {
   private Table table;
   private TableColumn typeTableColumn;
   private TableColumn valueTableColumn;
   private Group group;
   private LinkedList<TableItem> itemList;
   private ListIterator<TableItem> it;
   public String freqLabel;
   public String periodLabel;
   public String pkpkLabel;
   public String ADConnectLabel;
   public String currentTypeLabel;
   public String averVolLabel;
   public String rippleLabel;
   private WaveFormCurve curve;
   private boolean bempty;

   public InfoCom(Group parent) {
      this.group = parent;
      this.table = new Table(parent, 67584);
      this.itemList = new LinkedList<>();
      this.typeTableColumn = new TableColumn(this.table, 0);
      this.typeTableColumn.setWidth(120);
      this.valueTableColumn = new TableColumn(this.table, 0);
      this.valueTableColumn.setWidth(160);
      this.table.setHeaderVisible(true);
      this.table.setLinesVisible(true);
   }

   protected void initAdd() {
      this.it = this.itemList.listIterator();
   }

   protected void add(TxtEntry te) {
      TableItem ti;
      if (this.it.hasNext()) {
         ti = this.it.next();
      } else {
         ti = new TableItem(this.table, this.table.getItemCount());
         this.it.add(ti);
      }

      ti.setData(te);
      ti.setText(1, te.v);
   }

   protected void endAdd() {
      while (this.it.hasNext()) {
         TableItem ti = this.it.next();
         this.it.remove();
         ti.dispose();
      }
   }

   public void setWaveFormCurve(WaveFormCurve curve) {
      this.curve = curve;
      this.initAdd();
      if (curve != null) {
         for (TxtEntry te : curve.txts_coll()) {
            this.add(te);
         }
      }

      this.endAdd();
      this.localizeDetail();
   }

   protected void localizeDetail() {
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      String title = "";
      if (this.bempty) {
         if (Platform.getPlatform().getDrawingPanel().getWaveFormFileCurve().getWaveFormFile().mm != null) {
            title = bundle.getString("Center.mul");
         }
      } else if (this.curve != null) {
         title = this.curve.getStrChannelType() + " " + bundle.getString("Center.info");
      }

      this.group.setText(title);

      for (TableItem ti : this.itemList) {
         TxtEntry te = (TxtEntry)ti.getData();
         if (te.useKey) {
            te.localize(bundle);
         }

         ti.setText(0, te.n);
      }
   }

   public void setEmptyWF(WaveFormFile wff, boolean b) {
      this.bempty = b;
      if (b) {
         this.initAdd();
         MultiMeter mm = wff.mm;
         if (mm != null) {
            this.add(new TxtEntry(false, mm.type(), mm.info()));
         }

         this.endAdd();
      }

      this.localizeDetail();
   }

   public void localize(ResourceBundle bundle) {
      this.freqLabel = bundle.getString("Center.Freq");
      this.periodLabel = bundle.getString("Center.Period");
      this.pkpkLabel = bundle.getString("Center.PKPK");
      this.ADConnectLabel = bundle.getString("Center.ADConnectLabel");
      this.currentTypeLabel = bundle.getString("Center.CurrentType");
      this.averVolLabel = bundle.getString("Center.AverageVoltage");
      this.rippleLabel = bundle.getString("Center.RippleArgument");
      this.typeTableColumn.setText(bundle.getString("Center.ArgumentType"));
      this.valueTableColumn.setText(bundle.getString("Center.ArgumentValue"));
      this.localizeDetail();
   }
}
