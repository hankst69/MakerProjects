package com.owon.uppersoft.hdoscilloscope.model;

import java.util.ArrayList;
import java.util.List;

public class MathVlotBase {
   public static void main(String[] args) {
   }

   public List<Dbl_Txt> getVv(String operat) {
      List<Dbl_Txt> v = new ArrayList<>();
      Dbl_Txt.addDbl_Txt(v, "1.00nV", 1.0E-9);
      Dbl_Txt.addDbl_Txt(v, "2.00nV", 2.0E-9);
      Dbl_Txt.addDbl_Txt(v, "5.00nV", 5.0E-9);
      Dbl_Txt.addDbl_Txt(v, "10.0nV", 1.0E-8);
      Dbl_Txt.addDbl_Txt(v, "20.0nV", 2.0E-8);
      Dbl_Txt.addDbl_Txt(v, "50.0nV", 5.0E-8);
      Dbl_Txt.addDbl_Txt(v, "100 nV", 1.0E-7);
      Dbl_Txt.addDbl_Txt(v, "200 nV", 2.0E-7);
      Dbl_Txt.addDbl_Txt(v, "500 nV", 5.0E-7);
      Dbl_Txt.addDbl_Txt(v, "1.00uV", 1.0E-6);
      Dbl_Txt.addDbl_Txt(v, "2.00uV", 2.0E-6);
      Dbl_Txt.addDbl_Txt(v, "5.00uV", 5.0E-6);
      Dbl_Txt.addDbl_Txt(v, "10.0uV", 1.0E-5);
      Dbl_Txt.addDbl_Txt(v, "20.0uV", 2.0E-5);
      Dbl_Txt.addDbl_Txt(v, "50.0uV", 5.0E-5);
      Dbl_Txt.addDbl_Txt(v, "100 uV", 1.0E-4);
      Dbl_Txt.addDbl_Txt(v, "200 uV", 2.0E-4);
      Dbl_Txt.addDbl_Txt(v, "500 uV", 5.0E-4);
      Dbl_Txt.addDbl_Txt(v, "1.00mV", 0.001);
      Dbl_Txt.addDbl_Txt(v, "2.00mV", 0.002);
      Dbl_Txt.addDbl_Txt(v, "5.00mV", 0.005);
      Dbl_Txt.addDbl_Txt(v, "10.0mV", 0.01);
      Dbl_Txt.addDbl_Txt(v, "20.0mV", 0.02);
      Dbl_Txt.addDbl_Txt(v, "50.0mV", 0.05);
      Dbl_Txt.addDbl_Txt(v, "100 mV", 0.1);
      Dbl_Txt.addDbl_Txt(v, "200 mV", 0.2);
      Dbl_Txt.addDbl_Txt(v, "500 mV", 0.5);
      Dbl_Txt.addDbl_Txt(v, "1.00 V", 1.0);
      Dbl_Txt.addDbl_Txt(v, "2.00 V", 2.0);
      Dbl_Txt.addDbl_Txt(v, "5.00 V", 5.0);
      Dbl_Txt.addDbl_Txt(v, "10.0 V", 10.0);
      Dbl_Txt.addDbl_Txt(v, "100  V", 100.0);
      Dbl_Txt.addDbl_Txt(v, "200  V", 200.0);
      Dbl_Txt.addDbl_Txt(v, "500  V", 500.0);
      Dbl_Txt.addDbl_Txt(v, "1.00KV", 1000.0);
      Dbl_Txt.addDbl_Txt(v, "2.00KV", 2000.0);
      Dbl_Txt.addDbl_Txt(v, "5.00KV", 5000.0);
      Dbl_Txt.addDbl_Txt(v, "10.0KV", 10000.0);
      Dbl_Txt.addDbl_Txt(v, "20.0KV", 20000.0);
      Dbl_Txt.addDbl_Txt(v, "50.0KV", 50000.0);
      Dbl_Txt.addDbl_Txt(v, "100 KV", 100000.0);
      Dbl_Txt.addDbl_Txt(v, "200 KV", 200000.0);
      Dbl_Txt.addDbl_Txt(v, "500 KV", 500000.0);
      Dbl_Txt.addDbl_Txt(v, "1.00MV", 1000000.0);
      Dbl_Txt.addDbl_Txt(v, "2.00MV", 2000000.0);
      Dbl_Txt.addDbl_Txt(v, "5.00MV", 5000000.0);
      Dbl_Txt.addDbl_Txt(v, "10.0MV", 1.0E7);
      Dbl_Txt.addDbl_Txt(v, "20.0MV", 2.0E7);
      Dbl_Txt.addDbl_Txt(v, "50.0MV", 5.0E7);
      Dbl_Txt.addDbl_Txt(v, "100 MV", 1.0E8);
      Dbl_Txt.addDbl_Txt(v, "200 MV", 2.0E8);
      Dbl_Txt.addDbl_Txt(v, "500 MV", 5.0E8);
      Dbl_Txt.addDbl_Txt(v, "1.00GV", 1.0E9);
      return v;
   }
}
