package com.owon.uppersoft.hdoscilloscope.frame.view;

import com.owon.uppersoft.common.utils.ShellUtil;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseWheelListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class Display4k {
   private Shell shell;
   private Shell parent;
   private Canvas canvas;
   private List<int[]> wf;
   private int cells;
   private int time;

   public Display4k(Shell parent) {
      this.parent = parent;
      this.createContents();
   }

   public Object open() {
      this.shell.pack();
      ShellUtil.centerLoc(this.shell);
      this.shell.open();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }

      return null;
   }

   public void closed() {
      this.shell.dispose();
   }

   protected void createContents() {
      this.shell = new Shell(this.parent, 1104);
      this.shell.addDisposeListener(new DisposeListener() {
         public void widgetDisposed(DisposeEvent arg0) {
         }
      });
      this.shell.setMinimumSize(new Point(800, 400));
      this.shell.setLayout(new FillLayout(256));
      this.canvas = new Canvas(this.shell, 0);
      this.canvas.addMouseWheelListener(new MouseWheelListener() {
         public void mouseScrolled(MouseEvent arg0) {
            if (arg0.time - Display4k.this.time >= 500) {
               Display4k.this.time = arg0.time;
               int count = arg0.count;
               if (count > 0) {
                  if (Display4k.this.cells != 10) {
                     Display4k.this.cells = Display4k.this.cells + 1;
                  }
               } else if (Display4k.this.cells != 1) {
                  Display4k.this.cells = Display4k.this.cells - 1;
               }

               Display4k.this.canvas.redraw();
            }
         }
      });
      this.canvas.addPaintListener(new PaintListener() {
         public void paintControl(PaintEvent arg0) {
            if (Display4k.this.wf != null) {
               Display4k.this.drawBackgroud(arg0.gc);
               Iterator<int[]> it = Display4k.this.wf.iterator();
               Color[] c = new Color[]{arg0.display.getSystemColor(7), arg0.display.getSystemColor(9)};
               int i = 0;

               while (it.hasNext()) {
                  arg0.gc.setForeground(c[i++]);
                  Display4k.this.draw(arg0.gc, it.next());
               }

               arg0.gc.drawString("ZOOM:" + Display4k.this.cells + "X", 0, 0);
            }
         }
      });
      this.canvas.setBackground(this.shell.getDisplay().getSystemColor(2));
      this.cells = 10;
   }

   public void localize(ResourceBundle bundle) {
      this.shell.setText(bundle.getString("MF.about"));
   }

   public void drawBackgroud(GC gc) {
      Color c = gc.getDevice().getSystemColor(15);
      gc.setForeground(c);
      gc.setLineStyle(1);
      Point p = this.canvas.getSize();
      int line = p.y / this.cells;

      for (int i = 1; i < this.cells; i++) {
         int y = line * i;
         gc.drawLine(0, y, p.x, y);
      }

      int x = 0;

      while (x < p.x) {
         x += line;
         gc.drawLine(x, 0, x, p.y);
      }
   }

   public void setAdc(List<int[]> wf) {
      this.wf = wf;
      this.canvas.redraw();
   }

   private void draw(GC gc, int[] adc) {
      Point p = this.canvas.getSize();
      double ppx = 1.0;
      double ppy = (double)p.y / 4000.0;
      ppx = ppy * 4.0 * 10.0 / (double)this.cells;
      int x1 = 0;
      int y1 = (int)((2048.0 - (double)adc[0] * 10.0 / (double)this.cells) * ppy);

      for (int i = 1; i < adc.length; i++) {
         int y2 = (int)((2048.0 - (double)adc[i] * 10.0 / (double)this.cells) * ppy);
         int x2 = (int)(ppx * (double)i);
         gc.drawLine(x1, y1, x2, y2);
         y1 = y2;
         x1 = x2;
      }
   }

   private void tranlatecoordin() {
      for (int[] adc : this.wf) {
         for (int i = 1; i < adc.length; i++) {
            adc[i] = Math.abs(adc[i] - 2048);
         }
      }
   }
}
