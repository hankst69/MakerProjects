package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.chart.BackgroundDraw;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.ColorDialog;

public class BgColorAction extends DefaultAction {
   public BgColorAction(String id) {
      super(id);
   }

   public void run() {
      this.doSetBackground();
   }

   public void doSetBackground() {
      Platform pf = Platform.getPlatform();
      DrawingPanel dp = pf.getCenter().getDrawingPanel();
      ColorDialog ds = new ColorDialog(pf.getShell());
      BackgroundDraw bd = dp.getBackgroundDraw();
      ds.setRGB(bd.getBackgroundRGB());
      RGB rgb = ds.open();
      if (rgb != null) {
         bd.setBackgroundRGB(rgb);
         dp.redraw();
      }
   }
}
