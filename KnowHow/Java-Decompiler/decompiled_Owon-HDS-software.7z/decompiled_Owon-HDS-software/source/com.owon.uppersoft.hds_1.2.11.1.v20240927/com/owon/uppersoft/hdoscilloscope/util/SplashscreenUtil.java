package com.owon.uppersoft.hdoscilloscope.util;

import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.image.ImageShop;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class SplashscreenUtil implements PaintListener {
   private Shell shell;
   private Image image;
   private Display display;
   private ImageShop imageShop;

   public SplashscreenUtil(Display display) {
      this.display = display;
   }

   public void paintControl(PaintEvent e) {
      GC gc = e.gc;
      gc.drawImage(this.image, 0, 0);
      gc.drawString(VerInfoUtil.getVersionUtil().getAboutVer(), 20, 30, true);
   }

   public void show() {
      this.imageShop = Platform.getPlatform().getImageShop();
      this.image = this.imageShop.getImage("splash.gif");
      this.shell = new Shell(this.display, 16392);
      this.shell.addPaintListener(this);
      Rectangle r = this.image.getBounds();
      this.shell.setSize(r.width, r.height);
      ShellUtil.centerLoc(this.shell);
      this.shell.open();
   }

   public void close() {
      this.shell.close();
      this.imageShop.disposeImage(this.image);
   }
}
