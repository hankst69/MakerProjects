package com.owon.uppersoft.hdoscilloscope.communication.serial;

import com.owon.uppersoft.hdoscilloscope.communication.loop.ICommunicationListenerProvider;
import com.owon.uppersoft.hdoscilloscope.communication.loop.IRapidCommunication;
import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import java.io.File;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

public class RapidSerialCommunication implements IRapidCommunication {
   private String portName;
   private int baudRate;
   private int dataBits;
   private int stopBits;
   private int parity;
   private SerialCommunication serialComm;
   private ICommunicationListenerProvider iclp;

   public RapidSerialCommunication(String portName, int baudRate, int dataBits, int stopBits, int parity, ICommunicationListenerProvider iclp) {
      this.portName = portName;
      this.baudRate = baudRate;
      this.dataBits = dataBits;
      this.stopBits = stopBits;
      this.parity = parity;
      this.iclp = iclp;
   }

   @Override
   public boolean getData() {
      this.serialComm.isCommEnd();
      return !this.serialComm.isCommCancel() && !this.serialComm.isCommFail();
   }

   @Override
   public String getFileType() {
      return this.serialComm.getFileType();
   }

   @Override
   public CByteArrayInputStream byteInput() {
      return new CByteArrayInputStream(this.serialComm.buf());
   }

   @Override
   public boolean setSavedFile(File file) {
      return this.serialComm.setSavedFile(file);
   }

   @Override
   public void cancel() {
      if (this.serialComm != null && !this.serialComm.isCommTerminated()) {
         this.serialComm.cancelComm(-7);
      }
   }

   @Override
   public String getCommunicaitonErrorMsgKey() {
      return "Err.SerialConnect";
   }

   public static boolean checkSerialPortFreeForUse(Shell shell, String port) {
      if ("USB".equals(port)) {
         return true;
      } else if ("LAN".equals(port)) {
         return true;
      } else if ("USBTMC".equals(port)) {
         return true;
      } else {
         String key = null;

         try {
            CommPortIdentifier portId = CommPortIdentifier.getPortIdentifier(port);
            SerialPort serialPort = (SerialPort)portId.open("OWON_SerialPort", 2000);
            serialPort.close();
         } catch (NoSuchPortException var5) {
            var5.printStackTrace();
            key = "NoSuchPort";
         } catch (PortInUseException var6) {
            var6.printStackTrace();
            key = "PortInUse";
         }

         if (key != null) {
            ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
            MessageDialog.openError(shell, port, "[" + port + "]: " + bundle.getString("Serial." + key));
            return false;
         } else {
            return true;
         }
      }
   }

   @Override
   public void endFinl() {
      this.serialComm.close();
   }

   @Override
   public void endOnce() {
   }

   @Override
   public int read(byte[] arr, int beg, int len) {
      return -1;
   }

   @Override
   public int write(byte[] arr, int beg, int len) {
      System.err.println("empty method rapid serial comm");
      return -1;
   }

   @Override
   public void startInit() {
      this.serialComm = new SerialCommunication(this.iclp);
      this.serialComm.openPort(this.portName);
      this.serialComm.loadPort(this.baudRate, this.dataBits, this.stopBits, this.parity);
   }

   @Override
   public void startOnce() {
      this.serialComm.startComm();
   }
}
