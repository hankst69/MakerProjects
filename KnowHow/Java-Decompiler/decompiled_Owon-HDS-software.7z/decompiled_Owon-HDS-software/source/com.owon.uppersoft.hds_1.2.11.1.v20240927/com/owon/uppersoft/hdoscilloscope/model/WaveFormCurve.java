package com.owon.uppersoft.hdoscilloscope.model;

import com.owon.uppersoft.hdoscilloscope.chart.ContextDrawable;
import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.chart.aspect.DrawCompute;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Menu;

public interface WaveFormCurve extends DrawCompute, ContextDrawable {
   int WF = 0;
   int DMWF = 1;
   int FFT = 2;
   int MATH = 3;
   int EMPTY = 4;

   boolean equals(WaveFormCurve var1);

   String getStrChannelType();

   WaveForm getWaveForm();

   Color getColor();

   RGB getRGB();

   void setRGB(RGB var1);

   int getBlockNum();

   boolean isVisible();

   void setVisible(boolean var1);

   Menu getToolMenu();

   void applyToolComposite();

   ScalableDrawEngine getScalableDrawEngine();

   WFReg getWFReg();

   int getCurveType();

   boolean isChannel();
}
