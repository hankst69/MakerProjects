package com.owon.uppersoft.hdoscilloscope.chart.model;

public class ControlManger {
}
