package com.owon.uppersoft.hdoscilloscope.communication;

import com.owon.uppersoft.common.utils.FileUtil;
import com.owon.uppersoft.hdoscilloscope.communication.loop.ICommunicationListener;
import com.owon.uppersoft.hdoscilloscope.communication.loop.ICommunicationListenerProvider;
import com.owon.uppersoft.hdoscilloscope.communication.loop.RapidCommunication;
import com.owon.uppersoft.hdoscilloscope.communication.serial.RapidSerialCommunication;
import com.owon.uppersoft.hdoscilloscope.frame.view.ShowImageDialog;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.MessageErrRunner;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import com.owon.uppersoft.hdoscilloscope.util.UnitConversionUtil;
import java.io.File;
import java.io.IOException;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class BetaUploadFrame extends AlphaUploadFrame implements ICommunicationListener, ICommunicationListenerProvider, Listener, Runnable {
   private RapidCommunication rapidComm;
   private MessageErrRunner mer;
   private ICommunicationListener icl;
   private final int SWT_Selection = 13;
   private Thread uploadThread;
   public static final int start = 1;
   public static final int stop = 2;
   protected int status;

   public BetaUploadFrame(Shell shell, Configuration conf) {
      super(shell, conf);
      this.btnOperate.addListener(13, this);
      this.btnBrowse.addListener(13, this);
      this.getShell().addDisposeListener(new DisposeListener() {
         public void widgetDisposed(DisposeEvent e) {
            BetaUploadFrame.this.cancelComm();
            String path = "";

            try {
               path = BetaUploadFrame.this.saveDir.getCanonicalPath();
            } catch (IOException var4) {
               var4.printStackTrace();
            }

            BetaUploadFrame.this.config.savePath = path;
         }
      });
      this.mer = ResourceBundleProvider.getMessageErrRunner();
      this.pb.setMinimum(0);
      this.btnOperate.setText(this.txtStart);
      this.status = 2;
      this.rapidComm = new RapidCommunication(this);
      this.checkCloseOnDone.setSelection(this.config.closeOnDone);
      this.getShell().addDisposeListener(new DisposeListener() {
         public void widgetDisposed(DisposeEvent e) {
            BetaUploadFrame.this.config.closeOnDone = BetaUploadFrame.this.checkCloseOnDone.getSelection();
         }
      });
      this.getShell().setImage(Platform.getPlatform().getImageShop().getImage("getData.gif"));
   }

   public void handleEvent(Event event) {
      if (event.type == 13) {
         Object o = event.widget;
         if (o == this.btnOperate) {
            if (this.status == 1) {
               this.cancelComm();
            } else if (RapidSerialCommunication.checkSerialPortFreeForUse(this.getShell(), this.config.portType)) {
               this.startComm();
            }
         } else if (o == this.btnBrowse) {
            this.setSaveFile();
         }
      }
   }

   @Override
   public void setICL() {
      this.icl = this;
   }

   @Override
   public void resetICL() {
      this.icl = ICommunicationListenerProvider.EmptyICL;
   }

   protected void startComm() {
      this.txtFileType.setText("");
      this.setICL();
      this.status = 1;
      this.uploadThread = new Thread(this);
      this.uploadThread.start();
      this.setCommStatus();
   }

   @Override
   public void run() {
      Platform.getPlatform().getMainFrame().turnOffCheck();
      boolean flag = this.progressUpload();
      Platform.getPlatform().getMainFrame().turnOnCheck();
      this.status = 2;
      this.done(flag);
   }

   protected void cancelComm() {
      this.resetICL();
      this.rapidComm.cancel();
      this.status = 2;
      if (this.uploadThread != null) {
         try {
            this.uploadThread.join();
         } catch (InterruptedException var2) {
            var2.printStackTrace();
         }
      }

      this.setCommStatus();
   }

   public boolean progressUpload() {
      this.rapidComm.startInit();
      this.rapidComm.startOnce();
      boolean getDataSuccess = this.rapidComm.getData();
      this.rapidComm.endOnce();
      this.rapidComm.endFinl();
      if (this.status == 2) {
         return false;
      } else if (!getDataSuccess) {
         this.mer.setInfo(this.rapidComm.getCommunicaitonErrorMsgKey(), 1, this.shell);
         return false;
      } else {
         String fileExtension = this.rapidComm.getFileType();
         File f = this.setSaveFileExtension(fileExtension);
         FileUtil.checkPath(f);
         boolean saveFileSucess = this.rapidComm.setSavedFile(f);
         if (!saveFileSucess) {
            this.mer.setInfo("Err.FileUnsavable", 1, this.shell);
            return false;
         } else {
            if (fileExtension.equalsIgnoreCase("bmp")) {
               ShowImageDialog d = new ShowImageDialog(this.shell, f.getPath());
               d.open();
            }

            return true;
         }
      }
   }

   @Override
   protected void setCommStatus() {
      if (!this.shell.isDisposed()) {
         boolean flag = this.status == 2;
         this.btnBrowse.setEnabled(flag);
         this.btnOperate.setText(flag ? this.txtStart : this.txtCancel);
      }
   }

   @Override
   public ICommunicationListener getCommunicationListener() {
      return this.icl;
   }

   @Override
   public void communicateInfo_ifn(final int times, final String fileType) {
      this.shell.getDisplay().syncExec(new Runnable() {
         @Override
         public void run() {
            if (!BetaUploadFrame.this.shell.isDisposed()) {
               BetaUploadFrame.this.txtFileType.setText(fileType);
               BetaUploadFrame.this.pb.setMaximum(times);
               BetaUploadFrame.this.txtProgress.setText("?");
            }
         }
      });
   }

   @Override
   public void progressInfo_ifn(final int v) {
      this.shell.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            if (!BetaUploadFrame.this.shell.isDisposed()) {
               BetaUploadFrame.this.pb.setSelection(BetaUploadFrame.this.pb.getSelection() + 1);
               String progressValue = UnitConversionUtil.getBytesNumber(v);
               BetaUploadFrame.this.txtProgressValue.setText(progressValue);
            }
         }
      });
   }

   @Override
   public void communicateInfo(final int length, final String fileType) {
      this.shell.getDisplay().syncExec(new Runnable() {
         @Override
         public void run() {
            if (!BetaUploadFrame.this.shell.isDisposed()) {
               BetaUploadFrame.this.txtFileType.setText(fileType);
               BetaUploadFrame.this.pb.setMaximum(length);
               BetaUploadFrame.this.txtProgress.setText(UnitConversionUtil.getBytesNumber(length));
            }
         }
      });
   }

   @Override
   public void progressInfo(final int v) {
      this.shell.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            if (!BetaUploadFrame.this.shell.isDisposed()) {
               System.out.print("222222222" + v);
               BetaUploadFrame.this.pb.setSelection(v);
               String progressValue = UnitConversionUtil.getBytesNumber(v);
               BetaUploadFrame.this.txtProgressValue.setText(progressValue);
            }
         }
      });
   }
}
