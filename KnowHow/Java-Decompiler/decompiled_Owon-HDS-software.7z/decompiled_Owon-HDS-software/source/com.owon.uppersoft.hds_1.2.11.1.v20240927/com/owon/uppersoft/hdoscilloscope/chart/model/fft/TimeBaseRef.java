package com.owon.uppersoft.hdoscilloscope.chart.model.fft;

import java.util.StringTokenizer;

public class TimeBaseRef {
   private String sampleRateTxt;
   private String protofreqBaseTxt_1;
   private String freqBaseTxt_2;
   private String freqBaseTxt_5;
   private String freqBaseTxt_10;
   private double protofreqPP;
   private String timeBaseTxt;

   public TimeBaseRef(String line, int pixelsPerBlock) {
      StringTokenizer st = new StringTokenizer(line);
      st.nextToken();
      this.sampleRateTxt = st.nextToken();
      this.protofreqBaseTxt_1 = st.nextToken();
      this.freqBaseTxt_2 = st.nextToken();
      this.freqBaseTxt_5 = st.nextToken();
      this.freqBaseTxt_10 = st.nextToken();
      this.timeBaseTxt = st.nextToken();
      this.protofreqPP = (double)pixelsPerBlock * Double.parseDouble(st.nextToken());
   }

   public double getProtofreqPP() {
      return this.protofreqPP;
   }

   @Override
   public String toString() {
      return this.protofreqBaseTxt_1;
   }

   public String zoomFreqBase(int i) {
      String ret;
      switch (i) {
         case 1:
         case 3:
         case 4:
         case 6:
         case 7:
         case 8:
         case 9:
         default:
            ret = this.protofreqBaseTxt_1;
            break;
         case 2:
            ret = this.freqBaseTxt_2;
            break;
         case 5:
            ret = this.freqBaseTxt_5;
            break;
         case 10:
            ret = this.freqBaseTxt_10;
      }

      return ret;
   }
}
