package com.owon.uppersoft.hdoscilloscope.chart.model;

import com.owon.uppersoft.hdoscilloscope.chart.DrawEngine;
import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.model.PublicM;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;
import org.eclipse.swt.graphics.Point;

public class AlphaWaveFormCurve extends PrototypeWaveFormCurve implements ILowMovable {
   protected LowMoveChecker lmc;
   private DrawEngine dren;

   public AlphaWaveFormCurve(WaveForm wf, WaveFormFileCurve fileCurve, WFReg wfreg) {
      super(wf, fileCurve, wfreg);
   }

   @Override
   public LowMoveChecker getLowMoveChecker() {
      return this.lmc;
   }

   @Override
   public int getCurveType() {
      return 0;
   }

   @Override
   public boolean isChannel() {
      return true;
   }

   @Override
   protected void initPoints(WaveFormFileCurve fileCurve) {
      int intZeroYPoint = (this.wf.getWaveFormFile().getYPointNum() >> 1) - this.wf.getIntZeroYPoint();
      Point size = fileCurve.getDrawingPanel().getSize();
      int intFullScreenDataNum = this.wf.getIntFullScreenDataNum();
      double xpp = (double)size.x / (double)intFullScreenDataNum;
      double ypp = (double)size.y / (double)this.intFullScreenYPointNum;
      double y0 = (double)intZeroYPoint * ypp;
      double x0 = 0.0;
      int index = this.wf.getDesireXbase();
      this.currentTimeBaseIndex = index;
      double xscale = this.basicTimeBase / this.pm.getTimeBaseValue_mS(index);
      index = this.wf.getDesireYbase();
      this.currentVoltageBaseIndex = index;
      double yscale = this.basicVoltageBase / PublicM.getchVvValue(index);
      this.dren = this.createDrawEngine(fileCurve, this);
      this.lmc = new LowMoveChecker(this.wf);
      this.lmc.patchLowMove();
      this.dren.initPts(x0, y0, xpp, ypp, xscale, yscale);
   }

   @Override
   public ScalableDrawEngine getScalableDrawEngine() {
      return this.dren;
   }

   @Override
   public void setBaseIdxOnX(int index) {
      double timeBase = this.pm.getTimeBaseValue_mS(index);
      this.currentTimeBaseIndex = index;
      this.dren.setXScale(this.basicTimeBase / timeBase);
   }
}
