package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import java.nio.ByteBuffer;

public class VideoTrg extends AbsTrg {
   public static final int id = 1;
   public int module;
   public int sync;
   public int syncV = 1;
   public int holdoff = 1;

   public int getMax(int mod) {
      return mod == 0 ? 525 : 625;
   }

   @Override
   public void pack(ByteBuffer bb, int sna, int trgchl, int mode) {
      bb.put(mtr);
      bb.put((byte)sna);
      bb.put((byte)trgchl);
      bb.put((byte)mode);
      bb.put((byte)2);
      bb.put((byte)this.module);
      bb.put(mtr);
      bb.put((byte)sna);
      bb.put((byte)trgchl);
      bb.put((byte)mode);
      bb.put((byte)3);
      bb.put((byte)this.sync);
      if (this.sync == 4) {
         bb.putInt(this.syncV);
      }

      bb.put(mtr);
      bb.put((byte)sna);
      bb.put((byte)trgchl);
      bb.put((byte)mode);
      bb.put((byte)4);
      bb.putInt(this.holdoff);
   }
}
