package com.owon.uppersoft.hdoscilloscope.communication;

import com.owon.uppersoft.common.aspect.Localizable;
import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.communication.loop.RapidCommunication;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class UploadAgSavedWFFrame implements Localizable {
   protected Shell shell;
   private Button btnDownload;
   private Label lblNewLabel;
   private Button btnUpload;
   private Combo combo;

   public Shell getShell() {
      return this.shell;
   }

   public UploadAgSavedWFFrame(Shell parent) {
      this.shell = new Shell(parent, 1264);
      this.shell.setSize(541, 158);
      this.createContents();
   }

   public Object open() {
      this.shell.pack();
      ShellUtil.centerLoc(this.shell);
      this.shell.open();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }

      return null;
   }

   protected void createContents() {
      this.shell.setLayout(new GridLayout());
      Composite composite = new Composite(this.shell, 0);
      GridLayout gridLayout_1 = new GridLayout();
      gridLayout_1.numColumns = 4;
      gridLayout_1.verticalSpacing = 10;
      composite.setLayout(gridLayout_1);
      composite.setLayoutData(new GridData(4, 4, true, false));
      this.lblNewLabel = new Label(composite, 0);
      this.lblNewLabel.setLayoutData(new GridData(131072, 16777216, false, false, 1, 1));
      this.lblNewLabel.setText("New Label");
      this.combo = new Combo(composite, 8);
      this.combo.setLayoutData(new GridData(4, 16777216, true, false, 1, 1));
      this.btnUpload = new Button(composite, 0);
      this.btnUpload.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            String name = UploadAgSavedWFFrame.this.combo.getText();
            FileDialog fd = new FileDialog(UploadAgSavedWFFrame.this.shell);
            String s = fd.open();
            if (s != null) {
               byte[] b = null;

               try {
                  FileInputStream fis = new FileInputStream(s);
                  b = new byte[fis.available()];
                  fis.read(b);
                  fis.close();
               } catch (FileNotFoundException var11) {
                  var11.printStackTrace();
               } catch (IOException var12) {
                  var12.printStackTrace();
               }

               if (b != null) {
                  RapidCommunication comm = new RapidCommunication(null);
                  comm.startInit();
                  comm.startOnce();
                  int lenlen = String.valueOf(b.length).length();
                  String cmd = ":FILE:UPLoad " + name + ",#" + lenlen + b.length;
                  int totalLen = cmd.length() + b.length;
                  ByteBuffer bb = ByteBuffer.allocate(totalLen);
                  bb.put(cmd.getBytes());
                  bb.put(b);
                  comm.write(bb.array(), 0, totalLen);
                  comm.endOnce();
                  comm.endFinl();
               }
            }
         }
      });
      this.btnDownload = new Button(composite, 0);
      this.btnDownload.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            String name = UploadAgSavedWFFrame.this.combo.getText();
            FileDialog fd = new FileDialog(UploadAgSavedWFFrame.this.shell);
            String s = fd.open();
            if (s != null) {
               RapidCommunication comm = new RapidCommunication(null);
               comm.startInit();
               comm.startOnce();
               String cmd = ":FILE:Download " + name;
               comm.writeString(cmd);
               byte[] arr = new byte[20480];
               int len = comm.read(arr, 0, arr.length);
               comm.endOnce();
               comm.endFinl();
               if (len >= 0) {
                  try {
                     String c = new String(arr, 1, 1);
                     int offset = Integer.parseInt(c) + 2;
                     FileOutputStream fos = new FileOutputStream(s);
                     fos.write(arr, offset, len - offset);
                     fos.flush();
                     fos.close();
                  } catch (FileNotFoundException var12) {
                     var12.printStackTrace();
                  } catch (IOException var13) {
                     var13.printStackTrace();
                  }
               }
            }
         }
      });
      this.btnDownload.setText("New Button");
      int len = 48;

      for (int i = 0; i < len; i++) {
         this.combo.add("user" + i);
      }

      this.combo.select(0);
      this.localize();
   }

   public static void main_hide(String[] args) {
      UploadAgSavedWFFrame ps = new UploadAgSavedWFFrame(null);
      ps.open();
   }

   public void localize() {
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      this.shell.setText(bundle.getString("USF.GetData"));
      this.btnDownload.setText("download");
      this.btnUpload.setText("upload");
   }
}
