package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

public class CText extends Text {
   public CText(Composite parent, int style) {
      super(parent, style);
   }

   public boolean Check() {
      String value = this.getText().trim();
      if (!this.isEnabled()) {
         return true;
      } else if (value.length() > 20) {
         return false;
      } else if (value.equals("")) {
         return false;
      } else {
         Pattern p = Pattern.compile("^-?([1-9]\\d*\\.\\d*|0\\.\\d*[1-9]\\d*|0?\\.0+|[1-9]\\d*$|0)$");
         Matcher m = p.matcher(value);
         return m.find();
      }
   }

   protected void checkSubclass() {
   }
}
