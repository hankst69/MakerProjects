package com.owon.uppersoft.hdoscilloscope.scpi.mm;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.image.ImageShop;
import java.util.ResourceBundle;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class ScpiMMFrm implements Localizable2, Listener {
   private Shell shell;
   private SCPIMMAction sa;
   private Shell parent;
   private Composite composite;
   private List list;
   private Combo cobRang;
   private Combo cobAuto;
   private Combo cobDelta;
   private Label lblNewLabel;
   private Label lblNewLabel_1;
   private Label lblNewLabel_2;
   private Label lblNewLabel_3;
   private Text text_1;
   private Composite composite_1;
   private Button btnNewButton;
   private Button btnNewButton_1;
   private Button btnNewButton_2;
   private Combo combo_1;
   private ResourceBundle bundle;
   String[] types = new String[]{"", "ACV", "DCV", "DIODE", "C", "R", "ACA", "DCA", "BUZZER", "IN"};
   String[] units = new String[]{"", "Ω", "kΩ", "MΩ", "uA", "mA", "A", "pF", "nF", "uF", "uV", "mV", "V"};
   private final String[] cmds = new String[]{
      "*IDN?",
      "*OPC",
      "*OPC?",
      "*ESR?",
      "*ESE?",
      "*ESE 64",
      "*CLS",
      "*ESE 2",
      "*ESE 4",
      "*ESE 16",
      "*ESE 128",
      "*SRE 8",
      "*SRE 4",
      "*SRE 16",
      "*SRE?",
      "*STB?",
      "*WAI",
      "*TST?"
   };
   private final String[] sets = new String[]{":FUNC DCV", ":FUNC ACV", ":FUNC DCA", ":FUNC ACA", ":FUNC RES", ":FUNC DIOD", ":FUNC CAP", ":FUNC BEEP"};
   private final String[] enumList = new String[]{":VOLT:DC", ":VOLT:AC", ":CURR:DC", ":CURR:AC", ":RES", ":DIOD", ":CAP", ":BEEP"};
   private final String[] onOff = new String[]{"ON", "OFF"};
   private final String[][] valRang = new String[][]{
      {"4E-1", "4", "40", "400", "1000"}, {"4", "40", "400", "1000"}, {"4E-2", "4E-1"}, {"4E-2", "4E-1"}, {"OHM", "KOHM", "MOHM"}, {"4", "10"}, {"4", "10"}
   };
   private final String[][] strRang = new String[][]{
      {"-400mV~400mV ", "-4V~4V", "-40V~40V", "-400V~400V", "-1000V~1000V"},
      {"0~4V", "0~40V", "0~400V", "0~1000V"},
      {"-40mA~40mA", "-400mA~400mA"},
      {"0mA~40mA", "0mA~400mA"},
      {"Ω", "KΩ", "MΩ"},
      {"-4A~4A", "-10A~10A"},
      {"0A~4A", "0A~10A"}
   };
   private final String[] unit = new String[]{"mA", "10A"};
   private Combo combo;
   private Group group;
   private Button btnNewButton_3;

   public ScpiMMFrm(Shell parent, SCPIMMAction sa) {
      this.parent = parent;
      this.sa = sa;
   }

   public Shell getShell() {
      return this.shell;
   }

   public void open() {
      Display display = Display.getDefault();
      this.createContents();
      ShellUtil.centerLoc(this.shell);
      this.shell.open();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   protected void createContents() {
      this.shell = new Shell(this.parent, 192);
      this.shell.addDisposeListener(new DisposeListener() {
         public void widgetDisposed(DisposeEvent e) {
            ScpiMMFrm.this.sa.release();
         }
      });
      this.shell.setSize(550, 204);
      ImageShop is = Platform.getPlatform().getImageShop();
      this.shell.setImage(is.getImage("SCPI.gif"));
      this.shell.setLayout(new FillLayout(256));
      this.composite = new Composite(this.shell, 0);
      this.composite.setLayout(new GridLayout(4, false));
      this.lblNewLabel_2 = new Label(this.composite, 0);
      this.lblNewLabel = new Label(this.composite, 0);
      new Label(this.composite, 0);
      new Label(this.composite, 0);
      this.list = new List(this.composite, 2560);
      GridData gd_list = new GridData(16384, 4, false, false, 1, 5);
      gd_list.widthHint = 97;
      gd_list.heightHint = 107;
      this.list.setLayoutData(gd_list);
      this.cobAuto = new Combo(this.composite, 8);
      this.cobAuto.setEnabled(false);
      GridData gd_cobAuto = new GridData(16384, 16777216, false, false, 1, 1);
      gd_cobAuto.widthHint = 100;
      this.cobAuto.setLayoutData(gd_cobAuto);
      this.combo = new Combo(this.composite, 8);
      this.combo.setEnabled(false);
      this.text_1 = new Text(this.composite, 2048);
      this.text_1.setLayoutData(new GridData(4, 4, false, false, 1, 4));
      this.lblNewLabel_3 = new Label(this.composite, 0);
      this.lblNewLabel_1 = new Label(this.composite, 0);
      this.cobRang = new Combo(this.composite, 8);
      this.cobRang.setEnabled(false);
      GridData gd_cobRang = new GridData(16384, 16777216, false, false, 1, 1);
      gd_cobRang.widthHint = 100;
      this.cobRang.setLayoutData(gd_cobRang);
      this.cobDelta = new Combo(this.composite, 8);
      this.cobDelta.setEnabled(false);
      this.group = new Group(this.composite, 0);
      this.group.setLayout(new RowLayout(256));
      GridData gd_group = new GridData(16384, 16777216, false, false, 2, 1);
      gd_group.widthHint = 239;
      gd_group.heightHint = 34;
      this.group.setLayoutData(gd_group);
      this.combo_1 = new Combo(this.group, 0);
      this.combo_1.setLayoutData(new RowData(124, -1));
      this.btnNewButton_3 = new Button(this.group, 0);
      this.btnNewButton_3.setText("New Button");
      this.composite_1 = new Composite(this.composite, 0);
      this.composite_1.setLayout(new FillLayout(256));
      GridData gd_composite_1 = new GridData(16384, 4, false, false, 3, 1);
      gd_composite_1.widthHint = 407;
      this.composite_1.setLayoutData(gd_composite_1);
      this.btnNewButton = new Button(this.composite_1, 0);
      this.btnNewButton_1 = new Button(this.composite_1, 0);
      this.btnNewButton_2 = new Button(this.composite_1, 0);
      this.localize(ResourceBundleProvider.getMessageLibResourceBundle2());
      this.addListener();
   }

   public void localize(ResourceBundle bundle) {
      this.bundle = bundle;
      this.shell.setText(bundle.getString("MF.mmscpi"));
      this.lblNewLabel_2.setText(bundle.getString("Scpi.function"));
      this.lblNewLabel.setText(bundle.getString("Scpi.autoscale"));
      this.lblNewLabel_1.setText(bundle.getString("Scpi.delta"));
      this.lblNewLabel_3.setText(bundle.getString("Scpi.rang"));
      this.btnNewButton.setText(bundle.getString("Scpi.setup"));
      this.btnNewButton_1.setText(bundle.getString("Scpi.read"));
      this.btnNewButton_2.setText(bundle.getString("Scpi.close"));
      String[] items = new String[]{
         bundle.getString("Scpi.dcv"),
         bundle.getString("Scpi.acv"),
         bundle.getString("Scpi.dca"),
         bundle.getString("Scpi.aca"),
         bundle.getString("Scpi.res"),
         bundle.getString("Scpi.diod"),
         bundle.getString("Scpi.cap"),
         bundle.getString("Scpi.beep")
      };
      this.list.setItems(items);
      this.group.setText(bundle.getString("Scpi.comcmd"));
      this.btnNewButton_3.setText(bundle.getString("Scpi.send"));
      this.combo_1.setItems(this.cmds);
   }

   private void send(String cmd, boolean isDisp) {
      if (cmd.length() != 0) {
         this.text_1.setText(cmd);
      }
   }

   private void addListener() {
      this.list.addListener(13, this);
      this.cobAuto.addListener(13, this);
      this.cobDelta.addListener(13, this);
      this.cobRang.addListener(13, this);
      this.btnNewButton.addListener(13, this);
      this.btnNewButton_1.addListener(13, this);
      this.btnNewButton_2.addListener(13, this);
      this.btnNewButton_3.addListener(13, this);
      this.combo.addListener(13, this);
   }

   public void handleEvent(Event arg0) {
      Object o = arg0.widget;
      if (o == this.btnNewButton_1) {
         this.send(":READ?", true);
      } else if (o == this.btnNewButton_2) {
         this.shell.dispose();
      } else if (o == this.btnNewButton_3) {
         String s = this.combo_1.getText();
         if (!s.equals("")) {
            this.send(s, true);
         }
      } else {
         int index = this.list.getSelectionIndex();
         if (index >= 0) {
            if (o == this.list) {
               this.cobAuto.setItems(new String[]{this.bundle.getString("Scpi.auto"), this.bundle.getString("Scpi.manual")});
               this.cobDelta.setItems(new String[]{this.bundle.getString("Scpi.on"), this.bundle.getString("Scpi.off")});
               this.cobRang.setEnabled(false);
               this.combo.setEnabled(false);
               switch (index) {
                  case 2:
                  case 3:
                     this.combo.setEnabled(true);
                     this.combo.setItems(new String[]{"mA", "10A"});
                  case 0:
                  case 1:
                     this.cobAuto.setEnabled(true);
                     this.cobDelta.setEnabled(true);
                     break;
                  case 4:
                     this.cobAuto.setEnabled(true);
                     this.cobDelta.setEnabled(false);
                     break;
                  case 5:
                  case 7:
                     this.cobAuto.setEnabled(false);
                     this.cobDelta.setEnabled(false);
                     break;
                  case 6:
                     this.cobAuto.setEnabled(false);
                     this.cobDelta.setEnabled(true);
               }
            } else if (o == this.cobAuto) {
               int i = this.cobAuto.getSelectionIndex();
               this.send(this.enumList[index] + ":AUTO " + this.onOff[i], false);
               if (index != 2 && index != 3) {
                  this.cobRang.setEnabled(i != 0);
                  this.cobRang.setItems(this.strRang[index]);
               }
            } else if (o == this.cobDelta) {
               String cmd = this.enumList[index] + ":REL";
               int i = this.cobDelta.getSelectionIndex();
               this.send(cmd + " " + this.onOff[i], false);
            } else if (o != this.cobRang) {
               if (o == this.btnNewButton) {
                  this.send(this.sets[index], false);
               } else {
                  if (o == this.combo) {
                     int i = this.combo.getSelectionIndex();
                     this.send(this.enumList[index] + ":UNIT " + this.unit[i], false);
                     this.cobRang.setEnabled(true);
                     this.cobRang.setItems(this.strRang[index + 3 * i]);
                  }
               }
            } else {
               String cmd = this.enumList[index] + ":RANG ";
               int i = this.combo.getSelectionIndex();
               int j = this.cobRang.getSelectionIndex();
               if (index != 2 && index != 3) {
                  cmd = cmd + this.valRang[index][j];
               } else {
                  cmd = cmd + this.valRang[index + 3 * i][j];
               }

               this.send(cmd, false);
            }
         }
      }
   }
}
