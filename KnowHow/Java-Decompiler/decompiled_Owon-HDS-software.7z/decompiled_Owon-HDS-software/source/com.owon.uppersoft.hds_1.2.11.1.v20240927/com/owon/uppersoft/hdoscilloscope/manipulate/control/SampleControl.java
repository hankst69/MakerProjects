package com.owon.uppersoft.hdoscilloscope.manipulate.control;

import com.owon.uppersoft.hdoscilloscope.manipulate.IPack;
import java.nio.ByteBuffer;

public class SampleControl implements IPack {
   public int type;
   public int times;

   @Override
   public void pack(ByteBuffer bb) {
      bb.put("MAQ".getBytes());
      bb.put((byte)this.type);
      if (this.type == 2) {
         bb.put((byte)this.times);
      }
   }
}
