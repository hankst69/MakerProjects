package com.owon.uppersoft.hdoscilloscope.model.detail;

import net.sf.json.JSONObject;

public class ModelDetail {
   private JSONObject detail;

   public ModelDetail() {
      this.init();
   }

   private void init() {
      this.detail = new JSONObject();
      this.detail.accumulate("base", "0,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS272_1", "5,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS272S_1", "5,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS242_1", "5,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS242S_1", "5,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS252_1", "5,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS252S_1", "5,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS272SE_1", "5,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS2102S_LS", "4,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS2102_LS", "4,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS2102SE_LS", "4,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS2202S_LS", "3,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS2202_LS", "3,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS2202SE_LS", "3,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS241", "5,0,1,9,25,25,12,8");
      this.detail.accumulate("HDS251", "5,0,1,9,25,25,12,8");
      this.detail.accumulate("HDS271", "5,0,1,9,25,25,12,8");
      this.detail.accumulate("HDS252U_1", "5,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS252SU_1", "5,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS2102U_LS", "4,0,2,9,25,25,12,8");
      this.detail.accumulate("HDS2102SU_LS", "4,0,2,9,25,25,12,8");
   }

   public String getModel(String model) {
      for (int i = 0; i < model.length(); i++) {
         String s = model.substring(0, model.length() - i);
         String result = this.detail.optString(s, null);
         if (result != null) {
            return result;
         }
      }

      return this.detail.getString("base");
   }

   public ModelBean getModel(Idn idn) {
      String model = idn.getRealModel().toUpperCase();
      return model != null && model.length() > 4 ? new ModelBean(this.getModel(model)) : new ModelBean(this.getModel("base"));
   }

   public static void main(String[] args) {
      new JSONObject();
      System.out.println("jaa.toString()");
   }
}
