package com.owon.uppersoft.hdoscilloscope.test;

import java.io.File;
import org.eclipse.swt.dnd.DragSource;
import org.eclipse.swt.dnd.DragSourceAdapter;
import org.eclipse.swt.dnd.DragSourceEvent;
import org.eclipse.swt.dnd.DropTarget;
import org.eclipse.swt.dnd.DropTargetAdapter;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;

public class DNDTest {
   public static void main(String[] args) {
      Display display = new Display();
      Shell shell = new Shell(display);
      shell.setLayout(new FillLayout());
      Label label1 = new Label(shell, 2048);
      label1.setText("Drag Source");
      final Table table = new Table(shell, 2048);

      for (int i = 0; i < 4; i++) {
         TableItem item = new TableItem(table, 0);
         if (i % 2 == 0) {
            item.setText("Drop a file");
         }

         if (i % 2 == 1) {
            item.setText("Drop text");
         }
      }

      DragSource dragSource = new DragSource(label1, 1);
      dragSource.setTransfer(new Transfer[]{TextTransfer.getInstance(), FileTransfer.getInstance()});
      dragSource.addDragListener(new DragSourceAdapter() {
         public void dragSetData(DragSourceEvent event) {
            if (FileTransfer.getInstance().isSupportedType(event.dataType)) {
               File file = new File("temp");
               event.data = new String[]{file.getAbsolutePath()};
            }

            if (TextTransfer.getInstance().isSupportedType(event.dataType)) {
               event.data = "once upon a time";
            }
         }
      });
      DropTarget dropTarget = new DropTarget(table, 17);
      dropTarget.setTransfer(new Transfer[]{TextTransfer.getInstance(), FileTransfer.getInstance()});
      dropTarget.addDropListener(new DropTargetAdapter() {
         FileTransfer fileTransfer = FileTransfer.getInstance();
         TextTransfer textTransfer = TextTransfer.getInstance();

         public void dragEnter(DropTargetEvent event) {
            if (event.detail == 16) {
               event.detail = 1;
            }
         }

         public void dragOperationChanged(DropTargetEvent event) {
            if (event.detail == 16) {
               event.detail = 1;
            }
         }

         public void dragOver(DropTargetEvent event) {
            event.detail = 0;
            TableItem item = (TableItem)event.item;
            if (item != null) {
               int itemIndex = table.indexOf(item);
               if (itemIndex % 2 == 0) {
                  int index = 0;

                  while (index < event.dataTypes.length && !this.fileTransfer.isSupportedType(event.dataTypes[index])) {
                     index++;
                  }

                  if (index < event.dataTypes.length) {
                     event.currentDataType = event.dataTypes[index];
                     event.detail = 1;
                     return;
                  }
               } else {
                  int index = 0;

                  while (index < event.dataTypes.length && !this.textTransfer.isSupportedType(event.dataTypes[index])) {
                     index++;
                  }

                  if (index < event.dataTypes.length) {
                     event.currentDataType = event.dataTypes[index];
                     event.detail = 1;
                     return;
                  }
               }
            }
         }

         public void drop(DropTargetEvent event) {
            TableItem item = (TableItem)event.item;
            if (item == null) {
               event.detail = 0;
            } else {
               if (this.fileTransfer.isSupportedType(event.currentDataType)) {
                  String[] files = (String[])event.data;
                  if (files != null && files.length > 0) {
                     item.setText(files[0]);
                  }
               }

               if (this.textTransfer.isSupportedType(event.currentDataType)) {
                  String text = (String)event.data;
                  if (text != null) {
                     item.setText(text);
                  }
               }
            }
         }
      });
      shell.setSize(300, 150);
      shell.open();

      while (!shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }

      display.dispose();
   }
}
