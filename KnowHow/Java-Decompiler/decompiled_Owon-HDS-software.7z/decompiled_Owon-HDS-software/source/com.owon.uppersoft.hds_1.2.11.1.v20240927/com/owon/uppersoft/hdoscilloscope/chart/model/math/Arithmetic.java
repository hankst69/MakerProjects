package com.owon.uppersoft.hdoscilloscope.chart.model.math;

import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;

public class Arithmetic {
   private int FALL = -1;
   private int NONE = 0;
   private int RISE = 1;
   private int edgeFail = -1;
   private int pValueFail = 100000;
   private int nValueFail = -100000;
   private int riseP1;
   private int fallP1;
   private int riseP2;
   private int fallP2;
   private int peridDataSum;
   private int edgeBeing;
   private double vTop;
   private double vBase;
   private double vAmp;
   private double vOverShoot;
   private double vPreShoot;
   private double pDuty;
   private double nDuty;
   private double pWidth;
   private double nWidth;
   private int max;
   private int min;
   private int riseTime;
   private int fallTime;
   private int pDelay;
   private int nDelay;
   private int pPhaseDelay;
   private int nPhaseDelay;
   private int[] intADCollection;
   private int adcLen;
   private int step;
   private int maxmin;
   private int edgeSelect;
   private int zeroYPoint;
   private WaveForm wf1;
   private WaveForm wf2;
   private WaveForm wf;

   public Arithmetic() {
   }

   public Arithmetic(WaveFormFileCurve wffc) {
      this.wf1 = wffc.getWaveFormFile().getWaveForm("CH1");
      this.wf2 = wffc.getWaveFormFile().getWaveForm("CH2");
   }

   public void getValue(int step, WaveForm wf) {
      this.wf = wf;
      this.intADCollection = wf.getIntADCollection();
      this.zeroYPoint = 0;
      this.adcLen = this.intADCollection.length;
      this.step = step;
      this.max = wf.getMaxShtADData();
      this.min = wf.getMinShtADData();
      this.edgeSelect = this.NONE;
      this.maxmin = (this.max - this.min) / 2 + this.min;
      double squareSum = 0.0;
      double average = 0.0;

      for (int i = 0; i < this.adcLen; i++) {
         squareSum += (double)(this.intADCollection[i] * this.intADCollection[i]);
         average += (double)this.intADCollection[i];
      }

      if (this.adcLen > 0) {
         squareSum = Math.sqrt(squareSum / (double)this.adcLen);
         average /= (double)this.adcLen;
      } else {
         squareSum = 0.0;
         average = 0.0;
      }

      this.getVtopVbaseShootValue(0);
      this.getRiseFallTime(wf);
      this._get_PulseWidth();
   }

   public void getVtopVbaseShootValue(int start) {
      int i = 0;

      while (i < this.intADCollection.length) {
         if (this.maxmin + 7 < this.intADCollection[i]) {
            this.edgeSelect = this.FALL;
            break;
         }

         if (this.maxmin - 7 > this.intADCollection[i]) {
            this.edgeSelect = this.RISE;
            break;
         }

         i += this.step;
      }

      if (i >= this.intADCollection.length) {
         this.vTop = (double)this.pValueFail;
         this.vBase = (double)this.nValueFail;
      } else {
         if (this.RISE == this.edgeSelect) {
            this.getRise(i, this.maxmin + 7, this.maxmin - 7, this.edgeSelect);
         } else {
            this.getFall(i, this.maxmin + 7, this.maxmin - 7, this.edgeSelect);
         }

         this.getVtopVbaseShoot();
      }
   }

   private void getRise(int start, int winHigh, int winLow, int edgeSelect) {
      int i = start;

      while (i < this.intADCollection.length) {
         if (winHigh < this.intADCollection[i]) {
            this.riseP1 = i;
            break;
         }

         i += this.step;
      }

      if (i >= this.intADCollection.length) {
         this.riseP1 = this.edgeFail;
         this.peridDataSum = this.edgeFail;
         this.edgeBeing = 0;
      } else {
         for (this.edgeBeing = 1; i < this.intADCollection.length; i += this.step) {
            if (winLow > this.intADCollection[i]) {
               this.fallP1 = i;
               break;
            }
         }

         if (i >= this.intADCollection.length) {
            this.fallP1 = this.edgeFail;
            this.peridDataSum = this.edgeFail;
         } else {
            while (i < this.intADCollection.length) {
               if (winHigh < this.intADCollection[i]) {
                  this.riseP2 = i;
                  this.peridDataSum = this.riseP2 - this.riseP1;
                  return;
               }

               i += this.step;
            }

            this.riseP2 = this.edgeFail;
            this.peridDataSum = this.edgeFail;
         }
      }
   }

   private void getFall(int start, int winHigh, int winLow, int edgeSelect) {
   }

   private void getVtopVbaseShoot() {
      int[] ADData = new int[1024];
      if (this.RISE == this.edgeSelect) {
         if (this.edgeFail == this.peridDataSum) {
            if (this.edgeFail == this.riseP1) {
               this.vTop = (double)this.pValueFail;
               this.vBase = (double)this.nValueFail;
            } else {
               for (int i = 0; i < this.adcLen; i += this.step) {
                  ADData[this.intADCollection[i] + 128 + this.zeroYPoint]++;
               }
            }
         } else {
            for (int i = this.riseP1; i < this.riseP2; i += this.step) {
               ADData[this.intADCollection[i] + 128 + this.zeroYPoint]++;
            }
         }
      } else if (this.edgeFail == this.peridDataSum) {
         if (this.edgeFail == this.fallP1) {
            this.vTop = (double)this.pValueFail;
            this.vBase = (double)this.nValueFail;
         } else {
            for (int i = 0; i < this.adcLen; i += this.step) {
               ADData[this.intADCollection[i] + 128 + this.zeroYPoint]++;
            }
         }
      } else {
         for (int i = this.fallP1; i < this.fallP2; i += this.step) {
            ADData[this.intADCollection[i] + 128 + this.zeroYPoint]++;
         }
      }

      if ((double)this.pValueFail != this.vTop || (double)this.nValueFail != this.vBase) {
         int temp = 0;

         for (int i = this.min + 128 + this.zeroYPoint; i <= (this.max - this.min) / 2 + 128 + this.min + this.zeroYPoint; i++) {
            if (ADData[i] >= temp) {
               temp = ADData[i];
               this.vBase = (double)(i - 128 - this.zeroYPoint);
            }
         }

         temp = 0;

         for (int ix = (this.max - this.min) / 2 + 128 + this.min + this.zeroYPoint; ix <= this.max + 128 + this.zeroYPoint; ix++) {
            if (ADData[ix] >= temp) {
               temp = ADData[ix];
               this.vTop = (double)(ix - 128 - this.zeroYPoint);
            }
         }

         this.vAmp = this.vTop - this.vBase;
         if (0.0 == this.vAmp) {
            this.vOverShoot = (double)this.edgeFail;
            this.vPreShoot = (double)this.edgeFail;
         } else {
            this.vOverShoot = Math.abs((double)this.max - this.vTop) / this.vAmp;
            this.vPreShoot = Math.abs((double)this.min - this.vBase) / this.vAmp;
         }
      }
   }

   public void getRiseFallTime(WaveForm wf) {
      double edgeSelect = (double)this.NONE;
      double ampLow = this.vAmp / 10.0 + this.vBase;
      double ampHigh = this.vAmp * 9.0 / 10.0 + this.vBase;

      int i;
      for (i = 0; i < this.adcLen; i += this.step) {
         if (ampHigh < (double)this.intADCollection[i]) {
            edgeSelect = (double)this.FALL;
            break;
         }

         if (ampLow > (double)this.intADCollection[i]) {
            edgeSelect = (double)this.RISE;
            break;
         }
      }

      if (i >= this.adcLen) {
         this.riseTime = this.edgeFail;
         this.fallTime = this.edgeFail;
      } else if ((double)this.RISE == edgeSelect) {
         this._get_firstRiseEdge(i, ampHigh, ampLow);
      } else {
         this._get_firstFallEdge(i, ampHigh, ampLow);
      }
   }

   void _get_firstRiseEdge(int start, double winHigh, double winLow) {
      int riseP1 = 0;
      int fallP1 = 0;
      int i = start;

      while (i < this.adcLen) {
         if (winLow > (double)this.intADCollection[i]) {
            riseP1 = i;
         }

         if (winHigh <= (double)this.intADCollection[i]) {
            this.riseTime = i - riseP1;
            break;
         }

         i += this.step;
      }

      if (i >= this.adcLen) {
         this.riseTime = this.edgeFail;
         this.fallTime = this.edgeFail;
      } else {
         while (i < this.adcLen) {
            if (winHigh <= (double)this.intADCollection[i]) {
               fallP1 = i;
            }

            if (winLow > (double)this.intADCollection[i]) {
               this.fallTime = i - fallP1;
               return;
            }

            i += this.step;
         }

         if (i >= this.adcLen) {
            this.fallTime = this.edgeFail;
         }
      }
   }

   void _get_firstFallEdge(int start, double winHigh, double winLow) {
      int fallP1 = 0;
      int riseP1 = 0;
      int i = start;

      while (i < this.adcLen) {
         if (winHigh < (double)this.intADCollection[i]) {
            fallP1 = i;
         }

         if (winLow >= (double)this.intADCollection[i]) {
            this.fallTime = i - fallP1;
            break;
         }

         i += this.step;
      }

      if (i >= this.adcLen) {
         this.riseTime = this.edgeFail;
         this.fallTime = this.edgeFail;
      } else {
         while (i < this.adcLen) {
            if (winLow > (double)this.intADCollection[i]) {
               riseP1 = i;
            }

            if (winHigh <= (double)this.intADCollection[i]) {
               this.riseTime = i - riseP1;
               return;
            }

            i += this.step;
         }

         if (i >= this.adcLen) {
            this.riseTime = this.edgeFail;
         }
      }
   }

   public void _get_PulseWidth() {
      double ampHalf = this.vAmp / 2.0 + this.vBase;
      double ampHigh = ampHalf + 5.0;
      double ampLow = ampHalf - 5.0;

      for (int i = 0; i < this.adcLen; i += this.step) {
         if (ampHigh < (double)this.intADCollection[i]) {
            this._get_firstnWidth(i, ampHalf, ampHigh, ampLow);
            break;
         }

         if (ampLow > (double)this.intADCollection[i]) {
            this._get_firstPWidth(i, ampHalf, ampHigh, ampLow);
            break;
         }
      }

      if ((double)this.edgeFail == this.pWidth || (double)this.edgeFail == this.nWidth) {
         this.pDuty = (double)this.edgeFail;
         this.nDuty = (double)this.edgeFail;
      } else if (0.0 != this.pWidth + this.nWidth) {
         this.pDuty = this.pWidth / (this.pWidth + this.nWidth);
         this.nDuty = this.nWidth / (this.pWidth + this.nWidth);
      } else {
         this.pDuty = (double)this.edgeFail;
         this.nDuty = (double)this.edgeFail;
      }

      this.wf.getPublicM().getTimeBaseValue_mS(this.wf.getIntTimeBase());
      this.wf.getWaveFormFile().getXGraticuleNum();
      this.wf.getIntADCollectionNum();
   }

   public void _get_firstPWidth(int start, double winHalf, double winHigh, double winLow) {
      int riseP1 = 0;
      int fallP1 = 0;
      int i = start;

      while (i < this.adcLen) {
         if (winHalf <= (double)this.intADCollection[i]) {
            riseP1 = i;
            break;
         }

         i += this.step;
      }

      if (i >= this.adcLen) {
         this.pWidth = (double)this.edgeFail;
         this.nWidth = (double)this.edgeFail;
      } else {
         while (i < this.adcLen && !(winHigh <= (double)this.intADCollection[i])) {
            i += this.step;
         }

         if (i >= this.adcLen) {
            this.pWidth = (double)this.edgeFail;
            this.nWidth = (double)this.edgeFail;
         } else {
            while (i < this.adcLen) {
               if (winHalf >= (double)this.intADCollection[i]) {
                  fallP1 = i;
                  this.pWidth = (double)(i - riseP1);
                  break;
               }

               i += this.step;
            }

            if (i >= this.adcLen) {
               this.pWidth = (double)this.edgeFail;
               this.nWidth = (double)this.edgeFail;
            } else {
               while (i < this.adcLen && !(winLow >= (double)this.intADCollection[i])) {
                  i += this.step;
               }

               if (i >= this.adcLen) {
                  this.nWidth = (double)this.edgeFail;
               } else {
                  while (i < this.adcLen) {
                     if (winHalf <= (double)this.intADCollection[i]) {
                        this.nWidth = (double)(i - fallP1);
                        return;
                     }

                     i += this.step;
                  }

                  if (i >= this.adcLen) {
                     this.nWidth = (double)this.edgeFail;
                  }
               }
            }
         }
      }
   }

   public void _get_firstnWidth(int start, double winHalf, double winHigh, double winLow) {
      int riseP1 = 0;
      int fallP1 = 0;
      int i = start;

      while (i < this.adcLen) {
         if (winHalf >= (double)this.intADCollection[i]) {
            fallP1 = i;
            break;
         }

         i += this.step;
      }

      if (i >= this.adcLen) {
         this.pWidth = (double)this.edgeFail;
         this.nWidth = (double)this.edgeFail;
      } else {
         while (i < this.adcLen && !(winLow >= (double)this.intADCollection[i])) {
            i += this.step;
         }

         if (i >= this.adcLen) {
            this.pWidth = (double)this.edgeFail;
            this.nWidth = (double)this.edgeFail;
         } else {
            while (i < this.adcLen) {
               if (winHalf <= (double)this.intADCollection[i]) {
                  riseP1 = i;
                  this.nWidth = (double)(i - fallP1);
                  break;
               }

               i += this.step;
            }

            if (i >= this.adcLen) {
               this.pWidth = (double)this.edgeFail;
               this.nWidth = (double)this.edgeFail;
            } else {
               while (i < this.adcLen && !(winHigh <= (double)this.intADCollection[i])) {
                  i += this.step;
               }

               if (i >= this.adcLen) {
                  this.pWidth = (double)this.edgeFail;
               } else {
                  while (i < this.adcLen) {
                     if (winHalf >= (double)this.intADCollection[i]) {
                        this.pWidth = (double)(i - riseP1);
                        return;
                     }

                     i += this.step;
                  }

                  if (i >= this.adcLen) {
                     this.pWidth = (double)this.edgeFail;
                  }
               }
            }
         }
      }
   }
}
