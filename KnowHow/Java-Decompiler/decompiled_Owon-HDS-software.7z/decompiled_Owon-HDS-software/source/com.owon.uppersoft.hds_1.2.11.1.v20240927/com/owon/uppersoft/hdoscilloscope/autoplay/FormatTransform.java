package com.owon.uppersoft.hdoscilloscope.autoplay;

import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Listener;

public class FormatTransform extends FormatTransformFrame implements Listener, Runnable {
   private String src;
   private String dst;

   public FormatTransform() {
      this.addListener();
   }

   public boolean transform() {
      try {
         RandomAccessFile accessFile = new RandomAccessFile(this.src, "r");
         long len = accessFile.length();
         this.setMax((int)(len >> 10));
         int count = 0;
         FileWriter fw = new FileWriter(this.dst + "\\filename.ini");

         while (accessFile.getFilePointer() < len) {
            int i = this.nextInt(accessFile);
            byte[] b = new byte[i];
            accessFile.read(b);
            String file = this.dst + "\\" + count + ".bin";
            FileOutputStream fos = new FileOutputStream(file);
            fos.write("SPBXDS".getBytes());
            fos.write(b);
            fos.flush();
            fos.close();
            fw.write(count + ".bin\r\n");
            count++;
            if (this.shell.isDisposed()) {
               break;
            }

            this.setSelection((int)(accessFile.getFilePointer() >> 10));
         }

         fw.flush();
         fw.close();
         accessFile.close();
         this.result = this.dst;
         return true;
      } catch (FileNotFoundException var10) {
         var10.printStackTrace();
      } catch (IOException var11) {
         var11.printStackTrace();
      } catch (Exception var12) {
         var12.printStackTrace();
      }

      return false;
   }

   private int nextInt(RandomAccessFile f) {
      try {
         int i = f.readByte() & 255;
         i += (f.readByte() & 255) << 8;
         i += (f.readByte() & 255) << 16;
         return i + ((f.readByte() & 0xFF) << 24);
      } catch (IOException var3) {
         var3.printStackTrace();
         return -1;
      }
   }

   private void addListener() {
      this.btnOpenFile.addListener(3, this);
      this.btnOpenFolder.addListener(3, this);
      this.btnStart.addListener(3, this);
   }

   public void handleEvent(Event event) {
      Object o = event.widget;
      if (o == this.btnOpenFile) {
         FileDialog fd = new FileDialog(this.shell);
         fd.setFilterExtensions(new String[]{"*.bin"});
         String src = fd.open();
         if (src != null && src.length() != 0) {
            this.text.setText(src);
         }
      } else if (o == this.btnOpenFolder) {
         DirectoryDialog dd = new DirectoryDialog(this.shell);
         String dst = dd.open();
         if (dst != null && dst.length() != 0) {
            this.text_1.setText(dst);
         }
      } else if (o == this.btnStart) {
         this.src = this.text.getText();
         this.dst = this.text_1.getText();
         File f = new File(this.src);
         File f1 = new File(this.dst);
         if (this.src.length() != 0 && this.dst.length() != 0 && f.exists() && f1.isDirectory()) {
            new Thread(this).start();
         } else {
            ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle();
            MessageDialog.openError(this.shell, "", rb.getString("AutoPlay.err"));
         }
      }
   }

   @Override
   public void run() {
      this.transform();
      this.shell.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            FormatTransform.this.shell.dispose();
         }
      });
   }

   private void setMax(final int value) {
      this.shell.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            FormatTransform.this.progressBar.setMaximum(value);
         }
      });
   }

   private void setSelection(final int value) {
      this.shell.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            if (!FormatTransform.this.shell.isDisposed()) {
               FormatTransform.this.progressBar.setSelection(value);
            }
         }
      });
   }
}
