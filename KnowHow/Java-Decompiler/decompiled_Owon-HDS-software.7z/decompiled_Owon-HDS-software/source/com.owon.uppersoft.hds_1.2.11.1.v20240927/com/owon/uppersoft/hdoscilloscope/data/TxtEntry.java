package com.owon.uppersoft.hdoscilloscope.data;

import com.owon.uppersoft.common.aspect.Localizable2;
import java.util.ResourceBundle;

public class TxtEntry implements Localizable2 {
   public boolean common = false;
   public boolean useKey;
   public String k;
   public String n;
   public String v;

   public TxtEntry(boolean useKey, String n, String v) {
      this.useKey = useKey;
      this.k = this.n = n;
      this.v = v;
   }

   public void localize(ResourceBundle bundle) {
      if (this.useKey) {
         this.n = bundle.getString(this.k);
      }
   }
}
