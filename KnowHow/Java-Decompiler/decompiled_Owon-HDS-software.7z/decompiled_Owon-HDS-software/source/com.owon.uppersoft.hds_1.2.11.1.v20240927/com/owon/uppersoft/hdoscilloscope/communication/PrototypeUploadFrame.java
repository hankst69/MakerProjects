package com.owon.uppersoft.hdoscilloscope.communication;

import com.owon.uppersoft.common.aspect.Localizable;
import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.util.ResourceBundle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class PrototypeUploadFrame implements Localizable {
   protected Label retriesLabel;
   protected Label prograssLabel;
   protected Label labFileType;
   protected Label storingLabel;
   protected Label receivingLabel;
   protected Text txtProgress;
   protected Text txtProgressValue;
   protected Text txtRetries;
   protected Text txtFileType;
   protected Text txtStoring;
   protected Text txtReceiving;
   protected Button checkCloseOnDone;
   protected Button btnOperate;
   protected Button btnBrowse;
   protected ProgressBar pb;
   protected Shell shell;
   protected String txtStart;
   protected String txtCancel;

   public Shell getShell() {
      return this.shell;
   }

   public PrototypeUploadFrame(Shell parent) {
      this.shell = new Shell(parent, 67680);
      this.createContents();
   }

   public Object open() {
      this.shell.pack();
      ShellUtil.centerLoc(this.shell);
      this.shell.open();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }

      return null;
   }

   protected void createContents() {
      this.shell.setLayout(new GridLayout());
      Composite composite = new Composite(this.shell, 0);
      GridLayout gridLayout_1 = new GridLayout();
      gridLayout_1.verticalSpacing = 10;
      gridLayout_1.numColumns = 5;
      composite.setLayout(gridLayout_1);
      GridData gd_composite = new GridData(4, 4, true, true);
      composite.setLayoutData(gd_composite);
      this.receivingLabel = new Label(composite, 0);
      GridData gd_receivingLabel = new GridData(4, 4, false, false);
      gd_receivingLabel.heightHint = 20;
      gd_receivingLabel.widthHint = 100;
      this.receivingLabel.setLayoutData(gd_receivingLabel);
      this.txtReceiving = new Text(composite, 2056);
      GridData gd_txtReceiving = new GridData(16384, 16777216, false, false, 4, 1);
      gd_txtReceiving.widthHint = 80;
      this.txtReceiving.setLayoutData(gd_txtReceiving);
      this.storingLabel = new Label(composite, 0);
      GridData gd_storingLabel = new GridData(4, 4, false, false);
      gd_storingLabel.heightHint = 20;
      this.storingLabel.setLayoutData(gd_storingLabel);
      this.txtStoring = new Text(composite, 2056);
      this.txtStoring.setLayoutData(new GridData(4, 16777216, true, false, 3, 1));
      this.btnBrowse = new Button(composite, 0);
      this.btnBrowse.setLayoutData(new GridData(80, -1));
      this.labFileType = new Label(composite, 0);
      GridData gd_packetLabel = new GridData(4, 4, false, false);
      gd_packetLabel.heightHint = 20;
      this.labFileType.setLayoutData(gd_packetLabel);
      this.txtFileType = new Text(composite, 2056);
      this.txtFileType.setLayoutData(new GridData(80, -1));
      new Label(composite, 0);
      this.retriesLabel = new Label(composite, 0);
      GridData gd_retriesLabel = new GridData(4, 4, false, false);
      gd_retriesLabel.heightHint = 20;
      gd_retriesLabel.widthHint = 80;
      this.retriesLabel.setLayoutData(gd_retriesLabel);
      this.txtRetries = new Text(composite, 2056);
      GridData gd_txtRetries = new GridData(4, 16777216, false, false);
      gd_txtRetries.widthHint = 80;
      this.txtRetries.setLayoutData(gd_txtRetries);
      this.prograssLabel = new Label(composite, 0);
      GridData gd_prograssLabel = new GridData(4, 4, false, false);
      gd_prograssLabel.heightHint = 20;
      this.prograssLabel.setLayoutData(gd_prograssLabel);
      this.pb = new ProgressBar(composite, 0);
      this.pb.setLayoutData(new GridData(4, 16777216, true, false, 2, 1));
      this.txtProgressValue = new Text(composite, 2056);
      GridData gd_txtProgressValue = new GridData(4, 16777216, false, false);
      gd_txtProgressValue.widthHint = 80;
      this.txtProgressValue.setLayoutData(gd_txtProgressValue);
      this.txtProgress = new Text(composite, 2056);
      GridData gd_txtProgress = new GridData(4, 16777216, false, false);
      gd_txtProgress.widthHint = 80;
      this.txtProgress.setLayoutData(gd_txtProgress);
      Composite btnBar = new Composite(this.shell, 0);
      GridData gd_btnBar = new GridData(4, 4, true, false);
      btnBar.setLayoutData(gd_btnBar);
      GridLayout gridLayout = new GridLayout();
      gridLayout.horizontalSpacing = 10;
      gridLayout.numColumns = 2;
      btnBar.setLayout(gridLayout);
      this.checkCloseOnDone = new Button(btnBar, 32);
      GridData gd_checkCloseOnDone = new GridData(4, 4, true, false);
      gd_checkCloseOnDone.heightHint = 20;
      this.checkCloseOnDone.setLayoutData(gd_checkCloseOnDone);
      this.btnOperate = new Button(btnBar, 0);
      GridData gd_btnStart = new GridData(4, 16777216, false, false);
      gd_btnStart.widthHint = 100;
      this.btnOperate.setLayoutData(gd_btnStart);
      this.localize();
   }

   public static void main_hide(String[] args) {
      PrototypeUploadFrame ps = new PrototypeUploadFrame(null);
      ps.open();
   }

   public void localize() {
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      this.shell.setText(bundle.getString("UF.GetData"));
      this.receivingLabel.setText(bundle.getString("UF.Receive"));
      this.storingLabel.setText(bundle.getString("UF.Store"));
      this.labFileType.setText(bundle.getString("UF.FileType"));
      this.prograssLabel.setText(bundle.getString("UF.Progress"));
      this.btnBrowse.setText(bundle.getString("UF.Browse"));
      this.retriesLabel.setText(bundle.getString("UF.Retries"));
      this.txtStart = bundle.getString("UF.Start");
      this.txtCancel = bundle.getString("UF.Cancel");
      this.checkCloseOnDone.setText(bundle.getString("UF.CheckCloseOnDone"));
   }
}
