package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import java.nio.ByteBuffer;

public class TrgGroup {
   public EdgeTrg et = new EdgeTrg();
   public VideoTrg vt = new VideoTrg();
   private int idx = 0;

   public int getIndex() {
      return this.idx;
   }

   public AbsTrg cur() {
      switch (this.idx) {
         case 0:
         default:
            return this.et;
         case 1:
            return this.vt;
      }
   }

   public void setIndex(int v) {
      this.idx = v;
   }

   public int getMode() {
      switch (this.idx) {
         case 0:
         default:
            return 101;
         case 1:
            return 118;
      }
   }

   public void pack(ByteBuffer bb, int sna, int trgchl) {
      int mode = this.getMode();
      AbsTrg at = this.cur();
      at.pack(bb, sna, trgchl, mode);
   }
}
