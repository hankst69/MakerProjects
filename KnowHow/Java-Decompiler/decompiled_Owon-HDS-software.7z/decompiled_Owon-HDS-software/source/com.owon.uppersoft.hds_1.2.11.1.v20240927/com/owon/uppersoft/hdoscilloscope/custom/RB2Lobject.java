package com.owon.uppersoft.hdoscilloscope.custom;

import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;

public class RB2Lobject extends LObject {
   public RB2Lobject(String key) {
      super(key);
   }

   @Override
   public String toString() {
      return ResourceBundleProvider.getMessageLibResourceBundle2().getString(this.getKey());
   }
}
