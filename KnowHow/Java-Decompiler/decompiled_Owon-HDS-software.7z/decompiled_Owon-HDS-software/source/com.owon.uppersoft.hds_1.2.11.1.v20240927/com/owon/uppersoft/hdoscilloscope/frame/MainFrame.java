package com.owon.uppersoft.hdoscilloscope.frame;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.common.communication.LoopCheckUSBStatusThread;
import com.owon.uppersoft.common.utils.CDropTargetAdapter;
import com.owon.uppersoft.common.utils.FileHistoryUtil;
import com.owon.uppersoft.hdoscilloscope.action.ActionFactory;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.chart.model.ControlManger;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.frame.view.Display4k;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.dnd.DropTarget;
import org.eclipse.swt.dnd.FileTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Widget;

public class MainFrame extends PrototypeMainFrame implements Localizable2, Listener {
   public ControlManger ctrlMgr = new ControlManger();
   private boolean isDisp4k;
   private Display4k dsp;
   private LoopCheckUSBStatusThread checkThread;
   private FileHistoryUtil fhu;

   public boolean isDisp4k() {
      return this.isDisp4k;
   }

   public void setDisp4k(boolean isDisp4k) {
      this.isDisp4k = isDisp4k;
      if (isDisp4k) {
         this.dsp = new Display4k(this.shell);
         this.dsp.open();
      } else {
         this.dsp.closed();
      }
   }

   public MainFrame(Display display) {
      super(display);
      this.platform.setMainFrame(this);
      this.customizeContent();
      this.checkThread = new LoopCheckUSBStatusThread(this.getShell(), this.statusLine);
      this.checkThread.turnOnCheck();
   }

   public void turnOffCheck() {
      this.checkThread.turnOffCheck();
   }

   public void turnOnCheck() {
      this.checkThread.turnOnCheck();
   }

   protected void customizeContent() {
      Configuration config = this.platform.getConfiguration();
      this.fhu = new FileHistoryUtil(config.getFileHisCount(), config.fileHistory);
      this.fhu.setFileHistoryMenu(this.fileHistoryMenu, this);
      boolean dottedGraticulevisible = config.dottedGraticuleVisible;
      boolean lineVisible = config.lineVisible;
      this.langMenuItem.setText("&Language");
      Locale locale = config.locale;
      this.localeItemGroup.select(locale);
      DrawingPanel dp = this.center.getDrawingPanel();
      WaveFormFileCurve wffc = dp.getWaveFormFileCurve();
      wffc.setLineVisible(lineVisible);
      this.af.dataLine.setCheck(lineVisible);
      this.af.dataPoint.setCheck(!lineVisible);
      dp.getBackgroundDraw().setDottedGraticuleVisible(dottedGraticulevisible);
      this.af.gridLines.setCheck(dottedGraticulevisible);
      this.addDndSupport();
      this.af.localizeUtil.doLocalize(locale, true);
      this.shell.addShellListener(new ShellAdapter() {
         public void shellClosed(ShellEvent e) {
            MainFrame.this.shell.setVisible(false);
            MainFrame.this.checkThread.turnOffCheck();
            MainFrame.this.af.exit();
         }
      });
      dp.redraw();
   }

   protected void addDndSupport() {
      DropTarget dropTarget = new DropTarget(this.shell, 17);
      dropTarget.setTransfer(new Transfer[]{FileTransfer.getInstance()});
      dropTarget.addDropListener(new CDropTargetAdapter(this.af.open));
   }

   public void localize(ResourceBundle bundle) {
      String msg = ResourceBundleProvider.applyManufacture("MF.title");
      this.shell.setText(bundle.getString(msg));
      this.fileM.localize(bundle);
      this.viewM.localize(bundle);
      this.formatM.localize(bundle);
      this.commM.localize(bundle);
      this.helpM.localize(bundle);
      this.recentlyOpenedFileMenuItem.setText(bundle.getString("MF.recentlyOpenedFile"));
      this.center.localize(bundle);
      this.statusLine.localize(bundle);
      this.platform.getPrintService().localize(bundle);
   }

   public FileHistoryUtil getFileHistoryUtil() {
      return this.fhu;
   }

   public void setWaveFormFile(WaveFormFile wff) {
      if (wff.getIntFileSize() == 2) {
         ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
         String errDefault = bundle.getString("Err.Default");
         String msg = bundle.getString("Err.StopState");
         MessageDialog.openError(this.shell, errDefault, msg);
      } else {
         if (!wff.isRaw()) {
            File file = wff.getOrginalFile();
            this.fhu.add(file);
            this.statusLine.setPath(file.getPath());
         } else {
            this.statusLine.setPath(this.statusLine.getInfoNoFileLoop());
         }

         this.center.setWaveFormFile(wff);
         this.center.resetSashes2();
         this.shell.layout();
         if (this.isDisp4k) {
            List<int[]> wfs = new ArrayList<>();

            for (int i = 1; i < 5; i++) {
               WaveForm wf = wff.getWaveForm("ch" + i);
               if (wf != null) {
                  wfs.add(wf.getOriginalAD());
               }
            }

            try {
               this.dsp.setAdc(wfs);
            } catch (Exception var5) {
               this.setDisp4k(false);
            }
         }
      }
   }

   public ActionFactory getActionFactory() {
      return this.af;
   }

   public void handleEvent(Event event) {
      if (event.type == 13) {
         Widget w = event.widget;
         if (w instanceof MenuItem) {
            MenuItem mi = (MenuItem)w;
            File file = this.fhu.getFileFromMenuItem(mi, this.fileHistoryMenu);
            if (file != null) {
               this.af.open.doOpenFile(file);
            }
         }
      }
   }
}
