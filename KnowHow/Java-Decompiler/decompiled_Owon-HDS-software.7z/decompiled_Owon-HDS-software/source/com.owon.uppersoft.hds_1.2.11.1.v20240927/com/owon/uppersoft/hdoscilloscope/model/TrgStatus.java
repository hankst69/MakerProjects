package com.owon.uppersoft.hdoscilloscope.model;

public enum TrgStatus {
   Auto,
   Ready,
   Trigd,
   Scan,
   Stop,
   Play;

   public static final TrgStatus[] VALUES = values();

   public String getLabel() {
      return this.toString();
   }
}
