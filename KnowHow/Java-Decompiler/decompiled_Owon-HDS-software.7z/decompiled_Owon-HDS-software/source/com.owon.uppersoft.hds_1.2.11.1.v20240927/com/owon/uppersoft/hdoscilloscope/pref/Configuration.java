package com.owon.uppersoft.hdoscilloscope.pref;

import com.owon.uppersoft.common.preference.AbstractPref;
import com.owon.uppersoft.common.preference.PropertiesUtil;
import com.owon.uppersoft.hdoscilloscope.communication.usb.IDevice;
import com.owon.uppersoft.hdoscilloscope.communication.usb.IUSBProtocol;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Map.Entry;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;

public class Configuration extends AbstractPref {
   public static final String ini = "/com/owon/uppersoft/hdoscilloscope/pref/default.ini";
   public int minLoopDelay = 100;
   public int maxLoopDelay = 10000;
   public int incLoopDelay = 100;
   public int defLoopDelay = 2000;
   public int cmdAvailMode = 0;
   public boolean showMachineType = false;
   public Locale locale = Locale.ENGLISH;
   public boolean dottedGraticuleVisible = true;
   public boolean lineVisible = true;
   public String portType = "USB";
   public String address = "192.168.1.72:3000";
   public String strusbtmc = "";
   public final int parity = 0;
   public final int baudRate = 115200;
   public final int stopBits = 1;
   public final int dataBits = 8;
   public IDevice iDevice;
   public List<File> fileHistory;
   public Reg reg;
   public boolean closeOnDone = false;
   public String autoSavePath = "";
   public String savePath = "";
   public boolean showSplashscreen = true;
   public boolean notifyUSBchange = false;
   public int usbRequestCMDidx = 0;
   public boolean haveClickCOMM = true;
   public Point shellsize = new Point(1004, 709);
   public int[] mainSash = new int[]{10, 3};
   public int[] upSash = new int[]{10, 3};
   public int[] downSash = new int[]{2, 1};
   public RGB bgrgb = new RGB(28, 39, 57);
   public RGB gridrgb = new RGB(150, 184, 218);
   public RGB imgScalergb = new RGB(85, 109, 155);
   public boolean comeFromTDMachine = false;
   public int loopDelay;
   public boolean isDispSn = false;
   public boolean showCustomFreq = false;
   public List<String> iniList = new ArrayList<>(0);

   public boolean isMEMDEPTHRequest() {
      return this.usbRequestCMDidx == 2;
   }

   protected Configuration() {
      InputStream is = Configuration.class.getResourceAsStream("/com/owon/uppersoft/hdoscilloscope/pref/default.ini");
      this.load(is);
      this.loopDelay = this.defLoopDelay;
      this.reg = new Reg();
   }

   public void load(Properties p) {
      super.load(p);
      this.minLoopDelay = PropertiesUtil.loadInt(p, "minLoopDelay");
      this.maxLoopDelay = PropertiesUtil.loadInt(p, "maxLoopDelay");
      this.incLoopDelay = PropertiesUtil.loadInt(p, "incLoopDelay");
      this.defLoopDelay = PropertiesUtil.loadInt(p, "defLoopDelay");
      this.showMachineType = PropertiesUtil.loadBoolean(p, "ShowMachineType");
      this.isDispSn = PropertiesUtil.loadBoolean(p, "isDispSn");
      this.cmdAvailMode = PropertiesUtil.loadInt(p, "CMDAvailMode");
      if (this.cmdAvailMode < 0 || this.cmdAvailMode > 2) {
         this.cmdAvailMode = 2;
      }

      this.showCustomFreq = PropertiesUtil.loadBoolean(p, "showCustomFreq");
      this.showSplashscreen = PropertiesUtil.loadBoolean(p, "showSplashscreen");
   }

   public void loadConfigurationFromProperties(Properties p) {
      this.locale = PropertiesUtil.loadLocale(p);
      PropertiesUtil.loadPoint(p, "ShellSize", this.shellsize);
      int[] temp = PropertiesUtil.loadInts(p, "UpSash", this.upSash.length);
      if (temp.length == this.upSash.length) {
         this.upSash = temp;
      }

      temp = PropertiesUtil.loadInts(p, "DownSash", this.downSash.length);
      if (temp.length == this.downSash.length) {
         this.downSash = temp;
      }

      temp = PropertiesUtil.loadInts(p, "MainSash", this.mainSash.length);
      if (temp.length == this.mainSash.length) {
         this.mainSash = temp;
      }

      this.bgrgb = PropertiesUtil.loadRGB(p, "BackgroundRGB", this.bgrgb);
      this.gridrgb = PropertiesUtil.loadRGB(p, "GridRGB", this.gridrgb);
      this.imgScalergb = PropertiesUtil.loadRGB(p, "ImageScaleRGB", this.imgScalergb);
      this.dottedGraticuleVisible = PropertiesUtil.loadBoolean(p, "DottedGraticulevisible");
      this.lineVisible = PropertiesUtil.loadBoolean(p, "LineVisible");
      this.loadChannelsFromProperties(p);
      this.fileHistory = PropertiesUtil.loadFileHistory(p, "FileHistory", this.getFileHisCount());
      this.showSplashscreen = PropertiesUtil.loadBoolean(p, "ShowSplashscreen");
      this.notifyUSBchange = PropertiesUtil.loadBoolean(p, "NotifyUSBchange");
      this.haveClickCOMM = PropertiesUtil.loadBoolean(p, "HaveClickCOMM");
      this.portType = p.getProperty("PortType", this.portType);
      this.address = p.getProperty("Address", this.address);
      this.strusbtmc = p.getProperty("Address", this.strusbtmc);
      this.autoSavePath = p.getProperty("AutoSavePath", this.autoSavePath).trim();
      this.savePath = p.getProperty("SavePath", this.savePath);
      if (!this.autoSavePath.equals("")) {
         File dir = new File(this.autoSavePath);

         try {
            this.autoSavePath = dir.getCanonicalPath();
         } catch (IOException var5) {
            this.autoSavePath = "";
            var5.printStackTrace();
         }
      }

      this.usbRequestCMDidx = PropertiesUtil.loadInt(p, "USBRequestCMDidx");
      if (this.usbRequestCMDidx < 0 || this.usbRequestCMDidx > IUSBProtocol.CMDS.length - 1) {
         this.usbRequestCMDidx = 0;
      }

      int delay = PropertiesUtil.loadInt(p, "LoopDelay");
      if (delay >= this.minLoopDelay && delay <= this.maxLoopDelay) {
         this.loopDelay = delay;
      } else {
         this.loopDelay = this.defLoopDelay;
      }

      this.closeOnDone = PropertiesUtil.loadBoolean(p, "CloseOnDone");
      this.iniList = PropertiesUtil.loadStringList(p, "AutoPlayerHist", ";");
   }

   public void persistConfigurationToProperties(Properties p) {
      PropertiesUtil.persistLocale(p, this.locale);
      PropertiesUtil.persistPoint(p, "ShellSize", this.shellsize);
      PropertiesUtil.persistInts(p, "UpSash", this.upSash);
      PropertiesUtil.persistInts(p, "DownSash", this.downSash);
      PropertiesUtil.persistInts(p, "MainSash", this.mainSash);
      PropertiesUtil.persistRGB(p, "BackgroundRGB", this.bgrgb);
      PropertiesUtil.persistRGB(p, "GridRGB", this.gridrgb);
      PropertiesUtil.persistRGB(p, "ImageScaleRGB", this.imgScalergb);
      PropertiesUtil.persistBoolean(p, "DottedGraticulevisible", this.dottedGraticuleVisible);
      PropertiesUtil.persistBoolean(p, "LineVisible", this.lineVisible);
      this.persistChannelsToProperties(p);
      if (this.fileHistory != null) {
         PropertiesUtil.persistFileHistory(p, "FileHistory", this.fileHistory);
      }

      p.setProperty("AutoSavePath", this.autoSavePath);
      p.setProperty("SavePath", this.savePath);
      PropertiesUtil.persistBoolean(p, "ShowSplashscreen", this.showSplashscreen);
      PropertiesUtil.persistBoolean(p, "NotifyUSBchange", this.notifyUSBchange);
      PropertiesUtil.persistBoolean(p, "HaveClickCOMM", this.haveClickCOMM);
      p.setProperty("PortType", this.portType);
      p.setProperty("Address", this.address);
      p.setProperty("strusbtmc", this.strusbtmc);
      PropertiesUtil.persistInt(p, "USBRequestCMDidx", this.usbRequestCMDidx);
      PropertiesUtil.persistInt(p, "LoopDelay", this.loopDelay);
      PropertiesUtil.persistBoolean(p, "CloseOnDone", this.closeOnDone);
      PropertiesUtil.persistStringList(p, "AutoPlayerHist", this.iniList, ";");
   }

   protected void loadChannelsFromProperties(Properties p) {
      String chs = p.getProperty("Channels", "");
      StringTokenizer st1 = new StringTokenizer(chs, ";");
      int len1 = st1.countTokens();
      String cos = p.getProperty("ChannelColors", "");
      StringTokenizer st2 = new StringTokenizer(cos, ";");
      int len2 = st2.countTokens();
      len1 = Math.min(len1, len2);

      for (int i = 0; i < len1; i++) {
         String chl = st1.nextToken();
         int cV = Integer.parseInt(st2.nextToken());
         RGB rgb = new RGB(cV >> 16 & 0xFF, cV >> 8 & 0xFF, cV & 0xFF);
         this.reg.getWFReg(chl).setRgb(rgb);
      }
   }

   protected void persistChannelsToProperties(Properties p) {
      StringBuilder sb1 = new StringBuilder();
      StringBuilder sb2 = new StringBuilder();

      for (Entry<String, WFReg> m : this.reg.getTxt_WFReg().entrySet()) {
         String chl = m.getKey();
         if (chl != null) {
            sb1.append(chl);
            sb1.append(";");
            RGB rgb = m.getValue().getRGB();
            if (rgb != null) {
               int cV = rgb.red << 16 | rgb.green << 8 | rgb.blue;
               sb2.append(cV);
               sb2.append(";");
            }
         }
      }

      p.setProperty("Channels", sb1.toString());
      p.setProperty("ChannelColors", sb2.toString());
   }
}
