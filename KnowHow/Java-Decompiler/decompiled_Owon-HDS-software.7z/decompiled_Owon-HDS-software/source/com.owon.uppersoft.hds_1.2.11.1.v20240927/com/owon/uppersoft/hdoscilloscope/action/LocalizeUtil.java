package com.owon.uppersoft.hdoscilloscope.action;

import com.owon.uppersoft.common.i18n.CommonMessageLib;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.util.Locale;
import java.util.ResourceBundle;

public class LocalizeUtil {
   private ActionFactory af;

   public LocalizeUtil(ActionFactory af) {
      this.af = af;
   }

   public void doLocalize(Locale locale) {
      this.doLocalize(locale, false);
   }

   public void doLocalize(Locale locale, boolean force) {
      if (locale != null) {
         if (force || !Locale.getDefault().equals(locale)) {
            Locale.setDefault(locale);
            CommonMessageLib.updateLocale();
            ResourceBundleProvider.updateLocale();
            ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
            this.af.localizeChildren(bundle);
            Platform.getPlatform().getMainFrame().localize(bundle);
         }
      }
   }
}
