package com.owon.uppersoft.hdoscilloscope.chart;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

public class GraphicContext {
   public GC gc;
   public boolean linevisible;
   public Point size = new Point(0, 0);
}
