package com.owon.uppersoft.hdoscilloscope.communication.loop;

public interface ICommunicationListener {
   void progressInfo(int var1);

   void communicateInfo(int var1, String var2);

   void progressInfo_ifn(int var1);

   void communicateInfo_ifn(int var1, String var2);
}
