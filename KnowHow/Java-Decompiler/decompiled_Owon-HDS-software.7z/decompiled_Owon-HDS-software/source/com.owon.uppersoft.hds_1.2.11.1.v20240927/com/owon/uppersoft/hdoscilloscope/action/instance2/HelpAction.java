package com.owon.uppersoft.hdoscilloscope.action.instance2;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.common.utils.SystemPropertiesUtil;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import java.io.File;
import java.io.IOException;
import java.util.Locale;

public class HelpAction extends DefaultAction {
   private Process helpProcessHandle = null;

   public HelpAction(String id) {
      super(id);
   }

   public void run() {
      this.showHelp();
   }

   public void showHelp() {
      Configuration config = Platform.getPlatform().getConfiguration();
      if (SystemPropertiesUtil.isWin32System()) {
         String locale = Locale.getDefault().toString();
         File localeFile = new File(config.getLocaleDir() + File.separator + locale);
         if (!localeFile.exists()) {
            locale = Locale.ENGLISH.toString();
            localeFile = new File(config.getLocaleDir() + File.separator + locale);
         }

         File chmfile = new File(localeFile, config.getProductId() + "_" + locale + "." + "pdf");
         String showHelpCommand = "rundll32 url.dll FileProtocolHandler " + chmfile.getPath();

         try {
            if (this.helpProcessHandle != null) {
               this.helpProcessHandle.destroy();
            }

            this.helpProcessHandle = Runtime.getRuntime().exec(showHelpCommand);
         } catch (IOException var7) {
            var7.printStackTrace();
         }
      }
   }

   public void closeHelpHandle() {
      if (this.helpProcessHandle != null) {
         this.helpProcessHandle.destroy();
         this.helpProcessHandle = null;
      }
   }
}
