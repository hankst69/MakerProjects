package com.owon.uppersoft.hdoscilloscope.test;

import com.owon.uppersoft.common.utils.DisposeUtil;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;

class Feed implements Feedable {
   private int[] is;
   private Color[] cs;
   private String[] ss;
   private Display display;

   public Feed(Display aDisplay) {
      this.display = aDisplay;
      this.is = new int[]{50, 100, 200};
      this.ss = new String[]{"CH1", "CH2", "CH3"};
      this.cs = new Color[]{this.display.getSystemColor(9), this.display.getSystemColor(11), this.display.getSystemColor(5)};
   }

   @Override
   public int getValue(int key) {
      return this.is[key];
   }

   @Override
   public Color getColor(int key) {
      return this.cs[key];
   }

   @Override
   public int getSize() {
      return this.is.length;
   }

   @Override
   public void setColor(Color color, int key) {
      DisposeUtil.tryDispose(this.cs[key]);
      this.cs[key] = color;
   }

   @Override
   public void setValue(int value, int key) {
      int max = 400;
      int min = 0;
      if (value > max) {
         value = max;
      }

      if (value < min) {
         value = min;
      }

      this.is[key] = value;
   }

   @Override
   public String getString(int key) {
      return this.ss[key];
   }

   @Override
   public void setString(int key, String s) {
      this.ss[key] = s;
   }
}
