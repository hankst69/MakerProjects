package com.owon.uppersoft.hdoscilloscope.communication.loop;

import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import java.io.File;

public interface IRapidCommunication {
   void startInit();

   void startOnce();

   void endOnce();

   void endFinl();

   boolean getData();

   void cancel();

   String getFileType();

   CByteArrayInputStream byteInput();

   boolean setSavedFile(File var1);

   String getCommunicaitonErrorMsgKey();

   int read(byte[] var1, int var2, int var3);

   int write(byte[] var1, int var2, int var3);
}
