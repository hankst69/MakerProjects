package com.owon.uppersoft.hdoscilloscope.model;

import com.owon.uppersoft.hdoscilloscope.chart.model.fft.TimeBaseRef;
import com.owon.uppersoft.hdoscilloscope.model.detail.Idn;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MachineInfo {
   public String strFileHead;
   public MachineType mt;
   public List<Dbl_Txt> xbaseList;
   public List<Dbl_Txt> ybaseList;
   public List<TimeBaseRef> tbrs;

   public void setValue(Idn idn) {
      int pixelsPerBlock = WaveFormFileFactory.getPixelsPerBlock();
      this.setValue(idn, true, pixelsPerBlock);
   }

   public void setValue(Idn idn, boolean comeFromTDMachine, int pixelsPerBlock) {
      this.ybaseList = PublicM.StrVv;
      this.mt = MachineFactory.getMachinetype(idn);
      this.xbaseList = this.mt.getXbaseList();
      this.tbrs = setupOther(this.mt, pixelsPerBlock);
   }

   private static final List<TimeBaseRef> setupOther(MachineType mt, int pixelsPerBlock) {
      String filename = mt.getIniFileName();
      InputStream is = TimeBaseRef.class.getResourceAsStream("/com/owon/uppersoft/oscilloscope/chart/model/fft/params/" + filename + ".txt");
      ArrayList<TimeBaseRef> tbrs = new ArrayList<>();
      if (is != null) {
         try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            br.readLine();

            String line;
            while ((line = br.readLine()) != null && (line = line.trim()).length() != 0) {
               if (!line.startsWith("//")) {
                  tbrs.add(new TimeBaseRef(line, pixelsPerBlock));
               }
            }

            br.close();
            return tbrs;
         } catch (FileNotFoundException var7) {
            var7.printStackTrace();
         } catch (IOException var8) {
            var8.printStackTrace();
         }
      }

      return tbrs;
   }
}
