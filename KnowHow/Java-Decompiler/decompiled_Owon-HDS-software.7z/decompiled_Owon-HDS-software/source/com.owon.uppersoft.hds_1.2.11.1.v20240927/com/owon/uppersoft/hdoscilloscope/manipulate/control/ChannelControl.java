package com.owon.uppersoft.hdoscilloscope.manipulate.control;

public class ChannelControl {
   public ChannelInfo[] cis;

   public ChannelControl(int len) {
      this.cis = new ChannelInfo[len];

      for (int i = 0; i < len; i++) {
         this.cis[i] = new ChannelInfo(i);
      }
   }
}
