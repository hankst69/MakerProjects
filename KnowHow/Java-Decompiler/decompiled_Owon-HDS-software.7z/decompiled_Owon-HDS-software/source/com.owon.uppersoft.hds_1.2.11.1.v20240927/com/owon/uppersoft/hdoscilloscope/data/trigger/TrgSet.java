package com.owon.uppersoft.hdoscilloscope.data.trigger;

public class TrgSet {
   public int chlidx;
   public int mode;
   public int level;

   @Override
   public String toString() {
      return String.format("%d, %s, %d", this.chlidx, (char)this.mode, this.level);
   }

   public boolean hasLevel() {
      return this.mode == 101 || this.mode == 112;
   }
}
