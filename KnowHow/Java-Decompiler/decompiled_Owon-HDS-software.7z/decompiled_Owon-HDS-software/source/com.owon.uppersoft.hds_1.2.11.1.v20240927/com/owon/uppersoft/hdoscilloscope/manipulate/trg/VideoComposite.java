package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail2.TrgComposite;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

public class VideoComposite extends AbsTrgComposite implements Localizable2 {
   private Combo synccb;
   private Combo modulecb;
   private Spinner syncV_spin;
   private Label label;
   boolean use = false;

   private VideoTrg getVideoTrg() {
      return this.tcom.getTrgControl().getCurrent().vt;
   }

   public VideoComposite(Composite parent, TrgComposite tc) {
      super(parent, 0, tc);
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 3;
      this.setLayout(gridLayout);
      this.modulecb = new Combo(this, 8);
      this.modulecb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int idx = VideoComposite.this.modulecb.getSelectionIndex();
            VideoTrg vt = VideoComposite.this.getVideoTrg();
            int max = vt.getMax(idx);
            int v = vt.syncV;
            vt.module = idx;
            if (v > max) {
               v = max;
               vt.syncV = max;
            }

            VideoComposite.this.use = false;
            VideoComposite.this.syncV_spin.setSelection(v);
            VideoComposite.this.syncV_spin.setMaximum(max);
            VideoComposite.this.use = true;
            VideoComposite.this.label.setText(" <= " + max);
            String[] s = new String[]{"NTSC", "PAL", "SECAM"};
            String cmd = ":TRIGger:SINGle:System " + s[idx];
            VideoComposite.this.submit(cmd);
         }
      });
      this.modulecb.setItems(TrgControl.VIDEO_MODULE);
      GridData gd_combo = new GridData(16384, 16777216, true, false, 3, 1);
      gd_combo.widthHint = 80;
      this.modulecb.setLayoutData(gd_combo);
      this.synccb = new Combo(this, 8);
      this.synccb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            VideoTrg vt = VideoComposite.this.getVideoTrg();
            int idx = VideoComposite.this.synccb.getSelectionIndex();
            vt.sync = idx;
            VideoComposite.this.syncV_spin.setEnabled(idx == 4);
            String[] s = new String[]{"LINE", "FIELD", "ODD", "EVEN", "LNUM"};
            String cmd = ":TRIGger:SINGle:Sync " + s[idx];
            VideoComposite.this.submit(cmd);
         }
      });
      GridData gd_combo_1 = new GridData(80, -1);
      this.synccb.setLayoutData(gd_combo_1);
      this.syncV_spin = new Spinner(this, 2048);
      this.syncV_spin.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            VideoTrg vt = VideoComposite.this.getVideoTrg();
            int v = VideoComposite.this.syncV_spin.getSelection();
            vt.syncV = v;
            String cmd = ":TRIGger:SINGle:LineNum " + v;
            VideoComposite.this.submit(cmd);
         }
      });
      this.syncV_spin.setLayoutData(new GridData(40, -1));
      this.syncV_spin.setPageIncrement(1);
      this.modulecb.setItems(TrgControl.VIDEO_MODULE);
      this.synccb.setItems(ManipulateControl.toStrings(TrgControl.VIDEO_SYNC));
      this.modulecb.select(0);
      this.synccb.select(0);
      this.syncV_spin.setMinimum(1);
      this.label = new Label(this, 0);
      this.label.setLayoutData(new GridData(4, 16777216, true, false));
      VideoTrg vt = this.getVideoTrg();
      int max = vt.getMax(this.modulecb.getSelectionIndex());
      this.syncV_spin.setMaximum(max);
      this.label.setText(" <= " + max);
      this.syncV_spin.setEnabled(this.synccb.getSelectionIndex() == 4);
   }

   public void localize(ResourceBundle bundle) {
      this.use = false;
      int idx = this.synccb.getSelectionIndex();
      this.synccb.setItems(ManipulateControl.toStrings(TrgControl.VIDEO_SYNC));
      this.synccb.select(idx);
      this.use = true;
   }

   public void submit(String cmd) {
      Platform.getPlatform().getManipulateControl().send(cmd);
   }

   @Override
   protected void loadTrgGroup(TrgControl tc) {
      TrgGroup tg = tc.getCurrent();
      VideoTrg video = tg.vt;
      this.modulecb.select(video.module);
      this.synccb.select(video.sync);
      this.syncV_spin.setSelection(video.syncV);
   }
}
