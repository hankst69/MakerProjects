package com.owon.uppersoft.hdoscilloscope.recycle;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import java.util.ResourceBundle;

public class MemdepthAction extends DefaultAction {
   private SendCommandWindow scw;

   public MemdepthAction(String id) {
      super(id);
   }

   public void run() {
      this.scw = new SendCommandWindow(Platform.getPlatform().getShell());
      this.scw.open();
   }

   public void localize(ResourceBundle bundle) {
      super.localize(bundle);
      if (this.scw != null && !this.scw.getShell().isDisposed()) {
         this.scw.localize();
      }
   }
}
