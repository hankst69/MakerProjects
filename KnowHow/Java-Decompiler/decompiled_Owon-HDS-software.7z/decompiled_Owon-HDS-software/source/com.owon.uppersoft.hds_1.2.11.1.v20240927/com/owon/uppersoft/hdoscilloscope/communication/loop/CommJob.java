package com.owon.uppersoft.hdoscilloscope.communication.loop;

import com.owon.uppersoft.common.logger.LoggerUtil;
import com.owon.uppersoft.hdoscilloscope.communication.usb.PersistBuffer;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.manipulate.CommListenerProvider;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import com.owon.uppersoft.hdoscilloscope.util.DBG;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.logging.Logger;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class CommJob implements Runnable {
   private String[] cmd = new String[]{":DATA:WAVE:SCREEN:HEAD?\r\n", ":DATA:WAVE:SCREEN:BMP?\r\n", ":DATA:WAVE:DEPMEM:HEAD?\r\n"};
   private CommJob cj;
   private ICommunicationListenerProvider iclp;
   private Communication comm;
   public static final Logger logger = LoggerUtil.getConsoleLogger(Communication.class.getName(), DBG.global);
   private boolean isConnected;
   private String head;
   private PersistBuffer pb;
   private String fileType;

   public static void main(String[] args) {
      CommJob cj = new CommJob();
      cj.connect();
      cj.doGetData();
      cj.disConnect();
   }

   public CommJob getInstance() {
      if (this.cj == null) {
         this.cj = new CommJob();
      }

      return this.cj;
   }

   public CommJob() {
      this(new CommListenerProvider());
   }

   public CommJob(ICommunicationListenerProvider iclp) {
      this.iclp = iclp;
   }

   @Override
   public void run() {
   }

   public boolean getData() {
      return this.doGetData();
   }

   public boolean isConnected() {
      return true;
   }

   public void disConnect() {
      if (this.isConnected) {
         this.comm.close();
      }
   }

   public boolean connect() {
      this.isConnected = this.comm.open(new String[]{""});
      return this.isConnected;
   }

   private boolean doGetData() {
      if (!this.isConnected()) {
         return false;
      } else {
         this.pb = new PersistBuffer();
         this.pb.init();
         RandomAccessFile raf = this.pb.raf();
         Configuration config = Platform.getPlatform().getConfiguration();
         System.err.println(config.usbRequestCMDidx);
         if (config.usbRequestCMDidx == 1) {
            this.fileType = "bmp";
         } else {
            this.fileType = "bin";
         }

         String command = this.cmd[config.usbRequestCMDidx];
         this.comm.writeString(command);
         byte[] b = this.readIncludeSize(false);
         if (config.usbRequestCMDidx == 1) {
            try {
               raf.write(b);
            } catch (IOException var12) {
               var12.printStackTrace();
            }

            return true;
         } else {
            JSONObject jo = JSONObject.fromObject(new String(b).trim());
            this.comm.writeString(":model?");
            String model = this.comm.readString();
            System.out.println("model:" + model);
            jo.element("model", model);
            logger.fine(jo.toString());
            System.out.println("CommJob.doGetData()" + jo.toString());
            this.head = jo.toString();
            JSONArray ja = jo.getJSONArray("CHANNEL");

            try {
               raf.writeShort(this.head.length());
               raf.write(this.head.getBytes());

               for (int i = 0; i < ja.size(); i++) {
                  JSONObject ch = ja.getJSONObject(i);
                  String disp = ch.getString("DISPLAY");
                  String name = ch.getString("NAME");
                  if (disp.equalsIgnoreCase("on")) {
                     if (config.usbRequestCMDidx == 0) {
                        this.comm.writeString(":DATA:WAVE:SCREEN:" + name + "?\r\n");
                     } else {
                        this.comm.writeString(":DATA:WAVE:DEPMEM:" + name + "?\r\n");
                     }

                     b = this.readIncludeSize(false);
                     raf.write(b);
                  }
               }
            } catch (Exception var13) {
               var13.printStackTrace();
            }

            return true;
         }
      }
   }

   private byte[] readIncludeSize(boolean order) {
      byte[] b = new byte[4096];
      int num = this.comm.read(b, 0, b.length);
      if (num <= 4) {
         return null;
      } else {
         System.out.println(num);
         int len = this.getInt(b, order);
         this.iclp.getCommunicationListener().communicateInfo(len, "bin");
         System.out.println("len" + len);
         ByteBuffer bb = ByteBuffer.allocate(len);
         bb.put(b, 4, num - 4);
         int time = 0;

         while (bb.remaining() > 0) {
            num = this.comm.read(b, 0, b.length);
            if (num <= 0) {
               System.out.println("error");
               if (time-- < 0) {
                  break;
               }
            } else {
               bb.put(b, 0, num);
               this.iclp.getCommunicationListener().progressInfo(bb.position());
            }
         }

         return bb.array();
      }
   }

   private void slp() {
      try {
         Thread.sleep(1000L);
      } catch (InterruptedException var2) {
         var2.printStackTrace();
      }
   }

   private int getInt(byte[] b) {
      int i = b[0] & 255;
      i += (b[1] & 255) << 8;
      i += (b[2] & 255) << 16;
      return i + ((b[3] & 0xFF) << 24);
   }

   private int getInt(byte[] b, boolean order) {
      if (order) {
         int i = b[3] & 255;
         i += (b[2] & 255) << 8;
         i += (b[1] & 255) << 16;
         return i + ((b[0] & 0xFF) << 24);
      } else {
         int i = b[0] & 255;
         i += (b[1] & 255) << 8;
         i += (b[2] & 255) << 16;
         return i + ((b[3] & 0xFF) << 24);
      }
   }

   public String getHead() {
      return this.head;
   }

   public String getFileType() {
      return this.fileType;
   }

   public boolean setSavedFile(File f) {
      return this.pb.renameTo(f);
   }
}
