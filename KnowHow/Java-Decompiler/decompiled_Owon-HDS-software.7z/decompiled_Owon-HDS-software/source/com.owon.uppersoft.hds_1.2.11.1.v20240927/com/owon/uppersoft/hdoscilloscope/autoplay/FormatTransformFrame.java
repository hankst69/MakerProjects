package com.owon.uppersoft.hdoscilloscope.autoplay;

import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.util.ResourceBundle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class FormatTransformFrame {
   protected String result;
   protected Shell shell;
   private Display display;
   protected Text text;
   protected Text text_1;
   protected ProgressBar progressBar;
   protected Button btnOpenFile;
   protected Button btnOpenFolder;
   protected Button btnStart;
   private Label lbFile;
   private Label lbFoler;
   private Label lbprg;

   public FormatTransformFrame() {
      this.createContents();
   }

   public String open() {
      this.display = this.shell.getDisplay();
      this.shell.open();

      while (!this.shell.isDisposed()) {
         if (!this.display.readAndDispatch()) {
            this.display.sleep();
         }
      }

      return this.result;
   }

   protected void createContents() {
      this.shell = new Shell(Platform.getPlatform().getShell(), 82080);
      this.shell.setSize(600, 220);
      this.shell.setLayout(new FillLayout());
      Composite com = new Composite(this.shell, 0);
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 3;
      com.setLayout(gridLayout);
      this.lbFile = new Label(com, 0);
      this.lbFile.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.text = new Text(com, 2048);
      this.text.setLayoutData(new GridData(4, 16777216, true, false, 1, 1));
      this.btnOpenFile = new Button(com, 0);
      this.btnOpenFile.setText("New Button");
      this.lbFoler = new Label(com, 0);
      this.lbFoler.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.text_1 = new Text(com, 2048);
      this.text_1.setLayoutData(new GridData(4, 16777216, true, false, 1, 1));
      this.btnOpenFolder = new Button(com, 0);
      this.lbprg = new Label(com, 0);
      this.lbprg.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.progressBar = new ProgressBar(com, 0);
      this.progressBar.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.btnStart = new Button(com, 0);
      this.btnStart.setText("New Button");
      this.localize();
      ShellUtil.centerLoc(this.shell);
   }

   public Shell getShell() {
      return this.shell;
   }

   public void localize() {
      this.localize(ResourceBundleProvider.getMessageLibResourceBundle());
   }

   public void localize(ResourceBundle bundle) {
      if (!this.shell.isDisposed()) {
         this.btnOpenFile.setText(bundle.getString("AutoPlay.open"));
         this.btnOpenFolder.setText(bundle.getString("AutoPlay.open"));
         this.btnStart.setText(bundle.getString("AutoPlay.start"));
         this.lbFile.setText(bundle.getString("AutoPlay.srcChoose"));
         this.lbFoler.setText(bundle.getString("AutoPlay.dstChoose"));
         this.lbprg.setText(bundle.getString("AutoPlay.prg"));
      }
   }
}
