package com.owon.uppersoft.hdoscilloscope.print;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.common.print.CustomizeScale;
import com.owon.uppersoft.common.print.PageSetup;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.util.ResourceBundle;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.ColorDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;

public class PrintPreview implements PaintListener, Localizable2 {
   private MenuItem showWFBGmenuItem;
   private MenuItem paperBGMenuItem;
   private MenuItem viewMenuItem;
   private MenuItem fileMenuItem;
   private Composite previewCom;
   private ScrolledComposite scrolledComposite;
   private MenuItem customizeMenuItem;
   private MenuItem realPageMenuItem;
   private MenuItem wholePageMenuItem;
   private MenuItem pageSetupMenuItem;
   private MenuItem printMenuItem;
   private MenuItem exitMenuItem;
   private Shell shell;
   private PrintService ps;
   private PrintPreview.CSelectionListener cselect = new PrintPreview.CSelectionListener();
   private Rectangle customizeTrim;
   private PageSetup pageSetup;
   private CustomizeScale customizeScale;
   private Composite composite;
   private double scale;
   private int type;

   public Shell getShell() {
      return this.shell;
   }

   public PrintPreview(PrintService ps, Display display) {
      this.ps = ps;
      this.customizeTrim = ps.getCustomizeTrim();
      this.scale = 1.0;
      this.type = ps.getDrawJob().getPrintMode();
      this.shell = new Shell(display, 1264);
   }

   public static void main_hide(String[] args) {
      try {
         PrintPreview window = new PrintPreview(Platform.getPlatform().getPrintService(), Platform.getPlatform().getDisplay());
         window.open();
      } catch (Exception var2) {
         var2.printStackTrace();
      }
   }

   public void open() {
      this.createContents();
      this.customizeContents();
      this.shell.open();
      this.resetCompositeSize();
      this.shell.layout();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   protected void createContents() {
      this.shell.setLayout(new FillLayout());
      this.shell.setMaximized(true);
      Menu menu = new Menu(this.shell, 2);
      this.shell.setMenuBar(menu);
      this.fileMenuItem = new MenuItem(menu, 64);
      Menu fileMenu = new Menu(this.fileMenuItem);
      this.fileMenuItem.setMenu(fileMenu);
      this.pageSetupMenuItem = new MenuItem(fileMenu, 0);
      this.printMenuItem = new MenuItem(fileMenu, 0);
      new MenuItem(fileMenu, 2);
      this.exitMenuItem = new MenuItem(fileMenu, 0);
      this.viewMenuItem = new MenuItem(menu, 64);
      Menu viewMenu = new Menu(this.viewMenuItem);
      this.viewMenuItem.setMenu(viewMenu);
      this.wholePageMenuItem = new MenuItem(viewMenu, 0);
      this.realPageMenuItem = new MenuItem(viewMenu, 0);
      this.customizeMenuItem = new MenuItem(viewMenu, 0);
      new MenuItem(viewMenu, 2);
      this.showWFBGmenuItem = new MenuItem(viewMenu, 32);
      this.paperBGMenuItem = new MenuItem(viewMenu, 0);
      this.scrolledComposite = new ScrolledComposite(this.shell, 768);
      this.scrolledComposite.getVerticalBar().setPageIncrement(50);
      this.scrolledComposite.getHorizontalBar().setPageIncrement(50);
      this.scrolledComposite.getVerticalBar().setIncrement(50);
      this.scrolledComposite.getHorizontalBar().setIncrement(50);
      this.composite = new Composite(this.scrolledComposite, 0);
      this.scrolledComposite.setContent(this.composite);
      this.previewCom = new Composite(this.composite, 2048);
   }

   protected void customizeContents() {
      this.shell.setImage(Platform.getPlatform().getImageShop().getImage("printPreview.gif"));
      this.shell.addDisposeListener(new DisposeListener() {
         public void widgetDisposed(DisposeEvent e) {
            if (PrintPreview.this.pageSetup != null && !PrintPreview.this.pageSetup.getShell().isDisposed()) {
               PrintPreview.this.pageSetup.getShell().close();
            }

            if (PrintPreview.this.customizeScale != null && !PrintPreview.this.customizeScale.getShell().isDisposed()) {
               PrintPreview.this.customizeScale.getShell().close();
            }
         }
      });
      boolean b = this.ps.getDrawJob().getPrintMode() == 1;
      this.showWFBGmenuItem.setSelection(b);
      int SWT_Selection = 13;
      Listener listener = this.cselect;
      this.pageSetupMenuItem.addListener(SWT_Selection, listener);
      this.printMenuItem.addListener(SWT_Selection, listener);
      this.exitMenuItem.addListener(SWT_Selection, listener);
      this.wholePageMenuItem.addListener(SWT_Selection, listener);
      this.realPageMenuItem.addListener(SWT_Selection, listener);
      this.customizeMenuItem.addListener(SWT_Selection, listener);
      this.paperBGMenuItem.addListener(SWT_Selection, listener);
      this.showWFBGmenuItem.addListener(SWT_Selection, listener);
      this.previewCom.addPaintListener(this);
      this.localize(ResourceBundleProvider.getMessageLibResourceBundle());
   }

   public void paintControl(PaintEvent e) {
      this.ps.doPrintPreview(e.gc, this.customizeTrim, this.scale, this.type);
   }

   protected void resetCompositeSize() {
      int w = (int)((double)this.ps.getA4PageWidth() * this.scale);
      int h = (int)((double)this.ps.getA4PageHeight() * this.scale);
      Rectangle r = this.shell.getMonitor().getClientArea();
      int x = r.width - w >> 1;
      int y = r.height - h >> 1;
      if (x < 0) {
         x = 0;
      }

      if (y < 0) {
         y = 0;
      }

      this.previewCom.setBounds(x, y, w, h);
      this.composite.pack();
   }

   public void localize(ResourceBundle bundle) {
      this.shell.setText(bundle.getString("PP.title"));
      this.fileMenuItem.setText(bundle.getString("PP.file"));
      this.pageSetupMenuItem.setText(bundle.getString("PP.PageSetup"));
      this.printMenuItem.setText(bundle.getString("PP.Print"));
      this.exitMenuItem.setText(bundle.getString("PP.Exit"));
      this.viewMenuItem.setText(bundle.getString("PP.View"));
      this.wholePageMenuItem.setText(bundle.getString("PP.WholePage"));
      this.realPageMenuItem.setText(bundle.getString("PP.RealPage"));
      this.customizeMenuItem.setText(bundle.getString("PP.Customize"));
      this.paperBGMenuItem.setText(bundle.getString("PP.PaperBG"));
      this.showWFBGmenuItem.setText(bundle.getString("PP.ShowWFBG"));
      if (this.pageSetup != null && !this.pageSetup.getShell().isDisposed()) {
         this.pageSetup.localize();
      }

      if (this.customizeScale != null && !this.customizeScale.getShell().isDisposed()) {
         this.customizeScale.localize();
      }
   }

   class CSelectionListener implements Listener {
      private int SWT_Selection = 13;

      public void handleEvent(Event event) {
         if (event.type == this.SWT_Selection) {
            Object o = event.widget;
            if (o == PrintPreview.this.pageSetupMenuItem) {
               PrintPreview.this.pageSetup = new PageSetup(PrintPreview.this.shell);
               PrintPreview.this.customizeTrim = PrintPreview.this.pageSetup.open(PrintPreview.this.customizeTrim);
               PrintPreview.this.previewCom.redraw();
               PrintPreview.this.pageSetup = null;
            }

            if (o == PrintPreview.this.printMenuItem) {
               PrintPreview.this.ps.printProcedure(PrintPreview.this.shell);
            }

            if (o == PrintPreview.this.exitMenuItem) {
               PrintPreview.this.shell.close();
            }

            if (o == PrintPreview.this.wholePageMenuItem) {
               double dscale = (double)PrintPreview.this.scrolledComposite.getSize().y / (double)PrintPreview.this.ps.getA4PageHeight();
               PrintPreview.this.scale = dscale;
               PrintPreview.this.resetCompositeSize();
            }

            if (o == PrintPreview.this.realPageMenuItem) {
               PrintPreview.this.scale = 1.0;
               PrintPreview.this.resetCompositeSize();
            }

            if (o == PrintPreview.this.customizeMenuItem) {
               PrintPreview.this.customizeScale = new CustomizeScale(PrintPreview.this.shell);
               PrintPreview.this.scale = PrintPreview.this.customizeScale.open(PrintPreview.this.scale);
               PrintPreview.this.resetCompositeSize();
               PrintPreview.this.customizeScale = null;
            }

            if (o == PrintPreview.this.paperBGMenuItem) {
               ColorDialog ds = new ColorDialog(PrintPreview.this.shell);
               ds.setRGB(PrintPreview.this.ps.getPaperBackgroundRGB());
               RGB rgb = ds.open();
               if (rgb != null) {
                  PrintPreview.this.ps.setPaperBackgroundRGB(rgb);
                  PrintPreview.this.previewCom.redraw();
               }
            }

            if (o == PrintPreview.this.showWFBGmenuItem) {
               PrintPreview.this.type = PrintPreview.this.showWFBGmenuItem.getSelection() ? 1 : 0;
               PrintPreview.this.previewCom.redraw();
            }
         }
      }
   }
}
