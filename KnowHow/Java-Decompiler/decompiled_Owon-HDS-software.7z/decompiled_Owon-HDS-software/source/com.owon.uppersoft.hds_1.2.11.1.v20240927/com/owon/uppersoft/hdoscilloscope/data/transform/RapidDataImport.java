package com.owon.uppersoft.hdoscilloscope.data.transform;

import com.owon.uppersoft.hdoscilloscope.chart.model.ControlManger;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.FFTInfo;
import com.owon.uppersoft.hdoscilloscope.data.InfoPart;
import com.owon.uppersoft.hdoscilloscope.data.MultiMeter;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.model.MachineFactory;
import com.owon.uppersoft.hdoscilloscope.model.MachineType;
import com.owon.uppersoft.hdoscilloscope.model.PublicM;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormFileFactory;
import com.owon.uppersoft.hdoscilloscope.model.detail.Idn;
import java.io.UnsupportedEncodingException;
import java.util.logging.Handler;
import net.sf.json.JSONObject;

public class RapidDataImport extends AbstractDataImport {
   private CByteArrayInputStream ba;

   public int simulateReadIntNow() {
      return this.ba.nextInt();
   }

   protected WaveFormFile readFileLayer(CByteArrayInputStream ba) throws UnsupportedEncodingException {
      WaveFormFile wff = WaveFormFileFactory.createWaveFormFile();
      byte[] bs = new byte[6];
      ba.get(bs, 0, 6);
      String s = new String(bs);
      if (!s.equalsIgnoreCase("SPBXDS")) {
         return null;
      } else {
         int len = ba.nextInt();
         bs = new byte[len];
         ba.get(bs, 0, len);
         JSONObject jo = JSONObject.fromObject(new String(bs).toLowerCase());
         System.out.println(jo);
         wff.setHead(jo);
         String idn = jo.optString("idn", "OWON,XDS3102a,0000000,V1.0");
         System.err.println(idn);
         Idn id = new Idn(idn);
         String model = jo.optString("model");
         id.setRealModel(model);
         MachineType mt = MachineFactory.getMachinetype(id);
         wff.setMt(mt);
         return wff;
      }
   }

   public void readFFTData(WaveForm fwf, CByteArrayInputStream ba, String name, int offset, char c2nd, String fileheader) {
      FFTInfo f = fwf.getFFTInfo();
      f.setProtoFFT(true);
      fwf.beginFill();
      char c3rd = name.charAt(2);
      fwf.setStrChannelType("CH" + c3rd);
      int p = ba.pointer();
      int blkSize = ba.nextInt();
      fwf.setIntBlockSize(ba, blkSize);
      blkSize = fwf.getIntBlockSize();
      fwf.getWaveFormFile().confirmPublicM();
      f.setDB_Vrms(ba.nextInt());
      int length = ba.nextInt();
      fwf.setIntADCollectionNum(length);
      fwf.setIntLowMoveNum(1 - length);
      int freqIdx = ba.nextInt();
      f.setIntTimeBase(freqIdx);
      f.loc0 = ba.nextInt();
      fwf.setIntZeroYPoint(0);
      int tempInt = ba.nextInt();
      int probeRate = ba.nextInt();
      fwf.setIntAttenuationMultiple((double)probeRate);
      int v = ba.nextInt();
      double voltPP = (double)Float.intBitsToFloat(v);
      f.setDblVoltagePerPoint(voltPP);
      if (f.getDB_Vrms() == 1) {
         f.dbbaseidx = tempInt;
      } else {
         fwf.setIntVoltageBase(tempInt);
      }

      fwf.setDesireXbase(fwf.getIntTimeBase());
      fwf.setDesireYbase(fwf.getIntVoltageBase());
      f.zoomRateIdx = ba.nextInt();
      int zoomRate = f.getZoomRate();
      f.setWndTypeIdx(ba.nextInt());
      boolean b = (fileheader.equals("SPBX02") || fileheader.equals("SPBM01") || fileheader.equals("SPBN01")) && (c3rd == '1' || c3rd == '2');
      b = b || c2nd == 'f';
      if (b) {
         int tmp = ba.nextInt();
         f.posOffset = tmp + 5 * (zoomRate - 1) * fwf.getWaveFormFile().getXBlockPixels();
      }

      ba.skip(blkSize - (ba.pointer() - p));
      fwf.endAndCompute();
   }

   protected void readSavedWaveLayer(CByteArrayInputStream ba, WaveFormFile wff, boolean isdepMem) {
      WaveForm wf = null;
      int len = wff.getChannleLen();
      JSONObject head = wff.getHead();

      for (int i = 0; i < len; i++) {
         JSONObject ch = head.getJSONArray("channel").getJSONObject(i);
         String source = ch.getString("wave_character");
         if (!source.equalsIgnoreCase("fft")) {
            wf = wff.createWaveForm(source);
            wf.setStrChannelType(ch.getString("index"));
            wf.beginFill();
            double dblTimeBase = this.strToDbl(ch.getString("hscale"));
            logger.fine("intTimeBase: " + dblTimeBase);
            wf.setIntTimeBase(dblTimeBase);
            double adcTime = this.strToDbl(ch.getString("adc_data_time"));
            int intFullScreenDataNum = (int)(dblTimeBase / adcTime * wff.getXGraticuleNum());
            logger.fine("intFullScreenDataNum: " + intFullScreenDataNum);
            int intADCollectionNum = ch.getInt("data_length");
            wf.setIntADCollectionNum(intADCollectionNum);
            logger.fine("intADCollectionNum: " + intADCollectionNum);
            double trigAfterTime = this.strToDbl(ch.getString("trig_after_time"));
            double trigTopTime = this.strToDbl(ch.getString("trig_tops_tme"));
            int intOffsetNum = (int)((double)((intADCollectionNum - intFullScreenDataNum) / 2) + (trigAfterTime - trigTopTime) / adcTime);
            wf.setScreenStartLocation(intOffsetNum);
            int intLowMoveNum = -1;
            wf.setIntLowMoveNum(intLowMoveNum);
            logger.fine("intLowMoveNum: " + intLowMoveNum);
            int intZeroYPoint = ch.getInt("reference_zero");
            wf.setIntZeroYPoint(intZeroYPoint);
            logger.fine("intZeroYPoint: " + intZeroYPoint);
            String probe = ch.optString("probe_magnification", "1X");
            double intAttenuationMultiple = this.strToDbl(probe);
            wf.setIntAttenuationMultiple(intAttenuationMultiple);
            logger.fine("intAttenuationMultiple: " + intAttenuationMultiple);
            String strVoltageBase = ch.getString("vscale");
            String operator = ch.optString("operator", null);
            if (operator == null) {
               wf.setIntVoltageBase(this.strToDbl(strVoltageBase));
            } else {
               wf.setIntVoltageBase(0);
            }

            int intVoltageBase = wf.getIntVoltageBase();
            logger.fine("intVoltageBase: " + strVoltageBase);
            double dblTimeInterval = 1.0;
            wf.setDblTimeInterval(dblTimeInterval);
            logger.fine("dblTimeInterval: " + dblTimeInterval);
            String dblFrequency = ch.optString("freq");
            wf.setDblFrequency(this.strToDbl(dblFrequency));
            logger.fine("dblFrequency: " + dblFrequency);
            String dblPeriod = ch.optString("cyc");
            wf.setDblPeriod(this.strToDbl(dblPeriod));
            logger.fine("dblPeriod: " + dblPeriod);
            double dblVoltagePerPoint = 1.0;
            wf.setDblVoltagePerPoint(dblVoltagePerPoint);
            logger.fine("dblVoltagePerPoint: " + dblVoltagePerPoint);
            wf.setDesireYbase(intVoltageBase);
            wf.setDesireXbase(wf.getIntTimeBase());
            double basicVoltageBase = PublicM.getchVvValue(intVoltageBase);
            double volBase = dblVoltagePerPoint * (double)wff.getyBlockPixels() / 1000.0;
            Math.abs(volBase - basicVoltageBase);
            wf.setIntFullScreenDataNum(intFullScreenDataNum);
            wf.setDemMem(isdepMem);
            String curSwit = ch.optString("measure_current_switch", "off");
            wf.setCurrMeas(this.switch2Bool(curSwit));
            int curRate = ch.optInt("current_rate", 0);
            wf.setCurRate(curRate);
            this.readData(ba, wf, intADCollectionNum);
            wf.doMoreReadFromDataImport(this);
            logger.fine("dataAvailable():" + ba.available());
            wf.endAndCompute();
            wff.addWaveForm(wf);
         }
      }
   }

   protected WaveForm readWaveFormLayer(CByteArrayInputStream ba, WaveFormFile wff) throws UnsupportedEncodingException {
      WaveForm wf = null;
      int len = wff.getChannleLen();
      JSONObject head = wff.getHead();

      for (int i = 0; i < len; i++) {
         JSONObject ch = head.getJSONArray("channel").getJSONObject(i);
         String swit = ch.getString("display");
         wf = wff.createWaveForm("");
         wf.setStrChannelType(ch.getString("name").toUpperCase());
         wf.beginFill();
         int intFullScreenDataNum = head.getJSONObject("sample").getInt("fullscreen");
         logger.fine("intFullScreenDataNum: " + intFullScreenDataNum);
         wf.setIntFullScreenDataNum(intFullScreenDataNum);
         int intADCollectionNum = head.getJSONObject("sample").getInt("datalen");
         wf.setIntADCollectionNum(intADCollectionNum);
         logger.fine("intADCollectionNum: " + intADCollectionNum);
         int intOffsetNum = head.getJSONObject("sample").optInt("screenoffset");
         wf.setScreenStartLocation(intOffsetNum);
         int intLowMoveNum = head.getJSONObject("sample").getInt("slowmove");
         wf.setIntLowMoveNum(intLowMoveNum);
         logger.fine("intLowMoveNum: " + intLowMoveNum);
         String strTimeBase = head.getJSONObject("timebase").getString("scale");
         wf.setIntTimeBase(this.strToDbl(strTimeBase));
         logger.fine("intTimeBase: " + strTimeBase);
         int intZeroYPoint = ch.getInt("offset");
         wf.setIntZeroYPoint(intZeroYPoint);
         logger.fine("intZeroYPoint: " + intZeroYPoint);
         String probe = ch.getString("probe");
         double intAttenuationMultiple = this.strToDbl(probe);
         wf.setIntAttenuationMultiple(intAttenuationMultiple);
         logger.fine("intAttenuationMultiple: " + intAttenuationMultiple);
         String strVoltageBase = ch.getString("scale");
         double dblVoltage = this.strToDbl(strVoltageBase);
         wf.setIntVoltageBase(dblVoltage);
         int intVoltageBase = wf.getIntVoltageBase();
         logger.fine("intVoltageBase: " + strVoltageBase);
         double dblTimeInterval = 1.0;
         wf.setDblTimeInterval(dblTimeInterval);
         logger.fine("dblTimeInterval: " + dblTimeInterval);
         double dblFrequency = ch.getDouble("frequence");
         wf.setDblFrequency(dblFrequency);
         logger.fine("dblFrequency: " + dblFrequency);
         double dblPeriod = 1000000.0 / dblFrequency;
         wf.setDblPeriod(dblPeriod);
         logger.fine("dblPeriod: " + dblPeriod);
         double dblVoltagePerPoint = dblVoltage * intAttenuationMultiple / (double)wff.getyBlockPixels();
         wf.setDblVoltagePerPoint(dblVoltagePerPoint);
         logger.fine("dblVoltagePerPoint: " + dblVoltagePerPoint);
         wf.setDesireYbase(intVoltageBase);
         wf.setDesireXbase(wf.getIntTimeBase());
         double basicVoltageBase = PublicM.getchVvValue(intVoltageBase);
         double volBase = dblVoltagePerPoint * (double)wff.getyBlockPixels() / 1000.0;
         Math.abs(volBase - basicVoltageBase);
         String curSwit = ch.optString("measure_current_switch", "off");
         wf.setCurrMeas(this.switch2Bool(curSwit));
         int curRate = ch.optInt("current_rate", 0);
         wf.setCurRate(curRate);
         String dataType = head.getString("datatype");
         if (dataType.equalsIgnoreCase("screen")) {
            wf.setDemMem(false);
         } else {
            wf.setDemMem(true);
         }

         boolean isOff = swit.equalsIgnoreCase("off");
         if ((!isOff || !head.optBoolean("isskipifclosed")) && (!isOff || !wf.isDepMem())) {
            String model = head.optString("model", "hds272");
            System.out.println(model);
            this.readData(ba, wf, intADCollectionNum);
            wf.setIntVoltageBase(intVoltageBase);
            wf.doMoreReadFromDataImport(this);
            logger.fine("dataAvailable():" + ba.available());
            wf.endAndCompute();
            if (!isOff) {
               wff.addWaveForm(wf);
            }
         }
      }

      return wf;
   }

   private void setMaxAndMinData(int intADCollectionNum, CByteArrayInputStream ba, WaveForm wf) {
      int zy = wf.getIntZeroYPoint();
      int minShtADData;
      int maxShtADData = minShtADData = ba.nextByte() - zy;
      int upLmt = 250;
      int lowLmt = -252;
      int upperCount = 0;
      int lowerCount = 0;

      for (int j = 0; j < intADCollectionNum - 1; j++) {
         int v = ba.nextByte() - zy;
         if (maxShtADData < v) {
            maxShtADData = v;
         } else if (minShtADData > v) {
            minShtADData = v;
         }

         if (v < lowLmt) {
            lowerCount++;
         } else if (v > upLmt) {
            upperCount++;
         }
      }

      wf.setBeyondCount(upperCount, lowerCount);
      wf.setMaxShtAndMinShtADData(maxShtADData, minShtADData);
   }

   protected MultiMeter readMultiMeter(CByteArrayInputStream ba, WaveFormFile wff) {
      if (ba.available() < 33) {
         return null;
      } else {
         int len = 5;
         byte[] bs = new byte[len];
         ba.get(bs, 0, len);
         String name = "";

         try {
            name = new String(bs, 0, len, "ASCII");
         } catch (UnsupportedEncodingException var7) {
            var7.printStackTrace();
         }

         if (!name.startsWith("MUL")) {
            ba.reset(ba.pointer() - len);
            return null;
         } else {
            MultiMeter mm = new MultiMeter(name);
            mm.readin(ba);
            return wff.mm = mm;
         }
      }
   }

   @Override
   public WaveFormFile readBinary(CByteArrayInputStream ba, ControlManger cm, InfoPart ip) {
      this.ba = ba;
      WaveFormFile wff = null;

      try {
         wff = this.readFileLayer(ba);
         if (wff != null) {
            String s = wff.getDataType();
            if (s.equalsIgnoreCase("internal")) {
               this.readSavedWaveLayer(ba, wff, false);
            } else if (s.equalsIgnoreCase("screen")) {
               this.readWaveFormLayer(ba, wff);
            } else if (s.equalsIgnoreCase("wavedepmem")) {
               this.readWaveFormLayer(ba, wff);
            } else {
               this.readSavedWaveLayer(ba, wff, true);
            }

            wff.setRaw(true);
            wff.setOrginalFile(null);
            return wff;
         }
      } catch (Exception var15) {
         var15.printStackTrace();
         return wff;
      } finally {
         if (wff != null) {
            wff.endFileCreate();
            if (!wff.containMemDepth()) {
               ba.dispose();
            }
         }

         Handler[] hls = logger.getHandlers();

         for (Handler hl : hls) {
            hl.flush();
         }
      }

      return null;
   }

   public void readFftLayer(CByteArrayInputStream ba, WaveFormFile wff) {
   }

   @Override
   public WaveFormFile readBinary(CByteArrayInputStream ba, ControlManger cm) {
      return this.readBinary(ba, cm, null);
   }

   private double strToDbl(String str) {
      String s = str.toLowerCase();
      if (s.endsWith("us")) {
         double d = Double.parseDouble(s.substring(0, s.length() - 2));
         return d / 1000.0;
      } else if (s.endsWith("ns")) {
         double d = Double.parseDouble(s.substring(0, s.length() - 2));
         return d / 1000000.0;
      } else if (s.endsWith("ps")) {
         double d = Double.parseDouble(s.substring(0, s.length() - 2));
         return d / 1.0E9;
      } else if (s.endsWith("ms")) {
         return Double.parseDouble(s.substring(0, s.length() - 2));
      } else if (s.endsWith("s")) {
         double d = Double.parseDouble(s.substring(0, s.length() - 1));
         return d * 1000.0;
      } else if (s.endsWith("nv")) {
         double d = Double.parseDouble(s.substring(0, s.length() - 2));
         return d / 1.0E9;
      } else if (s.endsWith("uv")) {
         double d = Double.parseDouble(s.substring(0, s.length() - 2));
         return d / 1000000.0;
      } else if (s.endsWith("mv")) {
         double d = Double.parseDouble(s.substring(0, s.length() - 2));
         return d / 1000.0;
      } else if (s.endsWith("kv")) {
         double d = Double.parseDouble(s.substring(0, s.length() - 2));
         return d * 1000.0;
      } else if (s.endsWith("gv")) {
         System.out.println("GV");
         double d = Double.parseDouble(s.substring(0, s.length() - 3));
         return d * 1.0E9;
      } else if (s.endsWith("v")) {
         return Double.parseDouble(s.substring(0, s.length() - 1));
      } else if (s.endsWith("x")) {
         return Double.parseDouble(s.substring(0, s.length() - 1));
      } else {
         return s.endsWith("hz") ? Double.parseDouble(s.substring(0, s.length() - 2)) : 0.0;
      }
   }

   private void readData(CByteArrayInputStream ba, WaveForm wf, int size) {
      int len = ba.nextInt();
      int tempPointer = ba.pointer();
      if (wf.isDepMem()) {
         wf.setMemdepthDataIndex(tempPointer);
         wf.getWaveFormFile().setba(ba);
         this.setMaxAndMinData(size, ba, wf);
      } else {
         int[] shtADCollection = new int[size];
         int[] originalAD = new int[size];
         System.out.println("check len:" + len + " size:" + size);
         int zY = wf.getIntZeroYPoint();
         int upLmt = -zY + 250;
         int lowLmt = -zY - 252;
         int upperCount = 0;
         int lowerCount = 0;
         int shift = 0;
         originalAD[1] = originalAD[0] = ba.nextByte() - (zY << shift);
         ba.nextByte();
         int minShtADData;
         int maxShtADData = minShtADData = shtADCollection[1] = shtADCollection[0] = originalAD[0] >> shift;

         for (int j = 2; j < size; j++) {
            int b = ba.nextByte();
            if (j % 2 == 0) {
               originalAD[j] = b - (zY << shift);
            } else {
               originalAD[j] = originalAD[j - 1];
            }

            int v = originalAD[j] >> shift;
            if (maxShtADData < v) {
               maxShtADData = v;
            } else if (minShtADData > v) {
               minShtADData = v;
            }

            if (v < lowLmt) {
               lowerCount++;
            } else if (v > upLmt) {
               upperCount++;
            }

            shtADCollection[j] = v;
         }

         wf.setBeyondCount(upperCount, lowerCount);
         wf.setIntADCollection(shtADCollection);
         wf.setOriginalAD(originalAD);
         logger.fine("shtADCollection.length: " + shtADCollection.length);
         wf.setMaxShtAndMinShtADData(maxShtADData, minShtADData);
         logger.fine("maxShtADData: " + maxShtADData + "; minShtADData: " + minShtADData);
         wf.patchADCImport(ba);
      }
   }

   private boolean switch2Bool(String s) {
      return s.equalsIgnoreCase("on") ? true : s.equalsIgnoreCase("1");
   }
}
