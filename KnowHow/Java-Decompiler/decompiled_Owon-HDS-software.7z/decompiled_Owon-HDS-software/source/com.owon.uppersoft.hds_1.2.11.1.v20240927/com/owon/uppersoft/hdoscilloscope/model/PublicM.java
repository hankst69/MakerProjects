package com.owon.uppersoft.hdoscilloscope.model;

import com.owon.uppersoft.hdoscilloscope.chart.model.fft.TimeBaseRef;
import com.owon.uppersoft.hdoscilloscope.model.detail.Idn;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class PublicM {
   public static List<Dbl_Txt> StrHs_1ns = new ArrayList<>();
   public static List<Dbl_Txt> StrHs_2ns = StrHs_1ns.subList(1, StrHs_1ns.size());
   public static List<Dbl_Txt> StrHs_5ns = StrHs_1ns.subList(2, StrHs_1ns.size());
   public static List<Dbl_Txt> StrVv = new ArrayList<>();
   public static List<Dbl_Txt> freqtxts = new ArrayList<>(41);
   public static final int freqLength = 41;
   public static final double[] Mod521 = new double[]{1.0, 1.25, 2.5, 5.0};
   private List<Dbl_Txt> xbaseList;
   private List<TimeBaseRef> tbrs;
   private MachineType mt;

   static {
      Dbl_Txt.addDbl_Txt(StrVv, "10.0mV", 0.01);
      Dbl_Txt.addDbl_Txt(StrVv, "20.0mV", 0.02);
      Dbl_Txt.addDbl_Txt(StrVv, "50.0mV", 0.05);
      Dbl_Txt.addDbl_Txt(StrVv, "100 mV", 0.1);
      Dbl_Txt.addDbl_Txt(StrVv, "200 mV", 0.2);
      Dbl_Txt.addDbl_Txt(StrVv, "500 mV", 0.5);
      Dbl_Txt.addDbl_Txt(StrVv, "1.00 V", 1.0);
      Dbl_Txt.addDbl_Txt(StrVv, "2.00 V", 2.0);
      Dbl_Txt.addDbl_Txt(StrVv, "5.00 V", 5.0);
      Dbl_Txt.addDbl_Txt(StrVv, "10.0 V", 10.0);
      Dbl_Txt.addDbl_Txt(StrVv, "20.0 V", 20.0);
      Dbl_Txt.addDbl_Txt(StrVv, "50.0 V", 50.0);
      Dbl_Txt.addDbl_Txt(StrVv, "100 V", 100.0);
      Dbl_Txt.addDbl_Txt(StrVv, "200 V", 200.0);
      Dbl_Txt.addDbl_Txt(StrVv, "500 V", 500.0);
      Dbl_Txt.addDbl_Txt(StrVv, "1.00kV", 1000.0);
      Dbl_Txt.addDbl_Txt(StrVv, "2.00kV", 2000.0);
      Dbl_Txt.addDbl_Txt(StrVv, "5.00kV", 5000.0);
      Dbl_Txt.addDbl_Txt(StrVv, "10.0kV", 10000.0);
      Dbl_Txt.addDbl_Txt(StrVv, "20.0kV", 20000.0);
      Dbl_Txt.addDbl_Txt(StrVv, "50.0kV", 50000.0);
      Dbl_Txt.addDbl_Txt(StrVv, "100 kV", 100000.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "100ps", 1.0E-7);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "200ps", 2.0E-7);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "500ps", 5.0E-7);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "1.0ns", 1.0E-6);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "2.0ns", 2.0E-6);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "5.0ns", 5.0E-6);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "10 ns", 1.0E-5);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "20 ns", 2.0E-5);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "50 ns", 5.0E-5);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "100ns", 1.0E-4);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "200ns", 2.0E-4);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "500ns", 5.0E-4);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "1.0us", 0.001);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "2.0us", 0.002);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "5.0us", 0.005);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "10 us", 0.01);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "20 us", 0.02);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "50 us", 0.05);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "100us", 0.1);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "200us", 0.2);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "500us", 0.5);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "1.0ms", 1.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "2.0ms", 2.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "5.0ms", 5.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "10 ms", 10.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "20 ms", 20.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "50 ms", 50.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "100ms", 100.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "200ms", 200.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "500ms", 500.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "1.0 s", 1000.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "2.0 s", 2000.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "5.0 s", 5000.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "10  s", 10000.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "20  s", 20000.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "50  s", 50000.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "100 s", 100000.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "200 s", 200000.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "500 s", 500000.0);
      Dbl_Txt.addDbl_Txt(StrHs_1ns, "1000s", 1000000.0);

      for (int i = 0; i < 41; i++) {
         double dbfreq = generatefreq(i);
         String freqtxt = generatefreqtxt(dbfreq);
         Dbl_Txt.addDbl_Txt(freqtxts, freqtxt, dbfreq);
      }
   }

   public static List<Dbl_Txt> getFreqtxts() {
      return freqtxts;
   }

   private static double generatefreq(int idx) {
      idx = 40 - idx;
      int mod = Mod521.length;
      int cyc = idx / mod;
      int rem = idx % mod;
      return Math.pow(10.0, (double)cyc) * Mod521[rem];
   }

   private static String generatefreqtxt(double dbfreq) {
      double v = Math.abs(dbfreq);
      if (v < 1000.0) {
         return String.format("%.2f Hz", v);
      } else {
         v /= 1000.0;
         if (v < 1000.0) {
            return String.format("%.2f kHz", v);
         } else {
            v /= 1000.0;
            if (v < 1000.0) {
               return String.format("%.2f MHz", v);
            } else {
               v /= 1000.0;
               return String.format("%.2f GHz", v);
            }
         }
      }
   }

   public static void main(String[] args) {
      for (int i = 0; i < 41; i++) {
         System.out.println(generatefreq(i) + "\t" + generatefreqtxt((double)i));
      }
   }

   public static Collection<? extends Object> yb_coll() {
      return StrVv;
   }

   public static String getStrVvValue(int index) {
      return StrVv.get(index).n();
   }

   public static double getchVvValue(int index) {
      return StrVv.get(index).v();
   }

   public int getchVvIndexForCertainValue(double value) {
      int i = 0;

      for (Dbl_Txt dt : StrVv) {
         if (Math.abs(dt.v() - value) < 1.0E-7) {
            return i;
         }

         i++;
      }

      return -1;
   }

   public boolean isLowMove(int timebase) {
      int lmtb = this.getLowMoveTimeBase();
      if (lmtb < 0) {
         System.err.println("ERROR in LowMove judgement!");
         return false;
      } else {
         return timebase >= lmtb;
      }
   }

   protected int getLowMoveTimeBase() {
      int len = this.xbaseList.size();

      for (int i = 0; i < len; i++) {
         Dbl_Txt dt = this.xbaseList.get(i);
         if ((int)dt.v() == 100) {
            return i;
         }
      }

      return -1;
   }

   public List<TimeBaseRef> getTimeBaseRefs() {
      return this.tbrs;
   }

   public Collection<? extends Object> xb_coll() {
      return this.xbaseList;
   }

   public String getTimebaseTxt(int index) {
      return this.xbaseList.get(index).n();
   }

   public double getTimeBaseValue_mS(int index) {
      if (this.xbaseList == null) {
         System.err.println("xbaseList == null");
      }

      return this.xbaseList.get(index).v();
   }

   public int getTimebaseIdxForCertainValue(double value) {
      int i = 0;

      for (Dbl_Txt tb : this.xbaseList) {
         double d = Math.abs(tb.v() - value);
         if (d < 1.0E-7) {
            return i;
         }

         i++;
      }

      return -1;
   }

   public MachineType getMachineType() {
      return this.mt;
   }

   public void setValue(Idn idn, boolean comeFromTDMachine, int pixelsPerBlock) {
      MachineInfo mi = new MachineInfo();
      mi.setValue(idn, comeFromTDMachine, pixelsPerBlock);
      this.mt = mi.mt;
      this.xbaseList = mi.xbaseList;
      this.tbrs = mi.tbrs;
   }
}
