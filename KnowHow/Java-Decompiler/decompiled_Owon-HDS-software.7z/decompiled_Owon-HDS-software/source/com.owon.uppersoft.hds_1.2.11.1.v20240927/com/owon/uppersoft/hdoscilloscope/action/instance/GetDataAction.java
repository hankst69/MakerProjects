package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.communication.BetaUploadFrame;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class GetDataAction extends DefaultAction {
   public GetDataAction(String id) {
      super(id);
   }

   public void run() {
      Platform platform = Platform.getPlatform();
      new BetaUploadFrame(platform.getShell(), platform.getConfiguration()).open();
   }
}
