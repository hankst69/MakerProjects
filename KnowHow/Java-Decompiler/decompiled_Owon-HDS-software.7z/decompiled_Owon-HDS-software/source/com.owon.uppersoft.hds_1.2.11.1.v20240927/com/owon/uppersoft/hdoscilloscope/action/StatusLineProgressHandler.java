package com.owon.uppersoft.hdoscilloscope.action;

import com.owon.uppersoft.hdoscilloscope.communication.loop.ICommunicationListener;
import com.owon.uppersoft.hdoscilloscope.communication.loop.ICommunicationListenerProvider;
import com.owon.uppersoft.hdoscilloscope.communication.usb.rapid.RapidLoop;
import com.owon.uppersoft.hdoscilloscope.frame.view.StatusLine;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.util.UnitConversionUtil;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;

public class StatusLineProgressHandler implements ICommunicationListener, ICommunicationListenerProvider {
   private StatusLine sl;
   private ProgressBar pb;
   private Label labProgress;
   private RapidLoop rl;
   private Shell shell;
   private ICommunicationListener icl;
   private boolean isStart = false;

   public StatusLineProgressHandler(StatusLine statusLine) {
      this.sl = statusLine;
      this.pb = this.sl.getProgressBar();
      this.pb.setMinimum(0);
      this.labProgress = this.sl.getLabProgress();
      this.shell = this.sl.getShell();
   }

   @Override
   public void setICL() {
      this.icl = this;
   }

   @Override
   public void resetICL() {
      this.icl = ICommunicationListenerProvider.EmptyICL;
   }

   public void setRapidLoop(RapidLoop rl) {
      this.rl = rl;
   }

   public void finish() {
      this.sl.hideProgressBar();
      this.isStart = false;
   }

   private void comminfo(final int prgmax, String fileType) {
      boolean bmp = "bmp".equalsIgnoreCase(fileType);
      ResourceBundleProvider.getMessageErrRunner();
      if (bmp) {
         if (this.rl.getFilePool() != null) {
         }
      } else {
         this.isStart = false;
      }

      this.sl.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            if (!StatusLineProgressHandler.this.sl.isDisposed()) {
               StatusLineProgressHandler.this.sl.prepareShowProgress();
               StatusLineProgressHandler.this.pb.setMaximum(prgmax);
            }
         }
      });
   }

   @Override
   public ICommunicationListener getCommunicationListener() {
      return this.icl;
   }

   @Override
   public void communicateInfo(int l, String fileType) {
      this.comminfo(l, fileType);
   }

   @Override
   public void progressInfo(final int v) {
      this.sl.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            if (!StatusLineProgressHandler.this.sl.isDisposed()) {
               StatusLineProgressHandler.this.pb.setSelection(v);
               StatusLineProgressHandler.this.labProgress.setText(UnitConversionUtil.getBytesNumber(v));
            }
         }
      });
   }

   @Override
   public void communicateInfo_ifn(int times, String fileType) {
      this.comminfo(times, fileType);
   }

   @Override
   public void progressInfo_ifn(final int v) {
      this.sl.getDisplay().asyncExec(new Runnable() {
         @Override
         public void run() {
            if (!StatusLineProgressHandler.this.sl.isDisposed()) {
               StatusLineProgressHandler.this.pb.setSelection(StatusLineProgressHandler.this.pb.getSelection() + 1);
               StatusLineProgressHandler.this.labProgress.setText(UnitConversionUtil.getBytesNumber(v));
            }
         }
      });
   }
}
