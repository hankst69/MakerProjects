package com.owon.uppersoft.hdoscilloscope.chart.model.deep;

public class Pixel {
   public int x;
   public int y;

   public Pixel() {
   }

   public Pixel(int x, int y) {
      this.x = x;
      this.y = y;
   }
}
