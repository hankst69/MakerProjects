package com.owon.uppersoft.hdoscilloscope.communication.loop;

import com.owon.uppersoft.hdoscilloscope.action.StatusLineProgressHandler;
import com.owon.uppersoft.hdoscilloscope.communication.usb.rapid.FilePool;
import com.owon.uppersoft.hdoscilloscope.communication.usb.rapid.RapidLoop;
import com.owon.uppersoft.hdoscilloscope.frame.MainFrame;
import com.owon.uppersoft.hdoscilloscope.frame.view.StatusLine;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class LoopControl {
   private Platform pf;
   private RapidLoop rl;
   private StatusLineProgressHandler iclp;
   public ByteBuffer bb;
   public Set<JobUnit> queue;
   private boolean use = false;

   public LoopControl(Platform pf) {
      this.pf = pf;
   }

   public boolean DoLoop() {
      Configuration config = this.pf.getConfiguration();
      MainFrame mf = this.pf.getMainFrame();
      String path = config.autoSavePath;
      if (path != null) {
         path = path.trim();
      } else {
         path = "";
      }

      config.autoSavePath = path;
      FilePool fpool = null;
      if (path.length() != 0) {
         fpool = FilePool.confirmPath(config, mf.getShell());
         if (fpool == null) {
            return false;
         }
      }

      mf.setCommItemsStatus(false);
      this.doLoop(mf.getStatusLine(), fpool);
      return true;
   }

   private void doLoop(StatusLine sl, FilePool fpool) {
      if (this.iclp == null) {
         this.iclp = new StatusLineProgressHandler(sl);
      }

      this.stopLoop();
      this.rl = new RapidLoop(this.iclp, fpool);
      this.rl.startLoop();
   }

   public RapidLoop getRapidLoop() {
      return this.rl;
   }

   public void stopLoop() {
      if (this.rl != null && this.rl.isKeepOn()) {
         this.rl.stopLoop();
      }
   }

   public boolean isKeepOn() {
      return this.rl == null ? false : this.rl.isKeepOn();
   }

   public ByteBuffer resetBuffer() {
      if (this.bb == null) {
         this.bb = ByteBuffer.allocate(1024);
      }

      ((Buffer)this.bb).clear();
      return this.bb;
   }

   public boolean isUse() {
      return this.use;
   }

   public void setUse(boolean use) {
      this.use = use;
      if (use && this.queue == null) {
         this.queue = Collections.synchronizedSet(new HashSet<>());
      }
   }

   public boolean dealQueue(RapidCommunication irc) {
      if (this.queue == null) {
         return false;
      } else if (!this.use && this.queue.isEmpty()) {
         this.queue = null;
         return false;
      } else {
         synchronized (this.queue) {
            int num = this.queue.size();
            if (num == 0) {
               return false;
            } else {
               Iterator<JobUnit> it = this.queue.iterator();

               while (it.hasNext()) {
                  JobUnit p = it.next();
                  it.remove();
                  irc.startOnce();
                  p.doJob(irc, this.resetBuffer());
                  irc.endOnce();
               }

               return true;
            }
         }
      }
   }

   public void addDirectJobUnit(JobUnit p) {
      if (this.queue != null) {
         synchronized (this.queue) {
            this.queue.add(p);
         }
      }
   }

   public void addDealJobUnit(final JobUnit p) {
      if (this.queue != null) {
         (new Thread() {
            @Override
            public void run() {
               synchronized (LoopControl.this.queue) {
                  LoopControl.this.queue.add(p);
               }
            }
         }).start();
      }
   }

   public void addJobUnit(final JobUnit p) {
      if (this.queue != null) {
         (new Thread() {
            @Override
            public void run() {
               synchronized (LoopControl.this.queue) {
                  LoopControl.this.queue.add(p);
               }
            }
         }).start();
      }
   }

   public void activeSend(JobUnit p) {
      RapidCommunication rcomm = new RapidCommunication(null);
      rcomm.startInit();
      rcomm.startOnce();
      p.doJob(rcomm, this.resetBuffer());
      rcomm.endOnce();
      rcomm.endFinl();
   }
}
