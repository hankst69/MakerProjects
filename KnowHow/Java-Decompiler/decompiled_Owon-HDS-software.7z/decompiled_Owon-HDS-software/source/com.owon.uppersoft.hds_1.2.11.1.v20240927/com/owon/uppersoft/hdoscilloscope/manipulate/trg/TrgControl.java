package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import com.owon.uppersoft.hdoscilloscope.custom.RB2Lobject;
import com.owon.uppersoft.hdoscilloscope.manipulate.IPack;
import java.nio.ByteBuffer;

public class TrgControl implements IPack {
   public static final int TYPE_SINGLE = 0;
   public static final int TYPE_ALT = 1;
   public static final RB2Lobject[] SINGLE_ALT = new RB2Lobject[]{new RB2Lobject("M.Trg.Single")};
   public static final RB2Lobject[] TrggerNames = new RB2Lobject[]{new RB2Lobject("M.Trg.E")};
   public static final String[] VIDEO_MODULE = new String[]{"NTSC", "PAL", "SECAM"};
   public static final RB2Lobject[] VIDEO_SYNC = new RB2Lobject[]{
      new RB2Lobject("M.Trg.line"),
      new RB2Lobject("M.Trg.field"),
      new RB2Lobject("M.Trg.oddfield"),
      new RB2Lobject("M.Trg.evenfield"),
      new RB2Lobject("M.Trg.lineNum")
   };
   public static final String[] COUPLING = new String[]{"DC", "AC", "HF", "LF"};
   public static final RB2Lobject[] SWEEP = new RB2Lobject[]{
      new RB2Lobject("M.Trg.TrigMode.Auto"), new RB2Lobject("M.Trg.TrigMode.Normal"), new RB2Lobject("M.Trg.TrigMode.Single")
   };
   public static final RB2Lobject[] RiseFall = new RB2Lobject[]{new RB2Lobject("M.Trg.Edge.Rise"), new RB2Lobject("M.Trg.Edge.Fall")};
   public static final RB2Lobject[] Polarity = new RB2Lobject[]{new RB2Lobject("M.Trg.pulse.positive"), new RB2Lobject("M.Trg.pulse.negative")};
   private int altchlidx;
   private int sglchlidx;
   private int sna;
   public TrgGroup[] tgs;
   private TrgGroup sgl_trg;
   public int len;

   public TrgControl(int len) {
      this.len = len;
      this.altchlidx = 0;
      this.sglchlidx = 0;
      this.sna = 0;
      this.tgs = new TrgGroup[len];

      for (int i = 0; i < len; i++) {
         this.tgs[i] = new TrgGroup();
      }

      this.sgl_trg = new TrgGroup();
   }

   public void setSNA(int v) {
      this.sna = v;
   }

   public int sna() {
      return this.sna;
   }

   public boolean isSingle() {
      return this.sna == 0;
   }

   public TrgGroup getCurrent() {
      return this.isSingle() ? this.sgl_trg : this.tgs[this.altchlidx];
   }

   public int getChannelIndex() {
      return this.isSingle() ? this.sglchlidx : this.altchlidx;
   }

   public void setChannelIndex(int v) {
      if (this.isSingle()) {
         this.sglchlidx = v;
      } else {
         this.altchlidx = v;
      }
   }

   public int getSNAAlpha() {
      return this.sna == 0 ? 115 : 97;
   }

   @Override
   public void pack(ByteBuffer bb) {
      this.getCurrent().pack(bb, this.getSNAAlpha(), this.getChannelIndex());
   }

   public void packLevel(ByteBuffer bb, AbsTrg at, int level) {
      at.packLevel(bb, this.getSNAAlpha(), this.getChannelIndex(), this.getCurrent().getMode(), level);
   }
}
