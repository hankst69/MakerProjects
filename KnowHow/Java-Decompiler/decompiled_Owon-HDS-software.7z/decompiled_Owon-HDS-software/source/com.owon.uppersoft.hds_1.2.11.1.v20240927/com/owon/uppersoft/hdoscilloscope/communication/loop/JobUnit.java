package com.owon.uppersoft.hdoscilloscope.communication.loop;

import java.nio.ByteBuffer;

public class JobUnit {
   protected byte[] arr = null;
   public byte[] re_arr = null;
   private int resNum = 0;
   private int reqNum = 0;

   public JobUnit(String request) {
      this.arr = request.getBytes();
   }

   public JobUnit(String request, byte[] re_arr) {
      this.arr = request.getBytes();
      this.re_arr = re_arr;
   }

   public JobUnit(byte[] arr) {
      this.arr = arr;
      this.re_arr = new byte[512];
   }

   public JobUnit(byte[] arr, byte[] re_arr) {
      this.arr = arr;
      this.re_arr = re_arr;
   }

   public void doJob(RapidCommunication irc, ByteBuffer bbuf) {
      this.doPreparedArrayJob(irc);
      this.afterJob(irc, bbuf);
   }

   protected void doPreparedArrayJob(RapidCommunication irc) {
      this.interact(irc, this.arr, this.re_arr);
   }

   protected void afterJob(RapidCommunication irc, ByteBuffer bbuf) {
   }

   protected void interact(RapidCommunication irc, byte[] req, byte[] rsp) {
      this.resetSession();
      this.sendRequest(irc, req);
      if (this.re_arr != null) {
         this.receiveResponse(irc, rsp);
      }
   }

   private void sendRequest(RapidCommunication irc, byte[] req) {
      this.reqNum = irc.write(req, 0, req.length);
   }

   private void receiveResponse(RapidCommunication irc, byte[] rsp) {
      this.resNum = irc.read(rsp, 0, rsp.length);
   }

   public void resetSession() {
      this.resNum = 0;
      this.reqNum = 0;
   }

   public int getResNum() {
      return this.resNum;
   }

   public int getReqNum() {
      return this.reqNum;
   }
}
