package com.owon.uppersoft.hdoscilloscope.communication.usb.rapid;

import com.owon.uppersoft.common.utils.CloseUtil;
import com.owon.uppersoft.common.utils.FileUtil;
import com.owon.uppersoft.common.utils.StringPool;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

public class FilePool {
   public static final String INIFileFormatExtension = "ini";
   private BufferedWriter bw;
   private BufferedWriter subbw;
   private DateFormat sdf;
   private File pathfile;
   private File curDir;
   private File fcur;
   private int i;

   public File getPathFile() {
      return this.pathfile;
   }

   private FilePool(String path) {
      this(new File(path));
   }

   private FilePool(File dir) {
      this.pathfile = dir;

      try {
         this.pathfile = this.pathfile.getCanonicalFile();
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      FileUtil.deleteFile(this.pathfile);
      this.pathfile.mkdirs();
      this.sdf = new SimpleDateFormat("yy-MM-dd HH_mm_ss_S", Locale.ENGLISH);
   }

   public void beginRecord() {
      try {
         this.bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(this.pathfile, "filename.ini"), false), "UTF-8"));
      } catch (UnsupportedEncodingException var2) {
         var2.printStackTrace();
      } catch (FileNotFoundException var3) {
         var3.printStackTrace();
      }

      this.i = 1;
      this.curDir = this.nextRecord(this.pathfile);
   }

   public void endRecord() {
      try {
         CloseUtil.tryClose(this.subbw);
         CloseUtil.tryClose(this.bw);
      } catch (IOException var2) {
         var2.printStackTrace();
      }
   }

   protected BufferedWriter createINI(File dir) {
      dir.mkdirs();

      try {
         return new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File(dir, "filename.ini"), false), "UTF-8"));
      } catch (UnsupportedEncodingException var4) {
         var4.printStackTrace();
      } catch (FileNotFoundException var5) {
         var5.printStackTrace();
      }

      return null;
   }

   public File nextFile(String ext) {
      if (this.curDir != null && this.subbw != null) {
         this.fcur = new File(this.curDir, this.sdf.format(new Date()) + "." + ext);
         boolean created = false;

         try {
            created = this.fcur.createNewFile();
            if (created) {
               this.fcur = this.fcur.getCanonicalFile();
               this.subbw.append(StringPool.LINE_SEPARATOR);
               this.subbw.append(this.fcur.getName());
               this.bw.append(StringPool.LINE_SEPARATOR);
               this.bw.append(this.curDir.getName() + File.separator + this.fcur.getName());
               return this.fcur;
            }
         } catch (IOException var5) {
            created = false;
            var5.printStackTrace();
         } catch (Exception var6) {
            created = false;
            var6.printStackTrace();
         }

         try {
            CloseUtil.tryClose(this.subbw);
         } catch (IOException var4) {
            var4.printStackTrace();
         }

         this.curDir = this.nextRecord(this.curDir.getParentFile());
         return this.nextFile(ext);
      } else {
         return null;
      }
   }

   protected File nextRecord(File parentfile) {
      File subfile = new File(parentfile, String.valueOf(this.i++));
      FileUtil.deleteFile(subfile);
      boolean created = subfile.mkdirs();
      if (created) {
         this.subbw = this.createINI(subfile);
         return subfile;
      } else {
         return null;
      }
   }

   public static FilePool confirmPath(Configuration config, Shell shell) {
      String path = config.autoSavePath;
      FilePool fpool = null;
      File dir = new File(path);
      boolean createFilePool = true;
      if (dir.exists() && dir.isDirectory() && dir.list().length != 0) {
         int i = 1;
         boolean exists = true;
         String parent = dir.getParent();
         String name = dir.getName();

         File other;
         for (other = null; exists; i++) {
            other = new File(parent, name + "(" + i + ")");
            exists = other.exists();
         }

         try {
            other = other.getCanonicalFile();
         } catch (IOException var16) {
            var16.printStackTrace();
         }

         String msg = String.format(ResourceBundleProvider.getMessageLibResourceBundle().getString("PS.confirmPath"), path, other.getPath());
         createFilePool = true;
         ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
         MessageDialog dialog = new MessageDialog(shell, "", null, msg, 3, new String[]{bundle.getString("Options.OK"), bundle.getString("Options.Cancel")}, 0);
         int flag = dialog.open();
         if (flag == 1 || flag < 0) {
            createFilePool = false;
         }

         if (createFilePool) {
            WaveFormFile wff = Platform.getPlatform().getDrawingPanel().getWaveFormFileCurve().getWaveFormFile();
            if (wff != null) {
               wff.releaseBA();
            }

            createFilePool = dir.renameTo(other);
         }
      }

      if (createFilePool) {
         fpool = new FilePool(dir);
         path = fpool.getPathFile().getPath();
         config.autoSavePath = path;
         if (!config.iniList.contains(path)) {
            config.iniList.add(path);
         }
      }

      return fpool;
   }

   public static void main(String[] args) {
      FilePool fp = new FilePool("G:/0908022320/");
      fp.beginRecord();

      File f;
      try {
         do {
            f = fp.nextFile("bin");
            System.out.println(f);
            Thread.sleep(100L);
         } while (f != null);
      } catch (InterruptedException var4) {
         var4.printStackTrace();
      }

      fp.endRecord();
   }
}
