package com.owon.uppersoft.hdoscilloscope.communication.usb;

public interface IUSBProtocol {
   short IdVender = 21317;
   short IdProduct = 4660;
   int DevAltinterface = -1;
   int RetryTimeout = 2000;
   int RetryTimeout2 = 20000;
   int BufSize = 16384;
   int DefaultBMPFileFlag = 1;
   int ResponseOnSTARTDataLength = 512;
   String[] CMDS = new String[]{":DATA:WAVE:SCREEN:HEAD?", ":DATA:WAVE:SCREEN:BMP?", ":DATA:WAVE:DEPMEM:HEAD?"};
   int USB_REQUEST_MEMDEPTH_index = 2;
   int CMDAvailMode_SDS = 2;
   int CMDAvailMode_TD = 1;
   int CMDAvailMode_Normal = 0;
   boolean isFlter = false;
}
