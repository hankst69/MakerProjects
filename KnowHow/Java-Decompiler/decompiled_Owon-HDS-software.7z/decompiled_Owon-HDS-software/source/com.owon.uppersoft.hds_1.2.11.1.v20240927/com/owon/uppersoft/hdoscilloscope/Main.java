package com.owon.uppersoft.hdoscilloscope;

import com.owon.uppersoft.hdoscilloscope.global.Workbench;

public class Main {
   public static void main(String[] args) {
      launch();
   }

   public static void launch() {
      new Workbench().launch();
   }
}
