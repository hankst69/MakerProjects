package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import java.nio.ByteBuffer;

public abstract class AbsTrg {
   public static final byte[] mtr = "MTR".getBytes();

   public abstract void pack(ByteBuffer var1, int var2, int var3, int var4);

   public void packLevel(ByteBuffer bb, int sna, int trgchl, int mode, int level) {
   }
}
