package com.owon.uppersoft.hdoscilloscope.data;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

public class DataTableDialog implements Localizable2 {
   public static final int everyPageCount = 5000;
   private Button sequenceButton;
   private Button exitButton;
   private Button saveAsButton;
   private String unit;
   private Group saveGroup;
   private MenuItem selectItem;
   private MenuItem selectNoneMenuItem;
   private MenuItem selectAllMenuItem;
   private Shell shell;
   private Composite right;
   private Composite left;
   private Button[] btns;
   private TableViewer v;
   private WaveFormFile wff;
   private DataTableDialog.CSelectionListener cselect = new DataTableDialog.CSelectionListener();
   private Label counterLabel;
   private ItemModel[] models;
   private int currentPage = 0;
   private int allPage = 0;
   private int lastPageCount = 0;
   private int allCount = 0;

   public DataTableDialog(Shell parent, WaveFormFile waveFormFile) {
      this.wff = waveFormFile;
      this.shell = new Shell(parent, 1264);
   }

   public Shell getShell() {
      return this.shell;
   }

   public void open() {
      this.createContents();
      this.customizeContents();
      this.localize(ResourceBundleProvider.getMessageLibResourceBundle());
      this.shell.layout();
      ShellUtil.centerLoc(this.shell);
      this.shell.setFocus();
      this.shell.open();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   protected void createContents() {
      this.shell.setSize(750, 450);
      GridLayout gridLayout = new GridLayout();
      gridLayout.marginHeight = 0;
      gridLayout.verticalSpacing = 0;
      gridLayout.marginWidth = 0;
      gridLayout.horizontalSpacing = 0;
      gridLayout.numColumns = 2;
      this.shell.setLayout(gridLayout);
      Menu menu = new Menu(this.shell, 2);
      this.shell.setMenuBar(menu);
      this.selectItem = new MenuItem(menu, 64);
      Menu selsectMenu = new Menu(this.selectItem);
      this.selectItem.setMenu(selsectMenu);
      this.selectAllMenuItem = new MenuItem(selsectMenu, 0);
      this.selectNoneMenuItem = new MenuItem(selsectMenu, 0);
      this.left = new Composite(this.shell, 2048);
      this.left.setLayout(new FillLayout());
      this.left.setLayoutData(new GridData(4, 4, true, true));
      this.right = new Composite(this.shell, 0);
      GridLayout gridLayout_1 = new GridLayout();
      gridLayout_1.numColumns = 3;
      this.right.setLayout(gridLayout_1);
      GridData gd_right = new GridData(4, 4, false, true);
      gd_right.heightHint = 0;
      gd_right.widthHint = 155;
      this.right.setLayoutData(gd_right);
      this.saveGroup = new Group(this.right, 4194304);
      RowLayout rowLayout = new RowLayout(512);
      rowLayout.marginTop = 10;
      rowLayout.marginBottom = 10;
      rowLayout.marginLeft = 10;
      rowLayout.fill = true;
      this.saveGroup.setLayout(rowLayout);
      GridData gd_saveGroup = new GridData(4, 4, true, false, 3, 1);
      this.saveGroup.setLayoutData(gd_saveGroup);
      this.sequenceButton = new Button(this.saveGroup, 32);
      this.sequenceButton.setText("sequence");
      this.saveAsButton = new Button(this.right, 0);
      GridData gd_saveAsButton = new GridData(16777216, 16777216, false, false, 3, 1);
      gd_saveAsButton.widthHint = 100;
      this.saveAsButton.setLayoutData(gd_saveAsButton);
      this.exitButton = new Button(this.right, 0);
      GridData gd_exitButton = new GridData(16777216, 16777216, false, false, 3, 1);
      gd_exitButton.widthHint = 100;
      this.exitButton.setLayoutData(gd_exitButton);
      Button forwardButton = new Button(this.right, 0);
      forwardButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            DataTableDialog.this.changeCurrentPage(-1);
         }
      });
      forwardButton.setText("<<");
      this.counterLabel = new Label(this.right, 16777216);
      this.counterLabel.setLayoutData(new GridData(4, 16777216, true, false));
      this.counterLabel.setText("0/0");
      Button backwardButton = new Button(this.right, 0);
      backwardButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            DataTableDialog.this.changeCurrentPage(1);
         }
      });
      backwardButton.setLayoutData(new GridData());
      backwardButton.setText(">>");
   }

   protected void customizeContents() {
      this.shell.setImage(Platform.getPlatform().getImageShop().getImage("dataTable.gif"));
      int SWT_Selection = 13;
      Listener listener = this.cselect;
      this.exitButton.addListener(SWT_Selection, listener);
      this.saveAsButton.addListener(SWT_Selection, listener);
      this.selectAllMenuItem.addListener(SWT_Selection, listener);
      this.selectNoneMenuItem.addListener(SWT_Selection, listener);
      if (this.wff == null) {
         this.btns = new Button[0];
      } else {
         this.v = new TableViewer(this.left, 268500992);
         this.v.setLabelProvider(new ItemLabelProvider(this.v));
         this.v.setContentProvider(new ItemContentProvider(this.v));
         this.v.setUseHashlookup(false);

         for (WaveForm wf : this.wff.wf_collect()) {
            this.allCount = Math.max(wf.getIntADCollectionNum(), this.allCount);
         }

         if (this.allCount == 0) {
            this.allPage = 0;
            this.currentPage = 0;
         } else {
            this.lastPageCount = this.allCount % 5000;
            this.allPage = this.allCount / 5000;
            if (this.lastPageCount != 0) {
               this.allPage++;
            }

            this.currentPage = 1;
         }

         this.counterLabel.setText(this.currentPage + "/" + this.allPage);
         this.models = new ItemModel[5000];

         for (int i = 0; i < 5000; i++) {
            this.models[i] = new ItemModel(i);
         }

         Table t = this.v.getTable();
         t.setHeaderVisible(true);
         t.setLinesVisible(true);
         TableLayout tl = new TableLayout();
         t.setLayout(tl);
         tl.addColumnData(new ColumnWeightData(2));
         TableColumn tc = new TableColumn(t, 16384);
         tc.setWidth(100);
         tc.setData(null);
         tc.setText("");
         this.btns = new Button[this.wff.getWaveFormsNumber()];
         int i = 0;

         for (WaveForm wf : this.wff.wf_collect()) {
            tl.addColumnData(new ColumnWeightData(2));
            double att = wf == null ? 1.0 : wf.getRateYAsAttenuation();
            tc = new TableColumn(t, 131072);
            tc.setWidth(100);
            String name = wf.getStrChannelTypeWithUnit();
            tc.setData(wf);
            tc.setText(name + "/" + att);
            Button btn = new Button(this.saveGroup, 32);
            btn.setText(name);
            btn.setData(wf);
            this.btns[i] = btn;
            i++;
         }

         this.changeCurrentPage(0);
         this.setSelections(true);
      }
   }

   public WaveFormFile getWff() {
      return this.wff;
   }

   public int getCurrentPage() {
      return this.currentPage;
   }

   private void changeCurrentPage(int add) {
      if (this.allPage == 0) {
         this.models = new ItemModel[0];
         this.counterLabel.setText("0/0");
      } else {
         this.currentPage += add;
         if (this.currentPage < 1) {
            this.currentPage = 1;
         }

         if (this.currentPage > this.allPage) {
            this.currentPage = this.allPage;
         }

         int index = (this.currentPage - 1) * 5000;
         int len = 0;
         len = 5000;
         if (this.currentPage == this.allPage && this.lastPageCount != 0) {
            len = this.lastPageCount;
         }

         for (int i = 0; i < len; index++) {
            this.models[i].i = index;
            i++;
         }

         this.v.setItemCount(len);
         this.v.setInput(this.models);
         this.counterLabel.setText(this.currentPage + "/" + this.allPage);
      }
   }

   protected void setSelections(boolean selected) {
      for (Button btn : this.btns) {
         btn.setSelection(selected);
      }

      this.sequenceButton.setSelection(selected);
   }

   public void localize(ResourceBundle bundle) {
      if (!this.shell.isDisposed()) {
         this.shell.setText(bundle.getString("DT.title"));
         this.selectItem.setText(bundle.getString("DT.sel"));
         this.selectAllMenuItem.setText(bundle.getString("DT.selAll"));
         this.selectNoneMenuItem.setText(bundle.getString("DT.selNone"));
         this.saveGroup.setText(bundle.getString("DT.save"));
         this.unit = bundle.getString("DT.Unit");
         this.saveAsButton.setText(bundle.getString("DT.SaveAs"));
         this.exitButton.setText(bundle.getString("DT.Exit"));
      }
   }

   public List<WaveForm> getSelectedChannels() {
      List<WaveForm> list = new LinkedList<>();

      for (Button btn : this.btns) {
         if (btn.getSelection()) {
            list.add((WaveForm)btn.getData());
         }
      }

      return list;
   }

   public boolean isSequenceSelected() {
      return this.sequenceButton.getSelection();
   }

   public String getUnitText() {
      return this.unit;
   }

   class CSelectionListener implements Listener {
      private int SWT_Selection = 13;

      public void handleEvent(Event event) {
         if (event.type == this.SWT_Selection) {
            Object o = event.widget;
            if (o == DataTableDialog.this.exitButton) {
               DataTableDialog.this.shell.close();
            }

            if (o == DataTableDialog.this.saveAsButton) {
               new SaveDataUtil().saveData(DataTableDialog.this, DataTableDialog.this.wff);
            }

            if (o == DataTableDialog.this.selectAllMenuItem) {
               DataTableDialog.this.setSelections(true);
            }

            if (o == DataTableDialog.this.selectNoneMenuItem) {
               DataTableDialog.this.setSelections(false);
            }
         }
      }
   }
}
