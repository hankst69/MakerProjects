package com.owon.uppersoft.hdoscilloscope.action.instance2;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.ColorDialog;

public class GridColorAction extends DefaultAction {
   public GridColorAction(String id) {
      super(id);
   }

   public void run() {
      this.doSetGridColor();
   }

   public void doSetGridColor() {
      Platform pf = Platform.getPlatform();
      DrawingPanel dp = pf.getCenter().getDrawingPanel();
      ColorDialog ds = new ColorDialog(pf.getShell());
      ds.setRGB(dp.getBackgroundDraw().getGridRGB());
      RGB rgb = ds.open();
      if (rgb != null) {
         dp.getBackgroundDraw().setGridRGB(rgb);
         dp.redraw();
      }
   }
}
