package com.owon.uppersoft.hdoscilloscope.manipulate.detail2;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.custom.IntPropertyChangeAdapter;
import com.owon.uppersoft.hdoscilloscope.custom.LLabel;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.trg.AbsTrgComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.trg.EdgeComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.trg.PulseComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.trg.SlopeComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.trg.TrgControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.trg.TrgGroup;
import com.owon.uppersoft.hdoscilloscope.manipulate.trg.VideoComposite;
import com.owon.uppersoft.hdoscilloscope.util.CRadioButtons;
import java.beans.PropertyChangeListener;
import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

public class TrgComposite extends Composite implements Localizable2 {
   private IntPropertyChangeAdapter pcl_type = new IntPropertyChangeAdapter() {
      @Override
      protected void idx(int i) {
         if (TrgComposite.this.on) {
            TrgComposite.this.on = false;
            TrgComposite.this.tc.setSNA(i);
            TrgComposite.this.chl_crb.setSelected(TrgComposite.this.tc.getChannelIndex());
            TrgGroup tg = TrgComposite.this.tc.getCurrent();
            int id = tg.getIndex();
            TrgComposite.this.mode_crb.setSelected(id);
            AbsTrgComposite stc = TrgComposite.this.trgs[id].load(TrgComposite.this.tc);
            TrgComposite.this.stack.topControl = stc;
            TrgComposite.this.com_set.layout();
            TrgComposite.this.on = true;
         }
      }
   };
   private IntPropertyChangeAdapter pcl_chl = new IntPropertyChangeAdapter() {
      @Override
      protected void idx(int i) {
         if (TrgComposite.this.on) {
            TrgComposite.this.on = false;
            TrgComposite.this.tc.setChannelIndex(i);
            switch (TrgComposite.this.tc.sna()) {
               case 0:
                  String cmd = ":TRIGger:SINGle:SOURce CH" + (i + 1);
                  TrgComposite.this.send(cmd);
                  break;
               case 1:
                  TrgGroup tg = TrgComposite.this.tc.getCurrent();
                  int id = tg.getIndex();
                  AbsTrgComposite stc = TrgComposite.this.trgs[id].load(TrgComposite.this.tc);
                  TrgComposite.this.stack.topControl = stc;
                  TrgComposite.this.com_set.layout();
                  TrgComposite.this.mode_crb.setSelected(id);
            }

            TrgComposite.this.on = true;
         }
      }
   };
   private IntPropertyChangeAdapter pcl_mode = new IntPropertyChangeAdapter() {
      @Override
      protected void idx(int i) {
         if (TrgComposite.this.on) {
            TrgComposite.this.on = false;
            TrgGroup tg = TrgComposite.this.tc.getCurrent();
            tg.setIndex(i);
            TrgComposite.this.stack.topControl = TrgComposite.this.trgs[i].load(TrgComposite.this.tc);
            TrgComposite.this.com_set.layout();
            String[] s = new String[]{"EDGE", "VIDeo", "PULSe", "SLOPe"};
            String cmd = ":TRIGger:SINGle:MODE " + s[i];
            TrgComposite.this.send(cmd);
            TrgComposite.this.on = true;
         }
      }
   };
   private List<Localizable2> lol = new LinkedList<>();
   private AbsTrgComposite[] trgs = new AbsTrgComposite[TrgControl.TrggerNames.length];
   private TrgControl tc;
   private boolean on = false;
   private CRadioButtons chl_crb;
   private CRadioButtons mode_crb;
   private CRadioButtons type_crb;
   private Spinner spinner;
   private Combo sweepcb;
   private Label sweeplbl;
   private Combo cobUnit;
   private Label lbHoldoff;
   private StackLayout stack;
   private EdgeComposite ec;
   private VideoComposite vc;
   private PulseComposite pc;
   private SlopeComposite sc;
   private Composite com_set;
   private Button forcebtn;
   private Button btn50;
   private Button set0btn;

   public TrgControl getTrgControl() {
      return this.tc;
   }

   public TrgComposite(Composite parent, TrgControl tc) {
      super(parent, 0);
      this.tc = tc;
      GridLayout gridLayout_2 = new GridLayout();
      gridLayout_2.verticalSpacing = 0;
      this.setLayout(gridLayout_2);
      int type = tc.sna();
      int trgid = tc.getCurrent().getIndex();
      this.type_crb = this.createCRadioButtons(this.pcl_type, type, TrgControl.SINGLE_ALT, "M.Trg.type", TrgControl.SINGLE_ALT.length);
      this.chl_crb = this.createCRadioButtons(this.pcl_chl, tc.getChannelIndex(), ManipulateControl.CHANNELS, "M.Trg.channel", tc.len);
      this.mode_crb = this.createCRadioButtons(this.pcl_mode, trgid, TrgControl.TrggerNames, "M.Trg.mode", TrgControl.TrggerNames.length);
      this.com_set = new Composite(this, 2048);
      this.stack = new StackLayout();
      this.com_set.setLayout(this.stack);
      GridData gd_set_com = new GridData(4, 4, true, true);
      gd_set_com.verticalIndent = 5;
      gd_set_com.heightHint = 150;
      this.com_set.setLayoutData(gd_set_com);
      this.ec = new EdgeComposite(this.com_set, this);
      this.vc = new VideoComposite(this.com_set, this);
      this.pc = new PulseComposite(this.com_set, this);
      this.sc = new SlopeComposite(this.com_set, this);
      int i = 0;
      this.trgs[i++] = this.ec;
      this.lol.add(this.ec);
      this.stack.topControl = this.ec;
      Composite composite = new Composite(this, 0);
      composite.setLayoutData(new GridData(4, 16777216, true, false));
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 5;
      composite.setLayout(gridLayout);
      this.sweeplbl = new Label(composite, 0);
      this.sweeplbl.setLayoutData(new GridData(131072, 16777216, false, false, 1, 1));
      this.sweepcb = new Combo(composite, 8);
      this.sweepcb.setItems(ManipulateControl.toStrings(TrgControl.SWEEP));
      this.sweepcb.select(0);
      this.sweepcb.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int index = TrgComposite.this.sweepcb.getSelectionIndex();
            String[] s = new String[]{"Auto", "Normal", "Single"};
            String cmd = ":TRIGger:SINGle:Sweep " + s[index];
            TrgComposite.this.send(cmd);
         }
      });
      this.sweepcb.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.lbHoldoff = new Label(composite, 0);
      this.spinner = new Spinner(composite, 2048);
      this.spinner.setIncrement(10);
      this.spinner.setMaximum(1000);
      this.spinner.setMinimum(1);
      this.spinner.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
         }
      });
      this.cobUnit = new Combo(composite, 8);
      this.cobUnit.setItems(new String[]{"ns", "us", "ms", "s"});
      this.cobUnit.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int index = TrgComposite.this.cobUnit.getSelectionIndex();
            int value = TrgComposite.this.spinner.getSelection();
            if (index == 0 && value < 100) {
               Platform.getPlatform().getManipulateControl().alert("Alert.holdoff", null);
            } else if (index == 3 && value > 10) {
               Platform.getPlatform().getManipulateControl().alert("Alert.holdoff", null);
            } else {
               String cmd = ":TRIGger:SINGle:HoldOff " + value + TrgComposite.this.cobUnit.getText();
               TrgComposite.this.send(cmd);
            }
         }
      });
      this.custom();
   }

   public void send(String cmd) {
      Platform.getPlatform().getManipulateControl().send(cmd);
   }

   private void custom() {
      this.lbHoldoff.setVisible(false);
      this.spinner.setVisible(false);
      this.cobUnit.setVisible(false);
      this.on = true;
   }

   private CRadioButtons createCRadioButtons(PropertyChangeListener pcl, int sel, Object[] os, Object lo, int len) {
      Composite com = new Composite(this, 0);
      com.setLayoutData(new GridData(4, 16777216, true, false));
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 3;
      com.setLayout(gridLayout);
      LLabel lbl = new LLabel(com, 0);
      GridData gd_lbl = new GridData(4, 16777216, false, false);
      gd_lbl.widthHint = 80;
      lbl.setLayoutData(gd_lbl);
      lbl.setData(lo);
      CRadioButtons crb = new CRadioButtons(com, os, pcl, sel, len);
      crb.setLayoutData(new GridData(4, 16777216, true, false, 2, 1));
      this.lol.add(lbl);
      this.lol.add(crb);
      new Label(com, 0);
      return crb;
   }

   public void localize(ResourceBundle rb) {
      this.on = false;

      for (Localizable2 lo : this.lol) {
         lo.localize(rb);
      }

      this.sweeplbl.setText(rb.getString("M.Trg.sweep"));
      int idx = this.sweepcb.getSelectionIndex();
      this.sweepcb.setItems(ManipulateControl.toStrings(TrgControl.SWEEP));
      this.sweepcb.select(idx);
      this.lbHoldoff.setText(rb.getString("M.Trg.holdoff"));
      this.on = true;
   }
}
