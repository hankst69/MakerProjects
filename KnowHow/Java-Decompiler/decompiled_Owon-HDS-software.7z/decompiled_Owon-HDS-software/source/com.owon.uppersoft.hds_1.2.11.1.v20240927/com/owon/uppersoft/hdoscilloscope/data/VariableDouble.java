package com.owon.uppersoft.hdoscilloscope.data;

public class VariableDouble {
   private double value;

   public void setDoubleValue(double v) {
      this.value = v;
   }

   public double getDoubleValue() {
      return this.value;
   }

   @Override
   public String toString() {
      return String.valueOf(this.value);
   }
}
