package com.owon.uppersoft.hdoscilloscope.util;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;

public class DBG {
   public static final Level global = Level.FINEST;
   private static TextHandle th;
   public static boolean debug = true;
   private static boolean cmddebug = true;
   public static final Logger logger = LoggerUtil.getConsoleLogger(DBG.class.getName(), global);
   private static StringBuilder sb = new StringBuilder();

   public static final void prepareLogType(boolean cmd) {
      cmddebug = cmd;
      if (!cmd) {
         LoggerUtil.redirect2FileLog();
      }
   }

   public static final boolean isCMDDEBUG() {
      return cmddebug;
   }

   public static final void openTextLogger(JTextArea t) {
      th = new TextHandle(t);
      logger.addHandler(th);
   }

   public static final void dbgArray(byte[] arr, int start, int len) {
      if (debug) {
         int end = start + len;
         int i = start;

         for (int j = 0; i < end; j++) {
            if (j % 4 == 0) {
               dbg("," + arr[i] + " ");
            } else {
               dbg(arr[i] + " ");
            }

            i++;
         }

         dbgln("");
      }
   }

   public static final void dbgArray(int[] arr, int start, int len) {
      if (debug) {
         int end = start + len;

         for (int i = start; i < end; i++) {
            dbg(arr[i] + " ");
         }

         dbgln("");
      }
   }

   public static final void dbg(String t) {
      if (debug) {
         sb.append(t);
      }
   }

   public static final void dbgd(String t) {
      if (debug) {
         flushdbg();
         if (t.length() > 0) {
            fine(t);
         }
      }
   }

   public static final void dbgln(String t) {
      flushdbg();
      if (t.length() > 0) {
         fine(t + "\r\n");
      }
   }

   public static final void flushdbg() {
      int len = sb.length();
      if (len > 0) {
         fine(sb.toString() + "\r\n");
         sb.delete(0, len);
      }
   }

   public static final void config(String msg) {
      if (debug) {
         logger.config(msg);
      }
   }

   public static final void configln(String msg) {
      if (debug) {
         logger.config(msg + "\r\n");
      }
   }

   public static final void fine(String msg) {
      if (debug) {
         logger.fine(msg);
      }
   }

   public static final void finer(String msg) {
      if (debug) {
         logger.finer(msg);
      }
   }

   public static final void finest(String msg) {
      if (debug) {
         logger.finest(msg);
      }
   }

   public static final void info(String msg) {
      if (debug) {
         logger.info(msg);
      }
   }

   public static final void severe(String msg) {
      if (debug) {
         logger.severe(msg);
      }
   }

   public static final void warning(String msg) {
      if (debug) {
         logger.warning(msg);
      }
   }
}
