package com.owon.uppersoft.hdoscilloscope.action.instance2;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class StopAction extends DefaultAction {
   public StopAction(String id) {
      super(id);
   }

   public void run() {
      Platform platform = Platform.getPlatform();
      platform.getActionFactory().loopControl.stopLoop();
   }
}
