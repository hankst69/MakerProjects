package com.owon.uppersoft.hdoscilloscope.data;

import com.owon.uppersoft.hdoscilloscope.data.transform.AbstractDataImport;
import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;

public class MultiMeter {
   public static final int HeaderLength = 5;
   public static final int BLOCKSIZE = 28;
   public static final String[] units = new String[]{"", "Ω", "kΩ", "MΩ", "uA", "mA", "A", "pF", "nF", "uF", "uV", "mV", "V"};
   public static final String[] types = new String[]{"", "ACV", "DCV", "DIODE", "C", "R", "ACA", "DCA", "BUZZER", "IN"};
   public String name;
   public int intBlockSize;
   public int type;
   public int precision;
   public double value;
   public int unit;
   public boolean neg_val;
   public boolean neg_re;
   public boolean re_use;
   public double re_value;
   private String valueTxt;
   private String re_ValueTxt;
   private String info;

   public MultiMeter(String name) {
      this.name = name;
   }

   public void readin(CByteArrayInputStream ba) {
      int p1st = ba.pointer();
      this.intBlockSize = ba.nextInt();
      this.type = ba.nextInt();
      this.precision = ba.nextInt();
      this.value = (double)Float.intBitsToFloat(ba.nextInt());
      this.unit = ba.nextInt();
      this.re_use = ba.nextInt() != 0;
      this.re_value = (double)Float.intBitsToFloat(ba.nextInt());
      AbstractDataImport.logger.fine("MultiMeter");
      AbstractDataImport.logger.fine("intBlockSize: " + this.intBlockSize);
      AbstractDataImport.logger.fine("type: " + this.type);
      AbstractDataImport.logger.fine("precision: " + this.precision);
      AbstractDataImport.logger.fine("value: " + this.value);
      AbstractDataImport.logger.fine("unit: " + this.unit);
      AbstractDataImport.logger.fine("re_use: " + this.re_use);
      AbstractDataImport.logger.fine("re_value: " + this.re_value);
      ba.skip(this.intBlockSize - (ba.pointer() - p1st));
      this.neg_val = this.value < 0.0;
      this.neg_re = this.re_value < 0.0;
      String sign = "";
      if (this.neg_val) {
         sign = "-";
      }

      this.value = Math.abs(this.value);
      this.re_value = Math.abs(this.re_value);
      this.re_ValueTxt = "";
      if (this.re_use) {
         int p;
         if (this.re_value < 10.0) {
            p = 3;
         } else if (this.re_value < 100.0) {
            p = 2;
         } else if (this.re_value < 1000.0) {
            p = 1;
         } else {
            p = 0;
         }

         this.re_ValueTxt = "ref: " + (this.neg_re ? "-" : "") + String.format("%." + p + "f", this.re_value) + this.unit();
      }

      if (this.value < 8888.0) {
         switch (this.precision) {
            case 0:
            default:
               this.valueTxt = sign + (int)this.value;
               break;
            case 1:
            case 2:
            case 3:
               this.valueTxt = sign + String.format("%." + (4 - this.precision) + "f", this.value);
         }
      } else {
         this.valueTxt = "E";
      }

      this.info = this.valueTxt + this.unit();
      if (this.re_use) {
         this.info = this.info + "  (" + this.re_ValueTxt + ")";
      }
   }

   public String info() {
      return this.info;
   }

   public String type() {
      return types[this.type];
   }

   public String unit() {
      return units[this.unit];
   }
}
