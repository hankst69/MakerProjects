package com.owon.uppersoft.hdoscilloscope.autoplay;

import com.owon.uppersoft.hdoscilloscope.global.Platform;
import java.io.File;

public class ImagePlayer implements IAutoPlayer {
   public static final int In_turn = 0;
   public static final int Turn_back = 1;
   private PlayAttribute playAttr;
   private Thread th;
   private AutoPlayerFrame apFrame;
   private ImagePlayer.PlayMode pm;
   private boolean isEnd = false;
   private boolean isPause = false;
   private boolean isFastPlay = false;
   private boolean isFastBackOff = false;

   public ImagePlayer(AutoPlayerFrame apFrame, PlayAttribute playAttr) {
      this.apFrame = apFrame;
      this.playAttr = playAttr;
      this.pm = new ImagePlayer.PlayMode();
   }

   @Override
   public void setPlayAttribute(PlayAttribute playAttr) {
      this.playAttr = playAttr;
      this.pm.setPlayMode();
      this.signClean();
   }

   @Override
   public void fastForward() {
      this.isFastPlay = true;
      this.isFastBackOff = false;
   }

   @Override
   public void fastBackward() {
      this.isFastPlay = true;
      this.isFastBackOff = true;
   }

   @Override
   public void endFast() {
      this.isFastPlay = false;
      this.isFastBackOff = false;
   }

   @Override
   public void playSingle(int index) {
      if (this.play(index) && this.playAttr != null) {
         this.playAttr.setCurrentIndex(index);
      }
   }

   @Override
   public void previous() {
      if (this.playAttr != null) {
         int previous = this.pm.previous();
         if (this.isPause && previous >= -1) {
            this.play(previous);
            this.playAttr.setCurrentIndex(previous);
         }
      }
   }

   @Override
   public void next() {
      if (this.playAttr != null) {
         int next = this.pm.next();
         if (this.isPause && next >= -1) {
            this.play(next);
            this.playAttr.setCurrentIndex(next);
         }
      }
   }

   @Override
   public void playEnd() {
      this.isEnd = true;
      if (this.th != null) {
         this.th.stop();
      }
   }

   @Override
   public void playPause() {
      this.isPause = true;
   }

   @Override
   public void playContinue() {
      this.isPause = false;
   }

   @Override
   public void playStart() {
      if (this.playAttr != null) {
         this.signClean();
         this.th = new Thread() {
            @Override
            public void run() {
               Platform.getPlatform().getDrawingPanel().syncSetEnablebuf(false);
               Platform.getPlatform().getCenter().getToolCom().setFFTButton(false);

               label55:
               while (!ImagePlayer.this.isEnd) {
                  while (ImagePlayer.this.isPause && ImagePlayer.this.isPause) {
                     if (ImagePlayer.this.isEnd) {
                        break label55;
                     }
                  }

                  int index = ImagePlayer.this.isFastBackOff ? ImagePlayer.this.pm.getPrevious() : ImagePlayer.this.pm.getNext();
                  if (!ImagePlayer.this.play(index)) {
                     break;
                  }

                  ImagePlayer.this.apFrame.setScaleSelect(index);
                  ImagePlayer.this.playAttr.setCurrentIndex(index);
                  if (ImagePlayer.this.isEnd) {
                     break;
                  }

                  try {
                     Thread.sleep((long)(ImagePlayer.this.isFastPlay ? ImagePlayer.this.playAttr.getDelayTime() / 2 : ImagePlayer.this.playAttr.getDelayTime()));
                  } catch (InterruptedException var2) {
                     break;
                  }

                  if (ImagePlayer.this.isFastBackOff) {
                     ImagePlayer.this.pm.getPrevious();
                  } else {
                     ImagePlayer.this.pm.getNext();
                  }
               }

               ImagePlayer.this.resetThreadContext();
               Platform.getPlatform().getCenter().getToolCom().setFFTButton(true);
               Platform.getPlatform().getDrawingPanel().syncSetEnablebuf(true);
            }
         };
         this.th.start();
      }
   }

   private void resetThreadContext() {
      if (this.playAttr != null) {
         this.signClean();
         this.playAttr.resetCurrentIndex();
         this.apFrame.resetThreadContext();
      }
   }

   private void signClean() {
      this.isEnd = false;
      this.isPause = false;
      this.isFastPlay = false;
      this.isFastBackOff = false;
   }

   private boolean play(int index) {
      if (index >= 0 && index < this.playAttr.getPlayFileList().size()) {
         File f = new File(this.playAttr.getPlayFolderPath(), this.playAttr.getPlayFileList().get(index));
         if (!f.exists()) {
            return true;
         } else {
            this.apFrame.doOpenFile(f);
            return true;
         }
      } else {
         return false;
      }
   }

   public class PlayMode {
      private static final int In_turn = 0;
      private static final int Turn_back = 1;
      private static final int ERROR = -2;
      private boolean isTurnPlay = true;

      public void setPlayMode() {
         switch (ImagePlayer.this.playAttr.getPlayerMode()) {
            case 0:
               this.isTurnPlay = true;
               break;
            case 1:
               this.isTurnPlay = false;
               break;
            default:
               this.isTurnPlay = true;
         }
      }

      public int getPrevious() {
         return this.isTurnPlay ? this.isRight(ImagePlayer.this.playAttr.getCurrentIndex() - 1) : this.isRight(ImagePlayer.this.playAttr.getCurrentIndex() + 1);
      }

      public int getNext() {
         return this.isTurnPlay ? this.isRight(ImagePlayer.this.playAttr.getCurrentIndex() + 1) : this.isRight(ImagePlayer.this.playAttr.getCurrentIndex() - 1);
      }

      public int previous() {
         return this.isRight(ImagePlayer.this.playAttr.getCurrentIndex() - 1);
      }

      public int next() {
         return this.isRight(ImagePlayer.this.playAttr.getCurrentIndex() + 1);
      }

      private int isRight(int ret) {
         return ret >= 0 && ret < ImagePlayer.this.playAttr.getPlayFileList().size() ? ret : -2;
      }
   }
}
