package com.owon.uppersoft.hdoscilloscope.frame;

import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.swt.graphics.Image;

public class MyLabelProvider implements ITableLabelProvider {
   public static final int ChannelVisibleColumn = 0;
   public static final int ChannelHsColumn = 1;
   public static final int ChannelVvColumn = 2;
   public static final int ChannelAttenuationColumn = 3;

   public Image getColumnImage(Object element, int columnIndex) {
      return null;
   }

   public String getColumnText(Object element, int columnIndex) {
      String re = "";
      if (element == null) {
         return re;
      } else {
         if (element instanceof WaveFormCurve) {
            WaveFormCurve wfc = (WaveFormCurve)element;
            switch (columnIndex) {
               case 0:
                  re = wfc.getStrChannelType();
                  break;
               case 1:
                  re = wfc.getXBaseTxt();
                  break;
               case 2:
                  re = wfc.getYBaseTxt();
                  break;
               case 3:
                  WaveForm wf = wfc.getWaveForm();
                  if (wf != null) {
                     re = "/" + wf.getIntAttenuationMultiple();
                  }
            }
         }

         return re;
      }
   }

   public void addListener(ILabelProviderListener listener) {
   }

   public void dispose() {
   }

   public boolean isLabelProperty(Object element, String property) {
      return false;
   }

   public void removeListener(ILabelProviderListener listener) {
   }
}
