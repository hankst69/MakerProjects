package com.owon.uppersoft.hdoscilloscope.communication;

import ch.ntb.usb.USBException;
import com.owon.uppersoft.common.aspect.Localizable;
import com.owon.uppersoft.common.commjob.instance.VisaCommunication;
import com.owon.uppersoft.hdoscilloscope.communication.usb.CDevice;
import com.owon.uppersoft.hdoscilloscope.communication.usb.IDevice;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import com.owon.uppersoft.hdoscilloscope.pref.PreferencesFactory;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class PortSetting extends PrototypePortSettingFrame implements Localizable, Listener {
   protected Configuration config;
   protected String[] portType;
   protected String parityNone;
   protected final int SWT_Selection = 13;
   private Image warnImg;
   private Button[] choicesbtns;
   private PortSetting.CheckUSBRunner checkUSBRunner = new PortSetting.CheckUSBRunner();
   private PortSetting.SelectPortRunner selectPortRunner = new PortSetting.SelectPortRunner();
   private IDevice[] ids;

   public void handleEvent(Event event) {
      if (event.type == 13) {
         Object o = event.widget;
         if (o == this.btnOK) {
            if (this.saveStatus()) {
               this.getShell().close();
            }
         } else if (o == this.refreshButton) {
            this.refreshUSBPort();
         } else if (o == this.refreshTmcButton) {
            this.refreshUSBTMCPort();
         } else if (o == this.portTypeCombo) {
            String selected = this.portTypeCombo.getText();
            this.setPortInfoCom(selected);
         } else if (o == this.checkSave) {
            this.checkAutoSave();
         } else if (o == this.btnBrowse) {
            DirectoryDialog dd = new DirectoryDialog(this.getShell(), 4096);
            String path = dd.open();
            if (path != null) {
               this.txtPath.setText(path);
            }
         } else {
            Platform p = Platform.getPlatform();
            if (o == this.uploadButton) {
               if (this.saveStatus()) {
                  this.getShell().close();
                  new BetaUploadFrame(p.getMainFrame().getShell(), p.getConfiguration()).open();
               }
            } else if (o == this.keepgettingButton) {
               if (this.saveStatus() && p.getActionFactory().loopControl.DoLoop()) {
                  this.getShell().close();
               }
            }
         }
      }
   }

   public PortSetting(Shell shell, Configuration config) {
      super(shell);
      this.config = config;
      this.warnImg = Platform.getPlatform().getImageShop().getImage("msg_icon_warn.gif");
      this.btnOK.addListener(13, this);
      this.refreshButton.addListener(13, this);
      this.uploadButton.addListener(13, this);
      this.keepgettingButton.addListener(13, this);
      this.delaySpinner.setIncrement(config.incLoopDelay);
      this.delaySpinner.setMaximum(config.maxLoopDelay);
      this.delaySpinner.setMinimum(config.minLoopDelay);
      this.choicesbtns = new Button[]{this.binButton, this.bmpButton, this.memdepthButton};
      this.binButton.setData("PS.bin");
      this.bmpButton.setData("PS.bmp");
      this.memdepthButton.setData("PS.memdepth");
      SelectionAdapter sa = new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            PortSetting.this.cmdPrompt
               .setText(ResourceBundleProvider.getMessageLibResourceBundle().getString(((Control)e.getSource()).getData().toString() + "Prompt"));
         }
      };

      for (Button btn : this.choicesbtns) {
         btn.addSelectionListener(sa);
      }

      this.getShell().setImage(Platform.getPlatform().getImageShop().getImage("ports.gif"));
      this.localize();
      this.portTypeCombo.setText("loading...");
      this.portTypeCombo.addListener(13, this);
      this.checkSave.addListener(13, this);
      this.btnBrowse.addListener(13, this);
      (new Thread() {
         @Override
         public void run() {
            PortSetting.this.loadPortType();
            PortSetting.this.refreshUSBPort();
         }
      }).start();
      this.setStatus();
   }

   @Override
   protected void customCMDGroup() {
      switch (Platform.getPlatform().getConfiguration().cmdAvailMode) {
         case 0:
            super.customCMDGroupNormal();
            break;
         case 1:
            super.customCMDGroupTD();
            break;
         default:
            Platform.getPlatform().getConfiguration().cmdAvailMode = 2;
         case 2:
            super.customCMDGroupSDS();
      }
   }

   public void localize() {
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      this.shell.setText(bundle.getString("PS.title"));
      this.portTypeLabel.setText(bundle.getString("PS.portType"));
      this.baudLabel.setText(bundle.getString("PS.baudRate"));
      this.dataBitsLabel.setText(bundle.getString("PS.dataBits"));
      this.parityLabel.setText(bundle.getString("PS.parity"));
      this.stopbitsLabel.setText(bundle.getString("PS.stopBits"));
      this.btnOK.setText(bundle.getString("PS.OK"));
      this.availablePortsLabel.setText(bundle.getString("PS.availablePorts"));
      this.refreshButton.setText(bundle.getString("PS.refresh"));
      this.tmcAvailablePortsLabel.setText(bundle.getString("PS.availablePorts"));
      this.refreshTmcButton.setText(bundle.getString("PS.refresh"));
      this.loopSettingGroup.setText(bundle.getString("PS.groupTitle"));
      this.labDelay.setText(bundle.getString("PS.loopDelay"));
      this.labPort.setText(bundle.getString("PS.lanport"));
      this.checkSave.setText(bundle.getString("PS.checkSave"));
      this.clabel.setText(ResourceBundleProvider.getMessageLibResourceBundle().getString("PS.FSLimit"));
      this.clabel.setImage(this.warnImg);
      this.btnBrowse.setText(bundle.getString("PS.browse"));
      this.keepgettingButton.setText(bundle.getString("PS.keepgetting"));
      this.uploadButton.setText(bundle.getString("PS.upload"));
      this.parityNone = bundle.getString("PS.parityNone");

      for (Button btn : this.choicesbtns) {
         btn.setText(bundle.getString(btn.getData().toString()));
      }

      this.cmdGroup.setText(bundle.getString("PS.cmdGroupPrompt"));
   }

   protected boolean saveStatus() {
      String port = this.config.portType = this.portTypeCombo.getText();
      this.config.loopDelay = this.delaySpinner.getSelection();
      this.config.autoSavePath = this.checkSave.getSelection() ? this.txtPath.getText().trim() : "";
      int j = 0;

      for (Button btn : this.choicesbtns) {
         if (btn.getSelection()) {
            this.config.usbRequestCMDidx = j;
            System.out.println(j + ". " + btn.getData());
            break;
         }

         j++;
      }

      this.config.iDevice = null;
      if ("USB".equalsIgnoreCase(port)) {
         int i = this.usbCombo.getSelectionIndex();
         if (i >= 0) {
            this.config.iDevice = this.ids[i];
         }

         return true;
      } else if ("LAN".equalsIgnoreCase(port)) {
         this.config.address = this.txtIP.getText() + ":" + this.txtPort.getText();
         return true;
      } else {
         int i = this.usbtmcCombo.getSelectionIndex();
         if (i >= 0) {
            this.config.strusbtmc = this.usbtmcCombo.getText();
         }

         return true;
      }
   }

   protected void setStatus() {
      this.portTypeCombo.setText(this.config.portType);
      this.baudRateCombo.add(String.valueOf(115200));
      this.baudRateCombo.select(0);
      this.baudRateCombo.setEnabled(false);
      this.dataBitsCombo.add(String.valueOf(8));
      this.dataBitsCombo.select(0);
      this.dataBitsCombo.setEnabled(false);
      this.stopBitsCombo.add(String.valueOf(1));
      this.stopBitsCombo.select(0);
      this.stopBitsCombo.setEnabled(false);
      this.parityCombo.add(String.valueOf(this.parityNone));
      this.parityCombo.select(0);
      this.parityCombo.setEnabled(false);
      this.setPortInfoCom(this.config.portType);
      String[] s = this.config.address.split(":");
      this.txtIP.setText(s[0]);
      this.txtPort.setText(s[1]);
      this.delaySpinner.setSelection(this.config.loopDelay);
      Button btn = this.choicesbtns[Platform.getPlatform().getConfiguration().usbRequestCMDidx];
      btn.setSelection(true);
      this.cmdPrompt.setText(ResourceBundleProvider.getMessageLibResourceBundle().getString(btn.getData().toString() + "Prompt"));
      String path = this.config.autoSavePath;
      this.checkSave.setSelection(!path.equals(""));
      this.txtPath.setText(path);
      this.checkAutoSave();
   }

   private void loadPortType() {
      this.portType = new String[1];
      this.portType[0] = "USB";
      this.shell.getDisplay().asyncExec(this.checkUSBRunner);
   }

   private void refreshUSBPort() {
      try {
         List<IDevice> udl = CDevice.scanMatchedDevices((short)21317, (short)4660);
         this.ids = new IDevice[udl.size()];
         this.ids = udl.toArray(this.ids);
         Arrays.sort((Object[])this.ids);
         this.shell.getDisplay().asyncExec(this.selectPortRunner);
      } catch (USBException var2) {
         var2.printStackTrace();
      } catch (Throwable var3) {
         var3.printStackTrace();
      }
   }

   private void refreshUSBTMCPort() {
      VisaCommunication visa = new VisaCommunication();
      List<String> list = visa.findSrc();
      this.usbtmcCombo.removeAll();
      Iterator<String> it = list.iterator();

      while (it.hasNext()) {
         this.usbtmcCombo.add(it.next());
      }

      if (this.usbtmcCombo.getItemCount() > 0) {
         this.usbtmcCombo.select(0);
      }
   }

   public void setPortInfoCom(boolean enabled) {
      this.stackLayout.topControl = enabled ? this.usbInfoCom : this.serialInfoCom;
      this.infoCom.layout();
   }

   public void setPortInfoCom(String portType) {
      this.cmdGroup.setVisible(true);
      if (portType.equalsIgnoreCase("LAN")) {
         this.stackLayout.topControl = this.lanInfoCom;
      } else if (portType.equalsIgnoreCase("USB")) {
         this.stackLayout.topControl = this.usbInfoCom;
         this.refreshUSBPort();
      } else {
         this.stackLayout.topControl = this.usbtmcInfoCom;
         this.refreshUSBTMCPort();
      }

      this.infoCom.layout();
   }

   protected void checkAutoSave() {
      this.btnBrowse.setEnabled(this.checkSave.getSelection());
   }

   public static void main_hide(String[] args) {
      try {
         Locale.setDefault(Locale.ENGLISH);
         Shell s = new Shell();
         PreferencesFactory pf = new PreferencesFactory("conf", "pref.properties");
         Configuration con = pf.getConfiguration();
         PortSetting ps = new PortSetting(s, con);
         ps.open();
      } catch (Exception var5) {
         var5.printStackTrace();
      }
   }

   class CheckUSBRunner implements Runnable {
      @Override
      public void run() {
         PortSetting.this.portTypeCombo.removeAll();
         PortSetting.this.portTypeCombo.setItems(PortSetting.this.portType);
         PortSetting.this.portTypeCombo.setText(PortSetting.this.config.portType);
      }
   }

   class SelectPortRunner implements Runnable {
      @Override
      public void run() {
         if (!PortSetting.this.shell.isDisposed()) {
            PortSetting.this.usbCombo.removeAll();
            int length = PortSetting.this.ids.length;

            for (int i = 0; i < length; i++) {
               String sn = PortSetting.this.ids[i].getSerialNumber();
               if (sn == null) {
                  sn = "?";
               }

               if (PortSetting.this.config.isDispSn) {
                  PortSetting.this.usbCombo.add(i + 1 + ". (SN: " + sn + ")");
               } else {
                  PortSetting.this.usbCombo.add(i + 1 + ". (DEVICE" + i + ")");
               }
            }

            PortSetting.this.usbCombo.select(0);
         }
      }
   }
}
