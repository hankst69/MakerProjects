package com.owon.uppersoft.hdoscilloscope.data;

public class ItemModel {
   public int i;

   public ItemModel(int i) {
      this.i = i;
   }
}
