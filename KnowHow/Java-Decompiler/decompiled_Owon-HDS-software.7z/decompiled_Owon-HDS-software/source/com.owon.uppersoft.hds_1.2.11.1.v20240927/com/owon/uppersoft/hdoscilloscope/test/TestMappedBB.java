package com.owon.uppersoft.hdoscilloscope.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import sun.nio.ch.DirectBuffer;

public class TestMappedBB {
   public static void main(String[] args) {
      test1();
   }

   public static void test1() {
      File file = new File("i:\\b.txt");
      ByteBuffer mbb = null;

      try {
         RandomAccessFile in = new RandomAccessFile(file, "rw");
         FileChannel ch = in.getChannel();
         mbb = ch.map(MapMode.READ_WRITE, 10L, 50L);
         System.out.println(file.length());

         for (int i = 0; i < 10; i++) {
            mbb.put((byte)120);
         }

         System.out.println(file.length());
         ch.close();
      } catch (FileNotFoundException var6) {
         var6.printStackTrace();
      } catch (IOException var7) {
         var7.printStackTrace();
      }

      if (mbb instanceof DirectBuffer) {
         System.out.println(mbb);
         DirectBuffer db = (DirectBuffer)mbb;
         db.cleaner().clean();
         System.err.println("RELEASE");
      }

      try {
         boolean b = file.delete();
         System.out.println("Delete File: " + b);
         Thread.sleep(100000L);
      } catch (Exception var5) {
         var5.printStackTrace();
      }
   }
}
