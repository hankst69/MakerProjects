package com.owon.uppersoft.hdoscilloscope.chart;

import com.owon.uppersoft.common.aspect.Disposable;
import com.owon.uppersoft.common.aspect.Localizable;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;

public class DrawingPanel implements PaintListener, Disposable, Localizable {
   private BackgroundDraw background;
   private MarkDraw markDraw2D;
   private WaveFormFileCurve wffc;
   private WaveFormFileCurveRenderer renderer;
   private Composite mainCom;
   private Point lastSize = new Point(0, 0);
   private Point size = new Point(0, 0);
   private boolean dragging = false;
   private boolean dragMark = false;
   private boolean enablebuf = false;
   private DrawingPanelMouseAdapter ad;

   public BackgroundDraw getBackgroundDraw() {
      return this.background;
   }

   public MarkDraw getMarkDraw() {
      return this.markDraw2D;
   }

   public Composite getComposite() {
      return this.mainCom;
   }

   public void setCursor(Cursor cursor) {
      this.mainCom.setCursor(cursor);
   }

   public Point getLastSize() {
      return this.lastSize;
   }

   public Point getSize() {
      return this.size;
   }

   public DrawingPanel(Composite com) {
      this.mainCom = com;
      this.background = new BackgroundDraw(this);
      this.wffc = new WaveFormFileCurve(this);
      this.renderer = new WaveFormFileCurveRenderer(this.wffc);
      this.markDraw2D = new MarkDraw(this);
      this.ad = new DrawingPanelMouseAdapter(this);
      com.addMouseListener(this.ad);
      com.addMouseMoveListener(this.ad);
      com.addPaintListener(this);
   }

   public void setXYChosen(boolean XYChosen) {
      this.setEnablebuf(!XYChosen);
      this.ad.setShutdown(XYChosen);
      this.wffc.setXYChosen(XYChosen);
   }

   public boolean isXYChosen() {
      return this.wffc.isXYChosen();
   }

   public void updateBound() {
      this.lastSize = this.size;
      this.size = this.mainCom.getSize();
      if (this.size.x != 0 && this.size.y != 0) {
         this.background.updateBound(this.size);
         this.markDraw2D.updateBound(this.size);
         this.wffc.resizeTo(this.lastSize, this.size);
      }
   }

   public WaveFormFileCurve getWaveFormFileCurve() {
      return this.wffc;
   }

   public void setWaveFormFile(WaveFormFile wff) {
      if (wff != null) {
         this.wffc.setWaveFormFile(wff);
         this.background.setGraticuleNum(wff.getXGraticuleNum(), wff.getYGraticuleNum());
         this.redraw();
      }
   }

   public GraphicContext getGraphicContext(GC gc) {
      GraphicContext gx = new GraphicContext();
      gx.linevisible = this.wffc.getReg().isLineVisible();
      gx.gc = gc;
      Point sz = this.getSize();
      gx.size.x = sz.x;
      gx.size.y = sz.y;
      return gx;
   }

   public void paintControl(PaintEvent e) {
      GC gc = e.gc;
      if (this.enablebuf) {
         this.drawingPaint(gc);
      } else {
         GraphicContext gx = this.getGraphicContext(gc);
         this.background.draw(gx);
         this.renderer.draw(gx);
         this.markDraw2D.draw(gx);
      }
   }

   public void drawingPaint(GC gc) {
      GraphicContext gx = this.getGraphicContext(gc);
      this.background.draw(gx);
      if (this.dragging) {
         this.renderer.drawSelect(gx);
      }

      this.markDraw2D.draw(gx);
   }

   public void drawingPrint(GC gc) {
      GraphicContext gx = this.getGraphicContext(gc);
      RGB bgrgb = this.background.getBackgroundRGB();
      this.background.setBackgroundRGB(PropertiesItem.RGB_WHITE);
      this.background.updateBgImg();
      this.background.draw(gx);
      this.background.setBackgroundRGB(bgrgb);
      this.background.updateBgImg();
      this.renderer.draw(gx);
   }

   public void drawingPic(GC gc) {
      GraphicContext gx = this.getGraphicContext(gc);
      this.background.draw(gx);
      this.renderer.draw(gx);
      this.markDraw2D.draw(gx);
   }

   public void delegateDraw(GC gc) {
      if (this.enablebuf) {
         GraphicContext gx = this.getGraphicContext(gc);
         if (this.dragging) {
            this.renderer.drawWithoutSelect(gx);
         } else {
            this.renderer.draw(gx);
         }
      }
   }

   public void syncSetEnablebuf(boolean e) {
      if (!this.mainCom.isDisposed()) {
         if (this.enablebuf != e) {
            this.enablebuf = e;
            Display display = this.mainCom.getDisplay();
            display.syncExec(new Runnable() {
               @Override
               public void run() {
                  DrawingPanel.this.background.updateBgImg();
               }
            });
         }
      }
   }

   public void setEnablebuf(boolean e) {
      if (!this.mainCom.isDisposed()) {
         if (this.enablebuf != e) {
            this.enablebuf = e;
            this.background.updateBgImg();
         }
      }
   }

   public boolean isEnablebuf() {
      return this.enablebuf;
   }

   public void setDragging(boolean d) {
      if (this.enablebuf) {
         if (d != this.dragging) {
            this.dragging = d;
            this.background.updateBgImg();
         }
      }
   }

   public boolean isDragging() {
      return this.dragging;
   }

   public void setDragMark(boolean d) {
      if (this.enablebuf) {
         if (d != this.dragMark) {
            this.dragMark = d;
            this.background.updateBgImg();
         }
      }
   }

   public boolean isDragMark() {
      return this.dragMark;
   }

   public void redraw(boolean update) {
      if (update) {
         this.background.updateBgImg();
      }

      this.mainCom.redraw();
   }

   public void redraw() {
      this.redraw(!this.dragging && !this.dragMark);
   }

   public void dispose() {
      this.background.dispose();
      this.markDraw2D.dispose();
      this.wffc.dispose();
   }

   public void localize() {
      this.wffc.localize();
   }
}
