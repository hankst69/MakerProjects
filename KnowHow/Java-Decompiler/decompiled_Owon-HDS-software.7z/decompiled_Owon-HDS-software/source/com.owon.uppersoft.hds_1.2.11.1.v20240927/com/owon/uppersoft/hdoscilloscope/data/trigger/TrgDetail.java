package com.owon.uppersoft.hdoscilloscope.data.trigger;

import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.chart.GraphicContext;
import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.data.transform.AbstractDataImport;
import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.TrgStatus;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.Reg;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;

public class TrgDetail {
   public TrgStatus trgs = TrgStatus.Auto;
   public int chlstatus;
   public float htp;
   public int sna = 115;
   public TrgSet[] tss;
   public boolean use = false;
   private static final int[] arrps = new int[6];

   public boolean isSingle() {
      return this.sna == 115;
   }

   public void load(CByteArrayInputStream ba, int mid, int vid) {
      this.use = true;
      int en = ba.nextByte();
      this.trgs = TrgStatus.VALUES[en];
      int chls = this.chlstatus = ba.nextByte();
      int chlnum = Integer.bitCount(chls);
      this.htp = ba.nextFloat();
      this.sna = ba.nextByte();
      AbstractDataImport.logger.fine(String.format("trgs: %s, %d, %f, %s", this.trgs.toString(), chls, this.htp, (char)this.sna));
      if (this.isSingle()) {
         chlnum = 1;
      }

      this.tss = new TrgSet[chlnum];

      for (int i = 0; i < chlnum; i++) {
         TrgSet t = this.tss[i] = new TrgSet();
         t.chlidx = ba.nextByte();
         t.mode = ba.nextByte();
         if (t.hasLevel()) {
            t.level = ba.nextInt();
         }

         AbstractDataImport.logger.fine(t.toString());
         if (ba.nextByte() != 59) {
            System.err.println("ba.nextByte()!=';'");
         }
      }
   }

   public void draw(GraphicContext gx, WaveFormFileCurve wffc, DrawingPanel dp) {
      if (this.use) {
         GC gc = gx.gc;
         Point sz = dp.getSize();
         WaveFormCurve wfc = wffc.getAnyChannelWFC();
         if (wfc != null) {
            Reg reg = wffc.getReg();
            WaveForm wf = wfc.getWaveForm();
            if (!wf.isLowMove()) {
               WaveFormFile wff = wf.getWaveFormFile();
               double div_uS = wf.getPublicM().getTimeBaseValue_mS(wf.getIntTimeBase()) * 1000.0;
               double xgn = wff.getXGraticuleNum();
               int x = (int)((double)(sz.x >> 1) - (double)sz.x / xgn * (double)this.htp / div_uS);
               gc.setBackground(Display.getDefault().getSystemColor(3));
               if (x < 0) {
                  int var18 = 0;
                  setArrPs(var18, 0, var18, 10, var18 + 5, 10);
                  gc.fillPolygon(arrps);
               } else if (x > sz.x) {
                  x = sz.x;
                  setArrPs(x, 0, x, 10, x - 5, 10);
                  gc.fillPolygon(arrps);
               } else {
                  setArrPs(x, 0, x - 5, 10, x + 5, 10);
                  gc.fillPolygon(arrps);
               }

               int len = this.tss.length;

               for (int i = 0; i < len; i++) {
                  TrgSet ts = this.tss[i];
                  if (ts.hasLevel()) {
                     this.drawLevel(wfc, gc, sz, ts.level, ts.chlidx, reg);
                  }
               }
            }
         }
      }
   }

   private static final void setArrPs(int x0, int y0, int x1, int y1, int x2, int y2) {
      int i = 0;
      arrps[i++] = x0;
      arrps[i++] = y0;
      arrps[i++] = x1;
      arrps[i++] = y1;
      arrps[i++] = x2;
      arrps[i++] = y2;
   }

   private void drawLevel(WaveFormCurve wfc, GC gc, Point sz, int level, int chlidx, Reg reg) {
      RGB rgb = reg.getWFReg("CH" + (chlidx + 1)).getRGB();
      Color c = Platform.getPlatform().getColorShop().getColor(rgb);
      ScalableDrawEngine sd = wfc.getScalableDrawEngine();
      double sy = sd.getAbsoluteScaleY();
      double ypp = sd.getPixYPerPoint();
      gc.setBackground(c);
      int y = (int)((double)(sz.y >> 1) - sy * ypp * (double)level);
      int w = sz.x;
      if (y < 0) {
         int var16 = 0;
         setArrPs(w, var16, w - 10, var16, w - 10, var16 + 5);
         gc.fillPolygon(arrps);
      } else if (y > sz.y) {
         y = sz.y;
         setArrPs(w, y, w - 10, y, w - 10, y - 5);
         gc.fillPolygon(arrps);
      } else {
         setArrPs(w, y, w - 10, y + 5, w - 10, y - 5);
         gc.fillPolygon(arrps);
      }
   }
}
