package com.owon.uppersoft.hdoscilloscope.chart.model;

import com.owon.uppersoft.common.logger.LoggerUtil;
import com.owon.uppersoft.hdoscilloscope.chart.AbstWFC;
import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.data.TxtEntry;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.PublicM;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;
import com.owon.uppersoft.hdoscilloscope.util.UnitConversionUtil;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Menu;

public abstract class PrototypeWaveFormCurve extends AbstWFC {
   private static final int[] blockNums = new int[]{2000, 1000, 400, 200, 100, 40, 200, 100, 40, 20, 100, 40, 20, 10};
   public static final Logger logger = LoggerUtil.getFileLogger(PrototypeWaveFormCurve.class.getName(), Level.SEVERE, PropertiesItem.LogDir);
   protected WaveForm wf;
   protected PublicM pm;
   protected WFReg wfreg;
   protected int currentTimeBaseIndex;
   protected int currentVoltageBaseIndex;
   protected double basicTimeBase;
   protected double basicVoltageBase;
   protected int intFullScreenYPointNum;
   protected double dblFullScreenTimeScope;
   protected double dblFullScreenVoltageScope;
   protected double timePerPix;
   protected double voltagePerPix;
   private double xunits;
   private int yunits;
   private Collection<? extends Object> yb_coll;

   public static int getblockNum(int index) {
      return index > blockNums.length ? 10 : blockNums[index];
   }

   public PrototypeWaveFormCurve(WaveForm wf, WaveFormFileCurve fileCurve, WFReg wfreg) {
      super(fileCurve, wfreg);
      this.wfreg = wfreg;
      this.wf = wf;
      this.pm = wf.getPublicM();
      this.extractTimeVolt();
      this.extractTimeVoltScopes(fileCurve);
   }

   @Override
   public WFReg getWFReg() {
      return this.wfreg;
   }

   @Override
   public String getStrChannelType() {
      return this.wf.getStrChannelType();
   }

   @Override
   public int baseIdxOnX() {
      return this.currentTimeBaseIndex;
   }

   @Override
   public int baseIdxOnY() {
      return this.currentVoltageBaseIndex;
   }

   private void extractTimeVolt() {
      this.currentTimeBaseIndex = this.wf.getIntTimeBase();
      this.currentVoltageBaseIndex = this.wf.getIntVoltageBase();
      this.basicTimeBase = this.pm.getTimeBaseValue_mS(this.currentTimeBaseIndex);
      this.basicVoltageBase = PublicM.getchVvValue(this.currentVoltageBaseIndex);
   }

   @Override
   public WaveForm getWaveForm() {
      return this.wf;
   }

   public int getIntFullScreenYPointNum() {
      return this.intFullScreenYPointNum;
   }

   public double getXMajorUnitNum() {
      return this.xunits;
   }

   private void extractTimeVoltScopes(WaveFormFileCurve fileCurve) {
      WaveFormFile wff = this.wf.getWaveFormFile();
      this.xunits = wff.getXGraticuleNum();
      this.yunits = wff.getYGraticuleNum();
      this.intFullScreenYPointNum = this.yunits * wff.getyBlockPixels();
      this.dblFullScreenTimeScope = this.basicTimeBase * this.xunits;
      this.dblFullScreenVoltageScope = this.basicVoltageBase * (double)this.yunits;
      Point size = fileCurve.getDrawingPanel().getSize();
      this.timePerPix = this.dblFullScreenTimeScope / (double)size.x;
      this.voltagePerPix = this.dblFullScreenVoltageScope / (double)size.y;
      this.yb_coll = ((List)PublicM.yb_coll()).subList(0, 10);
      this.initPoints(fileCurve);
      this.setBlockNum(getblockNum(this.currentVoltageBaseIndex));
   }

   protected abstract void initPoints(WaveFormFileCurve var1);

   @Override
   public double valueAtX(double x) {
      ScalableDrawEngine dren = this.getScalableDrawEngine();
      return (x - dren.getZeroXLocation()) * this.timePerPix / dren.getXScale();
   }

   @Override
   public double valueAtY(double y) {
      ScalableDrawEngine dren = this.getScalableDrawEngine();
      return (dren.getZeroYLocation() - y) * this.voltagePerPix / dren.getAbsoluteScaleY();
   }

   @Override
   public Collection<? extends Object> xb_collect() {
      return this.pm.xb_coll();
   }

   @Override
   public Collection<? extends Object> yb_collect() {
      return this.yb_coll;
   }

   @Override
   public String getXBaseTxt() {
      return this.pm.getTimebaseTxt(this.currentTimeBaseIndex);
   }

   @Override
   public String getYBaseTxt() {
      double value = PublicM.getchVvValue(this.currentVoltageBaseIndex) * this.wf.getIntAttenuationMultiple();
      return this.wf.isCurrMeas() ? UnitConversionUtil.getCurrentLabel_ma((double)this.wf.getCurRate() * value) : this.unitForY(value);
   }

   @Override
   public double rateAtY() {
      return this.wf.getRateYAsAttenuation();
   }

   @Override
   public int rateAtX() {
      return 1;
   }

   @Override
   public Collection<TxtEntry> txts_coll() {
      return this.wf.getArgTxts();
   }

   @Override
   public boolean equals(WaveFormCurve iwfc) {
      return this == iwfc;
   }

   @Override
   public String unitForX(double x) {
      return UnitConversionUtil.getTimebaseLabel_mS(x);
   }

   @Override
   public String unitForY(double y) {
      return this.wf.isCurrMeas() ? UnitConversionUtil.getCurrentLabel_ma(y * (double)this.wf.getCurRate()) : UnitConversionUtil.getVoltageLabel_V(y);
   }

   @Override
   public void controlResize(Point lastsize, Point size) {
      this.getScalableDrawEngine().resizeTo(lastsize, size);
      this.timePerPix = this.dblFullScreenTimeScope / (double)size.x;
      this.voltagePerPix = this.dblFullScreenVoltageScope / (double)size.y;
   }

   @Override
   public void setBaseIdxOnY(int index) {
      double voltageBase = PublicM.getchVvValue(index);
      this.currentVoltageBaseIndex = index;
      this.setBlockNum(getblockNum(this.currentVoltageBaseIndex));
      this.getScalableDrawEngine().setAbsoluteScaleY(this.basicVoltageBase / voltageBase);
   }

   @Override
   public void applyToolComposite() {
      Platform.getPlatform().getCenter().getToolCom().applyProtoWFC(this);
   }

   @Override
   public Menu getToolMenu() {
      return Platform.getPlatform().getCenter().applyProtoWFC(this);
   }
}
