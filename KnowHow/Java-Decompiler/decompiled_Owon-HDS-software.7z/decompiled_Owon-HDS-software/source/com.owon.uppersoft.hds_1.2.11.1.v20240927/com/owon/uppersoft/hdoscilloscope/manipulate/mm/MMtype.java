package com.owon.uppersoft.hdoscilloscope.manipulate.mm;

import java.nio.ByteBuffer;

public class MMtype {
   public int type;
   public int set;
   public boolean abson;
   public boolean autoon;

   public MMtype(int t) {
      this.type = t;
   }

   public void pack(ByteBuffer bb) {
      bb.put(":EE".getBytes());
      bb.put((byte)this.type);
      bb.put((byte)this.set);
      bb.put((byte)(this.abson ? 1 : 0));
      bb.put((byte)(this.autoon ? 1 : 0));
      this.packself(bb);
      bb.put((byte)35);
   }

   protected void packself(ByteBuffer bb) {
   }

   public String[] getSets() {
      return new String[0];
   }
}
