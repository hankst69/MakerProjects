package com.owon.uppersoft.hdoscilloscope.chart;

import com.owon.uppersoft.common.aspect.Disposable;
import com.owon.uppersoft.common.utils.DisposeUtil;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.IPublicM;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

public class BackgroundDraw implements ContextDrawable, Disposable {
   private double xGraticuleNum = 15.2;
   private int yGraticuleNum = 10;
   private int minorGraticulesInMajor = 5;
   private int majorGraticuleLength = 4;
   private int minorGraticuleLength = 2;
   private Color gridColor;
   private Color bgColor;
   private boolean dottedGraticuleVisible = false;
   private boolean centerCrossVisible = true;
   private final int[] dashLines = IPublicM.DefaultDashLines;
   private int bgWidth;
   private int bgHeight;
   private int minX;
   private int minY;
   private int maxX;
   private int maxY;
   private int centerX;
   private int centerY;
   private DrawingPanel dp;
   private Image bgimg;
   private boolean isBGDraw = true;

   public BackgroundDraw(DrawingPanel dp) {
      Display display = dp.getComposite().getDisplay();
      Configuration cfg = Platform.getPlatform().getConfiguration();
      this.gridColor = new Color(display, cfg.gridrgb);
      this.bgColor = new Color(display, cfg.bgrgb);
      this.dp = dp;
      Rectangle r = display.getBounds();
      this.bgimg = new Image(display, r.width, r.height);
      this.updateBound(dp.getSize());
   }

   public void updateBound(Point size) {
      int bw = size.x;
      int bh = size.y;
      if (bw > 0 && bh > 0) {
         this.bgWidth = bw;
         this.bgHeight = bh;
         this.minX = 0;
         this.minY = 0;
         this.maxX = this.bgWidth - 1;
         this.maxY = this.bgHeight - 1;
         this.centerX = size.x >> 1;
         this.centerY = size.y >> 1;
      } else {
         this.bgWidth = bw;
         this.bgHeight = bh;
      }
   }

   public void setGridRGB(RGB rgb) {
      if (rgb != null) {
         DisposeUtil.tryDispose(this.gridColor);
         this.gridColor = new Color(this.dp.getComposite().getDisplay(), rgb);
      }
   }

   public RGB getGridRGB() {
      return this.gridColor.getRGB();
   }

   public void setGraticuleNum(double xvalue, int yvalue) {
      this.xGraticuleNum = xvalue;
      this.yGraticuleNum = yvalue;
   }

   public void setDottedGraticuleVisible(boolean dottedGraticulevisible) {
      this.dottedGraticuleVisible = dottedGraticulevisible;
   }

   public boolean isDottedGraticuleVisible() {
      return this.dottedGraticuleVisible;
   }

   public void updateBgImg() {
      GC gc = new GC(this.bgimg);
      this.drawMainField(gc);
      this.drawBasicGraticule(gc);
      gc.setLineStyle(1);
      this.dp.delegateDraw(gc);
      gc.dispose();
   }

   @Override
   public void draw(GraphicContext gx) {
      GC gc = gx.gc;
      if (this.bgimg != null) {
         gc.drawImage(this.bgimg, 0, 0, this.bgWidth, this.bgHeight, 0, 0, this.bgWidth, this.bgHeight);
      }
   }

   public boolean isBGDraw() {
      return this.isBGDraw;
   }

   public void setBGDraw(boolean isBGDraw) {
      this.isBGDraw = isBGDraw;
   }

   private void drawMainField(GC gc) {
      if (this.isBGDraw) {
         gc.setBackground(this.bgColor);
         gc.fillRectangle(this.minX, this.minY, this.maxX, this.maxY);
      }

      gc.setForeground(this.gridColor);
      gc.drawRectangle(this.minX, this.minY, this.maxX, this.maxY);
   }

   private void drawBasicGraticule(GC gc) {
      gc.setForeground(this.gridColor);
      double uxn = this.xGraticuleNum * (double)this.minorGraticulesInMajor;
      double unitXinterval = (double)this.bgWidth / uxn;
      double x0 = 0.0;
      double x1 = 0.0;
      int[] ld = gc.getLineDash();
      x0 = (double)this.centerX;
      x1 = (double)this.centerX;
      if (this.centerCrossVisible) {
         gc.drawLine(this.centerX, this.minY, this.centerX, this.maxY);
      }

      int len = (int)Math.floor(uxn / 2.0);

      for (int i = 1; i <= len; i++) {
         int xL = (int)(x0 -= unitXinterval);
         int xR = (int)(x1 += unitXinterval);
         int graticuleLength;
         if (i % this.minorGraticulesInMajor == 0) {
            graticuleLength = this.majorGraticuleLength;
            if (this.dottedGraticuleVisible) {
               gc.setLineDash(this.dashLines);
               gc.drawLine(xL, this.minY, xL, this.maxY);
               gc.drawLine(xR, this.minY, xR, this.maxY);
               gc.setLineDash(ld);
            }
         } else {
            graticuleLength = this.minorGraticuleLength;
         }

         int tmp1 = this.minY + graticuleLength;
         int tmp2 = this.centerY - graticuleLength;
         int tmp3 = this.centerY + graticuleLength;
         gc.drawLine(xL, this.minY, xL, tmp1);
         gc.drawLine(xR, this.minY, xR, tmp1);
         gc.drawLine(xL, tmp2, xL, tmp3);
         gc.drawLine(xR, tmp2, xR, tmp3);
         tmp3 = this.maxY - graticuleLength;
         gc.drawLine(xL, this.maxY, xL, tmp3);
         gc.drawLine(xR, this.maxY, xR, tmp3);
      }

      double y0 = (double)this.centerY;
      double y1 = (double)this.centerY;
      if (this.centerCrossVisible) {
         gc.drawLine(this.minX, this.centerY, this.maxX, this.centerY);
      }

      int unitYnum = this.yGraticuleNum * this.minorGraticulesInMajor;
      double unitYinterval = (double)this.bgHeight / (double)unitYnum;
      len = unitYnum >> 1;

      for (int i = 1; i <= len; i++) {
         int yL = (int)(y0 -= unitYinterval);
         int yR = (int)(y1 += unitYinterval);
         int graticuleLength;
         if (i % this.minorGraticulesInMajor == 0) {
            graticuleLength = this.majorGraticuleLength;
            if (this.dottedGraticuleVisible) {
               gc.setLineDash(this.dashLines);
               gc.drawLine(this.minX, yL, this.maxX, yL);
               gc.drawLine(this.minX, yR, this.maxX, yR);
               gc.setLineDash(ld);
            }
         } else {
            graticuleLength = this.minorGraticuleLength;
         }

         int tmp1 = this.minX + graticuleLength;
         int tmp2 = this.centerX - graticuleLength;
         int tmp3 = this.centerX + graticuleLength;
         gc.drawLine(this.minX, yL, tmp1, yL);
         gc.drawLine(this.minX, yR, tmp1, yR);
         gc.drawLine(tmp2, yL, tmp3, yL);
         gc.drawLine(tmp2, yR, tmp3, yR);
         tmp3 = this.maxX - graticuleLength;
         gc.drawLine(this.maxX, yL, tmp3, yL);
         gc.drawLine(this.maxX, yR, tmp3, yR);
      }
   }

   public void dispose() {
      DisposeUtil.tryDispose(this.gridColor);
      DisposeUtil.tryDispose(this.bgColor);
      DisposeUtil.tryDispose(this.bgimg);
   }

   public void setBackgroundRGB(RGB rgb) {
      DisposeUtil.tryDispose(this.bgColor);
      this.bgColor = new Color(this.dp.getComposite().getDisplay(), rgb);
   }

   public RGB getBackgroundRGB() {
      return this.bgColor.getRGB();
   }

   public Color getBackground() {
      return this.bgColor;
   }
}
