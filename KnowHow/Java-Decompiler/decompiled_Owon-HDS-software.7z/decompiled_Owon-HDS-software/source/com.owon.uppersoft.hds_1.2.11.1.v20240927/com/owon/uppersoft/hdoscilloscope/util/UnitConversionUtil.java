package com.owon.uppersoft.hdoscilloscope.util;

public class UnitConversionUtil {
   public static final String getTextFor_uS(double value) {
      if (value < 0.001 && value > -0.001) {
         double var5 = value * 1000.0;
         return String.format("%.3f nS", var5);
      } else if (value < 1000.0 && value > -1000.0) {
         return String.format("%.3f uS", value);
      } else {
         double v = value / 1000.0;
         double var4;
         return v < 1000.0 && v > -1000.0 ? String.format("%.3f mS", v) : String.format("%.3f S", var4 = v / 1000.0);
      }
   }

   public static final String getTimebaseLabel_mS(double value) {
      if (value >= 1000.0 || value <= -1000.0) {
         return String.format("%.3f S", value / 1000.0);
      } else if (!(value >= 1.0) && !(value <= -1.0)) {
         double v = value * 1000.0;
         return !(v >= 1.0) && !(v <= -1.0) ? String.format("%.3f nS", v * 1000.0) : String.format("%.3f uS", v);
      } else {
         return String.format("%.3f mS", value);
      }
   }

   public static final String getVoltageLabel_mV(double value) {
      return !(value >= 1000.0) && !(value <= -1000.0) ? String.format("%.3f mV", value) : String.format("%.3f V", value / 1000.0);
   }

   public static final String getVoltageLabel_V(double value) {
      if (value >= 1000.0 || value <= -1000.0) {
         return format(value / 1000.0) + "kV";
      } else if (!(value >= 1.0) && !(value <= -1.0)) {
         double v = value * 1000.0;
         if (!(v >= 1.0) && !(v <= -1.0)) {
            v *= 1000.0;
            return format(v) + "uV";
         } else {
            return format(v) + "mV";
         }
      } else {
         return format(value) + "V";
      }
   }

   public static final String getFrequencyLabel_Hz(double value) {
      if (value > -2.0 && value < 2.0) {
         return String.format("< 2Hz", value);
      } else if (value > -1000.0 && value < 1000.0) {
         return String.format("%.3f Hz", value);
      } else {
         double v = value / 1000.0;
         if (v > -1000.0 && v < 1000.0) {
            return String.format("%.3f kHz", v);
         } else {
            v /= 1000.0;
            if (v > -1000.0 && v < 1000.0) {
               return String.format("%.3f MHz", v);
            } else {
               v /= 1000.0;
               return String.format("%.3f GHz", v);
            }
         }
      }
   }

   public static final String getCurrentLabel_ma(double value) {
      if (value >= 1000.0 || value <= -1000.0) {
         return format(value / 1000.0) + "A";
      } else {
         return value < 1.0 && value > -1.0 ? format(value * 1000.0) + "uA" : format(value) + "mA";
      }
   }

   public static final String getBytesNumber(int number) {
      if (number < 0) {
         return "?";
      } else {
         int oneK = 1024;
         return number < oneK ? number + "B" : (number >> 10) + "kB";
      }
   }

   public static final String getPercent(int v, int l) {
      return v >= l ? "100%" : String.format("%d%%", v * 100 / l);
   }

   public static void main(String[] args) {
      System.out.println();
   }

   public static final String format(double d) {
      double d1 = Math.abs(d);
      if (d1 < 1.0) {
         return String.format("%.3f", d);
      } else if (d1 < 10.0) {
         return String.format("%.2f", d);
      } else if (d1 < 100.0) {
         return String.format("%.1f", d);
      } else {
         return d1 < 1000.0 ? String.format("%.0f", d) : String.valueOf(d);
      }
   }
}
