package com.owon.uppersoft.hdoscilloscope.chart;

import org.eclipse.swt.graphics.Point;

public interface ScalableDrawEngine extends ContextDrawable {
   double getZeroYLocation();

   void setZeroYLocation(double var1);

   void setZeroXoffset(double var1);

   double getZeroXLocation();

   boolean isPointSelected(Point var1);

   void resizeTo(Point var1, Point var2);

   void setInverted(boolean var1);

   double getAbsoluteScaleY();

   void setXScale(double var1);

   double getXScale();

   void setAbsoluteScaleY(double var1);

   Point getSize();

   double getPixYPerPoint();
}
