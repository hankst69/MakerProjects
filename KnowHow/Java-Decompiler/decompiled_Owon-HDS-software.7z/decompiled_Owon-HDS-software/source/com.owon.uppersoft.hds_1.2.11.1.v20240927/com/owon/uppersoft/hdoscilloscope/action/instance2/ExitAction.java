package com.owon.uppersoft.hdoscilloscope.action.instance2;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class ExitAction extends DefaultAction {
   public ExitAction(String id) {
      super(id);
   }

   public void run() {
      Platform.getPlatform().getShell().close();
   }
}
