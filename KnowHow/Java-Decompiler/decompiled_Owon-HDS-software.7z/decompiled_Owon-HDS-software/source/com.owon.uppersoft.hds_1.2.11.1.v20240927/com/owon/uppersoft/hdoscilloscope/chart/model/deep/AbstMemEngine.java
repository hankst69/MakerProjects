package com.owon.uppersoft.hdoscilloscope.chart.model.deep;

import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;
import org.eclipse.swt.graphics.Point;

public abstract class AbstMemEngine implements ScalableDrawEngine {
   protected DrawingPanel dp;
   protected WFReg wfreg;
   protected MemdepthWaveFormCurve curve;
   protected CByteArrayInputStream ba;

   public AbstMemEngine(DrawingPanel dp, MemdepthWaveFormCurve curve) {
      this.dp = dp;
      this.curve = curve;
      this.ba = dp.getWaveFormFileCurve().getWaveFormFile().getba();
      this.wfreg = curve.getWFReg();
   }

   @Override
   public Point getSize() {
      return this.dp.getSize();
   }

   @Override
   public double getAbsoluteScaleY() {
      return this.curve.absoluteScaleY;
   }

   @Override
   public double getPixYPerPoint() {
      return this.curve.ypp;
   }

   @Override
   public double getXScale() {
      return this.curve.xscale;
   }

   @Override
   public double getZeroXLocation() {
      return this.curve.x0;
   }

   @Override
   public double getZeroYLocation() {
      return this.curve.y0;
   }

   @Override
   public void setAbsoluteScaleY(double absoluteScaleY) {
      this.curve.absoluteScaleY = absoluteScaleY;
   }

   @Override
   public void setXScale(double xscale) {
      Point p = this.getSize();
      double halfBoundWidth = (double)p.x / 2.0;
      this.curve.x0 = halfBoundWidth - (halfBoundWidth - this.curve.x0) / this.curve.lastScale * xscale;
   }

   @Override
   public void setZeroXoffset(double x) {
      this.curve.x0 += x;
   }

   @Override
   public void setZeroYLocation(double y) {
      this.curve.y0 = y;
   }

   public MemdepthWaveFormCurve getMemdepthWaveFormCurve() {
      return this.curve;
   }
}
