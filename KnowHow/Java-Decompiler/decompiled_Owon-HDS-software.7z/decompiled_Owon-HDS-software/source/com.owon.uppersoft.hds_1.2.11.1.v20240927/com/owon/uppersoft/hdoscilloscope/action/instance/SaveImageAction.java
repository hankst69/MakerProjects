package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.common.utils.DisposeUtil;
import com.owon.uppersoft.common.utils.ImageSaver;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.util.ResourceBundle;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

public class SaveImageAction extends DefaultAction {
   public SaveImageAction(String id) {
      super(id);
   }

   public void run() {
      this.doSaveImage();
   }

   public void save() {
      Platform pf = Platform.getPlatform();

      try {
         Rectangle rec = pf.getMainFrame().getShell().getBounds();
         int h = rec.height;
         int w = rec.width;
         int x = rec.x;
         int y = rec.y;
         Robot robot = new Robot();
         BufferedImage image = robot.createScreenCapture(new java.awt.Rectangle(x, y, w, h));
         ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
         String infoDefault = bundle.getString("Info.Default");
         String prompt = bundle.getString("Info.ImageSaved");
         ImageSaver.doSave(pf.getShell(), image, infoDefault, prompt);
      } catch (AWTException var12) {
         var12.printStackTrace();
      }
   }

   public void doSaveImage() {
      Platform pf = Platform.getPlatform();
      DrawingPanel dp = pf.getCenter().getDrawingPanel();
      Point size = dp.getSize();
      Image image = new Image(pf.getDisplay(), size.x, size.y);
      GC gc = new GC(image);
      dp.drawingPic(gc);
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      String infoDefault = bundle.getString("Info.Default");
      String prompt = bundle.getString("Info.ImageSaved");
      ImageSaver.doSave(pf.getShell(), image, infoDefault, prompt);
      DisposeUtil.tryDispose(image);
   }
}
