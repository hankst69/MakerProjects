package com.owon.uppersoft.hdoscilloscope.data;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.graphics.Image;

public class ItemLabelProvider implements ITableLabelProvider {
   private TableViewer viewer;

   public ItemLabelProvider(TableViewer viewer) {
      this.viewer = viewer;
   }

   public Image getColumnImage(Object element, int columnIndex) {
      return null;
   }

   public String getColumnText(Object element, int columnIndex) {
      WaveForm wf = (WaveForm)this.viewer.getTable().getColumn(columnIndex).getData();
      ItemModel mm = (ItemModel)element;
      if (wf == null) {
         return String.valueOf(mm.i + 1);
      } else {
         double v = wf.voltAt(mm.i);
         return String.format("%.3f", v);
      }
   }

   public void addListener(ILabelProviderListener listener) {
   }

   public void dispose() {
   }

   public boolean isLabelProperty(Object element, String property) {
      return false;
   }

   public void removeListener(ILabelProviderListener listener) {
   }
}
