package com.owon.uppersoft.hdoscilloscope.chart.model.fft.mathD;

import com.owon.uppersoft.hdoscilloscope.chart.model.fft.math.IComplex;

public class ComplexD implements IComplex {
   public double re;
   public double im;

   public ComplexD() {
   }

   public ComplexD(double real, double imag) {
      this.re = real;
      this.im = imag;
   }

   @Override
   public String toString() {
      if (this.im == 0.0) {
         return String.valueOf(this.re);
      } else if (this.re == 0.0) {
         return this.im + "i";
      } else {
         return this.im < 0.0 ? this.re + " - " + -this.im + "i" : this.re + " + " + this.im + "i";
      }
   }

   public double abs() {
      return Math.hypot(this.re, this.im);
   }

   public double phase() {
      return Math.atan2(this.im, this.re);
   }

   public ComplexD plus(ComplexD b) {
      double real = this.re + b.re;
      double imag = this.im + b.im;
      return new ComplexD(real, imag);
   }

   public ComplexD minus(ComplexD b) {
      double real = this.re - b.re;
      double imag = this.im - b.im;
      return new ComplexD(real, imag);
   }

   public ComplexD times(ComplexD b) {
      double real = this.re * b.re - this.im * b.im;
      double imag = this.re * b.im + this.im * b.re;
      return new ComplexD(real, imag);
   }

   public ComplexD times(double alpha) {
      return new ComplexD(alpha * this.re, alpha * this.im);
   }

   public ComplexD conjugate() {
      return new ComplexD(this.re, -this.im);
   }

   public ComplexD reciprocal() {
      double scale = this.re * this.re + this.im * this.im;
      return new ComplexD(this.re / scale, -this.im / scale);
   }

   @Override
   public double re() {
      return this.re;
   }

   @Override
   public double im() {
      return this.im;
   }

   public ComplexD divides(ComplexD b) {
      return this.times(b.reciprocal());
   }

   public ComplexD exp() {
      return new ComplexD(Math.exp(this.re) * Math.cos(this.im), Math.exp(this.re) * Math.sin(this.im));
   }

   public ComplexD sin() {
      return new ComplexD(Math.sin(this.re) * Math.cosh(this.im), Math.cos(this.re) * Math.sinh(this.im));
   }

   public ComplexD cos() {
      return new ComplexD(Math.cos(this.re) * Math.cosh(this.im), -Math.sin(this.re) * Math.sinh(this.im));
   }

   public ComplexD tan() {
      return this.sin().divides(this.cos());
   }

   public static ComplexD plus(ComplexD a, ComplexD b) {
      double real = a.re + b.re;
      double imag = a.im + b.im;
      return new ComplexD(real, imag);
   }

   public static void main(String[] args) {
      ComplexD a = new ComplexD();
      ComplexD b = new ComplexD(-3.0, 4.0);
      System.out.println("a            = " + a);
      System.out.println("b            = " + b);
      System.out.println("Re(a)        = " + a.re());
      System.out.println("Im(a)        = " + a.im());
      System.out.println("b + a        = " + b.plus(a));
      System.out.println("a - b        = " + a.minus(b));
      System.out.println("a * b        = " + a.times(b));
      System.out.println("b * a        = " + b.times(a));
      System.out.println("a / b        = " + a.divides(b));
      System.out.println("(a / b) * b  = " + a.divides(b).times(b));
      System.out.println("conj(a)      = " + a.conjugate());
      System.out.println("|a|          = " + a.abs());
      System.out.println("tan(a)       = " + a.tan());
   }
}
