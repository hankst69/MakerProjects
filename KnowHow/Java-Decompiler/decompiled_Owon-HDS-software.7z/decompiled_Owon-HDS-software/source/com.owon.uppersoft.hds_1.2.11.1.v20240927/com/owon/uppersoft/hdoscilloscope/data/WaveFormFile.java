package com.owon.uppersoft.hdoscilloscope.data;

import com.owon.uppersoft.common.utils.StringPool;
import com.owon.uppersoft.hdoscilloscope.data.math.MathWF;
import com.owon.uppersoft.hdoscilloscope.data.normal.DefaultWF;
import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import com.owon.uppersoft.hdoscilloscope.model.MachineType;
import com.owon.uppersoft.hdoscilloscope.model.PublicM;
import com.owon.uppersoft.hdoscilloscope.model.detail.Idn;
import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import net.sf.json.JSONObject;

public abstract class WaveFormFile {
   public static final int HeaderLength = 6;
   public static final String StrFileExtension = "bin";
   public String sn;
   private Idn idn;
   private MachineType mt;
   private int intFileSize;
   private File orginalFile;
   private boolean raw = false;
   private List<WaveForm> waveForms;
   private PublicM pm;
   public MultiMeter mm = null;
   private boolean _1size2;
   private boolean _1DepMem2;
   public boolean comeFromTDMachine = false;
   private CByteArrayInputStream ba;
   private JSONObject head;
   private Map<String, byte[]> data = new HashMap<>();

   public abstract void confirmPublicM();

   public WaveForm createWaveForm(String source) {
      WaveForm wf;
      if (source.equalsIgnoreCase("math")) {
         wf = new MathWF(this);
      } else if (source.equalsIgnoreCase("fft")) {
         wf = new DefaultWF(this);
      } else {
         wf = new DefaultWF(this);
      }

      this.wfFullScreenNum(0, wf);
      return wf;
   }

   public abstract double getXGraticuleNum();

   public int getYGraticuleNum() {
      return this.mt.getyGraticuleNum();
   }

   public abstract int getYPointNum();

   public abstract int getXPointNum();

   public int getXBlockPixels() {
      return this.mt.getxBlockPixels();
   }

   public int getyBlockPixels() {
      return this.mt.getyBlockPixels();
   }

   public abstract void wfFullScreenNum(int var1, WaveForm var2);

   public IDataOutput getDataOutput() {
      return new DefaultDataOutput();
   }

   public boolean isRaw() {
      return this.raw;
   }

   public void setRaw(boolean raw) {
      this.raw = raw;
   }

   public File getOrginalFile() {
      return this.orginalFile;
   }

   public void setOrginalFile(File orginalFile) {
      this.orginalFile = orginalFile;
   }

   public WaveFormFile() {
      this.waveForms = new LinkedList<>();
      this.pm = new PublicM();
   }

   public boolean is1size2() {
      return this._1size2;
   }

   public boolean is1DepMem2() {
      return this._1DepMem2;
   }

   public boolean isMathAvailable() {
      return this.is1size2();
   }

   public void endFileCreate() {
      WaveForm wf1 = this.getWaveForm("CH1");
      WaveForm wf2 = this.getWaveForm("CH2");
      if (wf1 != null && wf2 != null) {
         this._1size2 = wf1.getIntADCollectionNum() == wf2.getIntADCollectionNum();
         this._1DepMem2 = wf1.isDepMem() && wf2.isDepMem();
      } else {
         this._1size2 = false;
      }
   }

   public Collection<WaveForm> wf_collect() {
      return this.waveForms;
   }

   public int getWaveFormsNumber() {
      return this.waveForms.size();
   }

   public void setIntFileSize(int intFileSize) {
      this.intFileSize = intFileSize;
   }

   public int getIntFileSize() {
      return this.intFileSize;
   }

   public MachineType getMt() {
      return this.mt;
   }

   public void setMt(MachineType mt) {
      this.mt = mt;
   }

   public void addWaveForm(WaveForm waveform) {
      this.waveForms.add(waveform);
   }

   public WaveForm getWaveForm(String strChannelType) {
      for (WaveForm waveForm : this.waveForms) {
         if (waveForm.getStrChannelType().equalsIgnoreCase(strChannelType)) {
            return waveForm;
         }
      }

      return null;
   }

   public PublicM getPublicM() {
      return this.pm;
   }

   protected final void confirmPublicMWithGraticuleNum(int pixelsPerBlock) {
      this.pm.setValue(this.mt.getIdn(), this.comeFromTDMachine, pixelsPerBlock);
   }

   public void setba(CByteArrayInputStream ba) {
      this.ba = ba;
   }

   public CByteArrayInputStream getba() {
      return this.ba;
   }

   public boolean containMemDepth() {
      return this.ba != null;
   }

   public void releaseBA() {
      if (this.ba != null) {
         this.ba.dispose();
      }
   }

   @Override
   public String toString() {
      String ln = StringPool.LINE_SEPARATOR;
      StringBuilder info = new StringBuilder();
      info.append("strFileHead: " + this.idn.getModel() + ln);
      info.append("intFileSize: " + this.intFileSize + ln);
      return info.toString();
   }

   public void doWFArgAdd() {
      if (this.mm != null) {
         String n = this.mm.type() + ": " + this.mm.info();

         for (WaveForm wf : this.waveForms) {
            wf.addArg("Center.mul", n);
         }
      }
   }

   public void setHead(JSONObject head) {
      this.head = head;
   }

   public JSONObject getHead() {
      return this.head;
   }

   public void addWaveForm(String name, byte[] b) {
      this.data.put(name, b);
   }

   public int getChannleLen() {
      return this.head.getJSONArray("channel").size();
   }

   public String getDataType() {
      return this.head.optString("datatype", "external");
   }

   public Idn getIdn() {
      return this.idn;
   }
}
