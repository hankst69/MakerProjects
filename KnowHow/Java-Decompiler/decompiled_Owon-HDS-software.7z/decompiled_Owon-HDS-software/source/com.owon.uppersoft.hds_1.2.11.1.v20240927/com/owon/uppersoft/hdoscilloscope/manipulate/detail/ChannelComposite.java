package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.control.ChannelControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.control.ChannelInfo;
import java.text.DecimalFormat;
import java.util.List;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

public class ChannelComposite extends Composite implements SelectionListener, Localizable2 {
   private Combo probecb;
   private ChannelControl cc;
   private ManipulateControl mc;
   private boolean use = false;
   private String[] VOLTS;
   private int pos0;
   public Spinner pos0spin;
   public Button signbtn;
   private Button onbtn;
   private Combo vbcbb;
   private Combo chlcplcbb;
   private Button reversebtn;
   private Label pos0lbl;
   private ChannelInfo ci;
   private Label vblbl;
   private Label cpllbl;
   private Label probelbl;
   private Label pos0lblback;

   public ChannelComposite(Composite parent, ChannelControl cc, ManipulateControl mc) {
      super(parent, 2048);
      this.cc = cc;
      this.mc = mc;
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 7;
      this.setLayout(gridLayout);
      this.onbtn = new Button(this, 32);
      if (mc.mt.getChLen() == 1) {
         this.onbtn.setVisible(false);
      }

      this.probelbl = new Label(this, 0);
      this.probelbl.setLayoutData(new GridData(80, -1));
      this.probecb = new Combo(this, 8);
      this.probecb.setItems(ManipulateControl.PROBES);
      this.probecb.select(0);
      this.cpllbl = new Label(this, 131072);
      GridData gd_cpllbl = new GridData(131072, 16777216, false, false, 2, 1);
      gd_cpllbl.widthHint = 70;
      this.cpllbl.setLayoutData(gd_cpllbl);
      this.chlcplcbb = new Combo(this, 8);
      this.reversebtn = new Button(this, 32);
      this.reversebtn.setLayoutData(new GridData(16384, 16777216, true, false));
      this.reversebtn.setVisible(false);
      this.vblbl = new Label(this, 0);
      this.vblbl.setLayoutData(new GridData(80, -1));
      this.vbcbb = new Combo(this, 8);
      this.pos0lbl = new Label(this, 131072);
      GridData gd_pos0lbl = new GridData(16384, 16777216, false, false);
      gd_pos0lbl.widthHint = 60;
      this.pos0lbl.setLayoutData(gd_pos0lbl);
      this.signbtn = new Button(this, 2);
      GridData gd_signbtn = new GridData(131072, 16777216, false, false);
      gd_signbtn.widthHint = 25;
      this.signbtn.setLayoutData(gd_signbtn);
      this.signbtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ChannelComposite.this.signbtn.setText(ChannelComposite.this.signbtn.getSelection() ? "+" : "-");
            int v = ChannelComposite.this.ci.pos0 = ChannelComposite.this.getPos0Value();
            ChannelComposite.this.updatePos0Label(v);
         }
      });
      this.signbtn.setText(this.signbtn.getSelection() ? "+" : "-");
      this.pos0spin = new Spinner(this, 2048);
      this.pos0spin.setLayoutData(new GridData(40, -1));
      this.pos0spin.setMinimum(0);
      this.pos0spin.setMaximum(250);
      this.pos0spin.setSelection(50);
      this.pos0lblback = new Label(this, 0);
      this.pos0lblback.setLayoutData(new GridData(4, 16777216, false, false));
      new Label(this, 0);
      this.custom();
      this.use = true;
   }

   private int getPos0Value() {
      boolean s = this.signbtn.getSelection();
      int v = this.pos0spin.getSelection();
      return s ? v : -v;
   }

   private void updatePos0Label(int v) {
      this.pos0lblback.setText(String.format("/%d = %.2f div", this.mc.pixelsPerBlock, (double)v / (double)this.mc.pixelsPerBlock));
   }

   public void load(int i) {
      this.use = false;
      this.ci = this.cc.cis[i];
      this.onbtn.setSelection(this.ci.on);
      this.reversebtn.setSelection(this.ci.reverse);
      this.chlcplcbb.select(this.ci.coupling);
      this.vbcbb.select(this.ci.vbidx);
      this.probecb.select(this.ci.probe);
      int l = this.ci.pos0;
      boolean b = l >= 0;
      this.signbtn.setSelection(b);
      this.signbtn.setText(b ? "+" : "-");
      this.pos0spin.setSelection(b ? l : -l);
      this.updatePos0Label(l);
      this.use = true;
   }

   private void custom() {
      int offset = 0;
      List l = this.mc.mt.getYbaseList().subList(offset, offset + 10);
      this.VOLTS = ManipulateControl.toStrings(l);
      this.vbcbb.setItems(this.VOLTS);
      this.chlcplcbb.setItems(ManipulateControl.CHANNELSCOUPLING);
      this.chlcplcbb.addSelectionListener(this);
      this.vbcbb.addSelectionListener(this);
      this.reversebtn.addSelectionListener(this);
      this.onbtn.addSelectionListener(this);
      this.probecb.addSelectionListener(this);
      this.pos0spin.addSelectionListener(this);
   }

   public void localize(ResourceBundle rb) {
      this.pos0lbl.setText(rb.getString("Action.pos0") + ":");
      this.reversebtn.setText(rb.getString("M.Channel.reverse"));
      this.onbtn.setText(rb.getString("M.Channel.on"));
      this.vblbl.setText(rb.getString("M.Channel.vb") + ":");
      this.probelbl.setText(rb.getString("M.Channel.probe") + ":");
      this.cpllbl.setText(rb.getString("M.Channel.coupling") + ":");
   }

   public void widgetDefaultSelected(SelectionEvent e) {
   }

   public void widgetSelected(SelectionEvent e) {
      Object o = e.getSource();
      if (o == this.chlcplcbb) {
         this.ci.coupling = this.chlcplcbb.getSelectionIndex();
         String cmd = ":" + ManipulateControl.CHANNELS[this.ci.number] + ":COUPling " + ManipulateControl.CHANNELSCOUPLING[this.ci.coupling];
         this.mc.send(cmd);
      } else if (o == this.vbcbb) {
         this.ci.vbidx = this.vbcbb.getSelectionIndex();
         String cmd = ":" + ManipulateControl.CHANNELS[this.ci.number] + ":Scale " + this.VOLTS[this.ci.vbidx];
         this.mc.send(cmd);
      } else if (o == this.reversebtn) {
         this.ci.reverse = this.reversebtn.getSelection();
         String cmd = ":" + ManipulateControl.CHANNELS[this.ci.number] + ":INVERSE " + (this.ci.reverse ? "on" : "off");
         this.mc.send(cmd);
      } else if (o == this.onbtn) {
         this.ci.on = this.onbtn.getSelection();
         String cmd = ":" + ManipulateControl.CHANNELS[this.ci.number] + ":DISPlay " + (this.ci.on ? "on" : "off");
         this.mc.send(cmd);
      } else if (o == this.probecb) {
         this.ci.probe = this.probecb.getSelectionIndex();
         int offset = 0 + 3 * this.ci.probe;
         List l = this.mc.mt.getYbaseList().subList(offset, offset + 10);
         this.VOLTS = ManipulateControl.toStrings(l);
         int index = this.vbcbb.getSelectionIndex();
         this.vbcbb.setItems(this.VOLTS);
         this.vbcbb.select(index);
         String cmd = ":" + ManipulateControl.CHANNELS[this.ci.number] + ":PROBe " + ManipulateControl.PROBES[this.ci.probe];
         this.mc.send(cmd);
      } else if (o == this.pos0spin) {
         int v = this.ci.pos0 = this.getPos0Value();
         this.updatePos0Label(v);
         DecimalFormat df = new DecimalFormat("#0.##");
         String g = df.format((double)v / (double)this.mc.pixelsPerBlock);
         String cmd = ":" + ManipulateControl.CHANNELS[this.ci.number] + ":OFFSET " + g;
         this.mc.send(cmd);
      }
   }

   public void storeFromUI() {
      this.pos0 = this.pos0spin.getSelection();
      this.pos0 = this.signbtn.getSelection() ? this.pos0 : -this.pos0;
   }

   public void setSign(boolean b) {
      this.signbtn.setSelection(b);
      this.signbtn.setText(b ? "+" : "-");
   }
}
