package com.owon.uppersoft.hdoscilloscope.chart.model.fft;

import com.owon.uppersoft.hdoscilloscope.chart.DrawEngine;
import com.owon.uppersoft.hdoscilloscope.data.TxtEntry;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.model.Dbl_Txt;
import com.owon.uppersoft.hdoscilloscope.model.PublicM;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.util.UnitConversionUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.eclipse.swt.graphics.Point;

public class DbFFTDrawCompute implements IFFTCompute {
   public static List<Dbl_Txt> dBbasesTxt = new ArrayList<>(5);
   private WaveForm wf;
   private int[] data;
   private DrawEngine dren;
   private int dataLength;
   private double zeroY;
   private int[] oadc;
   private PublicM pm;
   private FFTInfo fi;
   private FFTWaveFormCurve fw;
   private int posOffset = 0;
   private double timeScope;
   private double dbScope;
   private double xbase;
   private double ybase;
   private double timePerPix;
   private double dbPerPix;
   private double xpp;
   private double ypp;
   private int xbaseidx;
   private int ybaseidx;

   static {
      Dbl_Txt.addDbl_Txt(dBbasesTxt, "20db", 20.0);
      Dbl_Txt.addDbl_Txt(dBbasesTxt, "10db", 10.0);
      Dbl_Txt.addDbl_Txt(dBbasesTxt, "5db", 5.0);
      Dbl_Txt.addDbl_Txt(dBbasesTxt, "2db", 2.0);
      Dbl_Txt.addDbl_Txt(dBbasesTxt, "1db", 1.0);
   }

   public DbFFTDrawCompute(FFTWaveFormCurve fw, DrawEngine dren, WaveForm wf, int length, int[] oadc) {
      this.fw = fw;
      this.dren = dren;
      this.wf = wf;
      this.pm = wf.getPublicM();
      this.fi = wf.getFFTInfo();
      this.dataLength = length;
      this.oadc = oadc;
      this.data = new int[this.dataLength >> 1];
   }

   @Override
   public void controlResize(Point lastsize, Point size) {
      this.updateValueRate(size);
   }

   @Override
   public void updateWndType() {
      this.windowing();
      this.computeDren();
   }

   @Override
   public void resumeToMode() {
      Point size = this.dren.getSize();
      this.resetXYScope();
      this.resize(size);
      this.updateValueRate(size);
      this.windowing();
      this.computeDren();
      this.fw.setBlockNum(40);
   }

   protected void resetXYScope() {
      this.xbaseidx = this.fi.getfreqIdx();
      this.ybaseidx = this.fi.dbbaseidx;
      this.xbase = this.fi.getFreq(this.xbaseidx);
      this.ybase = dBbasesTxt.get(this.ybaseidx).v();
      WaveFormFile wff = this.wf.getWaveFormFile();
      this.timeScope = this.xbase * wff.getXGraticuleNum();
      this.dbScope = this.ybase * (double)wff.getYGraticuleNum();
   }

   protected void resize(Point size) {
      WaveFormFile wff = this.wf.getWaveFormFile();
      this.xpp = (double)size.x * this.fi.getMaxfreqPercent() * (double)this.fi.getZoomRate() / (double)this.data.length;
      this.ypp = (double)size.y / (this.ybase * (double)wff.getYGraticuleNum());
      int ypointScope = wff.getYPointNum();
      this.zeroY = (double)(size.y >> 1) - (double)this.fi.loc0 / (double)ypointScope * (double)size.y;
      this.posOffset = -this.fi.posOffset * size.x / wff.getXPointNum();
   }

   protected void updateValueRate(Point size) {
      this.timePerPix = this.timeScope / (double)size.x;
      this.dbPerPix = this.dbScope / (double)size.y;
   }

   protected void windowing() {
      FFTUtil.compute_db(this.oadc, this.data, FFTInfo.wndTypes[this.fw.getWndTypeIdx()], this.wf.getDblVoltagePerPoint());
   }

   protected void computeDren() {
      this.dren
         .initPts(
            this.data,
            0,
            this.data.length,
            (double)this.posOffset,
            this.zeroY,
            this.xpp,
            this.ypp,
            this.xbase / this.fi.getFreq(this.xbaseidx),
            this.ybase / dBbasesTxt.get(this.ybaseidx).v()
         );
   }

   public boolean equals(WaveFormCurve wfc) {
      return this == wfc;
   }

   @Override
   public double rateAtY() {
      return 1.0;
   }

   @Override
   public int rateAtX() {
      return 1;
   }

   @Override
   public Collection<? extends Object> xb_collect() {
      return this.fi.tb_collect();
   }

   @Override
   public Collection<? extends Object> yb_collect() {
      return dBbasesTxt;
   }

   @Override
   public String getFreqBaseTxt(int zoomRate) {
      return this.fi.getFreqTxt(zoomRate, this.xbaseidx);
   }

   @Override
   public String getXBaseTxt() {
      return this.getFreqBaseTxt(this.fw.getZoomRate());
   }

   @Override
   public String getYBaseTxt() {
      return dBbasesTxt.get(this.ybaseidx).n();
   }

   @Override
   public void setBaseIdxOnX(int idx) {
      this.xbaseidx = idx;
      this.dren.setXScale(this.xbase / this.fi.getFreq(this.xbaseidx));
   }

   @Override
   public void setBaseIdxOnY(int idx) {
      this.ybaseidx = idx;
      this.dren.setAbsoluteScaleY(this.ybase / dBbasesTxt.get(this.ybaseidx).v());
   }

   @Override
   public double valueAtX(double x) {
      return (x - this.dren.getZeroXLocation()) * this.timePerPix / this.dren.getXScale();
   }

   @Override
   public double valueAtY(double y) {
      return (this.dren.getZeroYLocation() - y) * this.dbPerPix / this.dren.getAbsoluteScaleY();
   }

   @Override
   public int baseIdxOnX() {
      return this.xbaseidx;
   }

   @Override
   public int baseIdxOnY() {
      return this.ybaseidx;
   }

   @Override
   public String unitForX(double x) {
      x /= (double)this.fi.getZoomRate();
      return UnitConversionUtil.getFrequencyLabel_Hz(x);
   }

   @Override
   public String unitForY(double y) {
      return String.format("%.2f dB", y);
   }

   @Override
   public Collection<TxtEntry> txts_coll() {
      return this.wf.getArgTxts();
   }
}
