package com.owon.uppersoft.hdoscilloscope.chart.model.deep;

import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.chart.GraphicContext;
import com.owon.uppersoft.hdoscilloscope.chart.WaveFormCurveRenderer;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import com.owon.uppersoft.hdoscilloscope.pref.Reg;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.swt.graphics.Point;

public class Pixel1Engine extends AbstMemEngine {
   private double zeroYoffset;
   private double xpp;
   private int[] adc;
   private List<Pixel> pts;
   private boolean firstComp = true;
   private int start;
   private int len;
   public static final int DefaultNoAction = 0;
   public static final int DefaultXScale = 1;
   public static final int DefaultYScale = 2;
   public static final int DefaultZeroYOffset = 3;
   public static final int DefaultZeroXOffset = 4;
   public static final int DefaultDatasUpdate = 5;

   public Pixel1Engine(DrawingPanel dp, MemdepthWaveFormCurve curve) {
      super(dp, curve);
   }

   @Override
   public void resizeTo(Point lsz, Point sz) {
      if (lsz.x != 0 && lsz.y != 0 && sz.x != 0 && sz.y != 0) {
         boolean xr = false;
         boolean yr = false;
         if (lsz.x != sz.x) {
            xr = true;
         }

         if (lsz.y != sz.y) {
            yr = true;
         }

         if (xr) {
            double rx = (double)sz.x / (double)lsz.x;
            this.curve.x0 *= rx;
            this.xpp *= rx;
            this.initPts();
         }

         if (yr) {
            double ry = (double)sz.y / (double)lsz.y;
            this.curve.y0 *= ry;
            this.curve.ypp *= ry;
            double pixYperPoint = this.curve.ypp * this.curve.absoluteScaleY;

            for (int i = 0; i < this.len; i++) {
               Pixel p = this.pts.get(i);
               double locationY = this.curve.y0 - (double)this.adc[i] * pixYperPoint;
               p.y = (int)locationY;
            }
         }
      }
   }

   @Override
   public void setInverted(boolean invert) {
      this.wfreg.setInverted(invert);
      this.datasUpdate();
   }

   @Override
   public void setAbsoluteScaleY(double absoluteScaleY) {
      super.setAbsoluteScaleY(absoluteScaleY);
      this.presetCurve(2);
   }

   @Override
   public void setXScale(double xscale) {
      super.setXScale(xscale);
      this.presetCurve(1);
   }

   @Override
   public void setZeroXoffset(double x) {
      super.setZeroXoffset(x);
      this.presetCurve(4);
   }

   @Override
   public void setZeroYLocation(double y) {
      Reg.AutoApplyZeroLocation = false;
      this.zeroYoffset = y - this.curve.y0;
      this.curve.y0 = y;
      this.wfreg.setZeroLocRate(this.curve.y0 / (double)this.getSize().y);
      this.presetCurve(3);
   }

   private void getPts() {
      WaveForm wf = this.curve.getWaveForm();
      Point p = this.getSize();
      int intADCollectionNum = wf.getIntADCollectionNum();
      int intFullScreenDataNum = wf.getIntFullScreenDataNum();
      int startPointer = wf.getMemdepthDataIndex();
      int endPointer = startPointer + intADCollectionNum * 2;
      int zy = wf.getIntZeroYPoint();
      CByteArrayInputStream ba = this.dp.getWaveFormFileCurve().getWaveFormFile().getba();
      double multiple = (double)intFullScreenDataNum / this.curve.xscale / (double)p.x;
      this.xpp = 1.0 / multiple;
      this.len = (int)((double)p.x * multiple) + 2;
      if (this.len < 1) {
         this.len = 2;
      }

      int skip;
      if (wf.isLowMove()) {
         skip = wf.getIntADCollectionNum() - wf.getIntLowMoveNum();
         if (this.curve.x0 < 0.0) {
            skip -= (int)(this.curve.x0 * multiple);
         }
      } else {
         skip = 0;
         if (this.curve.x0 < 0.0) {
            skip = (int)(-this.curve.x0 * multiple);
         }
      }

      if (skip > intADCollectionNum) {
         this.adc = new int[1];
         this.adc[0] = 0;
      } else {
         ba.reset(startPointer + skip * 2);
         int l = (endPointer - ba.pointer()) / 2;
         this.len = this.len < l ? this.len : l;
         this.adc = new int[this.len];
         int shift = wf.getShift();

         for (int i = 0; i < this.len; i++) {
            this.adc[i] = (ba.nextShort() >> shift) - zy;
         }
      }

      if (this.firstComp) {
         if (!this.curve.isNeedCom()) {
            wf.setIntADCollection(this.adc);
         }

         this.firstComp = false;
      }
   }

   public void initPts() {
      this.getPts();
      if (this.curve.x0 < 0.0) {
         this.start = 0;
      } else {
         this.start = (int)this.curve.x0;
      }

      this.len = this.adc.length;
      this.pts = new ArrayList<>(this.len);
      double pixXinterval = this.xpp;
      double pixYperPoint = this.curve.ypp * this.curve.absoluteScaleY;
      if (this.wfreg.isInverted()) {
         pixYperPoint = -pixYperPoint;
      }

      for (int i = 0; i < this.len; i++) {
         int x = (int)((double)this.start + (double)i * pixXinterval);
         int y = (int)(this.curve.y0 - (double)this.adc[i] * pixYperPoint);
         Pixel p = new Pixel(x, y);
         this.pts.add(p);
      }
   }

   public void datasUpdate() {
      this.presetCurve(5);
   }

   private void presetCurve(int actionStatus) {
      switch (actionStatus) {
         case 0:
         default:
            break;
         case 1:
            this.initPts();
            break;
         case 2:
            double pixYperPoint = this.curve.ypp * this.curve.absoluteScaleY;
            int end = this.start + this.len;
            int i = 0;

            for (int j = this.start; j < end; j++) {
               Pixel p = this.pts.get(i);
               double locationY = this.curve.y0 - (double)this.adc[j] * pixYperPoint;
               p.y = (int)locationY;
               i++;
            }
            break;
         case 3:
            int offset = (int)this.zeroYoffset;
            int length = this.pts.size();

            for (int i = 0; i < length; i++) {
               Pixel p = this.pts.get(i);
               p.y += offset;
            }
            break;
         case 4:
            this.initPts();
            break;
         case 5:
            double pixYperPoint = this.curve.ypp * this.curve.absoluteScaleY;
            if (this.wfreg.isInverted()) {
               pixYperPoint = -pixYperPoint;
            }

            int end = this.start + this.len;
            int i = this.start;

            for (int j = 0; i < end; j++) {
               Pixel p = this.pts.get(j);
               p.y = (int)(this.curve.y0 - (double)this.adc[i] * pixYperPoint);
               i++;
            }
      }
   }

   @Override
   public boolean isPointSelected(Point p) {
      int x = p.x;
      int y = p.y;
      List<Pixel> pointSet = this.pts;
      int length = pointSet.size();
      int minX = pointSet.get(0).x;
      int maxX = pointSet.get(length - 1).x;
      if (x >= minX + 1 && x <= maxX - 1) {
         double pixXinterval = this.xpp;
         int index;
         if (this.curve.x0 < 0.0) {
            index = (int)((double)x / pixXinterval);
         } else {
            index = (int)(((double)x - this.curve.x0) / pixXinterval);
         }

         if (index >= length) {
            index = length - 1;
         }

         int y1;
         int y3;
         if (index != length - 1) {
            y1 = pointSet.get(index).y;
            y3 = pointSet.get(index + 1).y;
         } else {
            y1 = pointSet.get(index - 1).y;
            y3 = pointSet.get(index).y;
         }

         int y2 = (y1 + y3) / 2;
         boolean flag2 = (y2 + 2 - y) * (y2 - 2 - y) <= 0;
         boolean flag1 = (y1 - y) * (y3 - y) <= 0;
         return flag1 || flag2;
      } else {
         return false;
      }
   }

   @Override
   public void draw(GraphicContext gx) {
      WaveFormCurveRenderer.draw(this.curve, this.pts, gx);
   }
}
