package com.owon.uppersoft.hdoscilloscope.communication;

import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import com.owon.uppersoft.hdoscilloscope.util.FileChooserUtil;
import java.io.File;
import java.io.IOException;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

public abstract class AlphaUploadFrame extends PrototypeUploadFrame {
   protected String fileExtension;
   private int saveTimes;
   protected File saveDir;
   private String saveFileName;
   protected File saveFile;
   protected Configuration config;
   private AlphaUploadFrame.DoneRunner dr = new AlphaUploadFrame.DoneRunner();

   public AlphaUploadFrame(Shell shell, Configuration conf) {
      super(shell);
      this.config = conf;
      this.saveDir = new File(this.config.savePath);
      this.saveFileName = FileChooserUtil.getRandomFileName();
      this.saveFile = new File(this.saveDir, this.saveFileName);
      this.showSaveFileInfo(this.saveFile);
   }

   protected void setSaveFile() {
      FileDialog fd = new FileDialog(this.shell, 4096);
      fd.setFileName(this.txtStoring.getText());
      String s = fd.open();
      if (s != null) {
         File file = new File(s);
         boolean flag = FileChooserUtil.checkFileWritable(file);
         if (flag) {
            this.saveDir = file.getParentFile();
            if (!file.getName().equalsIgnoreCase(this.saveFileName)) {
               this.saveTimes = 0;
            }

            this.saveFileName = file.getName();
            this.saveFile = file;
            this.showSaveFileInfo(this.saveFile);
         }
      }
   }

   protected void showSaveFileInfo(File file) {
      try {
         this.txtReceiving.setText(file.getName());
         this.txtStoring.setText(file.getCanonicalPath());
      } catch (IOException var3) {
         var3.printStackTrace();
      }
   }

   protected File setSaveFileExtension(String ext) {
      this.fileExtension = ext;
      File newFile = null;
      String dx = "." + ext;
      if (this.saveTimes == 0) {
         newFile = new File(this.saveDir, this.saveFileName + dx);
      } else {
         newFile = new File(this.saveDir, this.saveFileName + "(" + this.saveTimes + ")" + dx);
      }

      this.saveFile = newFile;
      this.saveTimes++;
      return newFile;
   }

   protected void done(boolean flag) {
      this.dr.setFlag(flag);
      this.shell.getDisplay().asyncExec(this.dr);
   }

   protected abstract void setCommStatus();

   class DoneRunner implements Runnable {
      private boolean flag;

      public void setFlag(boolean flag) {
         this.flag = flag;
      }

      @Override
      public void run() {
         AlphaUploadFrame.this.setCommStatus();
         if (this.flag) {
            AlphaUploadFrame.this.showSaveFileInfo(AlphaUploadFrame.this.saveFile);
            if (AlphaUploadFrame.this.fileExtension.equalsIgnoreCase("bin")) {
               Platform.getPlatform().getActionFactory().open.doOpenFile(AlphaUploadFrame.this.saveFile);
            }

            if (AlphaUploadFrame.this.checkCloseOnDone.getSelection()) {
               AlphaUploadFrame.this.shell.close();
            }
         }
      }
   }
}
