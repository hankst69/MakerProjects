package com.owon.uppersoft.hdoscilloscope.util;

import com.owon.uppersoft.hdoscilloscope.frame.MainFrame;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

public class FileChooserUtil {
   protected FileChooserUtil() {
   }

   public static String getAvalibleFileName(File dir, String[] exts) {
      String filepath = "";

      try {
         filepath = dir.getCanonicalPath();
      } catch (IOException var4) {
         Logger.getLogger("global").log(Level.SEVERE, null, var4);
      }

      return getAvalibleFileName(filepath, exts);
   }

   public static String getAvalibleFileName(String path, String[] exts) {
      boolean exist = false;

      String fileName;
      do {
         fileName = getRandomFileName();
         String filepath = path + File.separator + fileName;

         for (int i = 0; i < exts.length; i++) {
            File file = new File(filepath + "." + exts[i]);
            exist = file.exists();
            if (exist) {
               break;
            }
         }
      } while (exist);

      return fileName;
   }

   public static String getRandomFileName() {
      SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH_mm_ss_S");
      return format.format(new Date());
   }

   public static String getFileNameWithExtension(File file, String extension) {
      String filepath = "";

      try {
         filepath = file.getCanonicalPath();
      } catch (IOException var4) {
         Logger.getLogger("global").log(Level.SEVERE, null, var4);
      }

      return getFileNameWithExtension(filepath, extension);
   }

   public static String getFileNameWithExtension(String filepath, String extension) {
      boolean hasExt = filepath.substring(filepath.lastIndexOf(".") + 1).equalsIgnoreCase(extension);
      if (!hasExt) {
         filepath = filepath + "." + extension;
      }

      return filepath;
   }

   public static boolean checkFileReadable(Shell shell, File file) {
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      String filepath = "";
      String errDefault = bundle.getString("Err.Default");

      try {
         filepath = file.getCanonicalPath();
      } catch (IOException var6) {
         var6.printStackTrace();
         return false;
      }

      if (!file.exists() || !file.isFile()) {
         MessageDialog.openError(shell, errDefault, bundle.getString("Err.FileNotExist") + filepath);
         MainFrame mf = Platform.getPlatform().getMainFrame();
         mf.getFileHistoryUtil().remove(file, mf.getFileHistoryMenu());
         return false;
      } else if (!file.canRead()) {
         MessageDialog.openError(shell, errDefault, bundle.getString("Err.FileUnreadable") + filepath);
         return false;
      } else {
         return true;
      }
   }

   public static boolean checkFilesWritable(String filepath, String[] exts) {
      for (int i = 0; i < exts.length; i++) {
         boolean flag = checkFileWritable(filepath, exts[i]);
         if (!flag) {
            return false;
         }
      }

      return true;
   }

   public static boolean checkFileWritable(String filepath, String ext) {
      return checkFileWritable(filepath + ext);
   }

   public static boolean checkFileWritable(String filepath) {
      return checkFileWritable(new File(filepath));
   }

   public static boolean checkFileWritable(File file) {
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      String errDefault = bundle.getString("Err.Default");
      String infoDefault = bundle.getString("Info.Default");
      Shell shell = Platform.getPlatform().getShell();
      String txt = "";
      String path = "";

      try {
         path = file.getCanonicalPath();
         if (file.exists()) {
            txt = bundle.getString("Info.FileExist") + path;
            boolean option = MessageDialog.openConfirm(shell, infoDefault, txt);
            if (option) {
               if (file.canWrite()) {
                  return true;
               } else {
                  txt = bundle.getString("Err.FileUnwriteable") + path;
                  MessageDialog.openError(shell, errDefault, txt);
                  return false;
               }
            } else {
               return false;
            }
         } else {
            boolean flag = false;

            try {
               flag = file.createNewFile();
            } catch (IOException var8) {
               txt = bundle.getString("Err.FileUncreatable") + path;
               MessageDialog.openError(shell, infoDefault, txt);
               return false;
            }

            if (flag) {
               file.delete();
               return true;
            } else {
               txt = bundle.getString("Err.FileUncreatable") + path;
               MessageDialog.openError(shell, infoDefault, txt);
               return false;
            }
         }
      } catch (IOException var9) {
         txt = bundle.getString("Err.FileUncreatable") + path;
         MessageDialog.openError(shell, infoDefault, txt);
         return false;
      }
   }
}
