package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.control.TimeControl;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Spinner;

public class TBComposite extends Composite implements SelectionListener, Localizable2 {
   private ManipulateControl mc;
   private TimeControl tc;
   private String[] TIMEBASE;
   private int trgpos;
   private Label trg0lbl;
   private Spinner trgPosSpin;
   private Label dmlbl;
   private Combo dmcbb;
   private Combo tbcbb;
   private Button signbtn;
   private Label tblbl;
   private Label htplblback;
   private Label lbTips;

   public TBComposite(Composite parent, ManipulateControl mc, final TimeControl tc) {
      super(parent, 0);
      this.mc = mc;
      this.tc = tc;
      GridLayout gridLayout = new GridLayout();
      gridLayout.marginWidth = 10;
      gridLayout.marginHeight = 10;
      gridLayout.numColumns = 4;
      this.setLayout(gridLayout);
      this.dmlbl = new Label(this, 0);
      GridData gd_dmlbl = new GridData(4, 16777216, false, false);
      gd_dmlbl.widthHint = 120;
      this.dmlbl.setLayoutData(gd_dmlbl);
      this.dmcbb = new Combo(this, 8);
      this.dmcbb.setLayoutData(new GridData(1, 2, false, false, 2, 1));
      this.lbTips = new Label(this, 0);
      this.lbTips.setVisible(false);
      this.tblbl = new Label(this, 0);
      this.tblbl.setLayoutData(new GridData(4, 16777216, false, false));
      this.tbcbb = new Combo(this, 8);
      this.tbcbb.setLayoutData(new GridData(16384, 16777216, false, false, 3, 1));
      this.trg0lbl = new Label(this, 0);
      this.trg0lbl.setLayoutData(new GridData(4, 16777216, false, false));
      this.signbtn = new Button(this, 2);
      this.signbtn.setLayoutData(new GridData(23, -1));
      this.signbtn.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            TBComposite.this.signbtn.setText(TBComposite.this.signbtn.getSelection() ? "+" : "-");
            int v = tc.horpos = TBComposite.this.getHtpValue();
            TBComposite.this.updateHTPLabel(v);
         }
      });
      this.signbtn.setSelection(true);
      this.signbtn.setText(this.signbtn.getSelection() ? "+" : "-");
      this.trgPosSpin = new Spinner(this, 2048);
      this.trgPosSpin.setLayoutData(new GridData(50, -1));
      this.trgPosSpin.setMinimum(0);
      this.trgPosSpin.setMaximum(2000000000);
      int htp = 0;
      this.trgPosSpin.setSelection(htp);
      this.htplblback = new Label(this, 0);
      this.htplblback.setLayoutData(new GridData(4, 16777216, true, false));
      this.custom();
      this.updateHTPLabel(htp);
   }

   private int getHtpValue() {
      boolean s = this.signbtn.getSelection();
      int v = this.trgPosSpin.getSelection();
      return s ? v : -v;
   }

   private void updateHTPLabel(int v) {
      this.htplblback.setText(String.format("/%d = %.2f div", this.mc.pixelsPerBlock, (double)v / (double)this.mc.pixelsPerBlock));
   }

   public void localize(ResourceBundle rb) {
      this.dmlbl.setText(rb.getString("Action.dm") + ":");
      this.trg0lbl.setText(rb.getString("Action.trg0") + ":");
      this.tblbl.setText(rb.getString("M.Timebase.Name") + ":");
      this.lbTips.setText(rb.getString("M.Timebase.tips"));
   }

   private void custom() {
      this.dmcbb.setItems(ManipulateControl.DEEPS);
      this.TIMEBASE = ManipulateControl.toStrings(this.mc.mt.getXbaseList());
      this.tbcbb.setItems(this.TIMEBASE);
      this.tbcbb.select(this.tc.tbidx);
      this.dmcbb.select(this.tc.dmidx);
      this.tbcbb.addSelectionListener(this);
      this.dmcbb.addSelectionListener(this);
      this.trgPosSpin.addSelectionListener(this);
   }

   public void widgetDefaultSelected(SelectionEvent e) {
   }

   public void widgetSelected(SelectionEvent e) {
      Object o = e.getSource();
      if (o == this.tbcbb) {
         this.tc.tbidx = this.tbcbb.getSelectionIndex();
         String s = this.TIMEBASE[this.tc.tbidx];
         String cmd = ":HORIzontal:Scale " + s.replaceAll(" ", "");
         this.mc.send(cmd);
      } else if (o == this.dmcbb) {
         this.tc.dmidx = this.dmcbb.getSelectionIndex();
         String cmd = ":ACQUIRE:DEPMEM " + ManipulateControl.DEEPS[this.tc.dmidx];
         this.mc.send(cmd);
      } else if (o == this.trgPosSpin) {
         int v = this.tc.horpos = this.getHtpValue();
         this.updateHTPLabel(v);
         DecimalFormat df = new DecimalFormat("#0.##");
         String g = df.format((double)v / (double)this.mc.pixelsPerBlock);
         String cmd = ":HORIzontal:OFFSET " + g;
         this.mc.send(cmd);
      }
   }

   public void storeFromUI() {
      this.trgpos = this.trgPosSpin.getSelection();
      this.trgpos = this.signbtn.getSelection() ? this.trgpos : -this.trgpos;
   }
}
