package com.owon.uppersoft.hdoscilloscope.chart.model.fft.mathD;

public class InplaceFFT {
   public static void fft(ComplexD[] x) {
      int N = x.length;
      if (Integer.highestOneBit(N) != N) {
         throw new RuntimeException("N is not a power of 2");
      } else {
         int shift = 1 + Integer.numberOfLeadingZeros(N);

         for (int k = 0; k < N; k++) {
            int j = Integer.reverse(k) >>> shift;
            if (j > k) {
               ComplexD temp = x[j];
               x[j] = x[k];
               x[k] = temp;
            }
         }

         for (int L = 2; L <= N; L += L) {
            for (int kx = 0; kx < L / 2; kx++) {
               double kth = (double)(-2 * kx) * Math.PI / (double)L;
               ComplexD w = new ComplexD(Math.cos(kth), Math.sin(kth));

               for (int j = 0; j < N / L; j++) {
                  ComplexD tao = w.times(x[j * L + kx + L / 2]);
                  x[j * L + kx + L / 2] = x[j * L + kx].minus(tao);
                  x[j * L + kx] = x[j * L + kx].plus(tao);
               }
            }
         }
      }
   }

   public static void main(String[] args) {
      int N = 8;
      ComplexD[] x = new ComplexD[N];

      for (int i = 0; i < N; i++) {
         x[i] = new ComplexD((double)(i + 1), 0.0);
      }

      for (int i = 0; i < N; i++) {
         System.out.println(x[i]);
      }

      System.out.println();
      fft(x);

      for (int i = 0; i < N; i++) {
         System.out.println(x[i]);
      }

      System.out.println();
   }
}
