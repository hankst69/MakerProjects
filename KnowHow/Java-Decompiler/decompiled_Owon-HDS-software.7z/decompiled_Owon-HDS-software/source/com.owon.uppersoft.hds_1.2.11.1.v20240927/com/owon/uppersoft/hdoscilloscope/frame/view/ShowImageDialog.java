package com.owon.uppersoft.hdoscilloscope.frame.view;

import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.ImageTransfer;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class ShowImageDialog {
   private Shell parent;
   private Shell shell;
   private Display display;
   private Label composite;
   private String imagePath;

   public static void main(String[] args) {
      try {
         ShowImageDialog window = new ShowImageDialog(null, "");
         window.open();
      } catch (Exception var2) {
         var2.printStackTrace();
      }
   }

   public ShowImageDialog(Shell parent, String imagePath) {
      this.parent = parent;
      this.imagePath = imagePath;
   }

   public void open() {
      this.display = Display.getDefault();
      this.display.syncExec(new Runnable() {
         @Override
         public void run() {
            ShowImageDialog.this.createContents();
            ShowImageDialog.this.shell.pack();
            ShellUtil.centerLoc(ShowImageDialog.this.shell);
            ShowImageDialog.this.shell.open();

            while (!ShowImageDialog.this.shell.isDisposed()) {
               if (!ShowImageDialog.this.display.readAndDispatch()) {
                  ShowImageDialog.this.display.sleep();
               }
            }
         }
      });
   }

   protected void createContents() {
      this.shell = new Shell(this.parent, 67680);
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 2;
      this.shell.setLayout(gridLayout);
      Image image = new Image(this.display, this.imagePath);
      this.composite = new Label(this.shell, 0);
      this.composite.setLayoutData(new GridData(16777216, 4, true, true, 2, 1));
      this.composite.setImage(image);
      Text text = new Text(this.shell, 10);
      text.setLayoutData(new GridData(16384, 16777216, true, false));
      text.setText(this.imagePath);
      Button button = new Button(this.shell, 0);
      button.setLayoutData(new GridData());
      button.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            ShowImageDialog.this.shell.close();
         }
      });
      button.setText(ResourceBundleProvider.getMessageLibResourceBundle().getString("MF.ok"));
      this.setClipboard(image);
   }

   private void setClipboard(Image image) {
      ImageData data = image.getImageData();
      Clipboard clipboard = new Clipboard(this.display);
      clipboard.setContents(new ImageData[]{data}, new ImageTransfer[]{ImageTransfer.getInstance()});
   }
}
