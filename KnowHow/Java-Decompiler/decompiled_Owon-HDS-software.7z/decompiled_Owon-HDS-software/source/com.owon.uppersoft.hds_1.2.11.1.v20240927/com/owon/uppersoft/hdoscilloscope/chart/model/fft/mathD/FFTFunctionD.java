package com.owon.uppersoft.hdoscilloscope.chart.model.fft.mathD;

public class FFTFunctionD {
   public static final int powers(int size) {
      int i;
      for (i = 0; size > 1; i++) {
         size >>>= 1;
      }

      return i;
   }

   public static final ComplexD[] fft_adc(int[] wnd_adc, int start, int end, ComplexD[] TD) {
      int i = start;

      for (int j = 0; i < end; j++) {
         TD[j].re = (double)wnd_adc[i];
         TD[j].im = 0.0;
         i++;
      }

      InplaceFFT.fft(TD);
      return TD;
   }
}
