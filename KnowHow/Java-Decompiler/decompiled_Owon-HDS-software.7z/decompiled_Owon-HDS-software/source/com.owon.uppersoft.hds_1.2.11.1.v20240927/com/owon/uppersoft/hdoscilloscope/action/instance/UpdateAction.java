package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.common.update.UpdateRuntime;
import com.owon.uppersoft.hdoscilloscope.action.UpdateContent;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class UpdateAction extends DefaultAction {
   private UpdateRuntime ur;

   public UpdateAction(String id) {
      super(id);
   }

   public void run() {
      if (this.ur == null) {
         this.ur = new UpdateRuntime(new UpdateContent(Platform.getPlatform().getMainFrame()));
      }

      this.ur.clearUp();
      this.ur.checkUpdate();
   }
}
