package com.owon.uppersoft.hdoscilloscope.util;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.custom.LObject;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class CRadioButtons extends Composite implements Localizable2 {
   public static final String EXCLUDE = "EXCLUDE";
   public static final int DefaultWidth = 80;
   private Button[] btns;
   private int sel = 0;

   public CRadioButtons(Composite parent, Object[] os, final PropertyChangeListener pcl, int j, int w, int h, final int len) {
      super(parent, 0);
      RowLayout rowLayout = new RowLayout();
      rowLayout.marginTop = 0;
      rowLayout.marginBottom = 0;
      rowLayout.marginRight = 0;
      rowLayout.marginLeft = 0;
      rowLayout.spacing = 0;
      this.setLayout(rowLayout);
      this.btns = new Button[len];

      for (final int i = 0; i < len; i++) {
         Button btn = new Button(this, 16);
         btn.setData(os[i]);
         btn.setSelection(false);
         btn.setLayoutData(new RowData());
         this.btns[i] = btn;
         btn.addSelectionListener(new SelectionAdapter() {
            public void widgetSelected(SelectionEvent e) {
               Button btn = (Button)e.getSource();
               CRadioButtons.this.handleRadioButton(btn.getSelection(), i, len, pcl);
            }
         });
      }

      this.btns[j].setSelection(true);
      this.sel = j;
      this.updateTexts();
      this.setTabSize(w, h);
   }

   public CRadioButtons(Composite parent, Object[] os, PropertyChangeListener pcl, int j, int len) {
      this(parent, os, pcl, j, 80, -1, len);
   }

   private void handleRadioButton(boolean selection, int k, int len, PropertyChangeListener pcl) {
      if (selection) {
         this.sel = k;
         pcl.propertyChange(new PropertyChangeEvent(this, "EXCLUDE", null, k));
      }
   }

   public void setSelected(int s) {
      if (s >= 0 && s < this.btns.length) {
         this.btns[this.sel].setSelection(false);
         this.sel = s;
         this.btns[s].setSelection(true);
      }
   }

   public void setTabSize(int w, int h) {
      for (Button btn : this.btns) {
         RowData rd_button = (RowData)btn.getLayoutData();
         rd_button.width = w;
         rd_button.height = h;
      }
   }

   private void updateTexts() {
      for (Button btn : this.btns) {
         btn.setText(btn.getData().toString());
      }
   }

   public void updateTexts(ResourceBundle bundle) {
      for (Button btn : this.btns) {
         Object o = btn.getData();
         if (o instanceof LObject) {
            LObject lo = (LObject)o;
            btn.setText(lo.toString(bundle));
         } else {
            btn.setText(o.toString());
         }
      }
   }

   public void localize(ResourceBundle bundle) {
      this.updateTexts(bundle);
   }

   public static void main(String[] args) {
      Shell shell = new Shell();
      Display display = shell.getDisplay();
      shell.setLayout(new FillLayout());
      PropertyChangeListener pcl = new PropertyChangeListener() {
         @Override
         public void propertyChange(PropertyChangeEvent evt) {
         }
      };
      new CRadioButtons(shell, new CRadioButtons.CLObject[]{new CRadioButtons.CLObject(), new CRadioButtons.CLObject()}, pcl, 1, 2).setTabSize(80, -1);
      shell.layout();
      shell.open();

      while (!shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   private static class CLObject extends LObject {
      public CLObject() {
         super("XXX");
      }

      @Override
      public String toString(ResourceBundle rb) {
         return this.getKey();
      }
   }
}
