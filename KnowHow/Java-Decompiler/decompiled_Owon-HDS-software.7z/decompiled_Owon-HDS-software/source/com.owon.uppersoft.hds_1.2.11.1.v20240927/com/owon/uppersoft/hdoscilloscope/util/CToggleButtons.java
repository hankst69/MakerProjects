package com.owon.uppersoft.hdoscilloscope.util;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.custom.LObject;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class CToggleButtons extends Composite implements Localizable2 {
   public static final String EXCLUDE = "EXCLUDE";
   public static final int DefaultWidth = 80;
   private Button[] btns;
   private int sel = 0;

   public CToggleButtons(Composite parent, Object[] os, final PropertyChangeListener pcl, int j, int w, int h) {
      super(parent, 0);
      RowLayout rowLayout = new RowLayout();
      rowLayout.marginTop = 0;
      rowLayout.marginBottom = 0;
      rowLayout.marginRight = 0;
      rowLayout.marginLeft = 0;
      rowLayout.spacing = 0;
      this.setLayout(rowLayout);
      final int i = 0;
      final int len = os.length;
      this.btns = new Button[len];

      for (Object o : os) {
         Button btn = new Button(this, 2);
         btn.setData(o);
         btn.setSelection(false);
         btn.setLayoutData(new RowData());
         this.btns[i] = btn;
         btn.addSelectionListener(new SelectionAdapter() {
            public void widgetSelected(SelectionEvent e) {
               CToggleButtons.this.handleToggleButton(i, len, pcl);
            }
         });
         i++;
      }

      this.btns[j].setSelection(true);
      this.sel = j;
      this.updateTexts();
      this.setTabSize(w, h);
   }

   public CToggleButtons(Composite parent, Object[] os, PropertyChangeListener pcl, int j) {
      this(parent, os, pcl, j, 80, -1);
   }

   private void handleToggleButton(int k, int len, PropertyChangeListener pcl) {
      int v = k;
      if (this.sel == k) {
         v = (k + 1) % len;
      }

      this.setSelected(v);
      pcl.propertyChange(new PropertyChangeEvent(this, "EXCLUDE", null, v));
   }

   public void setSelected(int s) {
      if (s >= 0 && s < this.btns.length) {
         this.btns[this.sel].setSelection(false);
         this.sel = s;
         this.btns[s].setSelection(true);
      }
   }

   public void setTabSize(int w, int h) {
      for (Button btn : this.btns) {
         RowData rd_button = (RowData)btn.getLayoutData();
         rd_button.width = w;
         rd_button.height = h;
      }
   }

   private void updateTexts() {
      for (Button btn : this.btns) {
         btn.setText(btn.getData().toString());
      }
   }

   public void updateTexts(ResourceBundle bundle) {
      for (Button btn : this.btns) {
         Object o = btn.getData();
         if (o instanceof LObject) {
            LObject lo = (LObject)o;
            btn.setText(lo.toString(bundle));
         } else {
            btn.setText(o.toString());
         }
      }
   }

   public void localize(ResourceBundle bundle) {
      this.updateTexts(bundle);
   }

   public static void main(String[] args) {
      Shell shell = new Shell();
      Display display = shell.getDisplay();
      shell.setLayout(new FillLayout());
      PropertyChangeListener pcl = new PropertyChangeListener() {
         @Override
         public void propertyChange(PropertyChangeEvent evt) {
         }
      };
      new CToggleButtons(shell, new CToggleButtons.CLObject[]{new CToggleButtons.CLObject(), new CToggleButtons.CLObject()}, pcl, 1).setTabSize(80, -1);
      shell.layout();
      shell.open();

      while (!shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   private static class CLObject extends LObject {
      public CLObject() {
         super("XXX");
      }

      @Override
      public String toString(ResourceBundle rb) {
         return this.getKey();
      }
   }
}
