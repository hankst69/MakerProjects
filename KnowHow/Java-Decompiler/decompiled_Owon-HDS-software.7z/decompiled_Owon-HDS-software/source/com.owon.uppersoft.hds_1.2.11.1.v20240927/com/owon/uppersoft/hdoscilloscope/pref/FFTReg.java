package com.owon.uppersoft.hdoscilloscope.pref;

public class FFTReg extends WFReg {
   public int dr = 1;
   public int wt = 0;
   public int zr = 1;

   public FFTReg() {
      super(false, true);
   }
}
