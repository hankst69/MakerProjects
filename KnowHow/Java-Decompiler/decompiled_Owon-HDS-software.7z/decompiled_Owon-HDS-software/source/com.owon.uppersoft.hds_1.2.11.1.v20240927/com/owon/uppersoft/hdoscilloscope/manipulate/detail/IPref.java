package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

public interface IPref {
   String[] uFreq = new String[]{"uHz", "mHz", "Hz", "kHz", "MHz"};
   String[] uAmp = new String[]{"mVpp", "Vpp"};
   String[] uOffset = new String[]{"mV", "V"};
   String[] uPercent = new String[]{"%"};
   String[] uTime = new String[]{"nsec", "usec", "msec", "sec", "Ksec"};
   String[] uSource = new String[]{"Internal", "External", "Manual"};
   String[] uModType = new String[]{"AM", "FM", "PM", "FSK", "PWM"};
   String[] uModShape = new String[]{"Sine", "Square", "Ramp", "Noise", "Arb"};
   String[] uDegree = new String[]{"Degree"};
   String[] uCycle = new String[]{"Ncycle", "Gate"};
   String[] uPolarity = new String[]{"Positive", "Negative"};
   String[] uBuiltin = new String[]{"AmpALT", "AttALT", "StairDn", "StairUD", "StairUp", "Besselj", "Bessely", "Sinc"};
   String[] uCycles = new String[]{"Cyc", "Infinite"};
   int SINE = 0;
   int SQUARE = 1;
   int RAMP = 2;
   int PULSE = 3;
   int ARB = 4;
}
