package com.owon.uppersoft.hdoscilloscope.test;

import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class TestUpload {
   private Text text_5;
   private Text text_4;
   private Text text_3;
   private Text text_2;
   private Text text_1;
   private Text text;
   protected Shell shell;

   public static void main(String[] args) {
      try {
         TestUpload window = new TestUpload();
         window.open();
      } catch (Exception var2) {
         var2.printStackTrace();
      }
   }

   public void open() {
      this.createContents();
      this.shell.open();
      this.shell.layout();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   protected void createContents() {
      this.shell = new Shell();
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 4;
      this.shell.setLayout(gridLayout);
      this.shell.setSize(630, 353);
      this.shell.setText("SWT Application");
      final Label label1 = new Label(this.shell, 0);
      GridData gd_label1 = new GridData(-1, 20);
      label1.setLayoutData(gd_label1);
      label1.setText("Label");
      this.text = new Text(this.shell, 2048);
      GridData gd_text = new GridData(16384, 16777216, true, false);
      gd_text.widthHint = 60;
      this.text.setLayoutData(gd_text);
      new Label(this.shell, 0);
      new Label(this.shell, 0);
      final Label label2 = new Label(this.shell, 0);
      GridData gd_label2 = new GridData(-1, 20);
      label2.setLayoutData(gd_label2);
      label2.setText("Label");
      this.text_1 = new Text(this.shell, 2048);
      GridData gd_text_1 = new GridData(4, 16777216, true, false, 2, 1);
      gd_text_1.widthHint = 246;
      this.text_1.setLayoutData(gd_text_1);
      Button button = new Button(this.shell, 0);
      button.setLayoutData(new GridData());
      button.setText("button");
      final Label label3 = new Label(this.shell, 0);
      GridData gd_label3 = new GridData(-1, 20);
      label3.setLayoutData(gd_label3);
      label3.setText("Label");
      this.text_2 = new Text(this.shell, 2048);
      GridData gd_text_2 = new GridData(16384, 16777216, true, false);
      this.text_2.setLayoutData(gd_text_2);
      Label label_3 = new Label(this.shell, 0);
      label_3.setLayoutData(new GridData(131072, 16777216, false, false));
      label_3.setText("Label");
      this.text_3 = new Text(this.shell, 2048);
      GridData gd_text_3 = new GridData(16384, 16777216, true, false);
      this.text_3.setLayoutData(gd_text_3);
      final Label label4 = new Label(this.shell, 0);
      GridData gd_label4 = new GridData(-1, 20);
      label4.setLayoutData(gd_label4);
      label4.setText("Label");
      ProgressBar progressBar = new ProgressBar(this.shell, 0);
      progressBar.setLayoutData(new GridData(4, 16777216, false, false));
      this.text_4 = new Text(this.shell, 2048);
      GridData gd_text_4 = new GridData(131072, 16777216, true, false);
      this.text_4.setLayoutData(gd_text_4);
      this.text_5 = new Text(this.shell, 2048);
      GridData gd_text_5 = new GridData(16384, 16777216, true, false);
      this.text_5.setLayoutData(gd_text_5);
      new Label(this.shell, 0);
      new Label(this.shell, 0);
      Button button_1 = new Button(this.shell, 0);
      button_1.setLayoutData(new GridData(131072, 16777216, false, false));
      button_1.setText("button");
      Button button_2 = new Button(this.shell, 0);
      button_2.setLayoutData(new GridData());
      button_2.setText("button");
      button.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            String string = "2";
            label1.setText(string);
            label2.setText(string);
            label3.setText(string);
            label4.setText(string);
            TestUpload.this.shell.layout();
            TestUpload.this.shell.pack();
         }
      });
   }
}
