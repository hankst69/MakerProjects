package com.owon.uppersoft.hdoscilloscope.communication.serial;

import com.owon.uppersoft.common.logger.LoggerUtil;
import com.owon.uppersoft.common.utils.FileUtil;
import com.owon.uppersoft.common.utils.StringPool;
import com.owon.uppersoft.hdoscilloscope.communication.loop.ICommunicationListenerProvider;
import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class YModem {
   public static final byte SOH = 1;
   public static final byte STX = 2;
   public static final byte EOT = 4;
   public static final byte ACK = 6;
   public static final byte BS = 8;
   public static final byte NAK = 21;
   public static final byte CAN = 24;
   public static final byte Byte_C = 67;
   public static final int XMODEM_CRC_BLOCK_SIZE = 128;
   public static final int XMODEM_1K_BLOCK_SIZE = 1024;
   public static final int START_OF_COMMUNICATION = -1;
   public static final int END_OF_COMMUNICATION = -3;
   public static final int PASSIVE_CANCEL = -5;
   public static final int TIMEOUT_CANCEL = -6;
   public static final int ACTIVE_CANCEL = -7;
   public static final int TERMINATED = -10;
   public static final int END_OF_TRANSMISSION = -12;
   public static final int ERROR = -20;
   public static final int BLOCK_NO_ERROR = -24;
   public static final int CRC_ERROR = -25;
   public static final int UNKNOWN_ERROR = -30;
   public static final int InitBufferSize = 1029;
   private static final int bufferSize = 1029;
   private InputStream is;
   private OutputStream os;
   private int wantedBlockNo;
   private byte[] bigData;
   private int fileLength;
   private int blockLength;
   private String fileType;
   private String fileName;
   private int injectDataIndex = 0;
   private int transactionStatus;
   private int correctRate;
   public static final Logger logger = LoggerUtil.getFileLogger(YModem.class.getName(), Level.FINE, PropertiesItem.LogDir);
   private ICommunicationListenerProvider iclp;
   private byte[] b;

   public YModem(InputStream is, OutputStream os, ICommunicationListenerProvider iclp) {
      this.is = is;
      this.os = os;
      this.iclp = iclp;
      this.b = new byte[1029];
   }

   public int responseOnDataAvaible() {
      logger.fine("[YModem: log]");
      this.transactionStatus = this.extractBlock(this.b);
      logger.info("[YModem: log]extractBlock return:" + this.transactionStatus);
      if (this.transactionStatus < -20) {
         this.disacknowledge();
      }

      return this.transactionStatus;
   }

   private int extractBlock(byte[] b) {
      int size = 0;

      try {
         size = this.is.read(b, 0, 3);
      } catch (IOException var16) {
         var16.printStackTrace();
      }

      if (size < 0) {
         return -30;
      } else {
         logger.fine("[YModem: blockNo]" + this.wantedBlockNo);
         int blockNo = 0;
         int blockNoOnesCompl = 0;
         int crcValue = 0;
         logger.fine("[YModem: header]");
         switch (b[0]) {
            case 1:
               logger.fine("soh!");
               this.blockLength = 128;
               break;
            case 2:
               logger.fine("stx!");
               this.blockLength = 1024;
               break;
            case 4:
               logger.fine("eot!");
               this.acknowledge();
               this.initialC();
               this.updateWantedBlockNo();
               return -12;
            case 24:
               logger.fine("can!");
               this.acknowledge();
               return -5;
            default:
               logger.fine("others:" + b[0]);
               return -30;
         }

         blockNo = b[1] & 255;
         blockNoOnesCompl = b[2] & 255;
         boolean blockNoIncorrect = blockNo + blockNoOnesCompl != 255;
         if (this.transactionStatus == -12) {
            if (blockNo != 0 || blockNoIncorrect) {
               logger.fine("[YModem: log]blockNo:" + blockNo + " blockNoOnesCompl:" + blockNoOnesCompl + " error after END_OF_TRANSMISSION");
            }

            this.acknowledge();
            this.updateWantedBlockNo();
            return -3;
         } else if (blockNoIncorrect) {
            logger.fine("[YModem: error]blockNoIncorrect! blockNo:" + blockNo + " blockNoOnesCompl:" + blockNoOnesCompl);
            return -24;
         } else if (blockNo >= 0 && blockNo < this.wantedBlockNo) {
            logger.fine("[YModem: log]block already received! blockNo:" + blockNo + " wantedBlockNo:" + this.wantedBlockNo);
            this.acknowledge();
            return this.wantedBlockNo - 1;
         } else {
            boolean blockNoWrong = blockNo != this.wantedBlockNo;
            if (blockNoWrong) {
               logger.fine("[YModem: error]blockNoIncorrect! blockNo:" + blockNo + " wantedBlockNo:" + this.wantedBlockNo);
               return -24;
            } else {
               try {
                  size = this.is.read(b, 3, this.blockLength + 2);
               } catch (IOException var15) {
                  var15.printStackTrace();
               }

               if (size < 0) {
                  return -30;
               } else {
                  logger.info("[YModem: blockNo]" + this.wantedBlockNo + " size:" + b.length);
                  int crcHi = b[3 + this.blockLength] & 255;
                  int crcLow = b[3 + this.blockLength + 1] & 255;
                  crcValue = crcHi * 256 + crcLow;
                  int crcCal = CRC16.encode(b, 3, this.blockLength);
                  logger.fine("[YModem: crc]crcValue:0x" + Integer.toHexString(crcValue) + " crcCal:0x" + Integer.toHexString(crcCal));
                  if (crcValue != crcCal) {
                     logger.fine("[YModem: error]crc check error!");
                     return -25;
                  } else {
                     this.acknowledge();
                     if (this.wantedBlockNo == 0 && this.bigData == null) {
                        String trimBlock = "";

                        try {
                           trimBlock = new String(b, 3, this.blockLength, "UTF-8").trim();
                        } catch (UnsupportedEncodingException var14) {
                           var14.printStackTrace();
                        }

                        byte zero = 0;
                        int firstZero = trimBlock.indexOf(zero);
                        this.fileName = trimBlock.substring(0, firstZero);
                        this.fileType = FileUtil.getExtension(this.fileName);
                        this.fileLength = Integer.parseInt(trimBlock.substring(firstZero).trim());
                        logger.fine("[YModem: fileInfo]fileName:" + this.fileName + " fileLength:" + this.fileLength);
                        this.bigData = new byte[this.fileLength];
                        this.correctRate = 0;
                        this.injectDataIndex = 0;
                        this.setCommInfo(this.fileLength, this.fileType);
                        this.initialC();
                     } else {
                        this.correctRate++;
                        logger.fine("[YModem: injection]");
                        if (this.injectDataIndex + this.blockLength > this.fileLength) {
                           int lastLength = this.fileLength - this.injectDataIndex;
                           System.arraycopy(b, 3, this.bigData, this.injectDataIndex, lastLength);
                           logger.fine(this.injectDataIndex + "+" + lastLength + "=" + (this.injectDataIndex + lastLength) + "<=" + this.fileLength);
                           this.injectDataIndex += lastLength;
                        } else {
                           System.arraycopy(b, 3, this.bigData, this.injectDataIndex, this.blockLength);
                           logger.fine(this.injectDataIndex + "+" + this.blockLength + "=" + (this.injectDataIndex + this.blockLength) + "<=" + this.fileLength);
                           this.injectDataIndex = this.injectDataIndex + this.blockLength;
                        }
                     }

                     this.setProgressValue(this.injectDataIndex);
                     this.updateWantedBlockNo();
                     return blockNo;
                  }
               }
            }
         }
      }
   }

   private void updateWantedBlockNo() {
      if (this.wantedBlockNo < 255) {
         this.wantedBlockNo++;
      } else {
         this.wantedBlockNo = 0;
      }
   }

   private void setProgressValue(int value) {
      this.iclp.getCommunicationListener().progressInfo(value);
   }

   private void setCommInfo(int length, String fileType) {
      this.iclp.getCommunicationListener().communicateInfo(length, fileType);
   }

   public String getFileType() {
      return this.fileType;
   }

   public byte[] getBigData() {
      return this.bigData;
   }

   public void startTransaction() {
      this.wantedBlockNo = 0;
      this.bigData = null;
      this.initialC();
   }

   private void initialC() {
      byte[] byte_C = new byte[]{67};

      try {
         this.os.write(byte_C);
         this.os.flush();
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      logger.fine("[YModem: initC]: C");
   }

   private void acknowledge() {
      byte[] ack = new byte[]{6};

      try {
         this.os.write(ack);
         this.os.flush();
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      logger.fine("[YModem: ack]: ACK");
   }

   private void disacknowledge() {
      byte[] nak = new byte[]{21};

      try {
         this.os.write(nak);
         this.os.flush();
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      logger.fine("[YModem: nak]: NAK");
   }

   public void cancelTransaction() {
      byte[] can = new byte[]{24, 24, 24};

      try {
         this.os.write(can);
         this.os.flush();
      } catch (IOException var3) {
         var3.printStackTrace();
      }

      logger.info(StringPool.LINE_SEPARATOR + "[YModem: can]: CAN, CAN, CAN");
      this.setProgressValue(0);
      this.bigData = null;
   }
}
