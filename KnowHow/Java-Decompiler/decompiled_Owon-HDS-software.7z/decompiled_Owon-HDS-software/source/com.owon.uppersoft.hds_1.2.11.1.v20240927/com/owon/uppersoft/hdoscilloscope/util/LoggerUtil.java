package com.owon.uppersoft.hdoscilloscope.util;

import com.owon.uppersoft.common.utils.FileUtil;
import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.logging.StreamHandler;

public class LoggerUtil {
   public static final int LogStrategy_FILEASCONSOLE = 1;
   public static int LogStrategy = 0;

   public static final void redirect2FileLog() {
      File ef = new File(PropertiesItem.ErrDir);
      File of = new File(PropertiesItem.LogDir);
      FileUtil.checkPath(ef);
      FileUtil.checkPath(of);
      PrintStream errps = null;
      PrintStream outps = null;

      try {
         errps = new PrintStream(ef);
         outps = new PrintStream(of);
      } catch (FileNotFoundException var5) {
         var5.printStackTrace();
      }

      if (outps != null) {
         System.setOut(outps);
         DBG.dbgln("start log:");
      }

      if (errps != null) {
         System.setErr(errps);
      }
   }

   public static Logger getFileLogger(String className, Level level, String dirPath) {
      Logger logger = Logger.getLogger(className);
      StreamHandler sh = null;
      SimpleFormatter formatter = new SimpleFormatter();
      File logDir = new File(dirPath);
      logDir.mkdirs();

      try {
         sh = new StreamHandler(new FileOutputStream(new File(logDir, className)), formatter);
         sh.setLevel(level);
         logger.addHandler(sh);
      } catch (FileNotFoundException var8) {
         var8.printStackTrace();
      }

      logger.setLevel(level);
      return logger;
   }

   public static Logger getConsoleLogger(String className, Level level) {
      Logger logger = Logger.getLogger(className);
      new SimpleFormatter();
      Handler sh = new Handler() {
         @Override
         public synchronized void publish(LogRecord record) {
            String msg = record.getMessage();
            System.out.println(msg);
         }

         @Override
         public void close() {
            this.flush();
         }

         @Override
         public void flush() {
            System.out.flush();
         }
      };
      sh.setLevel(level);
      logger.addHandler(sh);
      logger.setLevel(level);
      return logger;
   }
}
