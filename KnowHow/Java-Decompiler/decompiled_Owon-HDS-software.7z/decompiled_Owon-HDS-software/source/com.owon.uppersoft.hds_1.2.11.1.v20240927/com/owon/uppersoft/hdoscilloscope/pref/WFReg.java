package com.owon.uppersoft.hdoscilloscope.pref;

import org.eclipse.swt.graphics.RGB;

public class WFReg {
   private boolean create;
   private boolean show;
   private double zeroLocRate = 0.5;
   private boolean inverted = false;
   private RGB rgb = PropertiesItem.RGB_DARK_CYAN;

   public WFReg() {
      this(false, true);
   }

   public WFReg(boolean c, boolean s) {
      this.create = c;
      this.show = s;
   }

   public void setCreate(boolean create) {
      this.create = create;
   }

   public boolean isCreate() {
      return this.create;
   }

   public void setShow(boolean show) {
      this.show = show;
   }

   public boolean isShow() {
      return this.show;
   }

   public double getZeroLocRate() {
      return this.zeroLocRate;
   }

   public void setZeroLocRate(double zeroLocRate) {
      this.zeroLocRate = zeroLocRate;
   }

   public boolean isInverted() {
      return this.inverted;
   }

   public void setInverted(boolean inverted) {
      this.inverted = inverted;
   }

   public RGB getRGB() {
      return this.rgb;
   }

   public WFReg setRgb(RGB rgb) {
      this.rgb = rgb;
      return this;
   }
}
