package com.owon.uppersoft.hdoscilloscope.scpi;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.action.ActionFactory;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.model.detail.Idn;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

public class SCPIAction extends DefaultAction {
   private Shell shell;
   private ManipulateControl mc;
   private ScpiFrm mf;
   private ActionFactory af;
   private boolean deal = false;

   public SCPIAction(String id, ActionFactory af) {
      super(id);
      this.af = af;
   }

   public SCPIAction(String id, Shell shell, ManipulateControl mc) {
      super(id);
      this.shell = shell;
      this.mc = mc;
   }

   public ManipulateControl getManipulateControl() {
      return this.mc;
   }

   public void release() {
      this.reEnable();
   }

   public void reEnable() {
      this.deal = false;
      this.mf = null;
   }

   public void run() {
      if (!this.deal) {
         this.deal = true;
         this.mc = new ManipulateControl(this.af.loopControl, new Idn("OWON,XDS3102a,0000000,V1.0"));
         this.mf = new ScpiFrm(this.shell, this);
         this.mf.open();
      }
   }

   private void loadSCPI(int len) {
      if (len <= 0) {
         ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle2();
         String errDefault = ResourceBundleProvider.getMessageLibResourceBundle().getString("Err.Default");
         String msg = bundle.getString("Warn.noSupportScpi");
         MessageDialog.openError(this.shell, errDefault, msg);
         this.reEnable();
      } else {
         this.mf = new ScpiFrm(this.shell, this);
         this.mf.open();
      }
   }

   public void open() {
      this.mf = new ScpiFrm(this.shell, this);
      this.mf.open();
   }
}
