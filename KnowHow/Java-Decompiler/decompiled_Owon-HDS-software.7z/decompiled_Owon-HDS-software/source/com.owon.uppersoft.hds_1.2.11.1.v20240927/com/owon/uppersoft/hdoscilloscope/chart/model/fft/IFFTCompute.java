package com.owon.uppersoft.hdoscilloscope.chart.model.fft;

import com.owon.uppersoft.hdoscilloscope.chart.aspect.DrawCompute;

public interface IFFTCompute extends DrawCompute {
   void updateWndType();

   void resumeToMode();

   String getFreqBaseTxt(int var1);
}
