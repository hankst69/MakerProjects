package com.owon.uppersoft.hdoscilloscope.pref;

public class MathReg extends WFReg {
   public int mt = 0;

   public MathReg() {
      super(false, true);
   }
}
