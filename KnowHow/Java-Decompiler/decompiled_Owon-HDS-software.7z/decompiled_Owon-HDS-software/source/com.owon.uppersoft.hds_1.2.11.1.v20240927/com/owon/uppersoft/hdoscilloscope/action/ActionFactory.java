package com.owon.uppersoft.hdoscilloscope.action;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.AutoPlayerAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.BgColorAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.DataLineAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.DataPointAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.DataTableAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.EditModleAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.GetDataAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.GetSaveDataAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.PageSetupAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.PortsAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.PrintAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.PrintPreviewAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.SaveImageAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.UpdateAction;
import com.owon.uppersoft.hdoscilloscope.action.instance.WaveXYAction;
import com.owon.uppersoft.hdoscilloscope.action.instance2.AboutAction;
import com.owon.uppersoft.hdoscilloscope.action.instance2.ExitAction;
import com.owon.uppersoft.hdoscilloscope.action.instance2.GridColorAction;
import com.owon.uppersoft.hdoscilloscope.action.instance2.GridLinesAction;
import com.owon.uppersoft.hdoscilloscope.action.instance2.HelpAction;
import com.owon.uppersoft.hdoscilloscope.action.instance2.KeepAction;
import com.owon.uppersoft.hdoscilloscope.action.instance2.Open4kAction;
import com.owon.uppersoft.hdoscilloscope.action.instance2.OpenAction;
import com.owon.uppersoft.hdoscilloscope.action.instance2.StopAction;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.communication.loop.LoopControl;
import com.owon.uppersoft.hdoscilloscope.frame.view.Center;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.image.ImageShop;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManiAction;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import com.owon.uppersoft.hdoscilloscope.manipulate.mm.MMManiAction;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import com.owon.uppersoft.hdoscilloscope.scpi.SCPIAction;
import com.owon.uppersoft.hdoscilloscope.scpi.mm.SCPIMMAction;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Shell;

public class ActionFactory {
   private Configuration config;
   List<DefaultAction> actions;
   private Platform pf;
   public final DefaultAction gridColor = new GridColorAction("gridColor");
   public final DefaultAction saveImage = new SaveImageAction("saveImage");
   public final BgColorAction bgColor = new BgColorAction("bgColor");
   public final OpenAction open = new OpenAction("open");
   public final Open4kAction open4k = new Open4kAction("open4k", 32);
   public final HelpAction help = new HelpAction("help");
   public final DefaultAction update = new UpdateAction("update");
   public final DataTableAction dataTable = new DataTableAction("dataTable");
   public final AutoPlayerAction autoplayer = new AutoPlayerAction("autoplayer");
   public final DefaultAction exit = new ExitAction("exit");
   public final DefaultAction keep = new KeepAction("keep");
   public final DefaultAction stop = new StopAction("stop");
   public final DefaultAction pageSetup = new PageSetupAction("pageSetup");
   public final DefaultAction print = new PrintAction("print");
   public final DefaultAction printPreview = new PrintPreviewAction("printPreview");
   public final DefaultAction waveXY = new WaveXYAction("waveXY", 32);
   public final DefaultAction gridLines = new GridLinesAction("gridLines", 32);
   public final DefaultAction dataLine = new DataLineAction("dataLine", 16);
   public final DefaultAction dataPoint = new DataPointAction("dataPoint", 16);
   public final DefaultAction ports = new PortsAction("ports");
   public final DefaultAction getData = new GetDataAction("getData");
   public final DefaultAction getSaveData = new GetSaveDataAction("getSaveData");
   public final DefaultAction about = new AboutAction("about");
   public final ManiAction manipulate = new ManiAction("manipulate", this);
   public final MMManiAction mmMainAction = new MMManiAction("mmMainAction", this);
   public final SCPIMMAction scpi = new SCPIMMAction("mmscpi", this);
   public final DefaultAction commandline = new SCPIAction("commandline", this);
   public final DefaultAction editmodel = new EditModleAction("editmodel");
   public final LocalizeUtil localizeUtil = new LocalizeUtil(this);
   public final LoopControl loopControl;

   public ActionFactory() {
      this.pf = Platform.getPlatform();
      this.config = this.pf.getConfiguration();
      this.loopControl = new LoopControl(this.pf);
      this.actions = new ArrayList<>();
      this.actions.add(this.gridColor);
      this.actions.add(this.saveImage);
      this.actions.add(this.bgColor);
      this.actions.add(this.open);
      this.actions.add(this.open4k);
      this.actions.add(this.print);
      this.actions.add(this.printPreview);
      this.actions.add(this.pageSetup);
      this.actions.add(this.dataLine);
      this.actions.add(this.dataPoint);
      this.actions.add(this.ports);
      this.actions.add(this.getData);
      this.actions.add(this.getSaveData);
      this.actions.add(this.dataTable);
      this.actions.add(this.about);
      this.actions.add(this.gridLines);
      this.actions.add(this.waveXY);
      this.actions.add(this.exit);
      this.actions.add(this.keep);
      this.actions.add(this.stop);
      this.actions.add(this.help);
      this.actions.add(this.update);
      this.actions.add(this.autoplayer);
      this.actions.add(this.manipulate);
      this.actions.add(this.scpi);
      this.actions.add(this.commandline);
      this.actions.add(this.editmodel);
      ImageShop is = this.pf.getImageShop();
      this.autoplayer.setImage(is.getImage("player.png"));
      if (this.config.haveClickCOMM) {
         this.ports.setImage(is.getImage("ports.gif"));
      } else {
         this.ports.setImage(is.getImage("ports_star.gif"));
      }

      for (DefaultAction da : this.actions) {
         String id = da.getId();
         if (da != this.ports && id != null && id.length() != 0) {
            Image img = is.getImage(da.getId() + ".gif");
            if (img != null) {
               da.setImage(img);
            }
         }
      }
   }

   public void exit() {
      Shell shell = this.pf.getShell();
      Center center = this.pf.getCenter();
      this.dataTable.shutdown();
      this.loopControl.stopLoop();
      this.config.locale = Locale.getDefault();
      DrawingPanel dp = center.getDrawingPanel();
      this.config.lineVisible = dp.getWaveFormFileCurve().isLineVisible();
      this.config.dottedGraticuleVisible = dp.getBackgroundDraw().isDottedGraticuleVisible();
      this.config.fileHistory = this.pf.getMainFrame().getFileHistoryUtil().getFileHistory();
      this.config.reg = dp.getWaveFormFileCurve().getReg();
      this.config.notifyUSBchange = this.pf.getMainFrame().getStatusLine().shouldPopupCheck();
      this.config.shellsize = shell.getSize();
      this.config.upSash = center.getUpSash().getWeights();
      this.config.downSash = center.getDownSash().getWeights();
      this.config.mainSash = center.getMainSash().getWeights();
      this.config.bgrgb = dp.getBackgroundDraw().getBackgroundRGB();
      this.config.gridrgb = dp.getBackgroundDraw().getGridRGB();
      this.config.imgScalergb = center.getImageScale().getBackgoundRGB();
      Platform.reset();
   }

   public void localizeChildren(ResourceBundle bundle) {
      ResourceBundle rb2 = ResourceBundleProvider.getMessageLibResourceBundle2();

      for (DefaultAction da : this.actions) {
         if (da instanceof ManiAction) {
            da.localize(rb2);
         } else {
            da.localize(bundle);
         }
      }
   }

   public ManipulateControl getManipulateControl() {
      return this.manipulate.getManipulateControl();
   }

   public Shell getShell() {
      return this.pf.getShell();
   }
}
