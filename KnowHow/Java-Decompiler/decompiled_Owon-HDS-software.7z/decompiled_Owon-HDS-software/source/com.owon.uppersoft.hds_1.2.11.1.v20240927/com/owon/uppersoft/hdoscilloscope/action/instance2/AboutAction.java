package com.owon.uppersoft.hdoscilloscope.action.instance2;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.frame.view.AboutDialog;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class AboutAction extends DefaultAction {
   public AboutAction(String id) {
      super(id);
   }

   public void run() {
      new AboutDialog(Platform.getPlatform().getShell()).open();
   }
}
