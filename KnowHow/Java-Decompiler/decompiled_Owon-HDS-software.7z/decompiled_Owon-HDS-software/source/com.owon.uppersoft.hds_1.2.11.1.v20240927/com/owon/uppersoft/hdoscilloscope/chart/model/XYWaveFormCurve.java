package com.owon.uppersoft.hdoscilloscope.chart.model;

import com.owon.uppersoft.common.aspect.Disposable;
import com.owon.uppersoft.common.utils.DisposeUtil;
import com.owon.uppersoft.hdoscilloscope.chart.ContextDrawable;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.chart.GraphicContext;
import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.model.IPublicM;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

public class XYWaveFormCurve implements ContextDrawable, Disposable {
   private boolean XYAvailable;
   private PrototypeWaveFormCurve wfc1;
   private PrototypeWaveFormCurve wfc2;
   private DrawingPanel dp;
   private Color color;
   private List<Point> pointSet;

   public XYWaveFormCurve(WaveFormFileCurve wffc) {
      this.dp = wffc.getDrawingPanel();
      this.color = new Color(this.dp.getComposite().getDisplay(), IPublicM.DefaultXYModeRGB);
      this.XYAvailable = wffc.getWaveFormFile().is1size2();
      if (this.XYAvailable) {
         this.wfc1 = (PrototypeWaveFormCurve)wffc.getWaveFormCurve("CH1");
         this.wfc2 = (PrototypeWaveFormCurve)wffc.getWaveFormCurve("CH2");
      }
   }

   @Override
   public void draw(GraphicContext gx) {
      GC gc = gx.gc;
      gc.setForeground(this.color);
      this.drawStuff(gx);
   }

   protected void setupPointSet(Point size) {
      WaveForm wf1 = this.wfc1.getWaveForm();
      WaveForm wf2 = this.wfc2.getWaveForm();
      int[] sht1 = wf1.getIntADCollection();
      int[] sht2 = wf2.getIntADCollection();
      double cx = (double)(size.x >> 1);
      double cy = (double)(size.y >> 1);
      int length = sht1.length;
      List<Point> pSet;
      if (this.pointSet == null) {
         pSet = new ArrayList<>(length);

         for (int i = 0; i < length; i++) {
            pSet.add(new Point(0, 0));
         }
      } else {
         pSet = this.pointSet;
      }

      ScalableDrawEngine dr1 = this.wfc1.getScalableDrawEngine();
      ScalableDrawEngine dr2 = this.wfc2.getScalableDrawEngine();
      double pixYPerPoint1 = dr1.getAbsoluteScaleY() * dr1.getPixYPerPoint();
      WaveFormFile wff = wf1.getWaveFormFile();
      double scale = wff.getXGraticuleNum() / (double)wff.getYGraticuleNum();
      if (Math.abs(wff.getXGraticuleNum() - (double)wff.getYGraticuleNum()) < 0.001) {
         pixYPerPoint1 *= scale;
      }

      double pixYPerPoint2 = dr2.getAbsoluteScaleY() * dr2.getPixYPerPoint();
      double zeroYLocation1 = dr1.getZeroYLocation();
      double zeroYLocation2 = dr2.getZeroYLocation();

      for (int i = 0; i < length; i++) {
         double locationX = cy - (zeroYLocation1 - (double)sht1[i] * pixYPerPoint1);
         double locationY = zeroYLocation2 - (double)sht2[i] * pixYPerPoint2 - cy;
         Point point = pSet.get(i);
         point.x = (int)(locationX + cx);
         point.y = (int)(locationY + cy);
      }

      this.pointSet = pSet;
   }

   protected void drawStuff(GraphicContext gx) {
      GC gc = gx.gc;
      Point size = gx.size;
      if (!this.XYAvailable) {
         String prompt = ResourceBundleProvider.getMessageLibResourceBundle().getString("Info.XYModeUnsupported");
         Point sp = gc.stringExtent(prompt);
         gc.drawText(prompt, (size.x >> 1) - (sp.x >> 1), (size.y >> 1) - (sp.y >> 1), true);
      } else {
         this.setupPointSet(size);
         int psize = this.pointSet.size();

         for (int i = 0; i < psize; i++) {
            Point p = this.pointSet.get(i);
            gc.drawLine(p.x, p.y, p.x, p.y);
         }
      }
   }

   public boolean isXYAvailable() {
      return this.XYAvailable;
   }

   public void dispose() {
      DisposeUtil.tryDispose(this.color);
   }
}
