package com.owon.uppersoft.hdoscilloscope.communication;

import net.sf.json.JSONArray;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.Viewer;

class TableViewerContentProvider implements IStructuredContentProvider {
   public Object[] getElements(Object element) {
      return element instanceof JSONArray ? ((JSONArray)element).toArray() : new Object[0];
   }

   public void dispose() {
   }

   public void inputChanged(Viewer arg0, Object arg1, Object arg2) {
   }
}
