package com.owon.uppersoft.hdoscilloscope.action.instance2;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.common.aspect.Linkable;
import com.owon.uppersoft.common.utils.FileUtil;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.data.transform.RapidDataImport;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.util.FileChooserUtil;
import java.io.File;
import java.io.IOException;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

public class OpenAction extends DefaultAction implements Linkable {
   private boolean isFirstTime = true;

   public OpenAction(String id) {
      super(id);
   }

   public void run() {
      this.doOpenFile();
   }

   public void doOpenFile() {
      Platform pf = Platform.getPlatform();
      FileDialog fd = new FileDialog(pf.getShell(), 4096);
      String wildcard = "*.";
      String[] ss = new String[]{wildcard + "bin"};
      fd.setFilterExtensions(ss);
      fd.setFilterNames(ss);
      if (this.isFirstTime) {
         fd.setFilterPath(pf.getConfiguration().getExampleDir());
         this.isFirstTime = false;
      }

      String path = fd.open();
      this.doOpenFile(path);
   }

   public void doOpenFile(String path) {
      if (path != null && !path.equals("")) {
         File file = new File(path);
         this.doOpenFile(file);
      }
   }

   public void doOpenFile(File file) {
      this.doOpenFile(file, true);
   }

   public void doOpenFile(File file, boolean prompt) {
      try {
         file = file.getCanonicalFile();
      } catch (IOException var11) {
         var11.printStackTrace();
      }

      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      String errDefault = bundle.getString("Err.Default");
      String fileName = file.getName();
      String filepath = file.getPath();
      String ext = FileUtil.getExtension(fileName);
      Shell shell = Platform.getPlatform().getShell();
      if (!ext.equalsIgnoreCase("bin")) {
         if (prompt) {
            String msg = bundle.getString("Err.BadFormatFile");
            MessageDialog.openInformation(shell, errDefault, msg + filepath);
         }
      } else if (FileChooserUtil.checkFileReadable(shell, file)) {
         WaveFormFile wff = new RapidDataImport().getWaveFormFile(file, Platform.getPlatform().getMainFrame().ctrlMgr);
         if (wff == null) {
            if (prompt) {
               String msg = bundle.getString("Err.BadContentFile");
               MessageDialog.openError(shell, errDefault, msg + filepath);
            }
         } else {
            Platform.getPlatform().getMainFrame().setWaveFormFile(wff);
         }
      }
   }

   public void link(String path) {
      this.doOpenFile(path);
   }
}
