package com.owon.uppersoft.hdoscilloscope.chart;

import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.XYWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;

public class WaveFormFileCurveRenderer implements ContextDrawable {
   private WaveFormFileCurve wffc;

   public WaveFormFileCurveRenderer(WaveFormFileCurve fileCurve) {
      this.wffc = fileCurve;
   }

   @Override
   public void draw(GraphicContext gx) {
      boolean XYChosen = this.wffc.isXYChosen();
      XYWaveFormCurve xyCurve = this.wffc.getXYWaveFormCurve();
      if (XYChosen && xyCurve != null) {
         xyCurve.draw(gx);
      } else {
         this.wffc.drawStuff(gx);
         WaveFormCurve selected = this.wffc.getSelectedWaveFormCurve();

         for (WaveFormCurve cur : this.wffc.all_collect()) {
            if (cur != null && cur != selected) {
               cur.draw(gx);
            }
         }

         if (selected != null) {
            selected.draw(gx);
         }
      }
   }

   public void drawWithoutSelect(GraphicContext gx) {
      WaveFormCurve wfc = this.wffc.getSelectedWaveFormCurve();
      if (wfc != null) {
         boolean v = wfc.isVisible();
         wfc.setVisible(false);
         this.draw(gx);
         wfc.setVisible(v);
      }
   }

   public void drawSelect(GraphicContext gx) {
      WaveFormCurve wfc = this.wffc.getSelectedWaveFormCurve();
      if (wfc != null) {
         wfc.draw(gx);
      }
   }
}
