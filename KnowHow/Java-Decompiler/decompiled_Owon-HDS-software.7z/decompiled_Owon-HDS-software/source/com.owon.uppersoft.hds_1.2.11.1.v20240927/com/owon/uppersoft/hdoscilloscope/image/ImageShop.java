package com.owon.uppersoft.hdoscilloscope.image;

import com.owon.uppersoft.hdoscilloscope.global.Platform;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;

public class ImageShop {
   public static final String ImageDirPath = "/com/owon/uppersoft/hdoscilloscope/image/";
   public static final String NeutralImageDirPath = "/com/owon/uppersoft/hdoscilloscope/neutral/image/";
   public static final String AboutPath = "about_.gif";
   public static final String BadConnectPath = "bad_connect.png";
   public static final String DataTablePath = "dataTable.gif";
   public static final String GoodConnectPath = "good_connect.png";
   public static final String GetData = "getData.gif";
   public static final String MFTitlePath = "MainFrame.gif";
   public static final String Autoplayer = "player.png";
   public static final String PortsSettingsPath = "ports.gif";
   public static final String PrintPreviewPath = "printPreview.gif";
   public static final String SplashscreenPath = "splash.gif";
   public static final String UncheckConnectPath = "uncheck_connect.gif";
   public static final String WarnPath = "msg_icon_warn.gif";
   private Map<String, Image> reg;
   private Display display;

   public ImageShop(Display display) {
      this.display = display;
      this.reg = new HashMap<>();
   }

   public Image getImage(String key) {
      Image image = this.reg.get(key);
      if (image != null) {
         return image;
      } else {
         InputStream is = null;
         if (Platform.getPlatform().getConfiguration().isNeutral()) {
            is = ImageShop.class.getResourceAsStream("/com/owon/uppersoft/hdoscilloscope/neutral/image/" + key);
         }

         if (is == null) {
            is = ImageShop.class.getResourceAsStream("/com/owon/uppersoft/hdoscilloscope/image/" + key);
         }

         if (is == null) {
            return null;
         } else {
            image = new Image(this.display, is);
            this.reg.put(key, image);
            return image;
         }
      }
   }

   public void dispose() {
      for (Image image : this.reg.values()) {
         image.dispose();
      }
   }

   public void disposeImage(Image image) {
      Image img = this.reg.get(image);
      if (img != null) {
         img.dispose();
         this.reg.remove(img);
      }
   }

   public static void main(String[] args) {
      InputStream is = ImageShop.class.getResourceAsStream("/com/owon/uppersoft/hdoscilloscope/image/about_.gif");
      System.out.println(is);
   }
}
