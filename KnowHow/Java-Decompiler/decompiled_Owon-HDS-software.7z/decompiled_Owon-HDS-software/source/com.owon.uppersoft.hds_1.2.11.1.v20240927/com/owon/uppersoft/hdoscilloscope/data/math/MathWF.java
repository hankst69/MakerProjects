package com.owon.uppersoft.hdoscilloscope.data.math;

import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;

public class MathWF extends WaveForm {
   private WaveFormFile swff;

   public MathWF(WaveFormFile wff) {
      this.swff = wff;
      this.prepareFFTInfo();
   }

   @Override
   public WaveFormFile getWaveFormFile() {
      return this.swff;
   }

   @Override
   public WaveFormCurve createWFC(WaveFormFileCurve wffc, WFReg wr) {
      WaveFormCurve wfc;
      if (this.isDepMem()) {
         wfc = new SDSMemdepthWFC(this, wffc, wr);
      } else {
         wfc = new SDSAlphaWFC(this, wffc, wr);
      }

      return wfc;
   }

   @Override
   public int getIntVoltageBase() {
      return 0;
   }
}
