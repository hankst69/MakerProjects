package com.owon.uppersoft.hdoscilloscope.chart.model.fft.mathD;

import com.owon.uppersoft.hdoscilloscope.chart.model.fft.math.IComplex;

public class AfterFFTD {
   public static final void fft_math_rms(IComplex[] cs, int[] data) {
      int length = data.length;
      double s = 1800.0;
      IComplex tc = cs[0];
      data[0] = (int)(Math.hypot(tc.re(), tc.im()) / s);
      s = (double)(length * 2) / 1.4;

      for (int i = 1; i < length; i++) {
         tc = cs[i];
         data[i] = (int)(Math.hypot(tc.re(), tc.im()) / s);
      }
   }

   public static final void fft_math_dB(IComplex[] cs, int[] data, double[] temps, double vb) {
      int length = data.length;
      double r = 0.0;

      for (int i = 0; i < length; i++) {
         IComplex tc = cs[i];
         double t = Math.pow(tc.re(), 2.0) + Math.pow(tc.im(), 2.0);
         r += t;
         temps[i] = Math.sqrt(t) / (double)length * vb;
      }

      r = 1000.0;
      double min = vb / 2000.0 / Math.sqrt(2.0) / 16.0;

      for (int i = 0; i < length; i++) {
         double t = temps[i] / r;
         t = t >= min ? t : min;
         data[i] = (int)(Math.log10(t) * 20.0);
      }
   }

   public static final void fft_math_dB_e(IComplex[] cs, int[] data, double[] temps, double vb) {
      int length = data.length;
      double r = 0.0;

      for (int i = 0; i < length; i++) {
         IComplex tc = cs[i];
         r += temps[i] = Math.pow(tc.re(), 2.0) + Math.pow(tc.im(), 2.0);
      }

      for (int i = 0; i < length; i++) {
         double t = temps[i];
         if (t != 0.0) {
            data[i] = (int)(Math.log10(t * (double)length / r) * 10.0);
         } else {
            data[i] = -20;
         }
      }
   }
}
