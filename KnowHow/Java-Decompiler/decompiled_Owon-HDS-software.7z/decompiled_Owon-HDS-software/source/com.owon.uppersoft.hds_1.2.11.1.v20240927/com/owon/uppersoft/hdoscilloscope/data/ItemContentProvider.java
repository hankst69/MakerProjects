package com.owon.uppersoft.hdoscilloscope.data;

import org.eclipse.jface.viewers.ILazyContentProvider;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;

public class ItemContentProvider implements IStructuredContentProvider, ILazyContentProvider {
   private TableViewer viewer;
   private ItemModel[] elements;

   public ItemContentProvider(TableViewer viewer) {
      this.viewer = viewer;
   }

   public Object[] getElements(Object inputElement) {
      return this.elements;
   }

   public void dispose() {
   }

   public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
      this.elements = (ItemModel[])newInput;
   }

   public void updateElement(int index) {
      this.viewer.replace(this.elements[index], index);
   }
}
