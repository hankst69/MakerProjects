package com.owon.uppersoft.hdoscilloscope.communication.loop;

public interface ICommunicationListenerProvider {
   ICommunicationListener EmptyICL = new ICommunicationListener() {
      @Override
      public void communicateInfo(int length, String fileType) {
      }

      @Override
      public void progressInfo(int value) {
      }

      @Override
      public void communicateInfo_ifn(int times, String fileType) {
      }

      @Override
      public void progressInfo_ifn(int value) {
      }
   };

   ICommunicationListener getCommunicationListener();

   void setICL();

   void resetICL();
}
