package com.owon.uppersoft.hdoscilloscope.data;

import com.owon.uppersoft.common.utils.StringPool;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.FFTInfo;
import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import com.owon.uppersoft.hdoscilloscope.data.transform.RapidDataImport;
import com.owon.uppersoft.hdoscilloscope.model.MachineType;
import com.owon.uppersoft.hdoscilloscope.model.PublicM;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;
import com.owon.uppersoft.hdoscilloscope.util.UnitConversionUtil;
import java.util.LinkedList;
import java.util.List;
import org.eclipse.swt.graphics.Point;

public abstract class WaveForm {
   public static final int IntChannelTypeLength = 3;
   private String strChannelType;
   private int intBlockSize;
   private int intFullScreenDataNum;
   private int intADCollectionNum;
   private int intLowMoveNum;
   private int intTimeBase;
   private int intZeroYPoint;
   private int intVoltageBase;
   private double intAttenuation;
   private double dblTimeInterval;
   private double dblFrequency;
   private double dblPeriod;
   private double dblVoltagePerPoint;
   private double peaksValue;
   private int[] intADCollection;
   private int[] originalAD;
   private int desireXbase;
   private int desireYbase;
   private boolean currMeas;
   private int curRate;
   private FFTInfo fwf;
   private boolean isDepMem;
   private int screenStartLoc = 0;
   private float compressRate = 0.0F;
   private String FFTName;
   private int maxShtADData;
   private int minShtADData;
   private boolean fftcomputable;
   private boolean isLowMove;
   private String txtFreq;
   private String txtPeriod;
   private String txtPk;
   private List<TxtEntry> argTxts = new LinkedList<>();
   private int upperCount;
   private int lowerCount;
   private int memdepthDataIndex = -1;
   private static double[] sample8102 = new double[]{
      4.8E7,
      2.4E7,
      1.2E7,
      8000000.0,
      4000000.0,
      2000000.0,
      1000000.0,
      500000.0,
      250000.0,
      125000.0,
      62500.0,
      25000.0,
      5000.0,
      2500.0,
      1000.0,
      500.0,
      200.0,
      100.0,
      50.0,
      20.0,
      10.0,
      5.0,
      2.0,
      1.0,
      0.5,
      0.2,
      0.1,
      0.05,
      0.02,
      0.01,
      0.005,
      0.002,
      0.001,
      5.0E-4
   };
   private static double[] sample7102 = new double[]{
      1.6E7,
      8000000.0,
      4000000.0,
      2000000.0,
      1000000.0,
      500000.0,
      250000.0,
      125000.0,
      62500.0,
      25000.0,
      12500.0,
      5000.0,
      2500.0,
      1000.0,
      500.0,
      200.0,
      100.0,
      50.0,
      20.0,
      10.0,
      5.0,
      2.0,
      1.0,
      0.5,
      0.2,
      0.1,
      0.05,
      0.02,
      0.01,
      0.005,
      0.002,
      0.001
   };
   private static double[] samplemso7102 = new double[]{
      1000000.0,
      1000000.0,
      1000000.0,
      1000000.0,
      1000000.0,
      1000000.0,
      500000.0,
      250000.0,
      125000.0,
      62500.0,
      25000.0,
      5000.0,
      2500.0,
      1000.0,
      500.0,
      200.0,
      100.0,
      50.0,
      20.0,
      10.0,
      5.0,
      2.0,
      1.0,
      0.5,
      0.2,
      0.1,
      0.05,
      0.02,
      0.01,
      0.005,
      0.002,
      0.001,
      5.0E-4
   };
   private static double[] sample6062 = new double[]{
      250000.0,
      250000.0,
      250000.0,
      250000.0,
      250000.0,
      250000.0,
      125000.0,
      62500.0,
      25000.0,
      12500.0,
      5000.0,
      2500.0,
      1000.0,
      500.0,
      200.0,
      100.0,
      50.0,
      20.0,
      10.0,
      5.0,
      2.0,
      1.0,
      0.5,
      0.2,
      0.1,
      0.05,
      0.02,
      0.01,
      0.005,
      0.002,
      0.001,
      5.0E-4
   };
   private static double[] sample5022 = new double[]{
      3200000.0,
      1600000.0,
      800000.0,
      400000.0,
      200000.0,
      100000.0,
      50000.0,
      20000.0,
      10000.0,
      5000.0,
      2000.0,
      1000.0,
      500.0,
      200.0,
      100.0,
      50.0,
      20.0,
      10.0,
      5.0,
      2.0,
      1.0,
      0.5,
      0.2,
      0.1,
      0.05,
      0.02,
      0.01,
      0.005,
      0.002,
      0.001,
      5.0E-4
   };
   public Point lp = new Point(0, 0);

   public abstract WaveFormFile getWaveFormFile();

   public abstract WaveFormCurve createWFC(WaveFormFileCurve var1, WFReg var2);

   public void patchADCImport(CByteArrayInputStream ba) {
      if (this.isLowMove()) {
         int intFullScreenDataNum = this.getIntFullScreenDataNum();
         int adnum = this.getIntADCollectionNum();
         if (intFullScreenDataNum - adnum > 0) {
            int sk = intFullScreenDataNum - adnum << 1;
            ba.skip(sk);
         }
      }
   }

   public void setDesireXbase(int desireXbase) {
      this.desireXbase = desireXbase;
   }

   public void setDesireYbase(int desireYbase) {
      this.desireYbase = desireYbase;
   }

   public int getDesireXbase() {
      return this.desireXbase;
   }

   public int getDesireYbase() {
      return this.desireYbase;
   }

   public FFTInfo getFFTInfo() {
      return this.fwf;
   }

   public PublicM getPublicM() {
      return this.getWaveFormFile().getPublicM();
   }

   protected WaveForm() {
   }

   private WaveForm(WaveFormFile wff) {
      this();
      this.prepareFFTInfo();
   }

   protected void prepareFFTInfo() {
      this.fwf = new FFTInfo(this);
   }

   public void doMoreReadFromDataImport(RapidDataImport rdi) {
   }

   protected double getPeaksValue() {
      return this.peaksValue;
   }

   protected void computePeaksValue() {
      this.peaksValue = (double)(this.maxShtADData - this.minShtADData) * this.dblVoltagePerPoint;
      System.out.println("value:" + this.maxShtADData + "  " + this.minShtADData);
   }

   public void setOriginalAD(int[] originalAD) {
      this.originalAD = originalAD;
   }

   public int[] getOriginalAD() {
      return this.originalAD;
   }

   public void setIntADCollection(int[] intADCollection) {
      this.intADCollection = intADCollection;
   }

   public int[] getIntADCollection() {
      return this.intADCollection;
   }

   public void setDblVoltagePerPoint(double dblBasicVoltage) {
      this.dblVoltagePerPoint = dblBasicVoltage;
   }

   public double getDblVoltagePerPoint() {
      return this.dblVoltagePerPoint;
   }

   public void setDblPeriod(double dblPeriod) {
      this.dblPeriod = dblPeriod;
   }

   protected double getDblPeriod() {
      return this.dblPeriod;
   }

   public void setDblFrequency(double dblFrequency) {
      this.dblFrequency = dblFrequency;
   }

   protected double getDblFrequency() {
      return this.dblFrequency;
   }

   public void setDblTimeInterval(double dblTimeInterval) {
      this.dblTimeInterval = dblTimeInterval;
   }

   public double getDblTimeInterval() {
      return this.dblTimeInterval;
   }

   public void setIntAttenuationMultiple(double intAttenuation) {
      this.intAttenuation = intAttenuation;
   }

   public double getIntAttenuationMultiple() {
      return this.intAttenuation;
   }

   public void setIntVoltageBase(int intVoltageBase) {
      this.intVoltageBase = intVoltageBase;
   }

   public void setIntVoltageBase(double dblVoltageBase) {
      int index = this.getPublicM().getchVvIndexForCertainValue(dblVoltageBase);
      this.setIntVoltageBase(index);
   }

   public int getIntVoltageBase() {
      return this.intVoltageBase;
   }

   public void setIntZeroYPoint(int intZeroPoint) {
      this.intZeroYPoint = intZeroPoint;
   }

   public int getIntZeroYPoint() {
      return this.intZeroYPoint;
   }

   public void setIntTimeBase(double dblTimeBase) {
      int index = this.getPublicM().getTimebaseIdxForCertainValue(dblTimeBase);
      this.setIntTimeBase(index);
   }

   public void setIntTimeBase(int intTimeBase) {
      this.intTimeBase = intTimeBase;
   }

   public int getIntTimeBase() {
      return this.intTimeBase;
   }

   public void setIntLowMoveNum(int intLowMoveNum) {
      this.intLowMoveNum = intLowMoveNum;
      if (intLowMoveNum > -1) {
         this.isLowMove = true;
      } else {
         int var2 = false;
      }
   }

   public int getIntLowMoveNum() {
      return this.intLowMoveNum;
   }

   public void setIntADCollectionNum(int intADCollectionNum) {
      this.intADCollectionNum = intADCollectionNum;
   }

   public int getIntADCollectionNum() {
      return this.intADCollectionNum;
   }

   public void setIntFullScreenDataNum(int intFullScreenDataNum) {
      this.intFullScreenDataNum = intFullScreenDataNum;
   }

   public int getIntFullScreenDataNum() {
      return this.intFullScreenDataNum;
   }

   public int getScreenStartLocation() {
      return this.screenStartLoc;
   }

   public void setScreenStartLocation(int value) {
      this.screenStartLoc = value;
   }

   public float getCompressRate() {
      return this.compressRate;
   }

   public void setCompressRate(float value) {
      this.compressRate = value;
   }

   public boolean isDepMem() {
      return this.isDepMem;
   }

   public void setDemMem(boolean isDepMem) {
      this.isDepMem = isDepMem;
   }

   public void setIntBlockSize(CByteArrayInputStream ba, int intBlockSize) {
      this.intBlockSize = intBlockSize;
   }

   public int getIntBlockSize() {
      return this.intBlockSize;
   }

   public void setStrChannelType(String strChannelType) {
      this.strChannelType = strChannelType;
   }

   public String getStrChannelType() {
      return this.strChannelType;
   }

   public String getStrChannelTypeWithUnit() {
      return this.isCurrMeas() ? this.strChannelType + "(Unit:mA)" : this.strChannelType + "(Unit:V)";
   }

   public String getFFTName() {
      return "fft1";
   }

   public double getRateYAsAttenuation() {
      return this.intAttenuation;
   }

   public void setMaxShtAndMinShtADData(int maxShtADData, int minShtADData) {
      this.maxShtADData = maxShtADData;
      this.minShtADData = minShtADData;
   }

   public int getMaxShtADData() {
      return this.maxShtADData;
   }

   public int getMinShtADData() {
      return this.minShtADData;
   }

   public boolean isFFTComputable() {
      return this.fftcomputable;
   }

   public void beginFill() {
   }

   public void endAndCompute() {
      this.computePeaksValue();
      this.prepareArgTxts();
      this.fwf.endAndCompute(this);
      this.getPublicM();
      this.fftcomputable = !this.isLowMove();
      if (!this.getFFTInfo().isProtoFFT()) {
         if (!this.isDepMem()) {
            this.checkLowMove();
         }
      }
   }

   protected void prepareArgTxts() {
      this.getWaveFormFile();
      if (!(this.dblFrequency <= 0.0) && !Double.isInfinite(this.dblFrequency) && !Double.isNaN(this.dblFrequency)) {
         this.txtFreq = UnitConversionUtil.getFrequencyLabel_Hz(this.dblFrequency);
      } else {
         this.txtFreq = "?";
         this.dblFrequency = 0.0;
      }

      if (!(this.dblPeriod <= 0.0) && !Double.isInfinite(this.dblPeriod) && !Double.isNaN(this.dblPeriod)) {
         this.txtPeriod = UnitConversionUtil.getTextFor_uS(this.dblPeriod);
      } else {
         this.txtPeriod = "?";
         this.dblPeriod = 0.0;
      }

      if (this.upperCount != this.intADCollectionNum && this.lowerCount != this.intADCollectionNum) {
         if (this.isCurrMeas()) {
            this.txtPk = UnitConversionUtil.getCurrentLabel_ma(this.peaksValue * (double)this.getCurRate());
         } else {
            this.txtPk = UnitConversionUtil.getVoltageLabel_V(this.peaksValue);
         }

         if (this.upperCount > 0 || this.lowerCount > 0) {
            this.txtPk = this.txtPk + " ?";
         }
      } else {
         this.txtPk = "?";
      }

      this.addArg("Center.Freq", this.txtFreq);
      this.addArg("Center.Period", this.txtPeriod);
      if (!this.fwf.isProtoFFT()) {
         this.addArg("Center.PKPK", this.txtPk);
      }
   }

   public TxtEntry addArg(boolean useKey, String n, String v) {
      for (int i = 0; i < this.argTxts.size(); i++) {
         TxtEntry te = this.argTxts.get(i);
         if (n.equalsIgnoreCase(te.n)) {
            this.argTxts.remove(i);
            this.argTxts.add(i, te = new TxtEntry(useKey, n, v));
            return te;
         }
      }

      TxtEntry te;
      this.argTxts.add(te = new TxtEntry(useKey, n, v));
      return te;
   }

   public TxtEntry addArg(String n, String v) {
      return this.addArg(true, n, v);
   }

   public boolean isLowMove() {
      return this.isLowMove;
   }

   public boolean isCurrMeas() {
      return this.currMeas;
   }

   public void setCurrMeas(boolean currMeas) {
      this.currMeas = currMeas;
   }

   public int getCurRate() {
      return this.curRate;
   }

   public void setCurRate(int curRate) {
      this.curRate = curRate;
   }

   @Override
   public String toString() {
      String ln = StringPool.LINE_SEPARATOR;
      StringBuilder info = new StringBuilder("strChannelType: " + this.strChannelType + ln);
      info.append("intBlockSize: " + this.intBlockSize + ln);
      info.append("intFullScreenDataNum: " + this.intFullScreenDataNum + ln);
      info.append("intADCollectionNum: " + this.intADCollectionNum + ln);
      info.append("intLowMoveNum: " + this.intLowMoveNum + ln);
      info.append("intTimeBase: " + this.intTimeBase + ln);
      info.append("intZeroYPoint: " + this.intZeroYPoint + ln);
      info.append("intVoltageBase: " + this.intVoltageBase + ln);
      info.append("dblTimeInterval: " + this.dblTimeInterval + ln);
      info.append("dblFrequency: " + this.dblFrequency + ln);
      info.append("dblPeriod: " + this.dblPeriod + ln);
      info.append("dblVoltagePerPoint: " + this.dblVoltagePerPoint + ln);
      info.append("shtADCollection: " + this.intADCollection.length + ln);
      info.append("maxShtADData: " + this.maxShtADData + ln);
      info.append("minShtADData: " + this.minShtADData + ln);
      info.append("screenStartLoc: " + this.screenStartLoc + ln);
      return info.toString();
   }

   public List<TxtEntry> getArgTxts() {
      return this.argTxts;
   }

   public String getTxtFreq() {
      return this.txtFreq;
   }

   public String getTxtPeriod() {
      return this.txtPeriod;
   }

   public String getTxtPk() {
      return this.txtPk;
   }

   public void setBeyondCount(int upperCount, int lowerCount) {
      this.upperCount = upperCount;
      this.lowerCount = lowerCount;
   }

   public int valueAt(int i) {
      if (i >= this.intADCollectionNum) {
         return 0;
      } else if (!this.isDepMem()) {
         return this.originalAD[i] >> this.getShift();
      } else {
         CByteArrayInputStream ba = this.getWaveFormFile().getba();
         int v = ba.byteAt(this.memdepthDataIndex + i * 2) - (this.intZeroYPoint << this.getShift());
         return v >> this.getShift();
      }
   }

   public double voltAt(int i) {
      int v = this.valueAt(i);
      System.out.println(i + " test " + v);
      if (v == 0) {
         return 0.0;
      } else {
         return this.isCurrMeas() ? (double)v * this.dblVoltagePerPoint * (double)this.curRate : (double)v * this.dblVoltagePerPoint;
      }
   }

   public void setMemdepthDataIndex(int memdepthDataIndex) {
      this.memdepthDataIndex = memdepthDataIndex;
   }

   public int getMemdepthDataIndex() {
      return this.memdepthDataIndex;
   }

   private double getSample() {
      return 0.0;
   }

   public static void showFreq(int start, int step, WaveForm wf) {
      int FALL = -1;
      int NONE = 0;
      int RISE = 1;
      int maxShtADData = wf.getMaxShtADData();
      int minShtADData = wf.getMinShtADData();
      int[] intADCollection = wf.intADCollection;
      int ADMiddle = (maxShtADData + minShtADData) / 2;
      int winLow = ADMiddle - 7;
      int winHigh = ADMiddle + 7;
      int status = NONE;
      int edge = NONE;
      int start_counter = 0;
      int win_cyc_counter = 0;
      int win_data_counter = 0;
      int j = start;

      while (j < intADCollection.length) {
         if (intADCollection[j] <= winLow) {
            if (status == RISE) {
               if (edge == FALL) {
                  win_cyc_counter++;
                  win_data_counter = start_counter;
               }

               if (edge == NONE) {
                  edge = FALL;
                  start_counter = 0;
               }
            }

            status = FALL;
         }

         if (intADCollection[j] >= winHigh) {
            if (status == FALL) {
               if (edge == RISE) {
                  win_cyc_counter++;
                  win_data_counter = start_counter;
               }

               if (edge == NONE) {
                  edge = RISE;
                  start_counter = 0;
               }
            }

            status = RISE;
         }

         start_counter++;
         j += step;
      }

      if (win_cyc_counter != 0 && win_cyc_counter <= 256) {
         double timePerG;
         if (wf.getFFTInfo().isProtoFFT()) {
            timePerG = 1000.0 / wf.getSample();
         } else {
            timePerG = 1000.0
               * wf.getPublicM().getTimeBaseValue_mS(wf.getIntTimeBase())
               * wf.getWaveFormFile().getXGraticuleNum()
               / (double)wf.getIntADCollectionNum();
         }

         double cyc_show = (double)step * timePerG * (double)win_data_counter / (double)win_cyc_counter;
         wf.setDblPeriod(cyc_show);
         double freq_show = 1000000.0 / cyc_show;
         wf.setDblFrequency(freq_show);
      }
   }

   protected void checkLowMove() {
      if (this.isLowMove()) {
         int fsn = this.getIntADCollectionNum();
         int lowmove = this.getIntLowMoveNum();
         System.err.println(fsn + "  " + lowmove);
         if (fsn > lowmove) {
            int begin = fsn - lowmove;
            this.lp.x = begin;
            this.lp.y = fsn;
         } else {
            this.lp.x = 0;
            this.lp.y = fsn;
         }
      }
   }

   public int getShift() {
      MachineType mt = this.getWaveFormFile().getMt();
      return mt.getMaxBit() - 9;
   }
}
