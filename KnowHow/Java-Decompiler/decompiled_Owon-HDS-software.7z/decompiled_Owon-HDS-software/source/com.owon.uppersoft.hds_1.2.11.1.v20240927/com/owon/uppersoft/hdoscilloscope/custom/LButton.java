package com.owon.uppersoft.hdoscilloscope.custom;

import com.owon.uppersoft.common.aspect.Localizable2;
import java.util.ResourceBundle;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

public class LButton implements Localizable2 {
   private Button btn;

   public LButton(Composite parent, int style) {
      this.btn = new Button(parent, style);
   }

   public void localize(ResourceBundle bundle) {
      this.btn.setText(bundle.getString(this.btn.getData().toString()));
   }

   public void setData(Object data) {
      this.btn.setData(data);
   }

   public void setLayoutData(Object layoutData) {
      this.btn.setLayoutData(layoutData);
   }

   public void setText(String string) {
      this.btn.setText(string);
   }
}
