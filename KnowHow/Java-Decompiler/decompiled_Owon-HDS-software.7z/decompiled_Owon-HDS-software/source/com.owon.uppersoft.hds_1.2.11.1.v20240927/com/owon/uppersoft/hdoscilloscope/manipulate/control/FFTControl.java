package com.owon.uppersoft.hdoscilloscope.manipulate.control;

import com.owon.uppersoft.hdoscilloscope.manipulate.IPack;
import java.nio.ByteBuffer;

public class FFTControl implements IPack {
   public static final String[] wnds = new String[]{"hamming", "rectangle", "blackman", "hanning"};
   public static final String[] fms = new String[]{"Vrms", "dB"};
   public static final String[] zooms = new String[]{"X1", "X2", "X5", "X10"};
   public static final byte[] mft = "MFT".getBytes();
   public boolean on;
   public int chl;
   public int wnd;
   public int vrms_db;
   public int ybaseidx;
   public int xbaseidx;
   public int zoom;

   @Override
   public void pack(ByteBuffer bb) {
      bb.put(mft);
      bb.put((byte)111);
      bb.put((byte)(this.on ? 1 : 0));
      if (this.on) {
         bb.put(mft);
         bb.put((byte)102);
         bb.put((byte)this.xbaseidx);
         bb.put(mft);
         bb.put((byte)115);
         bb.put((byte)this.chl);
         bb.put(mft);
         bb.put((byte)119);
         bb.put((byte)this.wnd);
         bb.put(mft);
         bb.put((byte)97);
         bb.put((byte)this.vrms_db);
         bb.put((byte)this.ybaseidx);
         bb.put(mft);
         bb.put((byte)122);
         bb.put((byte)this.zoom);
      }
   }

   public void c_xbase(ByteBuffer bb) {
      bb.put(mft);
      bb.put((byte)102);
      bb.put((byte)this.xbaseidx);
   }

   public void c_chl(ByteBuffer bb) {
      bb.put(mft);
      bb.put((byte)115);
      bb.put((byte)this.chl);
   }

   public void c_wnd(ByteBuffer bb) {
      bb.put(mft);
      bb.put((byte)119);
      bb.put((byte)this.wnd);
   }

   public void c_ybase(ByteBuffer bb) {
      bb.put(mft);
      bb.put((byte)97);
      bb.put((byte)this.vrms_db);
      bb.put((byte)this.ybaseidx);
   }

   public void c_zoom(ByteBuffer bb) {
      bb.put(mft);
      bb.put((byte)122);
      bb.put((byte)this.zoom);
   }
}
