package com.owon.uppersoft.hdoscilloscope.manipulate.control;

import com.owon.uppersoft.hdoscilloscope.manipulate.IPack;
import java.nio.ByteBuffer;

public class ChannelInfo implements IPack {
   public int number;
   public boolean on;
   public int coupling;
   public int vbidx = 8;
   public int pos0;
   public boolean reverse;
   public boolean bandlimit;
   public int probe;
   public static final byte[] mch = "MCH".getBytes();

   public ChannelInfo(int i) {
      this.number = i;
   }

   @Override
   public void pack(ByteBuffer bb) {
      bb.put(mch).put((byte)this.number);
      bb.put((byte)111);
      bb.put((byte)(this.on ? 1 : 0));
      if (this.on) {
         bb.put(mch).put((byte)this.number);
         bb.put((byte)99);
         bb.put((byte)this.coupling);
         bb.put(mch).put((byte)this.number);
         bb.put((byte)118);
         bb.put((byte)this.vbidx);
         bb.put(mch).put((byte)this.number);
         bb.put((byte)122);
         bb.putInt(this.pos0);
         bb.put(mch).put((byte)this.number);
         bb.put((byte)112);
         bb.put((byte)this.probe);
         bb.put(mch).put((byte)this.number);
         bb.put((byte)105);
         bb.put((byte)(this.reverse ? 1 : 0));
         bb.put(mch).put((byte)this.number);
         bb.put((byte)98);
         bb.put((byte)(this.bandlimit ? 1 : 0));
      }
   }

   public void c_coupling(ByteBuffer bb) {
      bb.put(mch).put((byte)this.number);
      bb.put((byte)99);
      bb.put((byte)this.coupling);
   }

   public void c_vb(ByteBuffer bb) {
      bb.put(mch).put((byte)this.number);
      bb.put((byte)118);
      bb.put((byte)this.vbidx);
   }

   public void c_pos0(ByteBuffer bb) {
      bb.put(mch).put((byte)this.number);
      bb.put((byte)122);
      bb.putInt(this.pos0);
   }

   public void c_probe(ByteBuffer bb) {
      bb.put(mch).put((byte)this.number);
      bb.put((byte)112);
      bb.put((byte)this.probe);
   }

   public void c_reverse(ByteBuffer bb) {
      bb.put(mch).put((byte)this.number);
      bb.put((byte)105);
      bb.put((byte)(this.reverse ? 1 : 0));
   }

   public void c_bandlimit(ByteBuffer bb) {
      bb.put(mch).put((byte)this.number);
      bb.put((byte)98);
      bb.put((byte)(this.bandlimit ? 1 : 0));
   }
}
