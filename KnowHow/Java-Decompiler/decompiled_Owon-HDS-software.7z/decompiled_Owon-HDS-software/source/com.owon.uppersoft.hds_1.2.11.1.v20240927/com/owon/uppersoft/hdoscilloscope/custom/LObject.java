package com.owon.uppersoft.hdoscilloscope.custom;

import java.util.ResourceBundle;

public class LObject {
   protected String key;

   public LObject(String key) {
      this.key = key;
   }

   public String getKey() {
      return this.key;
   }

   @Override
   public String toString() {
      return this.key;
   }

   public String toString(ResourceBundle rb) {
      return rb.getString(this.key);
   }
}
