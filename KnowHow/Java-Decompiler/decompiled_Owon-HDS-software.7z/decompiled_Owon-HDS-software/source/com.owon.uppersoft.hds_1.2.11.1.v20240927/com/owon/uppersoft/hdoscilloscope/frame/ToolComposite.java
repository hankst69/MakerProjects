package com.owon.uppersoft.hdoscilloscope.frame;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.chart.model.PrototypeWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.FFTInfo;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.FFTWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.WndType;
import com.owon.uppersoft.hdoscilloscope.chart.model.math.IMath;
import com.owon.uppersoft.hdoscilloscope.chart.model.math.MathWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.frame.view.Center;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.recycle.EmptyWaveFormCurve;
import java.util.ResourceBundle;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Widget;

public class ToolComposite implements Localizable2, Listener {
   private Composite mainCom;
   private StackLayout stackLayout;
   private Composite wf_com;
   private Composite fft_com;
   private Composite math_com;
   private Center center;
   private WaveFormFileCurve wffc;
   private MenuItem[] menu_db_rms;
   private MenuItem[] menu_wndtype;
   private Button tofft;
   private Button btnDB_rms;
   private Button add_wnd;
   private Button tomath;
   private Button remove_math;
   private Button btnInverted;
   private Button remove_fft;
   private Button btn_mathtype;
   private Button btn_factor1;
   private Button btn_factor2;
   private Button remove_wf;
   private String notsupport;
   private MenuItem[] math_menuitems;
   private Composite emptyCom;

   public Composite getMainCom() {
      return this.mainCom;
   }

   public ToolComposite(Composite parent, int style) {
      this.mainCom = new Composite(parent, 0);
      this.stackLayout = new StackLayout();
      this.mainCom.setLayout(this.stackLayout);
      this.wf_com = new Composite(this.mainCom, 8388608);
      RowLayout rowLayout = new RowLayout();
      rowLayout.marginTop = 0;
      rowLayout.marginLeft = 0;
      rowLayout.marginRight = 0;
      rowLayout.marginBottom = 0;
      this.wf_com.setLayout(rowLayout);
      this.fft_com = new Composite(this.mainCom, 8388608);
      RowLayout rowLayout_1 = new RowLayout();
      rowLayout_1.marginTop = 0;
      rowLayout_1.marginRight = 0;
      rowLayout_1.marginLeft = 0;
      rowLayout_1.marginBottom = 0;
      this.fft_com.setLayout(rowLayout_1);
      this.math_com = new Composite(this.mainCom, 8388608);
      RowLayout rowLayout_2 = new RowLayout();
      rowLayout_2.marginTop = 0;
      rowLayout_2.marginRight = 0;
      rowLayout_2.marginLeft = 0;
      rowLayout_2.marginBottom = 0;
      this.math_com.setLayout(rowLayout_2);
      this.emptyCom = new Composite(this.mainCom, 0);
      this.emptyCom.setLayout(new RowLayout());
      this.tofft = new Button(this.wf_com, 0);
      this.tomath = new Button(this.wf_com, 8);
      this.btnInverted = new Button(this.wf_com, 2);
      this.remove_wf = new Button(this.wf_com, 0);
      this.btnDB_rms = new Button(this.fft_com, 0);
      this.add_wnd = new Button(this.fft_com, 0);
      this.remove_fft = new Button(this.fft_com, 8);
      this.btn_mathtype = new Button(this.math_com, 8);
      this.remove_math = new Button(this.math_com, 8);
      this.btn_factor1 = new Button(this.math_com, 8);
      this.btn_factor1.setVisible(false);
      this.btn_factor2 = new Button(this.math_com, 8);
      this.btn_factor2.setVisible(false);
      this.stackLayout.topControl = this.emptyCom;
   }

   public void customizeContent(Center ce) {
      this.center = ce;
      this.wffc = this.center.getDrawingPanel().getWaveFormFileCurve();
      this.btnDB_rms.setText("db/Vrms");
      this.tofft.addListener(13, this);
      this.tomath.addListener(13, this);
      this.remove_wf.addListener(13, this);
      this.btnInverted.addListener(13, this);
      Menu me_db_rms = new Menu(this.fft_com);
      addDropDown(this.btnDB_rms, me_db_rms);
      Menu me_wnd = new Menu(this.fft_com);
      addDropDown(this.add_wnd, me_wnd);
      this.menu_db_rms = new MenuItem[2];
      MenuItem dbMenuItem = new MenuItem(me_db_rms, 16);
      this.menu_db_rms[1] = dbMenuItem;
      dbMenuItem.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (((MenuItem)e.widget).getSelection()) {
               ToolComposite.this.center.changeCompute(1);
               ToolComposite.this.btnDB_rms.setText(FFTInfo.db_rms_txts[1]);
            }
         }
      });
      MenuItem rmsMenuItem = new MenuItem(me_db_rms, 16);
      this.menu_db_rms[0] = rmsMenuItem;
      rmsMenuItem.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (((MenuItem)e.widget).getSelection()) {
               ToolComposite.this.center.changeCompute(0);
               ToolComposite.this.btnDB_rms.setText(FFTInfo.db_rms_txts[0]);
            }
         }
      });
      WndType[] wts = FFTInfo.wndTypes;
      int len = wts.length;
      this.menu_wndtype = new MenuItem[len];

      for (final int i = 0; i < len; i++) {
         MenuItem mi = this.menu_wndtype[i] = new MenuItem(me_wnd, 16);
         mi.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) {
            }

            public void widgetSelected(SelectionEvent e) {
               if (((MenuItem)e.widget).getSelection()) {
                  ToolComposite.this.center.changeWndType(i);
                  ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
                  ToolComposite.this.add_wnd.setText(bundle.getString("Center." + FFTInfo.wndTypes[i].name()));
               }
            }
         });
      }

      this.remove_fft.addListener(13, this);
      Menu me_math = new Menu(this.math_com);
      addDropDown(this.btn_mathtype, me_math);
      String[] math_types = IMath.math_types;
      len = math_types.length;
      this.math_menuitems = new MenuItem[len];

      for (final int i = 0; i < len; i++) {
         MenuItem mi = this.math_menuitems[i] = new MenuItem(me_math, 16);
         mi.setText(math_types[i]);
         mi.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) {
            }

            public void widgetSelected(SelectionEvent e) {
               if (((MenuItem)e.widget).getSelection()) {
                  ToolComposite.this.center.changeMathType(i);
               }

               ToolComposite.this.btn_mathtype.setText(IMath.math_types[i]);
            }
         });
      }

      this.remove_math.addListener(13, this);
   }

   private static void addDropDown(final Button item, final Menu menu) {
      item.addListener(13, new Listener() {
         public void handleEvent(Event event) {
            Rectangle rect = item.getBounds();
            Point pt = new Point(rect.x, rect.y + rect.height);
            pt = item.getParent().toDisplay(pt);
            menu.setLocation(pt.x, pt.y);
            menu.setVisible(true);
         }
      });
   }

   public void localize(ResourceBundle bundle) {
      this.notsupport = bundle.getString("Center.NotSupportCompute");
      String s = bundle.getString("Center.toWF");
      this.tomath.setText(bundle.getString("Center.tomath"));
      this.remove_wf.setText(bundle.getString("Center.remove"));
      this.btnInverted.setText(bundle.getString("Center.Inverted"));
      s = bundle.getString("Center.toFFT");
      this.tofft.setData(s);
      if (!this.tofft.isEnabled()) {
         s = s + ". " + this.notsupport;
      }

      this.tofft.setText(s);
      this.menu_db_rms[1].setText(bundle.getString("Center.todb"));
      this.menu_db_rms[0].setText(bundle.getString("Center.torms"));
      WndType[] wts = FFTInfo.wndTypes;
      int len = wts.length;

      for (int i = 0; i < len; i++) {
         this.menu_wndtype[i].setText(bundle.getString("Center." + wts[i].name()));
         if (this.menu_wndtype[i].getSelection()) {
            this.add_wnd.setText(bundle.getString("Center." + wts[i].name()));
         }
      }

      this.remove_fft.setText(bundle.getString("Center.remove"));
      this.remove_math.setText(bundle.getString("Center.remove"));
      this.fft_com.layout();
      this.wf_com.layout();
      this.math_com.layout();
   }

   public void applyWaveFormFile(WaveFormFile wff) {
      if (wff.wf_collect().size() == 0) {
         this.stackLayout.topControl = this.emptyCom;
         this.mainCom.layout();
      } else {
         this.tomath.setEnabled(wff.isMathAvailable());
      }
   }

   public void applyEmptyWFC(EmptyWaveFormCurve wfc) {
      this.stackLayout.topControl = this.emptyCom;
      this.mainCom.layout();
      this.emptyCom.layout();
   }

   public void applyFFTWFC(FFTWaveFormCurve fw) {
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      this.add_wnd.setText(bundle.getString("Center." + FFTInfo.wndTypes[fw.getWndTypeIdx()].name()));
      this.btnDB_rms.setText(FFTInfo.db_rms_txts[fw.getDb_Vrms()]);
      FFTInfo fi = fw.getWaveForm().getFFTInfo();
      this.stackLayout.topControl = this.fft_com;
      this.mainCom.layout();

      for (MenuItem mi : this.menu_db_rms) {
         mi.setSelection(false);
      }

      this.menu_db_rms[fw.getDb_Vrms()].setSelection(true);

      for (MenuItem mi : this.menu_wndtype) {
         mi.setSelection(false);
      }

      this.menu_wndtype[fw.getWndTypeIdx()].setSelection(true);
      fi.isWfreturnable();
      this.remove_fft.setEnabled(!fi.isProtoFFT());
      this.fft_com.layout();
   }

   public void applyProtoWFC(PrototypeWaveFormCurve wfc) {
      this.applyProtoWFC(wfc, false);
   }

   public void applyProtoWFC(PrototypeWaveFormCurve wfc, boolean onlyInverted) {
      FFTInfo fi = wfc.getWaveForm().getFFTInfo();
      this.stackLayout.topControl = this.wf_com;
      this.mainCom.layout();
      this.tofft.setVisible(!onlyInverted);
      this.tomath.setVisible(!onlyInverted);
      this.remove_wf.setVisible(!onlyInverted);
      boolean flag = wfc.getWaveForm().isFFTComputable();
      this.tofft.setEnabled(flag);
      String s = (String)this.tofft.getData();
      if (!flag && s != null) {
         s = s + ". " + this.notsupport;
      }

      this.tofft.setText(s);
      this.btnInverted.setSelection(this.wffc.getReg().getWFReg(wfc.getStrChannelType()).isInverted());
      this.remove_wf.setEnabled(fi.isProtoFFT());
      this.wf_com.layout();
   }

   public void applyMathWFC(MathWaveFormCurve mf) {
      this.stackLayout.topControl = this.math_com;
      this.mainCom.layout();

      for (MenuItem mi : this.math_menuitems) {
         mi.setSelection(false);
      }

      this.math_menuitems[mf.getType()].setSelection(true);
      this.btn_factor1.setText(mf.getFactor1());
      this.btn_mathtype.setText(IMath.math_types[mf.getType()]);
      this.btn_factor2.setText(mf.getFactor2());
      this.math_com.layout();
   }

   public void applyWaveFormCurve(WaveFormCurve wfc) {
      wfc.applyToolComposite();
   }

   public void handleEvent(Event event) {
      if (event.type == 13) {
         Widget w = event.widget;
         if (w == this.tofft) {
            this.center.gotoADC_FFT(false);
         } else if (w == this.remove_math) {
            this.center.removeWaveFormCurve();
         } else if (w == this.remove_fft) {
            this.center.removeWaveFormCurve();
         } else if (w == this.remove_wf) {
            this.center.removeWaveFormCurve();
         } else if (w == this.tomath) {
            this.center.toMath();
         } else if (w == this.btnInverted) {
            boolean b = ((Button)w).getSelection();
            this.center.inverted(b);
         }
      }
   }

   public Button getInvertedButton() {
      return this.btnInverted;
   }

   public void setFFTButton(final boolean b) {
      if (!this.mainCom.isDisposed()) {
         Display display = this.mainCom.getDisplay();
         display.syncExec(new Runnable() {
            @Override
            public void run() {
               ToolComposite.this.btnDB_rms.setEnabled(b);
               ToolComposite.this.add_wnd.setEnabled(b);
            }
         });
      }
   }
}
