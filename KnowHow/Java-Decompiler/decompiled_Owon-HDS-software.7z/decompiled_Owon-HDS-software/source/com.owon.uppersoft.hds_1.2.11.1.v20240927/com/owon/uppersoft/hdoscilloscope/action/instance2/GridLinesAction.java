package com.owon.uppersoft.hdoscilloscope.action.instance2;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.chart.BackgroundDraw;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class GridLinesAction extends DefaultAction {
   public GridLinesAction(String id, int type) {
      super(id, type);
   }

   public void run() {
      DrawingPanel dp = Platform.getPlatform().getDrawingPanel();
      BackgroundDraw bd = dp.getBackgroundDraw();
      boolean b = !bd.isDottedGraticuleVisible();
      bd.setDottedGraticuleVisible(b);
      this.setCheck(b);
      dp.redraw();
   }
}
