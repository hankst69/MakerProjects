package com.owon.uppersoft.hdoscilloscope.frame;

import com.owon.uppersoft.common.action.DefaultMenuManager;
import com.owon.uppersoft.common.action.ItemGroup;
import com.owon.uppersoft.common.action.ItemVisitor;
import com.owon.uppersoft.common.preference.PropertiesUtil;
import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.action.ActionFactory;
import com.owon.uppersoft.hdoscilloscope.frame.view.Center;
import com.owon.uppersoft.hdoscilloscope.frame.view.StatusLine;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.image.ImageShop;
import java.util.Locale;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;

public class PrototypeMainFrame {
   protected Platform platform;
   private boolean updatable;
   protected ActionFactory af;
   protected ItemGroup<Locale> localeItemGroup;
   protected DefaultMenuManager fileM;
   protected DefaultMenuManager viewM;
   protected DefaultMenuManager formatM;
   protected DefaultMenuManager commM;
   protected DefaultMenuManager helpM;
   protected Shell shell;
   protected StatusLine statusLine;
   protected Composite centerCom;
   protected Center center;
   protected Menu menu;
   protected MenuItem recentlyOpenedFileMenuItem;
   protected Menu fileHistoryMenu;
   protected MenuItem langMenuItem;
   protected ToolBar toolBar;

   public PrototypeMainFrame(Display display) {
      this.shell = new Shell(display, 1264);
      this.platform = Platform.getPlatform();
      this.updatable = this.platform.getConfiguration().getUpdatable();
      this.af = new ActionFactory();
      this.createContents();
      this.shell.setSize(this.platform.getConfiguration().shellsize);
      this.shell.setMinimumSize(600, 400);
      ShellUtil.centerLoc(this.shell);
      this.shell.setFocus();
   }

   public void open() {
      this.shell.open();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   public Shell getShell() {
      return this.shell;
   }

   public Center getCenter() {
      return this.center;
   }

   public boolean isDisposed() {
      return this.shell.isDisposed();
   }

   protected void createContents() {
      ImageShop IMAGESHOP = this.platform.getImageShop();
      GridLayout gridLayout = new GridLayout();
      gridLayout.verticalSpacing = 2;
      gridLayout.marginWidth = 2;
      gridLayout.marginHeight = 2;
      gridLayout.horizontalSpacing = 2;
      this.shell.setLayout(gridLayout);
      this.shell.setImage(IMAGESHOP.getImage("MainFrame.gif"));
      this.createMenuBar();
      this.createToolBar();
      this.center = new Center(this.shell);
      this.centerCom = this.center.getMainCom();
      this.centerCom.setLayoutData(new GridData(4, 4, true, true));
      this.statusLine = new StatusLine(this.shell, 0);
      GridData gd_statusLine = new GridData(4, 4, true, false);
      gd_statusLine.heightHint = 25;
      this.statusLine.setLayoutData(gd_statusLine);
   }

   protected void createMenuBar() {
      this.menu = new Menu(this.shell, 2);
      this.shell.setMenuBar(this.menu);
      this.fileM = new DefaultMenuManager("fileM");
      this.viewM = new DefaultMenuManager("viewM");
      this.formatM = new DefaultMenuManager("formatM");
      this.commM = new DefaultMenuManager("commM");
      this.helpM = new DefaultMenuManager("helpM");
      Menu fileMenu = this.fileM.fill(this.menu);
      this.fileM.add(this.af.open).setAccelerator(262223);
      this.recentlyOpenedFileMenuItem = new MenuItem(fileMenu, 64);
      this.fileHistoryMenu = new Menu(this.recentlyOpenedFileMenuItem);
      this.recentlyOpenedFileMenuItem.setMenu(this.fileHistoryMenu);
      new MenuItem(this.fileHistoryMenu, 2);
      this.fileM.add(this.af.saveImage);
      this.fileM.addSeparator();
      this.fileM.add(this.af.printPreview);
      this.fileM.add(this.af.print).setAccelerator(262224);
      this.fileM.add(this.af.pageSetup);
      this.fileM.addSeparator();
      this.fileM.add(this.af.exit).setAccelerator(262232);
      this.viewM.fill(this.menu);
      this.viewM.add(this.af.waveXY);
      this.viewM.add(this.af.dataTable);
      this.viewM.addSeparator();
      this.viewM.add(this.af.gridColor);
      this.viewM.add(this.af.bgColor);
      this.viewM.add(this.af.gridLines);
      this.formatM.fill(this.menu);
      this.formatM.add(this.af.dataLine);
      this.formatM.add(this.af.dataPoint);
      this.formatM.addSeparator();
      this.commM.fill(this.menu);
      this.commM.add(this.af.ports);
      this.commM.add(this.af.getData).setAccelerator(262209);
      this.commM.addSeparator();
      this.commM.add(this.af.keep);
      this.commM.add(this.af.stop);
      this.commM.addSeparator();
      this.commM.add(this.af.autoplayer);
      this.commM.add(this.af.manipulate);
      String[] lns = this.platform.getConfiguration().getAvailableLocaleNames();
      this.localeItemGroup = new ItemGroup(new ItemVisitor<Locale>() {
         public void invoke(Locale t) {
            PrototypeMainFrame.this.af.localizeUtil.doLocalize(t);
         }

         public String getText(Locale t) {
            return t.getLanguage().equalsIgnoreCase("nl") ? "Dutch" : t.getDisplayName(t);
         }
      }, 16);

      for (String ln : lns) {
         Locale l = PropertiesUtil.forName(ln);
         if (l != null) {
            this.localeItemGroup.add(l);
         }
      }

      this.langMenuItem = this.localeItemGroup.fill(this.menu);
      this.helpM.fill(this.menu);
      if (this.updatable) {
         this.helpM.add(this.af.update);
      }

      this.helpM.add(this.af.about);
   }

   protected void createToolBar() {
      this.toolBar = new ToolBar(this.shell, 8388608);
      this.toolBar.setLayoutData(new GridData(4, 4, true, false));
      this.af.open.fill(this.toolBar);
      this.af.print.fill(this.toolBar);
      this.af.printPreview.fill(this.toolBar);
      new ToolItem(this.toolBar, 2);
      this.af.dataTable.fill(this.toolBar);
      this.af.gridLines.fill(this.toolBar);
      this.af.dataLine.fill(this.toolBar);
      this.af.dataPoint.fill(this.toolBar);
      new ToolItem(this.toolBar, 2);
      this.af.ports.fill(this.toolBar);
      this.af.getData.fill(this.toolBar);
      this.af.keep.fill(this.toolBar);
      this.af.stop.fill(this.toolBar);
      new ToolItem(this.toolBar, 2);
      this.af.autoplayer.fill(this.toolBar);
      this.af.manipulate.fill(this.toolBar);
   }

   public StatusLine getStatusLine() {
      return this.statusLine;
   }

   public Menu getFileHistoryMenu() {
      return this.fileHistoryMenu;
   }

   public void setCommItemsStatus(boolean b) {
      this.af.ports.setEnabled(b);
      this.af.getData.setEnabled(b);
      this.af.keep.setEnabled(b);
      this.af.autoplayer.setEnabled(b);
      this.af.dataTable.setEnabled(b);
   }
}
