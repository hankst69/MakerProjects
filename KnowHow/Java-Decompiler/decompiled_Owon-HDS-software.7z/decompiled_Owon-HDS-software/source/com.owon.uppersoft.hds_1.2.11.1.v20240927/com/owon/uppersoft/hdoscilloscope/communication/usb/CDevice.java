package com.owon.uppersoft.hdoscilloscope.communication.usb;

import ch.ntb.usb.LibusbJava;
import ch.ntb.usb.USBException;
import ch.ntb.usb.USBTimeoutException;
import ch.ntb.usb.Usb_Bus;
import ch.ntb.usb.Usb_Config_Descriptor;
import ch.ntb.usb.Usb_Device;
import ch.ntb.usb.Usb_Device_Descriptor;
import ch.ntb.usb.Usb_Endpoint_Descriptor;
import ch.ntb.usb.Usb_Interface;
import ch.ntb.usb.Usb_Interface_Descriptor;
import ch.ntb.usb.logger.LogUtil;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CDevice {
   private static final Logger logger = LogUtil.getLogger("ch.ntb.usb");
   private int maxPacketSize;
   private int idVendor;
   private int idProduct;
   private int dev_configuration;
   private int dev_interface;
   private int dev_altinterface;
   private long usbDevHandle;
   private boolean resetOnFirstOpen;
   private boolean resetDone;
   private int resetTimeout = 2000;
   private Usb_Device dev;
   private boolean initUSBDone = false;

   protected CDevice(short idVendor, short idProduct) {
      this.resetOnFirstOpen = false;
      this.resetDone = false;
      this.maxPacketSize = -1;
      this.idVendor = idVendor;
      this.idProduct = idProduct;
   }

   private void initUSB() {
      LibusbJava.usb_init();
      this.initUSBDone = true;
   }

   private Usb_Bus initBus() throws USBException {
      LibusbJava.usb_find_busses();
      LibusbJava.usb_find_devices();
      Usb_Bus bus = LibusbJava.usb_get_busses();
      if (bus == null) {
         throw new USBException("LibusbJava.usb_get_busses(): " + LibusbJava.usb_strerror());
      } else {
         return bus;
      }
   }

   private void updateMaxPacketSize(Usb_Device device) throws USBException {
      this.maxPacketSize = -1;
      Usb_Config_Descriptor[] confDesc = device.getConfig();

      for (int i = 0; i < confDesc.length; i++) {
         Usb_Interface[] int_ = confDesc[i].getInterface();

         for (int j = 0; j < int_.length; j++) {
            Usb_Interface_Descriptor[] intDesc = int_[j].getAltsetting();

            for (int k = 0; k < intDesc.length; k++) {
               Usb_Endpoint_Descriptor[] epDesc = intDesc[k].getEndpoint();

               for (int l = 0; l < epDesc.length; l++) {
                  this.maxPacketSize = Math.max(epDesc[l].getWMaxPacketSize(), this.maxPacketSize);
               }
            }
         }
      }

      if (this.maxPacketSize <= 0) {
         throw new USBException("No USB endpoints found. Check the device configuration");
      }
   }

   private Usb_Device initDevice() throws USBException {
      Usb_Bus bus = this.initBus();

      for (Usb_Device device = null; bus != null; bus = bus.getNext()) {
         for (Usb_Device var4 = bus.getDevices(); var4 != null; var4 = var4.getNext()) {
            Usb_Device_Descriptor devDesc = var4.getDescriptor();
            if (devDesc.getIdVendor() == this.idVendor && devDesc.getIdProduct() == this.idProduct) {
               logger.info("Device found: " + var4.getFilename());
               this.updateMaxPacketSize(var4);
               return var4;
            }
         }
      }

      return null;
   }

   public void updateDescriptors() throws USBException {
      if (!this.initUSBDone) {
         this.initUSB();
      }

      this.dev = this.initDevice();
   }

   public Usb_Device_Descriptor getDeviceDescriptor() {
      return this.dev == null ? null : this.dev.getDescriptor();
   }

   public Usb_Config_Descriptor[] getConfigDescriptors() {
      return this.dev == null ? null : this.dev.getConfig();
   }

   public void open(int configuration, int interface_, int altinterface) throws USBException {
      this.dev_configuration = configuration;
      this.dev_interface = interface_;
      this.dev_altinterface = altinterface;
      if (this.usbDevHandle != 0L) {
         throw new USBException("device opened, close or reset first");
      } else {
         this.initUSB();
         this.dev = this.initDevice();
         if (this.dev != null) {
            long res = LibusbJava.usb_open(this.dev);
            if (res == 0L) {
               throw new USBException("LibusbJava.usb_open: " + LibusbJava.usb_strerror());
            }

            this.usbDevHandle = res;
         }

         if (this.dev != null && this.usbDevHandle != 0L) {
            this.claim_interface(this.usbDevHandle, configuration, interface_, altinterface);
            if (this.resetOnFirstOpen & !this.resetDone) {
               logger.info("reset on first open");
               this.resetDone = true;
               this.reset();

               try {
                  Thread.sleep((long)this.resetTimeout);
               } catch (InterruptedException var6) {
               }

               this.open(configuration, interface_, altinterface);
            }
         } else {
            throw new USBException(
               "USB device with idVendor 0x"
                  + Integer.toHexString(this.idVendor & 65535)
                  + " and idProduct 0x"
                  + Integer.toHexString(this.idProduct & 65535)
                  + " not found"
            );
         }
      }
   }

   public void close() throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else {
         this.release_interface(this.usbDevHandle, this.dev_interface);
         if (LibusbJava.usb_close(this.usbDevHandle) < 0) {
            this.usbDevHandle = 0L;
            throw new USBException("LibusbJava.usb_close: " + LibusbJava.usb_strerror());
         } else {
            this.usbDevHandle = 0L;
            this.maxPacketSize = -1;
            logger.info("device closed");
         }
      }
   }

   public void reset() throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else {
         this.release_interface(this.usbDevHandle, this.dev_interface);
         if (LibusbJava.usb_reset(this.usbDevHandle) < 0) {
            this.usbDevHandle = 0L;
            throw new USBException("LibusbJava.usb_reset: " + LibusbJava.usb_strerror());
         } else if (LibusbJava.usb_close(this.usbDevHandle) < 0) {
            this.usbDevHandle = 0L;
            throw new USBException("LibusbJava.usb_close: " + LibusbJava.usb_strerror());
         } else {
            this.usbDevHandle = 0L;
            logger.info("device reset");
         }
      }
   }

   public int writeBulk(int out_ep_address, byte[] data, int size, int timeout, boolean reopenOnTimeout) throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else if (data == null) {
         throw new USBException("data must not be null");
      } else if (size > 0 && size <= data.length) {
         int lenWritten = LibusbJava.usb_bulk_write(this.usbDevHandle, out_ep_address, data, size, timeout);
         if (lenWritten >= 0) {
            logger.info("length written: " + lenWritten);
            if (logger.isLoggable(Level.FINEST)) {
               StringBuffer sb = new StringBuffer("bulkwrite, ep 0x" + Integer.toHexString(out_ep_address) + ": " + lenWritten + " Bytes sent: ");

               for (int i = 0; i < lenWritten; i++) {
                  sb.append("0x" + String.format("%1$02X", data[i]) + " ");
               }

               logger.info(sb.toString());
            }

            return lenWritten;
         } else if (lenWritten != LibusbJava.ERROR_TIMEDOUT) {
            throw new USBException("LibusbJava.usb_bulk_write: " + LibusbJava.usb_strerror());
         } else if (reopenOnTimeout) {
            logger.info("try to reopen");
            this.reset();
            this.open(this.dev_configuration, this.dev_interface, this.dev_altinterface);
            return this.writeBulk(out_ep_address, data, size, timeout, false);
         } else {
            throw new USBTimeoutException("LibusbJava.usb_bulk_write: " + LibusbJava.usb_strerror());
         }
      } else {
         throw new ArrayIndexOutOfBoundsException("invalid size: " + size);
      }
   }

   public int readBulk(int in_ep_address, byte[] data, int size, int timeout, boolean reopenOnTimeout) throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else if (data == null) {
         throw new USBException("data must not be null");
      } else if (size > 0 && size <= data.length) {
         int lenRead = LibusbJava.usb_bulk_read(this.usbDevHandle, in_ep_address, data, size, timeout);
         if (lenRead >= 0) {
            logger.info("length read: " + lenRead);
            if (logger.isLoggable(Level.FINEST)) {
               StringBuffer sb = new StringBuffer("bulkread, ep 0x" + Integer.toHexString(in_ep_address) + ": " + lenRead + " Bytes received: ");

               for (int i = 0; i < lenRead; i++) {
                  sb.append("0x" + String.format("%1$02X", data[i]) + " ");
               }

               logger.info(sb.toString());
            }

            return lenRead;
         } else if (lenRead != LibusbJava.ERROR_TIMEDOUT) {
            throw new USBException("LibusbJava.usb_bulk_read: " + LibusbJava.usb_strerror());
         } else if (reopenOnTimeout) {
            logger.info("try to reopen");
            this.reset();
            this.open(this.dev_configuration, this.dev_interface, this.dev_altinterface);
            return this.readBulk(in_ep_address, data, size, timeout, false);
         } else {
            throw new USBTimeoutException("LibusbJava.usb_bulk_read: " + LibusbJava.usb_strerror());
         }
      } else {
         throw new ArrayIndexOutOfBoundsException("invalid size: " + size);
      }
   }

   public int writeInterrupt(int out_ep_address, byte[] data, int size, int timeout, boolean reopenOnTimeout) throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else if (data == null) {
         throw new USBException("data must not be null");
      } else if (size > 0 && size <= data.length) {
         int lenWritten = LibusbJava.usb_interrupt_write(this.usbDevHandle, out_ep_address, data, size, timeout);
         if (lenWritten >= 0) {
            logger.info("length written: " + lenWritten);
            if (logger.isLoggable(Level.FINEST)) {
               StringBuffer sb = new StringBuffer("interruptwrite, ep 0x" + Integer.toHexString(out_ep_address) + ": " + lenWritten + " Bytes sent: ");

               for (int i = 0; i < lenWritten; i++) {
                  sb.append("0x" + String.format("%1$02X", data[i]) + " ");
               }

               logger.info(sb.toString());
            }

            return lenWritten;
         } else if (lenWritten != LibusbJava.ERROR_TIMEDOUT) {
            throw new USBException("LibusbJava.usb_interrupt_write: " + LibusbJava.usb_strerror());
         } else if (reopenOnTimeout) {
            logger.info("try to reopen");
            this.reset();
            this.open(this.dev_configuration, this.dev_interface, this.dev_altinterface);
            return this.writeInterrupt(out_ep_address, data, size, timeout, false);
         } else {
            throw new USBTimeoutException("LibusbJava.usb_interrupt_write: " + LibusbJava.usb_strerror());
         }
      } else {
         throw new ArrayIndexOutOfBoundsException("invalid size: " + size);
      }
   }

   public int readInterrupt(int in_ep_address, byte[] data, int size, int timeout, boolean reopenOnTimeout) throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else if (data == null) {
         throw new USBException("data must not be null");
      } else if (size > 0 && size <= data.length) {
         int lenRead = LibusbJava.usb_interrupt_read(this.usbDevHandle, in_ep_address, data, size, timeout);
         if (lenRead >= 0) {
            logger.info("length read: " + lenRead);
            if (logger.isLoggable(Level.FINEST)) {
               StringBuffer sb = new StringBuffer("interrupt, ep 0x" + Integer.toHexString(in_ep_address) + ": " + lenRead + " Bytes received: ");

               for (int i = 0; i < lenRead; i++) {
                  sb.append("0x" + String.format("%1$02X", data[i]) + " ");
               }

               logger.info(sb.toString());
            }

            return lenRead;
         } else if (lenRead != LibusbJava.ERROR_TIMEDOUT) {
            throw new USBException("LibusbJava.usb_interrupt_read: " + LibusbJava.usb_strerror());
         } else if (reopenOnTimeout) {
            logger.info("try to reopen");
            this.reset();
            this.open(this.dev_configuration, this.dev_interface, this.dev_altinterface);
            return this.readInterrupt(in_ep_address, data, size, timeout, false);
         } else {
            throw new USBTimeoutException("LibusbJava.usb_interrupt_read: " + LibusbJava.usb_strerror());
         }
      } else {
         throw new ArrayIndexOutOfBoundsException("invalid size: " + size);
      }
   }

   public int controlMsg(int requestType, int request, int value, int index, byte[] data, int size, int timeout, boolean reopenOnTimeout) throws USBException {
      if (this.usbDevHandle == 0L) {
         throw new USBException("invalid device handle");
      } else if (data == null) {
         throw new USBException("data must not be null");
      } else if (size > 0 && size <= data.length) {
         int len = LibusbJava.usb_control_msg(this.usbDevHandle, requestType, request, value, index, data, size, timeout);
         if (len >= 0) {
            logger.info("length read/written: " + len);
            if (logger.isLoggable(Level.FINEST)) {
               StringBuffer sb = new StringBuffer("controlMsg: " + len + " Bytes received(written: ");

               for (int i = 0; i < len; i++) {
                  sb.append("0x" + String.format("%1$02X", data[i]) + " ");
               }

               logger.info(sb.toString());
            }

            return len;
         } else if (len != LibusbJava.ERROR_TIMEDOUT) {
            throw new USBException("LibusbJava.controlMsg: " + LibusbJava.usb_strerror());
         } else if (reopenOnTimeout) {
            logger.info("try to reopen");
            this.reset();
            this.open(this.dev_configuration, this.dev_interface, this.dev_altinterface);
            return this.controlMsg(requestType, request, value, index, data, size, timeout, false);
         } else {
            throw new USBTimeoutException("LibusbJava.controlMsg: " + LibusbJava.usb_strerror());
         }
      } else {
         throw new ArrayIndexOutOfBoundsException("invalid size: " + size);
      }
   }

   private void claim_interface(long usb_dev_handle, int configuration, int interface_, int altinterface) throws USBException {
      if (LibusbJava.usb_set_configuration(usb_dev_handle, configuration) < 0) {
         this.usbDevHandle = 0L;
         throw new USBException("LibusbJava.usb_set_configuration: " + LibusbJava.usb_strerror());
      } else if (LibusbJava.usb_claim_interface(usb_dev_handle, interface_) < 0) {
         this.usbDevHandle = 0L;
         throw new USBException("LibusbJava.usb_claim_interface: " + LibusbJava.usb_strerror());
      } else if (altinterface >= 0 && LibusbJava.usb_set_altinterface(usb_dev_handle, altinterface) < 0) {
         try {
            this.release_interface(usb_dev_handle, interface_);
         } catch (USBException var6) {
         }

         this.usbDevHandle = 0L;
         throw new USBException("LibusbJava.usb_set_altinterface: " + LibusbJava.usb_strerror());
      } else {
         logger.info("interface claimed");
      }
   }

   private void release_interface(long dev_handle, int interface_) throws USBException {
      if (LibusbJava.usb_release_interface(dev_handle, interface_) < 0) {
         this.usbDevHandle = 0L;
         throw new USBException("LibusbJava.usb_release_interface: " + LibusbJava.usb_strerror());
      } else {
         logger.info("interface released");
      }
   }

   public int getIdProduct() {
      return this.idProduct;
   }

   public int getIdVendor() {
      return this.idVendor;
   }

   public int getAltinterface() {
      return this.dev_altinterface;
   }

   public int getConfiguration() {
      return this.dev_configuration;
   }

   public int getInterface() {
      return this.dev_interface;
   }

   public int getMaxPacketSize() {
      return this.maxPacketSize;
   }

   public boolean isOpen() {
      return this.usbDevHandle != 0L;
   }

   public void setResetOnFirstOpen(boolean enable, int timeout) {
      this.resetOnFirstOpen = enable;
      this.resetTimeout = timeout;
   }

   public static List<IDevice> scanMatchedDevices(short idVendor, short idProduct) throws Throwable {
      LibusbJava.usb_init();
      LibusbJava.usb_find_busses();
      LibusbJava.usb_find_devices();
      Usb_Bus bus = LibusbJava.usb_get_busses();
      if (bus == null) {
         throw new USBException("LibusbJava.usb_get_busses(): " + LibusbJava.usb_strerror());
      } else {
         Usb_Device device = null;

         List<IDevice> devices;
         for (devices = new LinkedList<>(); bus != null; bus = bus.getNext()) {
            for (Usb_Device var10 = bus.getDevices(); var10 != null; var10 = var10.getNext()) {
               Usb_Device_Descriptor devDesc = var10.getDescriptor();
               if (devDesc.getIdVendor() == idVendor && devDesc.getIdProduct() == idProduct) {
                  ComparableDevice cd = ComparableDevice.getInstance(var10, "");
                  long handle = LibusbJava.usb_open(var10);
                  String iSerialNumber = LibusbJava.usb_get_string_simple(handle, devDesc.getISerialNumber());
                  cd.setSerialNumber(iSerialNumber);
                  LibusbJava.usb_close(handle);
                  if (cd != null) {
                     devices.add(cd);
                  }
               }
            }
         }

         return devices;
      }
   }

   public static CDevice getDevice(short idVendor, short idProduct) {
      return new CDevice(idVendor, idProduct);
   }

   public static void simulateOpen(CDevice device, IDevice id) throws USBException {
      Usb_Device dev = id.getUsb_Device();
      simulateOpen(device, dev, id.getBConfigurationValue(), id.getBInterfaceNumber(), id.getBAlternateSetting());
   }

   public static void simulateOpen(CDevice device, Usb_Device dev, int configuration, int interface_, int altinterface) throws USBException {
      device.dev_configuration = configuration;
      device.dev_interface = interface_;
      device.dev_altinterface = altinterface;
      if (device.usbDevHandle != 0L) {
         throw new USBException("device opened, close or reset first");
      } else {
         device.initUSB();
         device.initBus();
         if (dev != null) {
            long res = LibusbJava.usb_open(dev);
            if (res == 0L) {
               throw new USBException("LibusbJava.usb_open: " + LibusbJava.usb_strerror());
            }

            device.usbDevHandle = res;
         }

         if (dev != null && device.usbDevHandle != 0L) {
            device.claim_interface(device.usbDevHandle, configuration, interface_, altinterface);
            if (device.resetOnFirstOpen & !device.resetDone) {
               logger.info("reset on first open");
               device.resetDone = true;
               device.reset();

               try {
                  Thread.sleep((long)device.resetTimeout);
               } catch (InterruptedException var7) {
                  var7.printStackTrace();
               }

               simulateOpen(device, dev, configuration, interface_, altinterface);
            }
         } else {
            throw new USBException(
               "USB device with idVendor 0x"
                  + Integer.toHexString(device.idVendor & 65535)
                  + " and idProduct 0x"
                  + Integer.toHexString(device.idProduct & 65535)
                  + " not found"
            );
         }
      }
   }

   public static long direct_open(Usb_Device device, int configuration, int interface_, int altinterface) throws USBException {
      long usb_dev_handle = LibusbJava.usb_open(device);
      if (usb_dev_handle == 0L) {
         throw new USBException("LibusbJava.usb_open: " + LibusbJava.usb_strerror());
      } else if (LibusbJava.usb_set_configuration(usb_dev_handle, configuration) < 0) {
         throw new USBException("LibusbJava.usb_set_configuration: " + LibusbJava.usb_strerror());
      } else if (LibusbJava.usb_claim_interface(usb_dev_handle, interface_) < 0) {
         throw new USBException("LibusbJava.usb_claim_interface: " + LibusbJava.usb_strerror());
      } else if (altinterface >= 0 && LibusbJava.usb_set_altinterface(usb_dev_handle, altinterface) < 0) {
         try {
            if (LibusbJava.usb_release_interface(usb_dev_handle, interface_) < 0) {
               throw new USBException("LibusbJava.usb_release_interface: " + LibusbJava.usb_strerror());
            }
         } catch (USBException var6) {
         }

         throw new USBException("LibusbJava.usb_set_altinterface: " + LibusbJava.usb_strerror());
      } else {
         return usb_dev_handle;
      }
   }

   public static void direct_contact_test(long usb_dev_handle, int WriteEndpoint, int ReadEndpoint) {
      int len = LibusbJava.usb_bulk_write(usb_dev_handle, WriteEndpoint, "START".getBytes(), 5, 2000);
      if (len < 0) {
         ;
      }

      byte[] twv = new byte[12];
      len = LibusbJava.usb_bulk_read(usb_dev_handle, ReadEndpoint, twv, twv.length, 2000);
      System.out.println(len);

      for (int i = 0; i < len; i++) {
         System.out.print(Integer.toHexString(255 & twv[i]) + " ");
      }

      twv = new byte[1024];

      int i;
      for (i = 0; len > 0; i++) {
         len = LibusbJava.usb_bulk_read(usb_dev_handle, ReadEndpoint, twv, twv.length, 2000);
      }

      System.out.println(i);
   }

   public static void direct_reset(long usb_dev_handle, int interface_) throws USBException {
      LibusbJava.usb_release_interface(usb_dev_handle, interface_);
      if (LibusbJava.usb_reset(usb_dev_handle) < 0) {
         throw new USBException("LibusbJava.usb_reset: " + LibusbJava.usb_strerror());
      }
   }

   public static void direct_close(long usb_dev_handle, int interface_) throws USBException {
      LibusbJava.usb_release_interface(usb_dev_handle, interface_);
      if (LibusbJava.usb_close(usb_dev_handle) < 0) {
         throw new USBException("LibusbJava.usb_close: " + LibusbJava.usb_strerror());
      }
   }
}
