package com.owon.uppersoft.hdoscilloscope.scpi.mm;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.action.ActionFactory;
import com.owon.uppersoft.hdoscilloscope.communication.loop.IRapidCommunication;
import com.owon.uppersoft.hdoscilloscope.communication.loop.JobUnit;
import com.owon.uppersoft.hdoscilloscope.communication.loop.LoopControl;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.nio.ByteBuffer;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class SCPIMMAction extends DefaultAction {
   private Shell shell;
   private ScpiMMFrm mf;
   private ActionFactory af;
   private LoopControl lc;
   private boolean deal = false;

   public SCPIMMAction(String id, ActionFactory af) {
      super(id);
      this.af = af;
   }

   public void release() {
      this.reEnable();
      this.lc.setUse(false);
   }

   public void reEnable() {
      this.deal = false;
   }

   public void run() {
      if (!this.deal) {
         this.deal = true;
         this.lc = this.af.loopControl;
         this.lc.setUse(true);
         this.send(new JobUnit(":SCPI:DISP?".getBytes(), new byte[128]) {
            public void afterJob(IRapidCommunication irc, ByteBuffer bbuf) {
               Display.getDefault().asyncExec(new Runnable() {
                  @Override
                  public void run() {
                     int num = getResNum();
                     if (num <= 0) {
                        ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle2();
                        String errDefault = ResourceBundleProvider.getMessageLibResourceBundle().getString("Err.Default");
                        String msg = bundle.getString("Warn.noSupportMmScpi");
                        MessageDialog.openError(SCPIMMAction.this.shell, errDefault, msg);
                        SCPIMMAction.this.reEnable();
                     } else {
                        String s = new String(re_arr, 0, num);
                        System.out.println(s);
                        if (s.equalsIgnoreCase(":SCPION")) {
                           SCPIMMAction.this.loadSCPI();
                        } else {
                           SCPIMMAction.this.reEnable();
                        }
                     }
                  }
               });
            }
         });
      }
   }

   private void loadSCPI() {
      this.mf = new ScpiMMFrm(this.shell, this);
      this.mf.open();
   }

   public void send(JobUnit p) {
      this.lc.addJobUnit(p);
   }
}
