package com.owon.uppersoft.hdoscilloscope.manipulate;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.communication.loop.IRapidCommunication;
import com.owon.uppersoft.hdoscilloscope.communication.loop.JobUnit;
import com.owon.uppersoft.hdoscilloscope.communication.loop.LoopControl;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.image.ImageShop;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail.AGComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail.ChannelGroupComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail.FFTComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail.NetComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail.SampleComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail.TBComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail2.MultiMeterComposite;
import com.owon.uppersoft.hdoscilloscope.manipulate.detail2.TrgComposite;
import com.owon.uppersoft.hdoscilloscope.scpi.SCPIAction;
import java.util.ResourceBundle;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;

public class ManipulateFrame implements SelectionListener, Localizable2 {
   protected Shell shell;
   private Shell parent;
   private TabItem trgTabItem;
   private TabItem chlTabItem;
   private TabItem splTabItem;
   private TabItem tbTabItem;
   private TabItem mmTabItem;
   private TabItem netTabItem;
   private TabItem fftTabItem;
   private TabItem ultrwaveItem;
   private Button runstopButton;
   private ManiAction ma;
   private SCPIAction sa;
   public LoopControl lc;
   private TabFolder tabFolder;
   private Composite topcom;
   private Composite tabcom;
   private ManipulateControl mc;
   public static final byte[] slstop_rp = ":SDSLSTP0".getBytes();
   public static final byte[] slrun = ":SDSLRUN#".getBytes();
   public static final byte[] slstop = ":SDSLSTP#".getBytes();
   private Label prompt;
   private TrgComposite trg_com;
   private ChannelGroupComposite chl_com;
   private SampleComposite spl_com;
   private TBComposite tb_com;
   private MultiMeterComposite mm_com;
   private NetComposite net_com;
   private FFTComposite fft_com;
   private AGComposite ultrwave_com;
   private Button selfButton;
   private Button factoryButton;
   private Button SCPIButton;
   private Button autosetButton;
   private boolean isRunning = true;

   public ManipulateFrame(Shell parent, LoopControl lc, ManiAction ma, ManipulateControl mc) {
      this.parent = parent;
      this.lc = lc;
      this.ma = ma;
      this.mc = mc;
   }

   public boolean forceFocus() {
      return this.shell.forceFocus();
   }

   public void open() {
      Display display = Display.getDefault();
      this.createContents();
      this.customizeContents();
      this.shell.pack();
      ShellUtil.centerLoc(this.shell);
      this.shell.open();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   private void customizeContents() {
      this.shell.addDisposeListener(new DisposeListener() {
         public void widgetDisposed(DisposeEvent e) {
            ManipulateFrame.this.ma.release();
         }
      });
      ImageShop is = Platform.getPlatform().getImageShop();
      this.shell.setImage(is.getImage("manipulate.gif"));
   }

   protected void createContents() {
      this.shell = new Shell(this.parent);
      GridLayout gridLayout = new GridLayout();
      gridLayout.marginHeight = 10;
      gridLayout.marginWidth = 10;
      this.shell.setLayout(gridLayout);
      this.tabcom = new Composite(this.shell, 0);
      this.tabcom.setLayout(new FillLayout());
      this.tabcom.setLayoutData(new GridData(4, 4, true, true));
      this.tabFolder = new TabFolder(this.tabcom, 0);
      this.trgTabItem = new TabItem(this.tabFolder, 0);
      this.trg_com = new TrgComposite(this.tabFolder, this.mc.tc);
      this.trgTabItem.setControl(this.trg_com);
      this.chlTabItem = new TabItem(this.tabFolder, 0);
      this.chl_com = new ChannelGroupComposite(this.tabFolder, this.mc);
      this.chlTabItem.setControl(this.chl_com);
      this.splTabItem = new TabItem(this.tabFolder, 0);
      this.spl_com = new SampleComposite(this.tabFolder, this.mc, this.mc.sc);
      this.splTabItem.setControl(this.spl_com);
      this.tbTabItem = new TabItem(this.tabFolder, 0);
      this.tb_com = new TBComposite(this.tabFolder, this.mc, this.mc.tic);
      this.tbTabItem.setControl(this.tb_com);
      if (this.mc.hasMM) {
         this.mmTabItem = new TabItem(this.tabFolder, 0);
         this.mm_com = new MultiMeterComposite(this.tabFolder, this);
         this.mmTabItem.setControl(this.mm_com);
      }

      if (this.mc.mt.getChLen() == 1) {
         this.mc.hasUE = false;
      } else {
         this.mc.hasUE = true;
      }

      if (this.mc.hasUE) {
         this.ultrwaveItem = new TabItem(this.tabFolder, 0);
         this.ultrwave_com = new AGComposite(this.tabFolder, this.mc);
         this.ultrwaveItem.setControl(this.ultrwave_com);
      }

      this.localize(ResourceBundleProvider.getMessageLibResourceBundle2());
   }

   public void widgetDefaultSelected(SelectionEvent e) {
   }

   public void widgetSelected(SelectionEvent e) {
      boolean b = this.lc.isKeepOn();
      Object o = e.getSource();
      if (o == this.runstopButton) {
         this.autoget(b);
      }
   }

   private void autoget(boolean b) {
      if (this.isRunning) {
         this.mc.send(":RUNning STOP");
      } else {
         this.mc.send(":RUNning RUN");
      }

      this.updateRSButton(this.isRunning);
      this.isRunning = !this.isRunning;
   }

   public void updateRSButton(boolean run) {
      if (!this.shell.isDisposed()) {
         ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle2();
         this.runstopButton.setText(!run ? rb.getString("Action.stop") : rb.getString("Action.run"));
      }
   }

   private void runstop(boolean b) {
      boolean run = this.isRunning;
      if (run) {
         JobUnit p = new JobUnit(slstop) {
            public void afterJob(IRapidCommunication irc) {
            }
         };
         if (b) {
            this.lc.addJobUnit(p);
         } else {
            this.lc.activeSend(p);
         }
      } else {
         JobUnit p = new JobUnit(slrun);
         if (b) {
            this.lc.addDirectJobUnit(p);
         } else {
            this.lc.activeSend(p);
         }
      }

      ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle2();
      this.runstopButton.setText(!run ? rb.getString("Action.stop") : rb.getString("Action.run"));
   }

   public void rewindRun() {
      if (!this.isRunning) {
         this.lc.DoLoop();
         ResourceBundle rb = ResourceBundleProvider.getMessageLibResourceBundle2();
         this.runstopButton.setText(rb.getString("Action.stop"));
      }
   }

   public void localize(ResourceBundle rb) {
      this.trg_com.localize(rb);
      this.chl_com.localize(rb);
      this.spl_com.localize(rb);
      this.tb_com.localize(rb);
      if (this.mc.hasMM) {
         this.mm_com.localize(rb);
         this.mmTabItem.setText(rb.getString("M.MM.Name"));
      }

      this.tbTabItem.setText(rb.getString("M.Timebase.Name"));
      this.splTabItem.setText(rb.getString("M.Sample.Name"));
      this.chlTabItem.setText(rb.getString("M.Channel.Name"));
      this.trgTabItem.setText(rb.getString("M.Trg.Name"));
      if (this.mc.hasUE) {
         this.ultrwave_com.localize(rb);
         this.ultrwaveItem.setText(rb.getString("M.AG.Name"));
      }

      rb.getString("Action.prompt");
   }
}
