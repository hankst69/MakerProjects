package com.owon.uppersoft.hdoscilloscope.chart.aspect;

import com.owon.uppersoft.hdoscilloscope.data.TxtEntry;
import java.util.Collection;
import org.eclipse.swt.graphics.Point;

public interface DrawCompute {
   Collection<TxtEntry> txts_coll();

   double valueAtX(double var1);

   double valueAtY(double var1);

   double rateAtY();

   int rateAtX();

   Collection<? extends Object> xb_collect();

   Collection<? extends Object> yb_collect();

   String getXBaseTxt();

   String getYBaseTxt();

   int baseIdxOnX();

   int baseIdxOnY();

   void setBaseIdxOnX(int var1);

   void setBaseIdxOnY(int var1);

   String unitForX(double var1);

   String unitForY(double var1);

   void controlResize(Point var1, Point var2);
}
