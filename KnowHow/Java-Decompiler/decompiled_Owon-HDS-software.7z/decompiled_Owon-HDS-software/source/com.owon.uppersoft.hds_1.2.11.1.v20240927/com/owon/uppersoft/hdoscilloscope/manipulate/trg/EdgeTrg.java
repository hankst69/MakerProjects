package com.owon.uppersoft.hdoscilloscope.manipulate.trg;

import java.nio.ByteBuffer;

public class EdgeTrg extends AbsTrg {
   public static final int id = 0;
   public int coupling;
   public int sweep = 0;
   public int edge;
   public int level;
   public final int holdoff = 1;

   @Override
   public void pack(ByteBuffer bb, int sna, int trgchl, int mode) {
      bb.put(mtr);
      bb.put((byte)sna);
      bb.put((byte)trgchl);
      bb.put((byte)mode);
      bb.put((byte)2);
      bb.put((byte)this.coupling);
      bb.put(mtr);
      bb.put((byte)sna);
      bb.put((byte)trgchl);
      bb.put((byte)mode);
      bb.put((byte)3);
      bb.put((byte)this.sweep);
      bb.put(mtr);
      bb.put((byte)sna);
      bb.put((byte)trgchl);
      bb.put((byte)mode);
      bb.put((byte)4);
      bb.putInt(1);
      bb.put(mtr);
      bb.put((byte)sna);
      bb.put((byte)trgchl);
      bb.put((byte)mode);
      bb.put((byte)5);
      bb.put((byte)this.edge);
      bb.put(mtr);
      bb.put((byte)sna);
      bb.put((byte)trgchl);
      bb.put((byte)mode);
      bb.put((byte)6);
      bb.putInt(this.level);
   }

   @Override
   public void packLevel(ByteBuffer bb, int sna, int trgchl, int mode, int level) {
      this.level = level;
      bb.put(mtr);
      bb.put((byte)sna);
      bb.put((byte)trgchl);
      bb.put((byte)mode);
      bb.put((byte)6);
      bb.putInt(level);
   }
}
