package com.owon.uppersoft.hdoscilloscope.action.instance;

import com.owon.uppersoft.common.action.DefaultAction;
import com.owon.uppersoft.hdoscilloscope.communication.UploadSavedWFFrame;
import com.owon.uppersoft.hdoscilloscope.global.Platform;

public class GetSaveDataAction extends DefaultAction {
   public GetSaveDataAction(String id) {
      super(id);
   }

   public void run() {
      Platform platform = Platform.getPlatform();
      new UploadSavedWFFrame(platform.getShell()).open();
   }
}
