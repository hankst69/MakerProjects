package com.owon.uppersoft.hdoscilloscope.frame.view;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.image.ImageShop;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import com.owon.uppersoft.hdoscilloscope.util.VerInfoUtil;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class AboutDialog implements PaintListener, Localizable2, DisposeListener {
   private Button button;
   private Shell shell;
   private Image image;
   private Shell parent;
   private ImageShop imageShop;

   public AboutDialog(Shell parent) {
      this.parent = parent;
      this.createContents();
   }

   public Object open() {
      this.shell.pack();
      ShellUtil.centerLoc(this.shell);
      this.shell.open();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }

      return null;
   }

   protected void createContents() {
      this.shell = new Shell(this.parent, 67680);
      Composite com = new Composite(this.shell, 0);
      this.imageShop = Platform.getPlatform().getImageShop();
      this.image = this.imageShop.getImage("about_.gif");
      Rectangle r = this.image.getBounds();
      com.setSize(r.width, r.height + 27);
      com.addPaintListener(this);
      com.addDisposeListener(this);
      this.button = new Button(com, 0);
      this.button.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            AboutDialog.this.shell.close();
         }
      });
      this.button.setBounds(r.width / 2 - 60, r.height + 1, 130, 25);
      this.localize(ResourceBundleProvider.getMessageLibResourceBundle());
   }

   public void paintControl(PaintEvent e) {
      GC gc = e.gc;
      gc.drawImage(this.image, 0, 0);
   }

   public void localize(ResourceBundle bundle) {
      Configuration conf = Platform.getPlatform().getConfiguration();
      String info = VerInfoUtil.getVersionUtil().getAboutVer();
      if (conf.showMachineType) {
         WaveFormFileCurve wffc = Platform.getPlatform().getDrawingPanel().getWaveFormFileCurve();
         WaveFormFile wff = wffc.getWaveFormFile();
         if (wff != null) {
            info = info + " \"" + wff.getMt().getIdn().getModel() + "\" " + wff.getPublicM().getMachineType();
         }
      }

      this.shell.setText(bundle.getString("MF.about") + "    " + info);
      this.button.setText(bundle.getString("MF.ok"));
   }

   public static void main_hide(String[] args) {
      Shell shell = new Shell();
      Display display = shell.getDisplay();
      shell.open();

      try {
         new AboutDialog(shell).open();

         while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
               display.sleep();
            }
         }
      } catch (Exception var4) {
         MessageDialog.openError(shell, "Error", "Error ocurred during running!");
         var4.printStackTrace();
      }
   }

   public void widgetDisposed(DisposeEvent e) {
      this.imageShop.disposeImage(this.image);
   }
}
