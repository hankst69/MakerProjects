package com.owon.uppersoft.hdoscilloscope.i18n;

import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

public class MessageErrRunner implements Runnable {
   private String key;
   private int type;
   private Shell shell;

   public void syn_setInfo(String key, int type, Shell shell) {
      this.key = key;
      this.type = type;
      this.shell = shell;
      shell.getDisplay().syncExec(this);
   }

   public void setInfo(String key, int type, Shell shell) {
      this.key = key;
      this.type = type;
      this.shell = shell;
      shell.getDisplay().asyncExec(this);
   }

   @Override
   public void run() {
      if (!this.shell.isDisposed()) {
         ResourceBundle msgBundle = ResourceBundleProvider.getMessageLibResourceBundle();
         String title = "";
         String msg = msgBundle.getString(this.key);
         switch (this.type) {
            case 1:
               title = msgBundle.getString("Err.Default");
               MessageDialog.openError(this.shell, title, msg);
               break;
            case 2:
               title = msgBundle.getString("Info.Default");
               MessageDialog.openInformation(this.shell, title, msg);
            case 3:
            default:
               break;
            case 4:
               title = msgBundle.getString("Warn.Default");
               MessageDialog.openWarning(this.shell, title, msg);
         }
      }
   }
}
