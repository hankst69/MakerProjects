package com.owon.uppersoft.hdoscilloscope.test;

import com.owon.uppersoft.common.utils.DisposeUtil;
import com.owon.uppersoft.hdoscilloscope.model.IPublicM;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.ColorDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class CScale extends Canvas implements PaintListener, MouseListener, MouseMoveListener {
   private int halfH = 8;
   private Feedable fed;
   private Color bgColor;
   private int selectedIndex = -1;
   private int selectedY;

   public CScale(Composite parent) {
      super(parent, 536870912);
      this.bgColor = new Color(this.getDisplay(), IPublicM.DefaultCScaleBG);
      this.setBackground(this.bgColor);
      this.addPaintListener(this);
      this.addMouseListener(this);
      this.addMouseMoveListener(this);
   }

   public void setFeedable(Feedable fed) {
      if (fed != null) {
         this.fed = fed;
         this.redraw();
      }
   }

   public void paintControl(PaintEvent e) {
      GC gc = e.gc;
      Composite c = (Composite)e.getSource();
      Point size = c.getSize();
      if (this.fed != null) {
         int s = this.fed.getSize();

         for (int i = 0; i < s; i++) {
            int y = this.fed.getValue(i);
            gc.setBackground(this.fed.getColor(i));
            gc.fillRectangle(0, y - this.halfH, size.x, this.halfH << 1);
            gc.drawString(this.fed.getString(i), 2, y - this.halfH + 2, true);
         }
      }
   }

   public void mouseDoubleClick(MouseEvent e) {
      if (e.button == 1) {
         Composite c = (Composite)e.getSource();
         ColorDialog ds = new ColorDialog(c.getShell());
         if (this.selectedIndex < 0) {
            ds.setRGB(this.bgColor.getRGB());
         } else {
            Color color = this.fed.getColor(this.selectedIndex);
            ds.setRGB(color.getRGB());
         }

         RGB rgb = ds.open();
         if (rgb == null) {
            this.freeSelected();
         } else {
            Color color = new Color(this.getDisplay(), rgb);
            if (this.selectedIndex < 0) {
               this.bgColor = color;
               this.setBackground(this.bgColor);
            } else {
               this.fed.setColor(color, this.selectedIndex);
            }

            c.redraw();
            this.freeSelected();
         }
      }
   }

   public void mouseDown(MouseEvent e) {
      int s = this.fed.getSize();

      for (int i = 0; i < s; i++) {
         int y = this.fed.getValue(i);
         if (e.y >= y - this.halfH && e.y <= y + this.halfH) {
            this.selectedIndex = i;
            this.selectedY = e.y;
            return;
         }
      }

      this.freeSelected();
   }

   public void mouseUp(MouseEvent e) {
      this.freeSelected();
   }

   public void mouseMove(MouseEvent e) {
      System.out.println(this.selectedIndex + " *** " + e.time);
      if (this.selectedIndex >= 0) {
         int offset = e.y - this.selectedY;
         int orgY = this.fed.getValue(this.selectedIndex);
         int newY = offset + orgY;
         this.fed.setValue(newY, this.selectedIndex);
         this.selectedY = e.y;
         Composite c = (Composite)e.getSource();
         c.redraw();
      }
   }

   protected void freeSelected() {
      this.selectedIndex = -1;
   }

   public void dispose() {
      DisposeUtil.tryDispose(this.bgColor);
      super.dispose();
   }

   public static void main(String[] args) {
      Shell shell = new Shell();
      Display display = shell.getDisplay();
      shell.setLayout(new FillLayout());
      CScale cs = new CScale(shell);
      final Feedable fed = new Feed(display);
      cs.setFeedable(fed);
      final Canvas com = new Canvas(shell, 536870912);
      PaintListener p = new PaintListener() {
         public void paintControl(PaintEvent e) {
            GC gc = e.gc;
            int s = fed.getSize();
            Point p = com.getSize();

            for (int j = 0; j < s; j++) {
               gc.setForeground(fed.getColor(j));
               int y = fed.getValue(j);
               gc.drawLine(0, y, p.x, y);
            }
         }
      };
      cs.addPaintListener(new PaintListener() {
         public void paintControl(PaintEvent e) {
            com.redraw();
         }
      });
      com.addPaintListener(p);
      shell.layout();
      shell.open();

      while (!shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }
}
