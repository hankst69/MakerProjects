package com.owon.uppersoft.hdoscilloscope.manipulate;

import java.nio.ByteBuffer;

public interface IPack {
   void pack(ByteBuffer var1);
}
