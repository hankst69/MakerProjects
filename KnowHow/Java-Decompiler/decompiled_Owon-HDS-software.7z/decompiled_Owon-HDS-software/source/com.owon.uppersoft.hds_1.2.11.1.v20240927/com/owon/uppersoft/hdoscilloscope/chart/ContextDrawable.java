package com.owon.uppersoft.hdoscilloscope.chart;

public interface ContextDrawable {
   void draw(GraphicContext var1);
}
