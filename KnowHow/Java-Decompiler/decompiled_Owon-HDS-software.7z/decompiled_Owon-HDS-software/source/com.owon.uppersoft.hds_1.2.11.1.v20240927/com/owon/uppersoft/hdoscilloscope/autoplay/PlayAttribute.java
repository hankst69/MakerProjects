package com.owon.uppersoft.hdoscilloscope.autoplay;

import java.util.List;

class PlayAttribute extends AttributeData {
   public static final int In_turn = 0;
   public static final int Turn_back = 1;

   public PlayAttribute(int currentIndex, int delayTime, int playerMode, String playFolderPath, List<String> filesList) {
      super(currentIndex, delayTime, playerMode, playFolderPath, filesList);
   }

   public void resetCurrentIndex() {
      switch (this.getPlayerMode()) {
         case 0:
            this.setCurrentIndex(-1);
            break;
         case 1:
            this.setCurrentIndex(this.getPlayFileList().size());
            break;
         default:
            this.setCurrentIndex(-1);
      }
   }
}
