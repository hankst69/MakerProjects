package com.owon.uppersoft.hdoscilloscope.chart.model.fft;

import com.owon.uppersoft.hdoscilloscope.chart.model.fft.math.Complex;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.mathD.AfterFFTD;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.mathD.ComplexD;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.mathD.FFTFunctionD;
import java.util.Arrays;

public class FFTUtil {
   private static final int[] wnd_adc = new int[2048];
   private static final int[] temps = new int[2048];
   private static final double[] tempsD = new double[1024];
   private static final Complex[] TD = new Complex[2048];
   private static final Complex[] FD = new Complex[2048];
   private static final ComplexD[] TDD = new ComplexD[2048];
   private static final Complex[] X2 = new Complex[2048];

   static {
      Arrays.fill(wnd_adc, 0);
      Arrays.fill(temps, 0);
      Arrays.fill(tempsD, 0.0);

      for (int i = 0; i < 2048; i++) {
         TD[i] = new Complex();
         FD[i] = new Complex();
         X2[i] = new Complex();
         TDD[i] = new ComplexD();
      }
   }

   public static final void compute_db(int[] adc, int[] data, WndType wt, double vb) {
      wt.wnding(adc, 0, adc.length, 2048, wnd_adc);
      FFTFunctionD.fft_adc(wnd_adc, 0, wnd_adc.length, TDD);
      AfterFFTD.fft_math_dB(TDD, data, tempsD, vb);
   }

   public static final void compute_rms(int[] adc, int[] data, WndType wt) {
      wt.wnding(adc, 0, adc.length, 2048, wnd_adc);
      FFTFunctionD.fft_adc(wnd_adc, 0, wnd_adc.length, TDD);
      AfterFFTD.fft_math_rms(TDD, data);
   }

   public static final void plugValues(int[] src, int[] dest, int length) {
      int srclen = Integer.highestOneBit(src.length);
      System.out.println("srclen: " + srclen);
      int step = length / srclen;
      System.out.println("step: " + step);
      int half = srclen >> 1;
      int start = 0;
      int end = src.length;
      int center = start + end >> 1;
      start = center - half;
      end = center + half;
      System.out.println("start: " + start + "; end: " + end);
      dest[0] = src[start];
      int lasti = 0;
      int i = 0 + step;

      int k;
      for (k = start + 1; i < length; k++) {
         int f = dest[lasti];
         int s = dest[i] = src[k];
         int nv = (int)((double)(s - f) / (double)step);

         for (int m = lasti + 1; m < i; m++) {
            dest[m] = f += nv;
         }

         lasti = i;
         i += step;
      }

      System.out.println("lasti: " + lasti);
      System.out.println("k: " + k);
      System.out.println("i: " + i);
      int last = dest[lasti];

      for (int j = lasti + 1; j < length; j++) {
         dest[j] = last;
      }
   }
}
