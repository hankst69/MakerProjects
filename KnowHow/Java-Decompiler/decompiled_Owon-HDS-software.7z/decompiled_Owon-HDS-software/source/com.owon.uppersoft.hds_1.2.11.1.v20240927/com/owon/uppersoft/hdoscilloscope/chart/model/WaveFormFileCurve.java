package com.owon.uppersoft.hdoscilloscope.chart.model;

import com.owon.uppersoft.common.aspect.Disposable;
import com.owon.uppersoft.common.aspect.Localizable;
import com.owon.uppersoft.hdoscilloscope.chart.AbstWFC;
import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.chart.GraphicContext;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.FFTInfo;
import com.owon.uppersoft.hdoscilloscope.chart.model.fft.FFTWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.math.MathWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.FFTReg;
import com.owon.uppersoft.hdoscilloscope.pref.MathReg;
import com.owon.uppersoft.hdoscilloscope.pref.Reg;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;
import com.owon.uppersoft.hdoscilloscope.recycle.EmptyWaveFormCurve;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;
import org.eclipse.swt.graphics.Point;

public class WaveFormFileCurve implements Disposable, Localizable {
   private Map<String, WaveFormCurve> waveForms;
   private XYWaveFormCurve xyCurve;
   private DrawingPanel dp;
   private WaveFormFile wff;
   private boolean waveformMemento = false;
   private Reg reg;
   private WaveFormCurve selectedWaveFormCurve;
   private WaveFormCurve pointSelectedCurve;

   public XYWaveFormCurve getXYWaveFormCurve() {
      return this.xyCurve;
   }

   public void setXYChosen(boolean XYChosen) {
      this.reg.setXYChosen(XYChosen);
   }

   public boolean isXYChosen() {
      return this.reg.isXYChosen();
   }

   public WaveFormFile getWaveFormFile() {
      return this.wff;
   }

   public WaveFormFileCurve(DrawingPanel drawingPanel) {
      this.waveForms = new TreeMap<>();
      this.dp = drawingPanel;
      this.reg = Platform.getPlatform().getConfiguration().reg;
   }

   public DrawingPanel getDrawingPanel() {
      return this.dp;
   }

   public int getWaveformsNumber() {
      return this.waveForms.size();
   }

   public Collection<WaveFormCurve> wfc_collect() {
      return this.waveForms.values();
   }

   public Collection<WaveFormCurve> all_collect() {
      return this.waveForms.values();
   }

   public void removeWaveFormCurve(WaveFormCurve wfc) {
      this.waveForms.remove(wfc.getStrChannelType());
      if (wfc instanceof AbstWFC) {
         AbstWFC awfc = (AbstWFC)wfc;
         awfc.getWFReg().setCreate(false);
      }

      boolean var10000 = wfc instanceof EmptyWaveFormCurve;
   }

   public WaveFormCurve addMathWaveFormFile() {
      String n = "math";
      WaveFormCurve w = this.getWaveFormCurve(n);
      if (w != null) {
         return w;
      } else {
         MathReg r = this.reg.getMathReg();
         WaveFormCurve var4 = new MathWaveFormCurve(this, r);
         this.waveForms.put(n, var4);
         return var4;
      }
   }

   public WaveFormCurve addFFTWaveFormFile(PrototypeWaveFormCurve wfc) {
      String n = wfc.getWaveForm().getFFTName();
      FFTReg r = this.reg.getFFTReg(n);
      WaveFormCurve w = this.getWaveFormCurve(n);
      if (w != null) {
         return w;
      } else {
         WaveFormCurve var5 = new FFTWaveFormCurve(wfc.getWaveForm(), this, r);
         this.waveForms.put(n, var5);
         return var5;
      }
   }

   public WaveFormCurve addAlphaWaveFormFile(WaveFormCurve wfc) {
      String n = wfc.getWaveForm().getStrChannelType();
      WFReg r = this.reg.getWFReg(n);
      WaveFormCurve w = this.getWaveFormCurve(n);
      if (w != null) {
         return w;
      } else {
         WaveFormCurve var5 = new AlphaWaveFormCurve(wfc.getWaveForm(), this, r);
         this.waveForms.put(n, var5);
         return var5;
      }
   }

   public String getLastSelectedChannel() {
      return this.reg.getLastSelChlName();
   }

   public void setWaveFormFile(WaveFormFile wfile) {
      WaveFormCurve wfc = null;
      if (this.wff != null && this.waveformMemento) {
         for (WaveForm wf : this.wff.wf_collect()) {
            wfc = this.getWaveFormCurve(wf.getStrChannelType());
            if (wfc != null) {
               int xb = wfc.baseIdxOnX();
               int yb = wfc.baseIdxOnY();
               if (xb < 0 || xb >= wfc.xb_collect().size()) {
                  xb = wf.getIntTimeBase();
               }

               if (yb < 0 || yb >= wfc.yb_collect().size()) {
                  yb = wf.getIntVoltageBase();
               }

               wf.setDesireXbase(xb);
               wf.setDesireYbase(yb);
            }
         }
      }

      if (this.wff != null) {
         this.wff.releaseBA();
      }

      this.waveForms.clear();
      if (this.selectedWaveFormCurve != null) {
         this.reg.setLastSelChlName(this.selectedWaveFormCurve.getStrChannelType());
         this.selectedWaveFormCurve = null;
      }

      this.wff = wfile;

      for (WaveForm wfx : wfile.wf_collect()) {
         String chn = wfx.getStrChannelType();
         FFTInfo fi = wfx.getFFTInfo();
         boolean protofft = fi.isProtoFFT();
         FFTReg fr = this.reg.getFFTReg(wfx.getFFTName());
         WFReg wr = this.reg.getWFReg(chn);
         if (protofft) {
            fr.setCreate(true);
            wr.setCreate(false);
            this.reg.setAutoCreateFFT(false);
         } else {
            if (this.reg.isAutoCreateFFT()) {
               if (!wfx.isFFTComputable()) {
                  fr.setCreate(false);
               }
            } else {
               fr.setCreate(false);
            }

            wr.setCreate(true);
         }

         if (wr.isCreate()) {
            wfc = wfx.createWFC(this, wr);
            this.waveForms.put(chn, wfc);
         }

         if (fr.isCreate()) {
            if (!this.reg.isAutoApplyFFT()) {
               fr.dr = fi.getDB_Vrms();
               fr.wt = fi.getWndTypeIdx();
               fr.zr = fi.getZoomRate();
            }

            WaveFormCurve var13 = new FFTWaveFormCurve(wfx, this, fr);
            String fftchn = var13.getStrChannelType();
            this.waveForms.put(fftchn, var13);
         }
      }

      MathReg r = this.reg.getMathReg();
      if (r.isCreate() && wfile.isMathAvailable()) {
         WaveFormCurve var14 = new MathWaveFormCurve(this, r);
         String chnx = var14.getStrChannelType();
         this.waveForms.put(chnx, var14);
      }

      this.xyCurve = new XYWaveFormCurve(this);
   }

   public Reg getReg() {
      return this.reg;
   }

   public void resizeTo(Point lastsize, Point size) {
      for (WaveFormCurve wfc : this.all_collect()) {
         wfc.controlResize(lastsize, size);
      }
   }

   public void setLineVisible(boolean lineVisible) {
      this.reg.setLineVisible(lineVisible);
   }

   public boolean isLineVisible() {
      return this.reg.isLineVisible();
   }

   public WaveFormCurve getWaveFormCurve(String channelType) {
      if (channelType == null) {
         return null;
      } else {
         for (WaveFormCurve wfc : this.all_collect()) {
            if (wfc.getStrChannelType().equalsIgnoreCase(channelType)) {
               return wfc;
            }
         }

         return null;
      }
   }

   public WaveFormCurve getSelectedWaveFormCurve() {
      return this.selectedWaveFormCurve;
   }

   public WaveFormCurve getAnyChannelWFC() {
      for (WaveFormCurve wfc : this.wfc_collect()) {
         if (wfc.isChannel()) {
            return wfc;
         }
      }

      return null;
   }

   public void setSelectedWaveFormCurve(WaveFormCurve curve) {
      if (curve != null) {
         this.selectedWaveFormCurve = curve;
      }
   }

   public boolean isPointSelected(Point point) {
      for (WaveFormCurve wfc : this.all_collect()) {
         if (wfc.isVisible() && wfc.getScalableDrawEngine().isPointSelected(point)) {
            this.pointSelectedCurve = wfc;
            return true;
         }
      }

      this.pointSelectedCurve = null;
      return false;
   }

   public WaveFormCurve getPointSelectedCurve() {
      return this.pointSelectedCurve;
   }

   public void dispose() {
      if (this.xyCurve != null) {
         this.xyCurve.dispose();
      }
   }

   public void localize() {
      if (this.reg.isXYChosen() && this.xyCurve != null && !this.xyCurve.isXYAvailable()) {
         this.dp.redraw();
      }
   }

   public void drawStuff(GraphicContext gx) {
      if (this.wff != null) {
         ;
      }
   }
}
