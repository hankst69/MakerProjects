package com.owon.uppersoft.hdoscilloscope.communication;

import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.i18n.MessageErrRunner;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

public class PrototypePortSettingFrame {
   protected Text txtPort;
   protected Text txtIP;
   protected CLabel clabel;
   protected Button keepgettingButton;
   protected Button uploadButton;
   protected Composite serialInfoCom;
   protected Composite usbInfoCom;
   protected Composite usbtmcInfoCom;
   protected Composite lanInfoCom;
   protected Label serialInfoLabel;
   protected Composite infoCom;
   protected Label availablePortsLabel;
   protected Label tmcAvailablePortsLabel;
   protected Button btnBrowse;
   protected Button checkSave;
   protected Text txtPath;
   protected Spinner delaySpinner;
   protected Label labDelay;
   protected Composite loopSettingCom;
   protected Button refreshButton;
   protected Button refreshTmcButton;
   protected Combo usbCombo;
   protected Combo usbtmcCombo;
   protected Label stopbitsLabel;
   protected Label parityLabel;
   protected Label dataBitsLabel;
   protected Label baudLabel;
   protected Combo stopBitsCombo;
   protected Combo parityCombo;
   protected Combo dataBitsCombo;
   protected Combo baudRateCombo;
   protected Label portTypeLabel;
   protected Combo portTypeCombo;
   protected Button btnOK;
   protected Group loopSettingGroup;
   protected Shell shell;
   protected StackLayout stackLayout;
   protected Label label;
   protected Button binButton;
   protected Button bmpButton;
   protected Button memdepthButton;
   protected Label cmdPrompt;
   protected Label btnPrompt;
   protected Group cmdGroup;
   protected Composite portCom;
   private MessageErrRunner mer;
   protected Label labPort;

   public Shell getShell() {
      return this.shell;
   }

   public PrototypePortSettingFrame(Shell parent) {
      this.shell = new Shell(parent, 67680);
      this.createContents();
   }

   public Object open() {
      this.shell.pack();
      ShellUtil.centerLoc(this.shell);
      this.shell.open();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }

      return null;
   }

   protected void createContents() {
      GridLayout gridLayout = new GridLayout();
      this.shell.setLayout(gridLayout);
      this.portCom = new Composite(this.shell, 0);
      GridLayout gridLayout_3 = new GridLayout();
      gridLayout_3.numColumns = 2;
      this.portCom.setLayout(gridLayout_3);
      GridData gd_portCom = new GridData(4, 4, true, false);
      this.portCom.setLayoutData(gd_portCom);
      this.portTypeLabel = new Label(this.portCom, 0);
      GridData gd_portTypeLabel = new GridData();
      gd_portTypeLabel.horizontalIndent = 5;
      this.portTypeLabel.setLayoutData(gd_portTypeLabel);
      this.portTypeCombo = new Combo(this.portCom, 8);
      this.portTypeCombo.setLayoutData(new GridData());
      this.infoCom = new Composite(this.portCom, 0);
      GridData gd_infoCom = new GridData(4, 16777216, true, false, 2, 1);
      this.infoCom.setLayoutData(gd_infoCom);
      this.stackLayout = new StackLayout();
      this.infoCom.setLayout(this.stackLayout);
      this.usbInfoCom = new Composite(this.infoCom, 0);
      GridLayout gridLayout_1 = new GridLayout();
      gridLayout_1.numColumns = 4;
      this.usbInfoCom.setLayout(gridLayout_1);
      this.availablePortsLabel = new Label(this.usbInfoCom, 0);
      this.availablePortsLabel.setText("");
      this.usbCombo = new Combo(this.usbInfoCom, 8);
      this.usbCombo.setLayoutData(new GridData(120, -1));
      this.refreshButton = new Button(this.usbInfoCom, 0);
      this.refreshButton.setLayoutData(new GridData(80, -1));
      this.lanInfoCom = new Composite(this.infoCom, 0);
      GridLayout gridLayout_5 = new GridLayout();
      gridLayout_5.numColumns = 5;
      this.lanInfoCom.setLayout(gridLayout_5);
      Label labIP = new Label(this.lanInfoCom, 0);
      labIP.setText("IP:");
      this.txtIP = new Text(this.lanInfoCom, 2048);
      this.txtIP
         .addFocusListener(
            new FocusAdapter() {
               public void focusLost(FocusEvent e) {
                  String p = PrototypePortSettingFrame.this.txtIP.getText();
                  String m = "^(22[0-3]|2[0-1]\\d|1\\d{2}|[1-9]\\d|[1-9])\\.(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)\\.(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)\\.(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)$";
                  if (!p.matches(m)) {
                     PrototypePortSettingFrame.this.mer = ResourceBundleProvider.getMessageErrRunner();
                     PrototypePortSettingFrame.this.mer.setInfo("Err.BadIp", 1, PrototypePortSettingFrame.this.shell);
                     System.out.println(PrototypePortSettingFrame.this.txtIP.setFocus());
                  }
               }
            }
         );
      this.txtIP.addKeyListener(new KeyAdapter() {
         public void keyPressed(KeyEvent e) {
            if ("0123456789.".indexOf(e.character) < 0) {
               if (e.keyCode == 8 || e.keyCode == 127) {
                  return;
               }

               e.doit = false;
            }
         }
      });
      GridData gd_txtIP = new GridData(4, 16777216, false, false);
      gd_txtIP.widthHint = 134;
      this.txtIP.setLayoutData(gd_txtIP);
      this.labPort = new Label(this.lanInfoCom, 0);
      this.labPort.setLayoutData(new GridData());
      this.txtPort = new Text(this.lanInfoCom, 2048);
      this.txtPort.addKeyListener(new KeyAdapter() {
         public void keyPressed(KeyEvent e) {
            if ("0123456789".indexOf(e.character) < 0) {
               if (e.keyCode == 8 || e.keyCode == 127) {
                  return;
               }

               e.doit = false;
            }
         }
      });
      GridData gd_txtPort = new GridData(4, 16777216, false, false);
      gd_txtPort.widthHint = 54;
      this.txtPort.setLayoutData(gd_txtPort);
      this.usbtmcInfoCom = new Composite(this.infoCom, 0);
      GridLayout gridLayout_6 = new GridLayout();
      gridLayout_6.numColumns = 4;
      this.usbtmcInfoCom.setLayout(gridLayout_6);
      this.tmcAvailablePortsLabel = new Label(this.usbtmcInfoCom, 0);
      this.tmcAvailablePortsLabel.setText("");
      this.usbtmcCombo = new Combo(this.usbtmcInfoCom, 8);
      this.usbtmcCombo.setLayoutData(new GridData(120, -1));
      this.refreshTmcButton = new Button(this.usbtmcInfoCom, 0);
      this.refreshTmcButton.setLayoutData(new GridData(80, -1));
      this.serialInfoCom = new Composite(this.infoCom, 0);
      GridLayout gridLayout_2 = new GridLayout();
      gridLayout_2.numColumns = 8;
      this.serialInfoCom.setLayout(gridLayout_2);
      this.baudLabel = new Label(this.serialInfoCom, 0);
      this.baudRateCombo = new Combo(this.serialInfoCom, 8);
      this.dataBitsLabel = new Label(this.serialInfoCom, 0);
      this.dataBitsCombo = new Combo(this.serialInfoCom, 8);
      this.parityLabel = new Label(this.serialInfoCom, 0);
      this.parityCombo = new Combo(this.serialInfoCom, 8);
      this.stopbitsLabel = new Label(this.serialInfoCom, 0);
      this.stopBitsCombo = new Combo(this.serialInfoCom, 8);
      Label label_1 = new Label(this.usbInfoCom, 0);
      label_1.setLayoutData(new GridData(4, 16777216, true, false));
      this.stackLayout.topControl = this.lanInfoCom;
      Label plbl = new Label(this.lanInfoCom, 0);
      plbl.setText("(0~4000)");
      plbl.setLayoutData(new GridData());
      plbl.setVisible(false);
      this.customCMDGroup();
      this.loopSettingGroup = new Group(this.shell, 0);
      this.loopSettingGroup.setLayout(new FillLayout());
      this.loopSettingGroup.setLayoutData(new GridData(4, 4, true, true));
      this.loopSettingCom = new Composite(this.loopSettingGroup, 0);
      GridLayout gridLayout_4 = new GridLayout();
      gridLayout_4.numColumns = 3;
      this.loopSettingCom.setLayout(gridLayout_4);
      this.labDelay = new Label(this.loopSettingCom, 0);
      this.delaySpinner = new Spinner(this.loopSettingCom, 2048);
      this.delaySpinner.setLayoutData(new GridData(1, 16777216, false, false, 2, 1));
      this.checkSave = new Button(this.loopSettingCom, 32);
      this.checkSave.setLayoutData(new GridData(4, 16777216, true, false, 3, 1));
      this.txtPath = new Text(this.loopSettingCom, 2056);
      this.txtPath.setLayoutData(new GridData(4, 16777216, true, false, 2, 1));
      this.btnBrowse = new Button(this.loopSettingCom, 0);
      this.btnBrowse.setLayoutData(new GridData(4, 16777216, false, false));
      this.clabel = new CLabel(this.loopSettingCom, 66);
      GridData gd_text = new GridData(16384, 16777216, false, false, 3, 1);
      this.clabel.setLayoutData(gd_text);
      Composite btnBar = new Composite(this.shell, 0);
      RowLayout rowLayout = new RowLayout();
      rowLayout.pack = false;
      rowLayout.fill = true;
      rowLayout.spacing = 15;
      btnBar.setLayout(rowLayout);
      GridData gd_btnBar = new GridData(131072, 4, true, false);
      btnBar.setLayoutData(gd_btnBar);
      this.btnOK = new Button(btnBar, 0);
      this.uploadButton = new Button(btnBar, 0);
      this.keepgettingButton = new Button(btnBar, 0);
   }

   protected void customCMDGroup() {
      this.customCMDGroupNormal();
   }

   protected void customCMDGroupSDS() {
      this.cmdGroup = new Group(this.portCom, 0);
      this.cmdGroup.setVisible(false);
      this.cmdGroup.setLayoutData(new GridData(4, 16777216, true, false, 4, 1));
      GridLayout gridLayout_5 = new GridLayout();
      gridLayout_5.numColumns = 4;
      this.cmdGroup.setLayout(gridLayout_5);
      this.binButton = new Button(this.cmdGroup, 16);
      this.bmpButton = new Button(this.cmdGroup, 16);
      this.bmpButton.setVisible(false);
      this.memdepthButton = new Button(this.cmdGroup, 16);
      this.memdepthButton.setVisible(false);
      this.btnPrompt = new Label(this.cmdGroup, 0);
      this.btnPrompt.setLayoutData(new GridData(4, 16777216, true, false));
      this.cmdPrompt = new Label(this.cmdGroup, 0);
      this.cmdPrompt.setLayoutData(new GridData(4, 16777216, true, false, 4, 1));
   }

   protected void customCMDGroupTD() {
      this.customCMDGroupSDS();
      this.bmpButton.setVisible(false);
      this.cmdGroup.layout();
   }

   protected void customCMDGroupNormal() {
      this.customCMDGroupSDS();
      this.cmdGroup.setVisible(false);
      this.cmdGroup.layout();
   }

   public static void main_hide(String[] args) {
      try {
         Shell s = new Shell();
         PrototypePortSettingFrame ps = new PrototypePortSettingFrame(s);
         s.open();
         ps.open();
      } catch (Exception var3) {
         var3.printStackTrace();
      }
   }
}
