package com.owon.uppersoft.hdoscilloscope.communication.serial;

import java.io.UnsupportedEncodingException;

public class CRC16 {
   public static int encode(byte[] bytes) {
      return encode(bytes, 0, bytes.length);
   }

   public static int encode(byte[] bytes, int offset, int length) {
      int crc = 0;
      int tmp = 0;

      for (int i = offset; i < offset + length; i++) {
         int var7 = bytes[i];
         crc ^= var7 << 8;

         for (int j = 0; j < 8; j++) {
            if ((crc & 32768) != 0) {
               crc = (crc & 32767) << 1 ^ 4129;
            } else {
               crc = (crc & 32767) << 1;
            }
         }
      }

      return crc;
   }

   public static void main_hide(String[] args) {
      byte[] b1 = new byte[]{
         115,
         112,
         98,
         48,
         46,
         98,
         105,
         110,
         0,
         50,
         53,
         48,
         52,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0
      };
      System.out.println(encode(b1) == 8414);
      b1[3] = 49;
      System.out.println(encode(b1, 0, b1.length) == 38249);
      b1[3] = 50;
      System.out.println(encode(b1) == 23441);
      b1[3] = 51;
      System.out.println(encode(b1, 0, b1.length) == 60966);
      b1[3] = 52;
      System.out.println(encode(b1) == 54848);

      try {
         String ss = new String(b1, "UTF-8");
         System.out.println(ss);
         byte zero = 0;
         int index = ss.indexOf(zero);
         System.out.println(index);
         index = ss.indexOf(zero, ++index);
         System.out.println(index);
      } catch (UnsupportedEncodingException var5) {
         var5.printStackTrace();
      }
   }
}
