package com.owon.uppersoft.hdoscilloscope.recycle;

import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.communication.usb.IUSBProtocol;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.util.ResourceBundle;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class SendCommandWindow {
   protected Shell parent;
   protected Shell shell;
   private Label label;
   private Button sureButton;
   private Button cancelButton;
   private ResourceBundle bundle;
   private Button[] choicesbtns;

   public SendCommandWindow(Shell s) {
      this.parent = s;
   }

   public void open() {
      Display display = Display.getDefault();
      this.createContents();
      this.localize();
      this.shell.open();
      this.shell.layout();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }

   public Shell getShell() {
      return this.shell;
   }

   protected void createContents() {
      this.shell = new Shell(this.parent);
      GridLayout gridLayout = new GridLayout();
      gridLayout.numColumns = 4;
      this.shell.setLayout(gridLayout);
      this.shell.setSize(312, 127);
      ShellUtil.centerLoc(this.shell);
      this.label = new Label(this.shell, 0);
      GridData gd_label = new GridData(4, 4, false, false, 4, 1);
      gd_label.widthHint = 287;
      gd_label.heightHint = 21;
      this.label.setLayoutData(gd_label);
      Button binButton = new Button(this.shell, 16);
      GridData gd_binButton = new GridData(4, 16777216, false, false);
      gd_binButton.heightHint = 26;
      gd_binButton.widthHint = 49;
      binButton.setLayoutData(gd_binButton);
      binButton.setText("Bin");
      Button bmpButton = new Button(this.shell, 16);
      GridData gd_bmpButton = new GridData(4, 16777216, false, false);
      gd_bmpButton.widthHint = 59;
      bmpButton.setLayoutData(gd_bmpButton);
      bmpButton.setText("Bmp");
      Button memButton = new Button(this.shell, 16);
      memButton.setLayoutData(new GridData(4, 16777216, false, false));
      memButton.setText("Mem");
      Button nullButton = new Button(this.shell, 16);
      nullButton.setLayoutData(new GridData(131072, 4, false, false));
      nullButton.setText("Not of them");
      new Label(this.shell, 0);
      this.choicesbtns = new Button[]{nullButton, binButton, bmpButton, memButton};
      this.choicesbtns[Platform.getPlatform().getConfiguration().usbRequestCMDidx].setSelection(true);
      this.sureButton = new Button(this.shell, 0);
      GridData gd_sureButton = new GridData(16777216, 16777216, false, false);
      gd_sureButton.widthHint = 67;
      this.sureButton.setLayoutData(gd_sureButton);
      this.sureButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int len = SendCommandWindow.this.choicesbtns.length;

            int i;
            for (i = 0; i < len; i++) {
               if (SendCommandWindow.this.choicesbtns[i].getSelection()) {
                  Platform.getPlatform().getConfiguration().usbRequestCMDidx = i;
                  break;
               }
            }

            System.out.println(IUSBProtocol.CMDS[i]);
            SendCommandWindow.this.shell.close();
         }
      });
      new Label(this.shell, 0);
      this.cancelButton = new Button(this.shell, 0);
      GridData gd_cancelButton = new GridData(16777216, 4, false, false);
      gd_cancelButton.widthHint = 64;
      this.cancelButton.setLayoutData(gd_cancelButton);
      this.cancelButton.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            SendCommandWindow.this.shell.close();
         }
      });
   }

   public void localize() {
      this.bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      this.shell.setText(this.bundle.getString("SendCmdWin.FrameTxt"));
      this.label.setText(this.bundle.getString("SendCmdWin.Label"));
      this.sureButton.setText(this.bundle.getString("SendCmdWin.OK"));
      this.cancelButton.setText(this.bundle.getString("SendCmdWin.Cancel"));
   }
}
