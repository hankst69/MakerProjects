package com.owon.uppersoft.hdoscilloscope.test;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class TestModelessDialog extends Dialog {
   protected Object result;
   protected Shell shell;

   public TestModelessDialog(Shell parent, int style) {
      super(parent, style);
   }

   public TestModelessDialog(Shell parent) {
      this(parent, 0);
   }

   public Object open() {
      this.createContents();
      this.shell.open();
      this.shell.layout();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }

      return this.result;
   }

   protected void createContents() {
      this.shell = new Shell(this.getParent(), 1264);
      this.shell.setSize(500, 375);
      this.shell.setText("SWT DataTableDialog");
   }

   public static void main(String[] args) {
      Shell s = new Shell();
      Display display = s.getDisplay();
      s.setText("Parent");
      s.open();
      TestModelessDialog d = new TestModelessDialog(s);
      d.open();

      while (!s.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }
   }
}
