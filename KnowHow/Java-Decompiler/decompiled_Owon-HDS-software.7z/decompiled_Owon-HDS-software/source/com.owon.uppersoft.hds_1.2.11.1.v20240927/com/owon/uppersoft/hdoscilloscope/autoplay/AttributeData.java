package com.owon.uppersoft.hdoscilloscope.autoplay;

import java.util.List;

abstract class AttributeData {
   private int currentIndex;
   private int delayTime;
   private int playerMode;
   private List<String> filesList;
   private String playFolderPath;

   public AttributeData(int currentIndex, int delayTime, int playerMode, String playFolderPath, List<String> filesList) {
      this.currentIndex = currentIndex;
      this.delayTime = delayTime;
      this.playerMode = playerMode;
      this.playFolderPath = playFolderPath;
      this.filesList = filesList;
   }

   public List<String> getPlayFileList() {
      return this.filesList;
   }

   public void setPlayFileList(List<String> filesList) {
      this.filesList = filesList;
   }

   public synchronized void setCurrentIndex(int index) {
      this.currentIndex = index;
   }

   public synchronized int getCurrentIndex() {
      return this.currentIndex;
   }

   public void setDelayTime(int value) {
      this.delayTime = value;
   }

   public int getDelayTime() {
      return this.delayTime;
   }

   public void setPlayerMode(int value) {
      this.playerMode = value;
   }

   public int getPlayerMode() {
      return this.playerMode;
   }

   public void setPlayFolderPath(String value) {
      this.playFolderPath = value;
   }

   public String getPlayFolderPath() {
      return this.playFolderPath;
   }
}
