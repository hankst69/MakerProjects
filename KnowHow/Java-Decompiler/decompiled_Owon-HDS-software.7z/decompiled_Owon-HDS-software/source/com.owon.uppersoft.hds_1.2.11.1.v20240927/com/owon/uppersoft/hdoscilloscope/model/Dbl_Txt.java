package com.owon.uppersoft.hdoscilloscope.model;

import java.util.List;

public class Dbl_Txt {
   private double v;
   private String n;

   public double v() {
      return this.v;
   }

   public String n() {
      return this.n;
   }

   public Dbl_Txt(double v, String n) {
      this.v = v;
      this.n = n;
   }

   @Override
   public String toString() {
      return this.n;
   }

   public static final void addDbl_Txt(List<Dbl_Txt> l, String txt, double dbl) {
      l.add(new Dbl_Txt(dbl, txt));
   }
}
