package com.owon.uppersoft.hdoscilloscope.data.normal;

import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.deep.MemdepthWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;

public class DefaultMemdepthWFC extends MemdepthWaveFormCurve {
   public DefaultMemdepthWFC(WaveForm wf, WaveFormFileCurve fileCurve, WFReg wfreg) {
      super(wf, fileCurve, wfreg);
   }
}
