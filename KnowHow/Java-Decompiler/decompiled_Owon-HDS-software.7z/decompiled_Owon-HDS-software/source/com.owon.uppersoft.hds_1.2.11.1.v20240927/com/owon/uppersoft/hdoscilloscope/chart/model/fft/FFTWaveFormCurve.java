package com.owon.uppersoft.hdoscilloscope.chart.model.fft;

import com.owon.uppersoft.hdoscilloscope.chart.AbstWFC;
import com.owon.uppersoft.hdoscilloscope.chart.DrawEngine;
import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.TxtEntry;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.FFTReg;
import java.util.Collection;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Menu;

public class FFTWaveFormCurve extends AbstWFC {
   protected WaveForm wf;
   protected IFFTCompute cmode;
   protected IFFTCompute dbmode;
   protected IFFTCompute vrmsmode;
   private int[] oadc;
   private FFTInfo fi;
   private int zoomRate;
   private DrawEngine dren;
   private FFTReg wfreg;
   private int dB_Vrms;
   private int wndTypeIdx;
   private String name;

   public FFTWaveFormCurve(WaveForm wf, WaveFormFileCurve fileCurve, FFTReg wfreg) {
      super(fileCurve, wfreg);
      this.wfreg = wfreg;
      this.dB_Vrms = wfreg.dr;
      this.wndTypeIdx = wfreg.wt;
      this.zoomRate = wfreg.zr;
      this.wf = wf;
      this.fi = wf.getFFTInfo();
      int[] plugged = wf.getIntADCollection();
      if (wf.getIntADCollectionNum() < 2048) {
         int[] new_adc = new int[2048];
         FFTUtil.plugValues(plugged, new_adc, 2048);
         plugged = new_adc;
      }

      this.oadc = plugged;
      System.out.println(this.oadc.length);
      int mode = this.dB_Vrms;
      this.dB_Vrms = -1;
      this.dren = this.createDrawEngine(fileCurve, this);
      this.changeMode(mode);
   }

   @Override
   public ScalableDrawEngine getScalableDrawEngine() {
      return this.dren;
   }

   public int getZoomRate() {
      return this.zoomRate;
   }

   public void setZoomRate(int rate) {
      this.zoomRate = rate;
   }

   public int getDb_Vrms() {
      return this.dB_Vrms;
   }

   public int getWndTypeIdx() {
      return this.wndTypeIdx;
   }

   public boolean changeMode(int mode) {
      if (this.dB_Vrms == mode) {
         return false;
      } else {
         this.dB_Vrms = mode;
         if (mode == 1) {
            if (this.dbmode == null) {
               this.dbmode = new DbFFTDrawCompute(this, this.dren, this.wf, 2048, this.oadc);
            }

            this.cmode = this.dbmode;
         } else {
            if (this.vrmsmode == null) {
               this.vrmsmode = new VrmsFFTDrawCompute(this, this.dren, this.wf, 2048, this.oadc);
            }

            this.cmode = this.vrmsmode;
         }

         this.cmode.resumeToMode();
         this.getWFReg().dr = this.dB_Vrms;
         return true;
      }
   }

   public boolean changeWndType(int wnd) {
      if (this.wndTypeIdx != wnd && this.cmode != null) {
         this.wndTypeIdx = wnd;
         this.cmode.updateWndType();
         this.getWFReg().wt = this.wndTypeIdx;
         return true;
      } else {
         return false;
      }
   }

   public FFTReg getWFReg() {
      return this.wfreg;
   }

   public void datasUpdate() {
      this.cmode.updateWndType();
   }

   @Override
   public boolean equals(WaveFormCurve wfc) {
      return this == wfc;
   }

   @Override
   public int baseIdxOnX() {
      return this.cmode.baseIdxOnX();
   }

   @Override
   public int baseIdxOnY() {
      return this.cmode.baseIdxOnY();
   }

   @Override
   public Collection<? extends Object> xb_collect() {
      return this.cmode.xb_collect();
   }

   @Override
   public Collection<? extends Object> yb_collect() {
      return this.cmode.yb_collect();
   }

   @Override
   public Collection<TxtEntry> txts_coll() {
      return this.cmode.txts_coll();
   }

   @Override
   public String getStrChannelType() {
      if (this.name == null) {
         this.name = "fft" + this.wf.getStrChannelType().substring(2);
      }

      return this.name;
   }

   @Override
   public int getCurveType() {
      return 2;
   }

   @Override
   public boolean isChannel() {
      return false;
   }

   @Override
   public String getXBaseTxt() {
      return this.cmode.getXBaseTxt();
   }

   @Override
   public String getYBaseTxt() {
      return this.cmode.getYBaseTxt();
   }

   @Override
   public int rateAtX() {
      return this.cmode.rateAtX();
   }

   @Override
   public double rateAtY() {
      return this.cmode.rateAtY();
   }

   @Override
   public void setBaseIdxOnX(int idx) {
      this.cmode.setBaseIdxOnX(idx);
   }

   @Override
   public void setBaseIdxOnY(int idx) {
      this.cmode.setBaseIdxOnY(idx);
   }

   @Override
   public String unitForX(double x) {
      return this.cmode.unitForX(x);
   }

   @Override
   public String unitForY(double y) {
      return this.cmode.unitForY(y);
   }

   @Override
   public double valueAtX(double x) {
      return this.cmode.valueAtX(x);
   }

   @Override
   public double valueAtY(double y) {
      return this.cmode.valueAtY(y);
   }

   @Override
   public WaveForm getWaveForm() {
      return this.wf;
   }

   @Override
   public void controlResize(Point lastsize, Point size) {
      this.getScalableDrawEngine().resizeTo(lastsize, size);
      this.cmode.controlResize(lastsize, size);
   }

   @Override
   public void applyToolComposite() {
      Platform.getPlatform().getCenter().getToolCom().applyFFTWFC(this);
   }

   @Override
   public Menu getToolMenu() {
      return Platform.getPlatform().getCenter().applyFFTWFC(this);
   }
}
