package com.owon.uppersoft.hdoscilloscope.chart.model.deep;

import com.owon.uppersoft.hdoscilloscope.chart.DrawingPanel;
import com.owon.uppersoft.hdoscilloscope.chart.GraphicContext;
import com.owon.uppersoft.hdoscilloscope.chart.WaveFormCurveRenderer;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import com.owon.uppersoft.hdoscilloscope.pref.Reg;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.swt.graphics.Point;

public class Pixel4in1Engine extends AbstMemEngine {
   private double zeroYoffset;
   private boolean firstComp;
   private boolean fullComp;
   private double xpp = 0.25;
   private int[] adc;
   private List<Pixel> pts;
   private int start;
   private int len;
   public static final int DefaultNoAction = 0;
   public static final int DefaultXScale = 1;
   public static final int DefaultYScale = 2;
   public static final int DefaultZeroYOffset = 3;
   public static final int DefaultZeroXOffset = 4;
   public static final int DefaultDatasUpdate = 5;

   public Pixel4in1Engine(DrawingPanel dp, MemdepthWaveFormCurve curve) {
      super(dp, curve);
      this.firstComp = true;
      this.fullComp = false;
      this.initPts();
      this.firstComp = false;
      curve.getWaveForm().setIntADCollection(this.adc);
      int maxPos = 0;
      int minPos = 0;
      int maxData;
      int minData;
      int average = maxData = minData = this.adc[0];

      for (int i = 1; i < this.adc.length; i++) {
         int v = this.adc[i];
         average += v;
         if (maxData < v) {
            maxData = v;
            maxPos = i;
         } else if (minData > v) {
            minData = v;
            minPos = i;
         }
      }

      average /= this.adc.length;
      int mid = (maxData + minData) / 2;
      int start;
      if (average >= mid) {
         start = minPos % 4;
      } else {
         start = maxPos % 4;
      }

      WaveForm.showFreq(start, 4, curve.getWaveForm());
   }

   @Override
   public void resizeTo(Point lsz, Point sz) {
      if (lsz.x != 0 && lsz.y != 0 && sz.x != 0 && sz.y != 0) {
         boolean xr = false;
         boolean yr = false;
         if (lsz.x != sz.x) {
            xr = true;
         }

         if (lsz.y != sz.y) {
            yr = true;
         }

         if (xr) {
            double rx = (double)sz.x / (double)lsz.x;
            this.curve.x0 *= rx;
            this.xpp *= rx;
            this.initPts();
         }

         if (yr) {
            double ry = (double)sz.y / (double)lsz.y;
            this.curve.y0 *= ry;
            this.curve.ypp *= ry;
            double pixYperPoint = this.curve.ypp * this.curve.absoluteScaleY;
            int len = this.pts.size();

            for (int i = 0; i < len; i++) {
               Pixel p = this.pts.get(i);
               double locationY = this.curve.y0 - (double)this.adc[i] * pixYperPoint;
               p.y = (int)locationY;
            }
         }
      }
   }

   @Override
   public void setAbsoluteScaleY(double absoluteScaleY) {
      super.setAbsoluteScaleY(absoluteScaleY);
      this.presetCurve(2);
   }

   @Override
   public void setXScale(double xscale) {
      super.setXScale(xscale);
      this.initPts();
   }

   @Override
   public void setZeroXoffset(double x) {
      super.setZeroXoffset(x);
      this.initPts();
   }

   @Override
   public void setZeroYLocation(double y) {
      Reg.AutoApplyZeroLocation = false;
      this.zeroYoffset = y - this.curve.y0;
      this.curve.y0 = y;
      this.wfreg.setZeroLocRate(this.curve.y0 / (double)this.getSize().y);
      this.presetCurve(3);
   }

   public void initPts() {
      if (this.curve.xscale >= 0.0) {
         this.adc = this.compression();
         if (this.curve.x0 < 0.0) {
            this.start = 0;
         } else {
            this.start = (int)this.curve.x0;
         }

         this.len = this.adc.length;
         this.pts = new ArrayList<>(this.len);
         double pixXinterval = this.curve.xpp;
         double pixYperPoint = this.curve.ypp * this.curve.absoluteScaleY;
         if (this.wfreg.isInverted()) {
            pixYperPoint = -pixYperPoint;
         }

         for (int i = 0; i < this.len; i++) {
            int x = (int)((double)this.start + (double)i * pixXinterval);
            int y = (int)(this.curve.y0 - (double)this.adc[i] * pixYperPoint);
            Pixel p = new Pixel(x, y);
            this.pts.add(p);
         }
      } else {
         if (this.fullComp) {
            this.adc = this.curve.getWaveForm().getIntADCollection();
         } else {
            this.adc = this.compression();
            this.curve.getWaveForm().setIntADCollection(this.adc);
            this.fullComp = true;
         }

         this.len = this.adc.length;
         this.pts = new ArrayList<>(this.len);
         double pixXinterval = this.xpp * this.curve.xscale;
         double pixYperPoint = this.curve.ypp * this.curve.absoluteScaleY;
         if (this.wfreg.isInverted()) {
            pixYperPoint = -pixYperPoint;
         }

         for (int i = 0; i < this.len; i++) {
            int x = (int)(this.curve.x0 + (double)i * pixXinterval);
            int y = (int)(this.curve.y0 - (double)this.adc[i] * pixYperPoint);
            Pixel p = new Pixel(x, y);
            this.pts.add(p);
         }
      }
   }

   private int[] compression() {
      WaveForm wf = this.curve.getWaveForm();
      WaveFormFileCurve wffc = this.dp.getWaveFormFileCurve();
      Point size = wffc.getDrawingPanel().getSize();
      int zy = wf.getIntZeroYPoint();
      int intADCollectionNum = wf.getIntADCollectionNum();
      int intFullScreenDataNum = wf.getIntFullScreenDataNum();
      int startPointer = wf.getMemdepthDataIndex();
      CByteArrayInputStream ba = wffc.getWaveFormFile().getba();
      double multiple = (double)intFullScreenDataNum / this.curve.xscale / (double)size.x;
      int skip = 0;
      int lowMove = intADCollectionNum - wf.getIntLowMoveNum();
      if (this.firstComp) {
         int offset = wf.getScreenStartLocation();
         if (offset == 0) {
            this.fullComp = true;
         } else if (wf.isLowMove()) {
            this.curve.x0 = (double)(lowMove - offset) / multiple;
         } else {
            this.curve.x0 = (double)(-offset) / multiple;
         }
      }

      if (this.curve.x0 < 0.0) {
         skip = (int)(-this.curve.x0 * multiple);
      }

      if (wf.isLowMove()) {
         skip += lowMove;
      }

      int x = (int)((double)(intADCollectionNum - skip) / multiple);
      int shift = wf.getShift();
      int[] shtADCollection;
      if (x < 1) {
         if (this.curve.x0 < 0.0) {
            shtADCollection = new int[]{0};
         } else {
            shtADCollection = new int[4];
            ba.reset(startPointer);
            shtADCollection[0] = (ba.nextShort() >> shift) - zy;
            shtADCollection[1] = wf.getMinShtADData();
            shtADCollection[2] = wf.getMaxShtADData();
            int endPointer = startPointer + intADCollectionNum * 2;
            ba.reset(endPointer - 2);
            shtADCollection[3] = (ba.nextShort() >> shift) - zy;
         }
      } else {
         if (x > size.x) {
            x = size.x;
         }

         shtADCollection = new int[4 * x];
         ba.reset(startPointer + skip * 2);
         int k = ba.pointer();

         for (int j = 0; j < x; j++) {
            long packEnd = (long)(startPointer + skip * 2) + Math.round((double)(j + 1) * multiple);
            int packMaxShtADData;
            int packMinShtADData;
            int v = packMaxShtADData = packMinShtADData = ba.nextShort() >> shift;
            k++;

            for (shtADCollection[4 * j] = v - zy; (long)k < packEnd - 1L; k++) {
               v = ba.nextShort() >> shift;
               if (packMaxShtADData < v) {
                  packMaxShtADData = v;
               } else if (packMinShtADData > v) {
                  packMinShtADData = v;
               }
            }

            shtADCollection[4 * j + 1] = packMinShtADData - zy;
            shtADCollection[4 * j + 2] = packMaxShtADData - zy;
            shtADCollection[4 * j + 3] = (ba.nextShort() >> shift) - zy;
            k++;
         }
      }

      return shtADCollection;
   }

   private void presetCurve(int actionStatus) {
      switch (actionStatus) {
         case 0:
         default:
            break;
         case 1:
            Point sz = this.getSize();
            double halfBoundWidth = (double)sz.x / 2.0;
            this.curve.x0 = halfBoundWidth - (halfBoundWidth - this.curve.x0) / this.curve.lastScale * this.curve.xscale;
            this.initPts();
            break;
         case 2:
            double pixYperPoint = this.curve.ypp * this.curve.absoluteScaleY;

            for (int i = 0; i < this.len; i++) {
               Pixel p = this.pts.get(i);
               double locationY = this.curve.y0 - (double)this.adc[i] * pixYperPoint;
               p.y = (int)locationY;
            }
            break;
         case 3:
            int offset = (int)this.zeroYoffset;
            int length = this.pts.size();

            for (int i = 0; i < length; i++) {
               Pixel p = this.pts.get(i);
               p.y += offset;
            }
            break;
         case 4:
            this.initPts();
            break;
         case 5:
            double pixYperPoint = this.curve.ypp * this.curve.absoluteScaleY;
            if (this.wfreg.isInverted()) {
               pixYperPoint = -pixYperPoint;
            }

            for (int i = 0; i < this.len; i++) {
               Pixel p = this.pts.get(i);
               p.y = (int)(this.curve.y0 - (double)this.adc[i] * pixYperPoint);
            }
      }
   }

   @Override
   public void setInverted(boolean invert) {
      this.wfreg.setInverted(invert);
      this.presetCurve(5);
   }

   @Override
   public boolean isPointSelected(Point p) {
      int x = p.x;
      int y = p.y;
      List<Pixel> pointSet = this.pts;
      int length = pointSet.size();
      int minX = pointSet.get(0).x;
      int maxX = pointSet.get(length - 1).x;
      if (x >= minX + 1 && x <= maxX - 1) {
         int index;
         if (this.curve.xscale >= 1.0) {
            double pixXinterval = this.curve.xpp;
            if (this.curve.x0 < 0.0) {
               index = (int)((double)x / pixXinterval);
            } else {
               index = (int)(((double)x - this.curve.x0) / pixXinterval);
            }
         } else {
            double pixXinterval = this.xpp * this.curve.xscale;
            index = (int)(((double)x - this.curve.x0) / pixXinterval);
         }

         if (index >= length) {
            index = length - 1;
         }

         int y3;
         int y1;
         if (index != length - 1) {
            y1 = pointSet.get(index).y;
            y3 = pointSet.get(index + 1).y;
         } else {
            y1 = pointSet.get(index - 1).y;
            y3 = pointSet.get(index).y;
         }

         int y2 = (y1 + y3) / 2;
         boolean flag2 = (y2 + 2 - y) * (y2 - 2 - y) <= 0;
         boolean flag1 = (y1 - y) * (y3 - y) <= 0;
         return flag1 || flag2;
      } else {
         return false;
      }
   }

   @Override
   public void draw(GraphicContext gx) {
      WaveFormCurveRenderer.draw(this.curve, this.pts, gx);
   }
}
