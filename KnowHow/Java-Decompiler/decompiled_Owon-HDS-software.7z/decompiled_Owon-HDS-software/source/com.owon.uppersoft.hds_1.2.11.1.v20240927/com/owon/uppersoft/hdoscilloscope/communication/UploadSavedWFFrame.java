package com.owon.uppersoft.hdoscilloscope.communication;

import com.owon.uppersoft.common.aspect.Localizable;
import com.owon.uppersoft.common.utils.ShellUtil;
import com.owon.uppersoft.hdoscilloscope.communication.loop.RapidCommunication;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.util.FileChooserUtil;
import java.io.File;
import java.nio.ByteBuffer;
import java.util.ResourceBundle;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.eclipse.jface.viewers.CheckboxTableViewer;
import org.eclipse.jface.viewers.ColumnPixelData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;

public class UploadSavedWFFrame implements Localizable {
   protected Shell shell;
   private Button btngetData;
   private Table table;
   private CheckboxTableViewer tableViewer;
   private Button btnDisplay;
   private Button btnAll;
   private Button btnRefresh;
   private Label lbPath;
   private Text txtPath;
   private Button btnBrowse;

   public Shell getShell() {
      return this.shell;
   }

   public UploadSavedWFFrame(Shell parent) {
      this.shell = new Shell(parent, 1264);
      this.shell.setSize(541, 390);
      this.createContents();
   }

   public Object open() {
      this.shell.pack();
      ShellUtil.centerLoc(this.shell);
      this.shell.open();
      Display display = this.shell.getDisplay();

      while (!this.shell.isDisposed()) {
         if (!display.readAndDispatch()) {
            display.sleep();
         }
      }

      return null;
   }

   protected void createContents() {
      this.shell.setLayout(new GridLayout());
      this.tableViewer = CheckboxTableViewer.newCheckList(this.shell, 67584);
      this.table = this.tableViewer.getTable();
      this.table.setLayoutData(new GridData(4, 4, true, true, 1, 1));
      this.table.setHeaderVisible(true);
      this.table.setLinesVisible(true);
      TableLayout tableLayout = new TableLayout();
      this.table.setLayout(tableLayout);
      tableLayout.addColumnData(new ColumnPixelData(80));
      new TableColumn(this.table, 0).setText("ID");
      tableLayout.addColumnData(new ColumnPixelData(80));
      new TableColumn(this.table, 0).setText("Source");
      tableLayout.addColumnData(new ColumnPixelData(80));
      new TableColumn(this.table, 0).setText("Display");
      this.tableViewer.setContentProvider(new TableViewerContentProvider());
      this.tableViewer.setLabelProvider(new TableViewerLabelProvider());
      this.tableViewer.getCheckedElements();
      Composite composite = new Composite(this.shell, 0);
      GridLayout gridLayout_1 = new GridLayout();
      gridLayout_1.numColumns = 4;
      gridLayout_1.verticalSpacing = 10;
      composite.setLayout(gridLayout_1);
      composite.setLayoutData(new GridData(4, 4, true, false));
      this.btnDisplay = new Button(composite, 0);
      this.btnDisplay.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            JSONArray ja = (JSONArray)UploadSavedWFFrame.this.tableViewer.getInput();
            UploadSavedWFFrame.this.tableViewer.setAllChecked(false);

            for (int i = 0; i < ja.size(); i++) {
               JSONObject jo = ja.getJSONObject(i);
               if (jo.getString("display_switch").equalsIgnoreCase("on")) {
                  UploadSavedWFFrame.this.tableViewer.setChecked(jo, true);
               }
            }

            UploadSavedWFFrame.this.tableViewer.refresh();
         }
      });
      this.btnDisplay.setText("Radio Button");
      this.btnAll = new Button(composite, 0);
      this.btnAll.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            UploadSavedWFFrame.this.tableViewer.setAllChecked(true);
            UploadSavedWFFrame.this.tableViewer.refresh();
         }
      });
      this.btnAll.setText("Radio Button");
      this.btnAll.setSelection(true);
      this.btnRefresh = new Button(composite, 0);
      this.btnRefresh.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            UploadSavedWFFrame.this.getHead();
         }
      });
      this.btnRefresh.setText("New Button");
      this.btngetData = new Button(composite, 0);
      this.btngetData.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            Object[] obj = UploadSavedWFFrame.this.tableViewer.getCheckedElements();
            if (obj.length != 0) {
               JSONArray ja = new JSONArray();

               for (int i = 0; i < obj.length; i++) {
                  ja.element(obj[i]);
               }

               RapidCommunication comm = new RapidCommunication(null);
               comm.startInit();
               comm.startOnce();
               comm.getSavedData(ja);
               comm.endOnce();
               comm.endFinl();
               File f = new File(UploadSavedWFFrame.this.txtPath.getText().trim());
               comm.setSavedFile(f);
               Platform.getPlatform().getActionFactory().open.doOpenFile(f);
            }
         }
      });
      this.btngetData.setText("New Button");
      this.lbPath = new Label(composite, 0);
      this.lbPath.setLayoutData(new GridData(131072, 16777216, false, false, 1, 1));
      this.lbPath.setText("New Label");
      this.txtPath = new Text(composite, 2048);
      GridData gd_text = new GridData(4, 16777216, true, false, 2, 1);
      gd_text.widthHint = 303;
      this.txtPath.setLayoutData(gd_text);
      this.btnBrowse = new Button(composite, 0);
      this.btnBrowse.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            FileDialog fd = new FileDialog(UploadSavedWFFrame.this.shell);
            fd.setFilterExtensions(new String[]{"*.bin"});
            String s = fd.open();
            if (s != null) {
               if (!s.endsWith(".bin")) {
                  s = s + ".bin";
               }

               UploadSavedWFFrame.this.txtPath.setText(s);
            }
         }
      });
      this.btnBrowse.setText("New Button");
      this.localize();
      this.setPath();
      this.getHead();
   }

   private void setPath() {
      String path = Platform.getPlatform().getConfiguration().savePath;
      this.txtPath.setText(path + FileChooserUtil.getRandomFileName() + ".bin");
   }

   public static void main_hide(String[] args) {
      UploadSavedWFFrame ps = new UploadSavedWFFrame(null);
      ps.open();
   }

   public void localize() {
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      this.shell.setText(bundle.getString("USF.GetData"));
      this.btngetData.setText(bundle.getString("USF.GetData"));
      this.btnDisplay.setText(bundle.getString("USF.Display"));
      this.btnAll.setText(bundle.getString("USF.All"));
      this.btnRefresh.setText(bundle.getString("USF.Refresh"));
      this.btnBrowse.setText(bundle.getString("USF.Browse"));
      this.lbPath.setText(bundle.getString("USF.Path"));
   }

   public void getHead() {
      RapidCommunication rcomm = new RapidCommunication(null);
      rcomm.startInit();
      rcomm.startOnce();
      byte[] b = ":SAVE:READ:HEAD?\r\n".getBytes();
      rcomm.write(b, 0, b.length);
      b = new byte[512];
      int num = rcomm.read(b, 0, b.length);
      if (num >= 0) {
         System.out.println(num);
         int len = this.getInt(b, false);
         System.out.println("len" + len);
         ByteBuffer bb = ByteBuffer.allocate(len);
         bb.put(b, 4, num - 4);
         int time = 0;

         while (bb.remaining() > 0) {
            num = rcomm.read(b, 0, b.length);
            if (num <= 0) {
               System.out.println("error");
               if (time-- < 0) {
                  break;
               }
            } else {
               bb.put(b, 0, num);
            }
         }

         rcomm.endOnce();
         rcomm.endFinl();
         this.getJsonHead(new String(bb.array()).trim());
      }
   }

   public void getJsonHead(String s) {
      JSONArray ja;
      if (s.equalsIgnoreCase("[?]")) {
         ja = new JSONArray();
      } else {
         ja = JSONArray.fromObject(s.toLowerCase());
      }

      System.out.println(ja);
      this.tableViewer.setInput(ja);
      this.tableViewer.refresh();
   }

   private int getInt(byte[] b, boolean order) {
      if (order) {
         int i = b[3] & 255;
         i += (b[2] & 255) << 8;
         i += (b[1] & 255) << 16;
         return i + ((b[0] & 0xFF) << 24);
      } else {
         int i = b[0] & 255;
         i += (b[1] & 255) << 8;
         i += (b[2] & 255) << 16;
         return i + ((b[3] & 0xFF) << 24);
      }
   }
}
