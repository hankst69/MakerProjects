package com.owon.uppersoft.hdoscilloscope.communication.usb.rapid;

import com.owon.uppersoft.hdoscilloscope.action.StatusLineProgressHandler;
import com.owon.uppersoft.hdoscilloscope.chart.model.ControlManger;
import com.owon.uppersoft.hdoscilloscope.communication.loop.LoopControl;
import com.owon.uppersoft.hdoscilloscope.communication.loop.RapidCommunication;
import com.owon.uppersoft.hdoscilloscope.data.InfoPart;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.data.transform.CByteArrayInputStream;
import com.owon.uppersoft.hdoscilloscope.data.transform.IDataImport;
import com.owon.uppersoft.hdoscilloscope.data.transform.RapidDataImport;
import com.owon.uppersoft.hdoscilloscope.frame.MainFrame;
import com.owon.uppersoft.hdoscilloscope.frame.view.StatusLine;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.MessageErrRunner;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import com.owon.uppersoft.hdoscilloscope.pref.Configuration;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;

public class RapidLoop implements Runnable {
   public static final int Default_RetryCount = 10;
   public static final int Default_RetryTimeDelay = 1000;
   private RapidCommunication rcomm;
   private IDataImport rid;
   private boolean keepOn;
   private Platform platform;
   private int retryCount;
   private int loopDelay;
   private RapidLoop.ImportRunner importRunner = new RapidLoop.ImportRunner();
   private RapidLoop.RenableRunner renableRunner = new RapidLoop.RenableRunner();
   private StatusLineProgressHandler iclp;
   private MessageErrRunner mer;
   private FilePool fpool;
   private Thread t;
   private boolean doGet = true;
   private ShowImageDialog2 showImageDlg2;

   public RapidLoop(StatusLineProgressHandler iclp, FilePool fpool) {
      this.platform = Platform.getPlatform();
      Configuration config = this.platform.getConfiguration();
      this.fpool = fpool;
      if (fpool == null) {
         StatusLine sl = this.platform.getMainFrame().getStatusLine();
         sl.setPath(sl.getInfoNoFileLoop());
      }

      this.loopDelay = config.loopDelay;
      this.rcomm = new RapidCommunication(iclp);
      iclp.setRapidLoop(this);
      this.iclp = iclp;
      this.rid = new RapidDataImport();
      this.keepOn = true;
      this.mer = ResourceBundleProvider.getMessageErrRunner();
   }

   public void startLoop() {
      this.t = new Thread(this);
      this.t.start();
   }

   public void stopLoop() {
      this.iclp.resetICL();
      this.keepOn = false;
      this.rcomm.cancel();
   }

   public boolean isKeepOn() {
      return this.keepOn;
   }

   private void beforeRun() {
      this.resumeGet();
      this.platform.getActionFactory().manipulate.updateRSButton(false);
      this.platform.getDrawingPanel().syncSetEnablebuf(false);
      this.platform.getCenter().getToolCom().setFFTButton(false);
   }

   private void afterRun() {
      this.platform.getCenter().getToolCom().setFFTButton(true);
      this.platform.getDrawingPanel().syncSetEnablebuf(true);
      this.renableRunner.reenable();
      this.platform.getActionFactory().manipulate.updateRSButton(true);
   }

   public void suspendGet() {
      this.doGet = false;
   }

   public void resumeGet() {
      this.doGet = true;
   }

   @Override
   public void run() {
      this.beforeRun();
      this.iclp.setICL();
      this.retryCount = 0;
      int retryTimeDelay = 1000 > this.loopDelay ? 1000 : this.loopDelay;
      if (this.fpool != null) {
         this.fpool.beginRecord();
      }

      LoopControl lc = this.platform.getActionFactory().loopControl;
      lc.setUse(true);

      while (this.keepOn) {
         try {
            this.rcomm.startInit();
            if (lc.dealQueue(this.rcomm)) {
               Thread.sleep(200L);
            }

            if (!this.keepOn) {
               break;
            }

            if (!this.doGet) {
               Thread.sleep((long)this.loopDelay);
            } else {
               boolean flag = this.rcomm.getData();
               if (!this.keepOn) {
                  break;
               }

               if (!flag) {
                  this.retryCount++;
                  if (this.retryCount > 10) {
                     this.mer.setInfo("Err.Connect", 1, this.platform.getShell());
                     break;
                  }

                  Thread.sleep((long)retryTimeDelay);
                  this.rcomm.endFinl();
               } else {
                  if (!this.handleReceive()) {
                     break;
                  }

                  this.retryCount = 0;
                  Thread.sleep((long)this.loopDelay);
               }
            }
         } catch (Exception var7) {
            var7.printStackTrace();
         } finally {
            this.rcomm.endFinl();
         }
      }

      if (this.showImageDlg2 != null) {
         this.showImageDlg2.close();
      }

      this.keepOn = false;
      if (this.fpool != null) {
         this.fpool.endRecord();
      }

      this.afterRun();
   }

   private boolean autoSave(String ext) {
      ControlManger cm = Platform.getPlatform().getMainFrame().ctrlMgr;
      File f = this.fpool.nextFile(ext);
      boolean ff = !this.rcomm.setSavedFile(f);
      if (f != null && !ff) {
         if (ext.equalsIgnoreCase("bin")) {
            RandomAccessFile raf;
            try {
               raf = new RandomAccessFile(f, "rw");
            } catch (FileNotFoundException var8) {
               var8.printStackTrace();
               return false;
            }

            InfoPart.write(raf, f);
            CByteArrayInputStream ba = new CByteArrayInputStream(f, raf, false);
            WaveFormFile wff = this.rid.readBinary(ba, cm);
            if (wff != null) {
               wff.setRaw(false);
               wff.setOrginalFile(f);
               this.importRunner.setWaveFormFile(wff);
            } else {
               this.retryCount++;
            }

            if (this.showImageDlg2 != null) {
               this.showImageDlg2.setVisible(false);
            }
         } else {
            this.importRunner.setFile(f);
            if (this.showImageDlg2 == null) {
               this.showImageDlg2 = new ShowImageDialog2(this.platform.getShell(), f.getPath());
               this.showImageDlg2.open();
            } else if (!this.showImageDlg2.isDispose()) {
               this.showImageDlg2.setVisible(true);
               this.showImageDlg2.changeImage(f);
            }
         }

         return true;
      } else {
         return false;
      }
   }

   protected boolean simpleLoad(String ext) {
      ControlManger cm = Platform.getPlatform().getMainFrame().ctrlMgr;
      CByteArrayInputStream ba = this.rcomm.byteInput();
      if (ext.equalsIgnoreCase("bin")) {
         InfoPart ip = new InfoPart();
         ip.setTimestamp();
         WaveFormFile wff = this.rid.readBinary(ba, cm, ip);
         if (wff != null) {
            this.importRunner.setWaveFormFile(wff);
         } else {
            this.retryCount++;
         }

         if (this.showImageDlg2 != null) {
            this.showImageDlg2.setVisible(false);
         }
      } else {
         InputStream is = ba.getInputStream();
         if (is == null) {
            return false;
         }

         ImageData id = new ImageData(is);
         Image image = new Image(this.platform.getDisplay(), id);
         if (this.showImageDlg2 == null) {
            this.showImageDlg2 = new ShowImageDialog2(this.platform.getShell(), image);
            this.showImageDlg2.open();
         } else if (!this.showImageDlg2.isDispose()) {
            this.showImageDlg2.setVisible(true);
            this.showImageDlg2.changeImage(image);
         }

         try {
            is.close();
         } catch (IOException var8) {
            var8.printStackTrace();
         }

         ba.dispose();
      }

      return true;
   }

   protected boolean handleReceive() {
      String ext = this.rcomm.getFileType();
      return this.fpool != null ? this.autoSave(ext) : this.simpleLoad(ext);
   }

   public FilePool getFilePool() {
      return this.fpool;
   }

   class ImportRunner implements Runnable {
      private WaveFormFile wff;
      private File f;

      public void setWaveFormFile(WaveFormFile wff) {
         this.wff = wff;
         RapidLoop.this.platform.getDisplay().asyncExec(this);
      }

      public void setFile(File f) {
         this.f = f;
         RapidLoop.this.platform.getDisplay().asyncExec(this);
      }

      @Override
      public void run() {
         MainFrame mf = RapidLoop.this.platform.getMainFrame();
         if (!mf.getShell().isDisposed()) {
            if (this.wff != null) {
               mf.setWaveFormFile(this.wff);
               this.wff = null;
            }

            if (this.f != null) {
               mf.getStatusLine().setPath(this.f.getPath());
               this.f = null;
            }
         }
      }
   }

   class RenableRunner implements Runnable {
      public void reenable() {
         RapidLoop.this.platform.getDisplay().asyncExec(this);
      }

      @Override
      public void run() {
         MainFrame mf = RapidLoop.this.platform.getMainFrame();
         if (!mf.getShell().isDisposed()) {
            mf.setCommItemsStatus(true);
         }

         RapidLoop.this.iclp.finish();
      }
   }
}
