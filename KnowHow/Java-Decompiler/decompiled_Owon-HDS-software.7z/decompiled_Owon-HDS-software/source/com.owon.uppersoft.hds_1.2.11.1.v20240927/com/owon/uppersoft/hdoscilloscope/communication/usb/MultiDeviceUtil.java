package com.owon.uppersoft.hdoscilloscope.communication.usb;

import ch.ntb.usb.LibusbJava;
import ch.ntb.usb.USBException;
import ch.ntb.usb.Usb_Device;
import ch.ntb.usb.Usb_Device_Descriptor;

public class MultiDeviceUtil {
   public void test() {
      try {
         for (IDevice id : CDevice.scanMatchedDevices((short)21317, (short)4660)) {
            Usb_Device dev = id.getUsb_Device();
            long handle = LibusbJava.usb_open(dev);
            Usb_Device_Descriptor devDesc = dev.getDescriptor();
            String iProduct = LibusbJava.usb_get_string_simple(handle, devDesc.getIProduct());
            String iManufacturer = LibusbJava.usb_get_string_simple(handle, devDesc.getIManufacturer());
            String iSerialNumber = LibusbJava.usb_get_string_simple(handle, devDesc.getISerialNumber());
            String Devnum = LibusbJava.usb_get_string_simple(handle, dev.getDevnum());
            String msg = String.format("iProduct: %s; iManufacturer: %s; iSerialNumber: %s; Devnum: %s,", iProduct, iManufacturer, iSerialNumber, Devnum);
            System.out.printf(msg);
            LibusbJava.usb_close(handle);
         }
      } catch (USBException var13) {
         var13.printStackTrace();
      } catch (Throwable var14) {
         var14.printStackTrace();
      }
   }

   public void doConnect() {
      try {
         for (IDevice id : CDevice.scanMatchedDevices((short)21317, (short)4660)) {
            CDevice device = CDevice.getDevice((short)21317, (short)4660);
            CDevice.simulateOpen(device, id);
            device.close();
         }
      } catch (USBException var5) {
         var5.printStackTrace();
      } catch (Throwable var6) {
         var6.printStackTrace();
      }
   }

   public static void main(String[] args) {
      MultiDeviceUtil mdu = new MultiDeviceUtil();
      mdu.test();
   }
}
