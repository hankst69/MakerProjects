package com.owon.uppersoft.hdoscilloscope.data.normal;

import com.owon.uppersoft.hdoscilloscope.chart.model.AlphaWaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.pref.WFReg;

public class DefaultAlphaWFC extends AlphaWaveFormCurve {
   public DefaultAlphaWFC(WaveForm wf, WaveFormFileCurve fileCurve, WFReg wfreg) {
      super(wf, fileCurve, wfreg);
   }
}
