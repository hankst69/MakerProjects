package com.owon.uppersoft.hdoscilloscope.chart.model.fft;

import com.owon.uppersoft.common.utils.StringPool;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.model.Dbl_Txt;
import com.owon.uppersoft.hdoscilloscope.model.PublicM;
import com.owon.uppersoft.hdoscilloscope.util.DBG;
import java.util.Collection;
import java.util.List;

public class FFTInfo {
   public static String[] db_rms_txts = new String[]{"Vrms", "dB"};
   public static int[] dBbases = new int[]{20, 10, 5, 2, 1};
   public static int[] probeRates = new int[]{1, 10, 100, 1000};
   public static int[] zoomRates = new int[]{1, 2, 5, 10};
   public static WndType[] wndTypes = WndType.values();
   public static final int Normal = 2;
   public static final int DBType = 1;
   public static final int VrmsType = 0;
   private boolean protofft = false;
   private int dB_Vrms = 1;
   public int loc0 = 0;
   public int zoomRateIdx = 0;
   private int wndTypeIdx = 0;
   public int dbbaseidx = 0;
   public int posOffset = 0;
   private int freqidx = -1;
   private double maxfreq;
   private double maxfreqpercent;
   public WaveForm wf;
   private boolean wfreturnable;
   private List<? extends Object> tbrftxts;

   public double getMaxfreqPercent() {
      return this.maxfreqpercent;
   }

   public boolean isProtoFFT() {
      return this.protofft;
   }

   public void setProtoFFT(boolean b) {
      this.protofft = b;
   }

   public int getfreqIdx() {
      return this.freqidx;
   }

   public FFTInfo(WaveForm wf) {
      this.wf = wf;
   }

   public void endAndCompute(WaveForm wf) {
      if (this.isProtoFFT()) {
         wf.addArg("Center.zoom", "Ⅹ" + this.getZoomRate());
      }

      PublicM pm = wf.getPublicM();
      WaveFormFile wff = wf.getWaveFormFile();
      int tbidx = wf.getIntTimeBase();
      double xgnum = wff.getXGraticuleNum();
      if (Math.abs(xgnum - 15.2) < 0.001) {
         this.posOffset = (int)((double)this.posOffset - 2.6 * (double)wff.getXBlockPixels());
      }

      if (this.isProtoFFT()) {
         List<TimeBaseRef> tbrftxts = pm.getTimeBaseRefs();
         this.tbrftxts = tbrftxts;
         this.freqidx = tbidx;
         this.maxfreq = tbrftxts.get(this.freqidx).getProtofreqPP() * 10.0;
         this.maxfreqpercent = 10.0 / xgnum;
      } else {
         this.tbrftxts = PublicM.getFreqtxts();
         this.maxfreq = this.getFreqBetweenSamplePoints(pm, tbidx, xgnum);
         double freqbase = this.maxfreq / xgnum;
         DBG.dbgln("maxfreqbase: " + freqbase);
         List<Dbl_Txt> freqs = PublicM.getFreqtxts();
         FFTInfo.DBLObject fo = new FFTInfo.DBLObject();
         this.freqidx = this.getFreqIndex(freqs, freqbase, fo);
         this.maxfreqpercent = freqbase / fo.v;
         DBG.dbgln("fo.v:" + fo.v);
         DBG.dbgln("maxfreqpercent:" + this.maxfreqpercent);
      }
   }

   private int getFreqIndex(List<Dbl_Txt> freqs, double maxfreqbase, FFTInfo.DBLObject fo) {
      int len = freqs.size();
      int freqidx = 0;
      double v = 0.0;

      for (int i = len - 1; i >= 0; i--) {
         v = freqs.get(i).v();
         if (maxfreqbase <= v) {
            freqidx = i;
            fo.v = v;
            DBG.dbgln("freqidx: " + i);
            break;
         }
      }

      fo.v = freqs.get(freqidx).v();
      return freqidx;
   }

   private double getFreqBetweenSamplePoints(PublicM pm, int tbidx, double xgnum) {
      int fnum = this.wf.getIntFullScreenDataNum();
      double dbtb = pm.getTimeBaseValue_mS(tbidx);
      double maxfreq = (double)fnum / (dbtb * xgnum / 1000.0) / 2.0;
      if (fnum < 2048) {
         maxfreq *= 2048.0 / (double)Integer.highestOneBit(fnum);
         DBG.dbgln("fnum < IFFTRef.LENGTH");
      }

      DBG.dbgln("fnum: " + fnum);
      DBG.dbgln("chHs: " + dbtb);
      DBG.dbgln("maxfreq: " + maxfreq);
      return maxfreq;
   }

   public boolean isWfreturnable() {
      return this.wfreturnable;
   }

   public Collection<? extends Object> tb_collect() {
      return this.tbrftxts;
   }

   public String getFreqTxt(int zoomRate, int idx) {
      Object o = this.tbrftxts.get(idx);
      if (this.isProtoFFT()) {
         TimeBaseRef rbr = (TimeBaseRef)o;
         return rbr.zoomFreqBase(zoomRate);
      } else {
         return o.toString();
      }
   }

   public double getFreq(int idx) {
      return this.isProtoFFT() ? this.wf.getPublicM().getTimeBaseRefs().get(idx).getProtofreqPP() : PublicM.getFreqtxts().get(idx).v();
   }

   public int getDBBase() {
      return dBbases[this.dbbaseidx];
   }

   public int getZoomRate() {
      return zoomRates[this.zoomRateIdx];
   }

   public WndType getWndType() {
      return wndTypes[this.wndTypeIdx];
   }

   public void setIntTimeBase(int intTimeBase) {
      WaveFormFile wff = this.wf.getWaveFormFile();
      this.wf.setIntTimeBase(intTimeBase);
      PublicM pm = this.wf.getPublicM();
      double dbtb = pm.getTimeBaseValue_mS(intTimeBase);
      this.wf.setDblTimeInterval(dbtb / (double)wff.getXBlockPixels());
      int fnum = (int)(this.getFreq(intTimeBase) * 10.0 * 2.0 * dbtb / 1000.0 * wff.getXGraticuleNum());
      DBG.dbgln("fnum: " + fnum);
      this.wf.setIntFullScreenDataNum(fnum);
   }

   public void setDblVoltagePerPoint(double dblBasicVoltage) {
      this.wf.setDblVoltagePerPoint(dblBasicVoltage);
      this.wf.getWaveFormFile().getyBlockPixels();
   }

   @Override
   public String toString() {
      String n = StringPool.LINE_SEPARATOR;
      StringBuilder sb = new StringBuilder(super.toString());
      sb.append(this.dB_Vrms + " dB_Vrms: " + (this.dB_Vrms == 1 ? "dB" : "Vrms"));
      sb.append(n);
      sb.append(this.dbbaseidx + " dBbases: " + dBbases[this.dbbaseidx]);
      sb.append(n);
      sb.append(" zoomRates[" + this.zoomRateIdx + "]: " + zoomRates[this.zoomRateIdx]);
      sb.append(n);
      sb.append(this.loc0 + " loc0: " + this.loc0);
      sb.append(n);
      sb.append(this.wndTypeIdx + " wndTypes: " + wndTypes[this.wndTypeIdx]);
      sb.append(n);
      return sb.toString();
   }

   public int getDB_Vrms() {
      return this.dB_Vrms;
   }

   public void setDB_Vrms(int vrms) {
      this.dB_Vrms = vrms;
   }

   public int getWndTypeIdx() {
      return this.wndTypeIdx;
   }

   public void setWndTypeIdx(int idx) {
      this.wndTypeIdx = idx & 3;
   }

   class DBLObject {
      double v;
   }
}
