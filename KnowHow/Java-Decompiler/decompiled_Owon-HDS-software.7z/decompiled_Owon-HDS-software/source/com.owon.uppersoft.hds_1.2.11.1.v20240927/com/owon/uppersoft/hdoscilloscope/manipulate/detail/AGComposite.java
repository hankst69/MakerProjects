package com.owon.uppersoft.hdoscilloscope.manipulate.detail;

import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.hdoscilloscope.manipulate.ManipulateControl;
import java.util.ResourceBundle;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;

public class AGComposite extends Composite implements Localizable2, Listener, IPref {
   private ManipulateControl mc;
   private Button btnSine;
   private Button btnSquare;
   private Button btnRamp;
   private Button btnPulse;
   private Button btnArb;
   private Button[] btnWave;
   private Label lbTime;
   private Button btnCh1Sw;
   private Button btnCh2Sw;
   private Combo cobTime;
   private Label lbFreq;
   private Combo cobFreq;
   private Label lbAmp;
   private Label lbOffset;
   private Combo cobAmp;
   private Combo cobOffset;
   private Cspinner spOffset;
   private Cspinner spAmp;
   private Cspinner spFreq;
   private Label lbDute;
   private Cspinner spDute;
   private Cspinner spTime;
   private Combo cobDute;
   private int selectedWave;
   private boolean changeFreq;
   private boolean changeAmp;
   private boolean changeDute;
   private boolean changeTime;
   private ResourceBundle rb;

   public AGComposite(Composite parent, final ManipulateControl mc) {
      super(parent, 0);
      this.mc = mc;
      GridLayout gridLayout = new GridLayout();
      gridLayout.marginWidth = 10;
      gridLayout.marginHeight = 10;
      this.setLayout(gridLayout);
      Group group = new Group(this, 0);
      group.setLayout(new RowLayout(256));
      group.setLayoutData(new GridData(4, 16777216, true, false, 1, 1));
      this.btnSine = new Button(group, 16);
      this.btnSine.setData(":function sine");
      this.btnSquare = new Button(group, 16);
      this.btnSquare.setData(":function square");
      this.btnRamp = new Button(group, 16);
      this.btnRamp.setData(":function ramp");
      this.btnPulse = new Button(group, 16);
      this.btnPulse.setData(":function pulse");
      this.btnArb = new Button(group, 16);
      this.btnArb.setData(":function AmpALT");
      this.btnWave = new Button[]{this.btnSine, this.btnSquare, this.btnRamp, this.btnPulse, this.btnArb};
      Group group_1 = new Group(this, 0);
      group_1.setLayout(new GridLayout(3, false));
      group_1.setLayoutData(new GridData(4, 16777216, true, false, 1, 1));
      this.lbFreq = new Label(group_1, 0);
      GridData gd_lbFreq = new GridData(4, 16777216, false, false, 1, 1);
      gd_lbFreq.widthHint = 60;
      this.lbFreq.setLayoutData(gd_lbFreq);
      this.lbFreq.addMouseListener(new MouseAdapter() {
         public void mouseUp(MouseEvent e) {
            AGComposite.this.changeFreq = !AGComposite.this.changeFreq;
            AGComposite.this.refreshItem();
         }
      });
      this.spFreq = new Cspinner(group_1, 0);
      this.spFreq.setMaximum(10000);
      this.spFreq.setMinimum(1);
      this.spFreq.EnableSign(false);
      this.spFreq.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.cobFreq = new Combo(group_1, 8);
      final String[] freqLimit = new String[]{"25", "5", "1", "5", "5"};
      final String[] periodLimit = new String[]{"40ns", "200ns", "1us", "200ns", "200ns"};
      this.cobFreq.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int index = AGComposite.this.cobFreq.getSelectionIndex();
            double value = AGComposite.this.spFreq.getSelection();
            if (AGComposite.this.changeFreq) {
               value *= Math.pow(1000.0, (double)(index - 3));
               if (AGComposite.this.check(1.0 / value, freqLimit[AGComposite.this.selectedWave])) {
                  mc.send(":function:period " + value);
               } else {
                  mc.alert("Alert.period", new Object[]{periodLimit[AGComposite.this.selectedWave]});
               }
            } else {
               value *= Math.pow(1000.0, (double)(index - 2));
               if (AGComposite.this.check(value, freqLimit[AGComposite.this.selectedWave])) {
                  mc.send(":function:freq " + value);
               } else {
                  mc.alert("Alert.freq", new Object[]{freqLimit[AGComposite.this.selectedWave]});
               }
            }
         }
      });
      this.cobFreq.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.lbAmp = new Label(group_1, 0);
      this.lbAmp.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.lbAmp.addMouseListener(new MouseAdapter() {
         public void mouseUp(MouseEvent e) {
            AGComposite.this.changeAmp = !AGComposite.this.changeAmp;
            AGComposite.this.refreshItem();
         }
      });
      this.spAmp = new Cspinner(group_1, 0);
      this.spAmp.setMaximum(10000);
      this.spAmp.setMinimum(1);
      this.spAmp.EnableSign(false);
      this.spAmp.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.cobAmp = new Combo(group_1, 8);
      this.cobAmp.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int index = AGComposite.this.cobAmp.getSelectionIndex();
            double value = AGComposite.this.spAmp.getSelection();
            if (AGComposite.this.changeAmp) {
               value *= Math.pow(1000.0, (double)(index - 1));
               mc.send(":function:high " + value);
            } else {
               value *= Math.pow(1000.0, (double)(index - 1));
               if (value > 5.0 || value < 0.02) {
                  mc.alert("Alert.amp", null);
                  return;
               }

               mc.send(":function:ampl " + value);
            }
         }
      });
      this.cobAmp.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.lbOffset = new Label(group_1, 0);
      this.lbOffset.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.lbOffset.addMouseListener(new MouseAdapter() {
         public void mouseUp(MouseEvent e) {
            AGComposite.this.changeAmp = !AGComposite.this.changeAmp;
            AGComposite.this.refreshItem();
         }
      });
      this.spOffset = new Cspinner(group_1, 0);
      this.spOffset.setMaximum(10000);
      this.spOffset.setMinimum(0);
      this.spOffset.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.cobOffset = new Combo(group_1, 8);
      this.cobOffset.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int index = AGComposite.this.cobOffset.getSelectionIndex();
            double value = AGComposite.this.spOffset.getSelection();
            if (AGComposite.this.changeAmp) {
               value *= Math.pow(1000.0, (double)(index - 1));
               mc.send(":function:low " + value);
            } else {
               value *= Math.pow(1000.0, (double)(index - 1));
               mc.send(":function:offset " + value);
            }
         }
      });
      this.cobOffset.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.spOffset.EnableSign(true);
      this.lbDute = new Label(group_1, 0);
      this.lbDute.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.lbDute.addMouseListener(new MouseAdapter() {
         public void mouseUp(MouseEvent e) {
            AGComposite.this.changeDute = !AGComposite.this.changeDute;
            AGComposite.this.refreshItem();
         }
      });
      this.spDute = new Cspinner(group_1, 2048);
      this.spDute.setMaximum(10000);
      this.spDute.setMinimum(0);
      this.spDute.EnableSign(false);
      this.spDute.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.cobDute = new Combo(group_1, 8);
      this.cobDute.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            if (AGComposite.this.selectedWave == 4) {
               mc.send(":function " + AGComposite.this.cobDute.getText());
            } else {
               int index = AGComposite.this.cobDute.getSelectionIndex();
               double value = AGComposite.this.spDute.getSelection();
               if (AGComposite.this.selectedWave == 2) {
                  if (value > 100.0) {
                     mc.alert("Alert.symmetry", null);
                     return;
                  }

                  mc.send(":function:symmetry " + value);
               }

               if (AGComposite.this.selectedWave == 3) {
                  if (AGComposite.this.changeDute) {
                     value *= Math.pow(1000.0, (double)(index - 3));
                     mc.send(":function:WIDTh " + value);
                  } else {
                     if (value > 99.7 || value < 0.2) {
                        mc.alert("Alert.dute", null);
                        return;
                     }

                     mc.send(":function:dtycycle " + value);
                  }
               }
            }
         }
      });
      this.cobDute.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.lbTime = new Label(group_1, 0);
      this.lbTime.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.lbTime.addMouseListener(new MouseAdapter() {
         public void mouseUp(MouseEvent e) {
            AGComposite.this.changeTime = !AGComposite.this.changeTime;
            AGComposite.this.refreshItem();
         }
      });
      this.spTime = new Cspinner(group_1, 2048);
      this.spTime.setMaximum(10000);
      this.spTime.setMinimum(0);
      this.spTime.EnableSign(false);
      this.spTime.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.cobTime = new Combo(group_1, 8);
      this.cobTime.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            int index = AGComposite.this.cobTime.getSelectionIndex();
            double value = AGComposite.this.spTime.getSelection();
            if (AGComposite.this.changeTime) {
               value *= Math.pow(1000.0, (double)(index - 3));
               mc.send(":FUNCtion:RISing " + value);
            } else {
               value *= Math.pow(1000.0, (double)(index - 3));
               mc.send(":FUNCtion:FALing " + value);
            }
         }
      });
      this.cobTime.setLayoutData(new GridData(4, 16777216, false, false, 1, 1));
      this.cobTime.setItems(uTime);
      Group group_2 = new Group(this, 0);
      group_2.setLayout(new GridLayout(4, false));
      group_2.setLayoutData(new GridData(4, 16777216, true, false, 1, 1));
      this.btnCh1Sw = new Button(group_2, 32);
      this.btnCh1Sw.addSelectionListener(new SelectionAdapter() {
         public void widgetSelected(SelectionEvent e) {
            String sw = AGComposite.this.btnCh1Sw.getSelection() ? "ON" : "OFF";
            String s = ":CHANnel " + sw;
            mc.send(s);
         }
      });
      this.btnCh1Sw.setText("Check Button");
      new Label(group_2, 0);
      new Label(group_2, 0);
      new Label(group_2, 0);

      for (int i = 0; i < this.btnWave.length; i++) {
         this.btnWave[i].addListener(13, this);
      }

      this.btnSine.setSelection(true);
      this.lbDute.setVisible(false);
      this.spDute.setVisible(false);
      this.cobDute.setVisible(false);
      this.cobOffset.setItems(uOffset);
      this.cobDute.setItems(uPercent);
      this.lbTime.setVisible(false);
      this.spTime.setVisible(false);
      this.cobTime.setVisible(false);
      this.cobTime.setItems(uTime);
   }

   public void localize(ResourceBundle rb) {
      this.rb = rb;
      this.btnSine.setText(rb.getString("Mp.Sine"));
      this.btnSquare.setText(rb.getString("Mp.Square"));
      this.btnRamp.setText(rb.getString("Mp.Ramp"));
      this.btnPulse.setText(rb.getString("Mp.Pulse"));
      this.btnArb.setText(rb.getString("Mp.Arb"));
      this.btnCh1Sw.setText(rb.getString("Mp.ch1output"));
      this.refreshItem();
   }

   public void handleEvent(Event arg0) {
      Object o = arg0.widget;
      this.mc.send((String)arg0.widget.getData());

      for (int i = 0; i < this.btnWave.length; i++) {
         if (o == this.btnWave[i]) {
            this.selectedWave = i;
         }
      }

      this.lbDute.setVisible(false);
      this.spDute.setVisible(false);
      this.cobDute.setVisible(false);
      this.lbTime.setVisible(false);
      this.spTime.setVisible(false);
      this.cobTime.setVisible(false);
      if (o == this.btnPulse) {
         System.out.println("pulse");
         this.lbDute.setVisible(true);
         this.spDute.setVisible(true);
         this.cobDute.setVisible(true);
         this.lbTime.setVisible(true);
         this.spTime.setVisible(true);
         this.cobTime.setVisible(true);
         this.changeTime = true;
         this.refreshItem();
      } else if (o == this.btnRamp) {
         System.out.println("ramp");
         this.lbDute.setVisible(true);
         this.spDute.setVisible(true);
         this.cobDute.setVisible(true);
         this.changeDute = true;
         this.refreshItem();
      } else if (o == this.btnArb) {
         System.out.println("arb");
         this.lbDute.setVisible(true);
         this.spDute.setVisible(false);
         this.cobDute.setVisible(true);
         this.refreshItem();
      }
   }

   private void refreshItem() {
      if (this.changeFreq) {
         this.lbFreq.setText(this.rb.getString("Mp.period"));
         this.cobFreq.setItems(uTime);
      } else {
         this.lbFreq.setText(this.rb.getString("Mp.frequency"));
         this.cobFreq.setItems(uFreq);
      }

      if (this.changeAmp) {
         this.lbAmp.setText(this.rb.getString("Mp.hlevel"));
         this.lbOffset.setText(this.rb.getString("Mp.llevel"));
         this.cobAmp.setItems(uOffset);
         this.spAmp.EnableSign(true);
      } else {
         this.lbAmp.setText(this.rb.getString("Mp.amplitude"));
         this.lbOffset.setText(this.rb.getString("Mp.offset"));
         this.cobAmp.setItems(uAmp);
         this.spAmp.EnableSign(false);
      }

      if (this.changeDute) {
         this.lbDute.setText(this.rb.getString("Mp.width"));
         this.cobDute.setItems(uTime);
      } else {
         this.lbDute.setText(this.rb.getString("Mp.dtycycle"));
         this.cobDute.setItems(uPercent);
      }

      if (this.selectedWave == 2) {
         this.lbDute.setText(this.rb.getString("Mp.symmetry"));
         this.cobDute.setItems(uPercent);
      }

      if (this.selectedWave == 4) {
         this.lbDute.setText(this.rb.getString("Mp.arbtype"));
         this.cobDute.setItems(uBuiltin);
         this.cobDute.select(0);
      }

      if (this.changeTime) {
         this.lbTime.setText(this.rb.getString("Mp.rising"));
      } else {
         this.lbTime.setText(this.rb.getString("Mp.faling"));
      }
   }

   private boolean check(double value, String freq) {
      double limit = (double)Integer.parseInt(freq) * 1000000.0;
      return value <= limit && value >= 0.1;
   }
}
