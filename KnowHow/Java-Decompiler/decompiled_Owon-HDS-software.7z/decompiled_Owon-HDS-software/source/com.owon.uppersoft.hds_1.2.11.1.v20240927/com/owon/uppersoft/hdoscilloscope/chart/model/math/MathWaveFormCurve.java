package com.owon.uppersoft.hdoscilloscope.chart.model.math;

import com.owon.uppersoft.hdoscilloscope.chart.AbstWFC;
import com.owon.uppersoft.hdoscilloscope.chart.DrawEngine;
import com.owon.uppersoft.hdoscilloscope.chart.ScalableDrawEngine;
import com.owon.uppersoft.hdoscilloscope.chart.model.ILowMovable;
import com.owon.uppersoft.hdoscilloscope.chart.model.LowMoveChecker;
import com.owon.uppersoft.hdoscilloscope.chart.model.WaveFormFileCurve;
import com.owon.uppersoft.hdoscilloscope.data.TxtEntry;
import com.owon.uppersoft.hdoscilloscope.data.WaveForm;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.model.WaveFormCurve;
import com.owon.uppersoft.hdoscilloscope.pref.MathReg;
import com.owon.uppersoft.hdoscilloscope.pref.PropertiesItem;
import java.util.Collection;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Menu;

public class MathWaveFormCurve extends AbstWFC implements ILowMovable {
   private int type = -1;
   private String name;
   private int[] results;
   private WaveForm wf1;
   private WaveForm wf2;
   private DrawEngine dren;
   private MathReg wfreg;
   private String factor1;
   private String factor2;
   private LowMoveChecker lmc;
   private double x0;
   private double y0;
   private double xpp;
   private double ypp;

   public MathWaveFormCurve(WaveFormFileCurve wffc, MathReg wfreg) {
      super(wffc, wfreg);
      this.wfreg = wfreg;
      this.lmc = new LowMoveChecker(wffc.getWaveFormFile().getWaveForm("CH1"));
      this.lmc.patchLowMove();
      this.wf1 = wffc.getWaveFormFile().getWaveForm("CH1");
      this.wf2 = wffc.getWaveFormFile().getWaveForm("CH2");
      this.factor1 = "CH1";
      this.factor2 = "CH2";
      this.dren = this.createDrawEngine(wffc, this);
      this.changeType(wfreg.mt);
   }

   @Override
   public ScalableDrawEngine getScalableDrawEngine() {
      return this.dren;
   }

   @Override
   public LowMoveChecker getLowMoveChecker() {
      return this.lmc;
   }

   @Override
   public int getCurveType() {
      return 3;
   }

   @Override
   public boolean isChannel() {
      return false;
   }

   public int getType() {
      return this.type;
   }

   public String getFactor1() {
      return this.factor1;
   }

   public String getFactor2() {
      return this.factor2;
   }

   public void datasUpdate() {
      this.rangeResults();
      this.dren.datasUpdate();
   }

   protected void rangeResults() {
      int len = this.wf1.getIntADCollectionNum();
      int[] a = this.wf1.getIntADCollection();
      int[] b = this.wf2.getIntADCollection();
      len = a.length;
      if (this.results == null || this.results.length < len) {
         this.results = new int[len];
      }

      switch (this.type) {
         case 0:
            for (int ixx = 0; ixx < len; ixx++) {
               this.results[ixx] = a[ixx] + b[ixx];
            }
            break;
         case 1:
            for (int ixx = 0; ixx < len; ixx++) {
               this.results[ixx] = a[ixx] - b[ixx];
            }
            break;
         case 2:
            for (int ixx = 0; ixx < len; ixx++) {
               this.results[ixx] = b[ixx] - a[ixx];
            }
            break;
         case 3:
            for (int ixx = 0; ixx < len; ixx++) {
               this.results[ixx] = a[ixx] * b[ixx];
            }
            break;
         case 4:
            for (int ix = 0; ix < len; ix++) {
               if (b[ix] != 0 && a[ix] != 0) {
                  this.results[ix] = a[ix] / b[ix];
               } else {
                  this.results[ix] = 0;
               }
            }
            break;
         case 5:
            for (int i = 0; i < len; i++) {
               if (b[i] != 0 && a[i] != 0) {
                  this.results[i] = b[i] / a[i];
               } else {
                  this.results[i] = 0;
               }
            }
            break;
         case 6:
            for (int i = 0; i < len; i++) {
               this.results[i] = a[i] * a[i];
            }
            break;
         case 7:
            for (int i = 0; i < len; i++) {
               this.results[i] = b[i] * b[i];
            }
            break;
         case 8:
            double d = this.wf1.getDblTimeInterval();
            this.results[0] = 0;

            for (int i = 1; i < len; i++) {
               this.results[i] = this.results[i - 1] + (int)((double)a[i] * d / 20.0);
            }
            break;
         case 9:
            double d = this.wf1.getDblTimeInterval();
            this.results[0] = 0;

            for (int i = 1; i < len; i++) {
               this.results[i] = (int)((double)(a[i] - a[i - 1]) / d);
            }
            break;
         case 10:
            for (int i = 0; i < len; i++) {
               this.results[i] = (int)Math.sqrt((double)a[i]);
            }
            break;
         case 11:
            double d = this.wf2.getDblTimeInterval();
            this.results[0] = 0;

            for (int i = 1; i < len; i++) {
               this.results[i] = this.results[i - 1] + (int)((double)b[i] * d / 20.0);
            }
            break;
         case 12:
            double d = this.wf2.getDblTimeInterval();
            this.results[0] = 0;

            for (int i = 1; i < len; i++) {
               this.results[i] = (int)((double)(b[i] - b[i - 1]) / d);
            }
            break;
         case 13:
            for (int i = 0; i < len; i++) {
               this.results[i] = (int)Math.sqrt((double)b[i]);
            }
      }
   }

   public boolean changeType(int type) {
      if (this.type == type) {
         return false;
      } else {
         this.type = type;
         this.name = IMath.math_types[type];
         this.rangeResults();
         Point size = this.dren.getSize();
         this.x0 = 0.0;
         this.y0 = (double)(size.y >> 1);
         this.xpp = (double)size.x / (double)this.results.length;
         this.ypp = (double)size.y / (double)this.wf1.getWaveFormFile().getYPointNum();
         this.setBlockNum(40);
         this.dren.initPts(this.results, 0, this.results.length, this.x0, this.y0, this.xpp, this.ypp);
         this.getWFReg().mt = type;
         return true;
      }
   }

   public MathReg getWFReg() {
      return this.wfreg;
   }

   @Override
   public int baseIdxOnX() {
      return 0;
   }

   @Override
   public int baseIdxOnY() {
      return 0;
   }

   @Override
   public Collection<? extends Object> xb_collect() {
      return PropertiesItem.StickStringList;
   }

   @Override
   public Collection<? extends Object> yb_collect() {
      return PropertiesItem.StickStringList;
   }

   @Override
   public void controlResize(Point lastsize, Point size) {
      this.getScalableDrawEngine().resizeTo(lastsize, size);
   }

   @Override
   public Collection<TxtEntry> txts_coll() {
      return PropertiesItem.EmptyTxtEntryArray;
   }

   @Override
   public String getStrChannelType() {
      return "math";
   }

   @Override
   public WaveForm getWaveForm() {
      return null;
   }

   @Override
   public String getXBaseTxt() {
      return this.name;
   }

   @Override
   public String getYBaseTxt() {
      return "";
   }

   @Override
   public int rateAtX() {
      return 1;
   }

   @Override
   public double rateAtY() {
      return 1.0;
   }

   @Override
   public void setBaseIdxOnX(int idx) {
   }

   @Override
   public void setBaseIdxOnY(int idx) {
   }

   @Override
   public String unitForX(double x) {
      return "-";
   }

   @Override
   public String unitForY(double y) {
      return "-";
   }

   @Override
   public double valueAtX(double x) {
      return 0.0;
   }

   @Override
   public double valueAtY(double y) {
      return 0.0;
   }

   @Override
   public boolean equals(WaveFormCurve wfc) {
      return this == wfc;
   }

   @Override
   public void applyToolComposite() {
      Platform.getPlatform().getCenter().getToolCom().applyMathWFC(this);
   }

   @Override
   public Menu getToolMenu() {
      return Platform.getPlatform().getCenter().applyMathWFC(this);
   }
}
