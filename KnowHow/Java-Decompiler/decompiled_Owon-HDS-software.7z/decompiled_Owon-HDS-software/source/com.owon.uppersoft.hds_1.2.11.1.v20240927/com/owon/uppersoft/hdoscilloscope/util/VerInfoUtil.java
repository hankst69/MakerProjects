package com.owon.uppersoft.hdoscilloscope.util;

import com.owon.uppersoft.common.utils.VersionUtil;

public class VerInfoUtil {
   public static void main(String[] args) {
   }

   public static VersionUtil getVersionUtil() {
      String path = VerInfoUtil.class.getProtectionDomain().getCodeSource().getLocation().getPath();
      String info = null;

      try {
         info = path.substring(path.lastIndexOf("/") + 1, path.lastIndexOf("."));
      } catch (StringIndexOutOfBoundsException var2) {
      }

      return new VersionUtil(info);
   }
}
