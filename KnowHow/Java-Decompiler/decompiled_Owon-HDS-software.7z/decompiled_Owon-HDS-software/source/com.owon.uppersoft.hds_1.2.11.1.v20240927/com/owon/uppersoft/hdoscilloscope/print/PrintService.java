package com.owon.uppersoft.hdoscilloscope.print;

import com.owon.uppersoft.common.aspect.Disposable;
import com.owon.uppersoft.common.aspect.Localizable2;
import com.owon.uppersoft.common.utils.DisposeUtil;
import com.owon.uppersoft.hdoscilloscope.data.WaveFormFile;
import com.owon.uppersoft.hdoscilloscope.global.Platform;
import com.owon.uppersoft.hdoscilloscope.i18n.ResourceBundleProvider;
import java.util.ResourceBundle;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.graphics.Transform;
import org.eclipse.swt.printing.PrintDialog;
import org.eclipse.swt.printing.Printer;
import org.eclipse.swt.printing.PrinterData;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class PrintService implements Disposable, Localizable2 {
   public static final double mmPerInch = 25.4;
   public static final double inchPerMM = 0.03937007874015748;
   public static final int A4PaperXPixels = 2480;
   public static final int A4PaperYPixels = 3508;
   public static final int A4PaperBorderTrim = 75;
   public static final int DefaultPrinterDPI = 300;
   public static final int A4PaperClientXPixels = 2330;
   public static final int A4PaperClientYPixels = 3358;
   private DrawJob drawJob;
   private Rectangle customizeTrim;
   private int A4EdgeSpace;
   private int A4PageWidth;
   private int A4PageHeight;
   private PrintPreview printPreview;
   private Color paperBG;
   private Display display;
   private Transform transform;

   public RGB getPaperBackgroundRGB() {
      return this.paperBG.getRGB();
   }

   public Color getPaperBackground() {
      return this.paperBG;
   }

   public void setPaperBackgroundRGB(RGB rgb) {
      DisposeUtil.tryDispose(this.paperBG);
      this.paperBG = new Color(this.display, rgb);
   }

   protected int getA4EdgeSpace() {
      return this.A4EdgeSpace;
   }

   public int getA4PageWidth() {
      return this.A4PageWidth;
   }

   public int getA4PageHeight() {
      return this.A4PageHeight;
   }

   public void setCustomizeTrim(Rectangle customizeTrim) {
      this.customizeTrim = customizeTrim;
   }

   public Rectangle getCustomizeTrim() {
      return this.customizeTrim;
   }

   public DrawJob getDrawJob() {
      if (this.drawJob == null) {
         this.drawJob = new DrawJob(this, this.display);
      }

      return this.drawJob;
   }

   public PrintService(Display display) {
      this.display = display;
      this.paperBG = display.getSystemColor(1);
      double dpiScale = (double)display.getDPI().x / 300.0;
      this.A4EdgeSpace = (int)(75.0 * dpiScale);
      this.A4PageWidth = (int)(2480.0 * dpiScale);
      this.A4PageHeight = (int)(3508.0 * dpiScale);
      int mmSpace = 6;
      int var5 = 20;
      this.customizeTrim = new Rectangle(var5, var5, var5, var5);
   }

   public void printPreviewProcedure(Shell shell) {
      this.getDrawJob();
      if (this.printPreview != null && !this.printPreview.getShell().isDisposed()) {
         this.printPreview.getShell().setActive();
      } else {
         this.printPreview = new PrintPreview(this, this.display);
         this.printPreview.open();
         this.printPreview = null;
      }
   }

   public void localize(ResourceBundle bundle) {
      if (this.printPreview != null) {
         this.printPreview.localize(bundle);
      }

      if (this.drawJob != null) {
         this.drawJob.localize(bundle);
      }
   }

   public void doPrintPreview(GC gc, Rectangle customizeTrim, double scale, int type) {
      Rectangle pixelTrim = pageSetupToDevice(this.display, customizeTrim, 0.03937007874015748);
      this.customizeTrim = customizeTrim;
      if (pixelTrim.x < this.A4EdgeSpace) {
         pixelTrim.x = this.A4EdgeSpace;
      }

      if (pixelTrim.y < this.A4EdgeSpace) {
         pixelTrim.y = this.A4EdgeSpace;
      }

      if (pixelTrim.width < this.A4EdgeSpace) {
         pixelTrim.width = this.A4EdgeSpace;
      }

      if (pixelTrim.height < this.A4EdgeSpace) {
         pixelTrim.height = this.A4EdgeSpace;
      }

      Rectangle clientRect = new Rectangle(0, 0, 0, 0);
      clientRect.x = pixelTrim.x;
      clientRect.y = pixelTrim.y;
      clientRect.width = this.A4PageWidth - pixelTrim.x - pixelTrim.width;
      clientRect.height = this.A4PageHeight - pixelTrim.y - pixelTrim.height;
      if (this.transform == null) {
         this.transform = new Transform(this.display);
      }

      resetTransform(this.transform);
      this.transform.scale((float)scale, (float)scale);
      gc.setTransform(this.transform);
      gc.setBackground(this.paperBG);
      gc.fillRectangle(0, 0, this.A4PageWidth, this.A4PageHeight);
      gc.setForeground(this.display.getSystemColor(15));
      gc.setLineStyle(2);
      gc.drawRectangle(clientRect.x, clientRect.y, clientRect.width, clientRect.height);
      gc.setLineStyle(1);
      this.transform.translate((float)clientRect.x, (float)clientRect.y);
      gc.setTransform(this.transform);
      this.drawJob.forceUpdatePrintMode(type);
      this.drawJob.draw(gc, this.transform, clientRect);
   }

   public void printProcedure(Shell shell) {
      this.getDrawJob();
      ResourceBundle bundle = ResourceBundleProvider.getMessageLibResourceBundle();
      MessageDialog dialog = new MessageDialog(
         Platform.getPlatform().getShell(),
         bundle.getString("Info.Default"),
         null,
         bundle.getString("Info.IfPrintBG"),
         3,
         new String[]{bundle.getString("Options.No"), bundle.getString("Options.Yes"), bundle.getString("Options.Cancel")},
         0
      );
      int flag = dialog.open();
      if (flag != 2 && flag >= 0) {
         PrintDialog pd = new PrintDialog(shell);
         PrinterData pdata = pd.open();
         if (pdata != null) {
            Printer printer = new Printer(pdata);
            GC gc = new GC(printer);
            WaveFormFile wff = Platform.getPlatform().getDrawingPanel().getWaveFormFileCurve().getWaveFormFile();
            String jobName = "Default Print Job";
            if (wff != null && !wff.isRaw()) {
               jobName = wff.getOrginalFile().getPath();
            }

            if (printer.startJob(jobName)) {
               Rectangle pixelTrim = pageSetupToDevice(printer, this.customizeTrim, 0.03937007874015748);
               Rectangle trim = printer.computeTrim(0, 0, 0, 0);
               Rectangle client = printer.getClientArea();
               int left = trim.x + pixelTrim.x;
               if (left < client.x) {
                  left = client.x;
               }

               int right = client.width + trim.width + trim.x - pixelTrim.width;
               if (right > client.width) {
                  right = client.width;
               }

               int top = trim.y + pixelTrim.y;
               if (top < client.y) {
                  top = client.y;
               }

               int bottom = client.height + trim.height + trim.y - pixelTrim.height;
               if (bottom > client.height) {
                  bottom = client.height;
               }

               Rectangle clientRect = new Rectangle(left, top, right - left, bottom - top);
               if (this.transform == null) {
                  this.transform = new Transform(this.display);
               }

               resetTransform(this.transform);
               Point screenDPI = this.display.getDPI();
               Point printerDPI = printer.getDPI();
               double scale = (double)printerDPI.x / (double)screenDPI.x;
               this.transform.translate((float)clientRect.x, (float)clientRect.y);
               this.transform.scale((float)scale, (float)scale);
               gc.setTransform(this.transform);
               clientRect.x = (int)((double)clientRect.x / scale);
               clientRect.y = (int)((double)clientRect.y / scale);
               clientRect.width = (int)((double)clientRect.width / scale);
               clientRect.height = (int)((double)clientRect.height / scale);
               Color temp = this.paperBG;
               this.paperBG = shell.getDisplay().getSystemColor(1);
               this.drawJob.forceUpdatePrintMode(flag);
               this.drawJob.draw(gc, this.transform, clientRect);
               this.paperBG = temp;
               printer.endJob();
            }

            gc.dispose();
            printer.dispose();
         }
      }
   }

   public void dispose() {
      if (this.printPreview != null && !this.printPreview.getShell().isDisposed()) {
         this.printPreview.getShell().close();
      }

      if (this.drawJob != null) {
         this.drawJob.dispose();
      }

      DisposeUtil.tryDispose(this.paperBG);
      DisposeUtil.tryDispose(this.transform);
   }

   public static final void resetTransform(Transform transform) {
      transform.setElements(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
   }

   public static final Rectangle pageSetupToDevice(Device dev, Rectangle trim, double toInch) {
      Point screenDPI = dev.getDPI();
      int dpi = screenDPI.x;
      Rectangle pixelTrim = new Rectangle(0, 0, 0, 0);
      pixelTrim.x = (int)((double)trim.x * toInch * (double)dpi);
      pixelTrim.y = (int)((double)trim.y * toInch * (double)dpi);
      pixelTrim.width = (int)((double)trim.width * toInch * (double)dpi);
      pixelTrim.height = (int)((double)trim.height * toInch * (double)dpi);
      return pixelTrim;
   }
}
