package ch.ntb.inf.libusb.ctest;

public class LibusbJavaHandling {

	public static void main(){
		
	}
}
