package ch.ntb.inf.libusb.test.junit.mpc555Bdi;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ 
				DescriptorTest.class, 
				Mpc555BdiDeviceTest.class })

public class AllMpc555BdiTests {

}
