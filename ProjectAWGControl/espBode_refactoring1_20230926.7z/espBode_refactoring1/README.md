# espBode
Interface between a Siglent oscilloscope and FY6800, FY6900 or JDS2800 AWG

The idea bases on solution proposed by 4x1md in https://github.com/4x1md/sds1004x_bode

Currently implemented features:
 - ESP is able to connect to a selected WiFi network and listen to oscilloscope requests
 - After ESP sends request to AWG it waits for confirmation

TODO:
 - rewrite whole thing to C++, so adding new AWGs would be easier
 - add possibility to configure SSID/PSK + IP without flashing the new SW

Known issues:
 - some users report UART connection problems via the FY6900 AWG TTL

   see: [eevblog Bode plot with a non-Siglent AWG msg3580066](https://www.eevblog.com/forum/testgear/siglent-sds1104x-e-and-sds1204x-e-bode-plot-with-non-siglent-awg/msg3580066/#msg3580066)
 
 - there semm to be incompatibilities with either the new Arduino ESP8266 board libraries (3.x) which lead to blocking TCP/IP communication

   solution is to downgrade the board library to 2.7.4
   
   maybe this relates only to the older ESP001 board but not to the ESP001S
   
   see: [eevblog Bode plot with a non-Siglent AWG msg3933608](https://www.eevblog.com/forum/testgear/siglent-sds1104x-e-and-sds1204x-e-bode-plot-with-non-siglent-awg/msg3933608/#msg3933608)

   see: [eevblog Bode plot with a non-Siglent AWG msg4132834](https://www.eevblog.com/forum/testgear/siglent-sds1104x-e-and-sds1204x-e-bode-plot-with-non-siglent-awg/msg4132834/?PHPSESSID=p0v329ju951nur8mkqmoq9ps18#msg4132834)

Currently supported AWG's:
 - FY6800
 - FY6900
 - JDS2800

You can view a video with the SDS-1204X-E and the FY6900 here https://www.youtube.com/watch?v=3_4DelT9P2A

**!WARNING! FY6800 VCC level is 5V, so it has to be dropped somehow to 3.3V ESP may release the magic smoke otherwise.**

![image test](img/connection.png)

In my configuration I've just used a yellow LED, that dropped the voltage by ~2V.
ESP consumes about 70mA, that's probably too much for a LED, but maybe it'll survive.

![image LED](img/espLed.jpg)
